# Changelog

## 2026.1.30

### Changes

- Version alignment with core OpenClaw release numbers.

## 2026.1.29

### Changes

- Version alignment with core OpenClaw release numbers.

## 2026.1.23

### Changes

- Version alignment with core OpenClaw release numbers.

## 2026.1.22

### Changes

- Version alignment with core OpenClaw release numbers.

## 2026.1.21

### Changes

- Version alignment with core OpenClaw release numbers.

## 2026.1.20

### Changes

- Version alignment with core OpenClaw release numbers.

## 2026.1.17-1

- Initial version with full channel plugin support
- QR code login via zca-cli
- Multi-account support
- Agent tool for sending messages
- Group and DM policy support
- ChannelDock for lightweight shared metadata
- Zod-based config schema validation
- Setup adapter for programmatic configuration
- Dedicated probe and status issues modules

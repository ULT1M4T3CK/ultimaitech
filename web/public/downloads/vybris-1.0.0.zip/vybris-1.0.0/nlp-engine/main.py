"""
NLP Engine Microservice for VYBR!S
Provides query preprocessing, intent detection, and sentiment analysis.

This service can work standalone for simple NLP tasks or forward 
complex requests to the main backend RAG pipeline.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import re
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="VYBR!S NLP Engine", version="2.0.0")


class TextRequest(BaseModel):
    text: str
    client_id: str
    context: Optional[Dict[str, Any]] = None


class ProcessedText(BaseModel):
    original: str
    normalized: str
    intent: str
    intent_confidence: float
    entities: List[Dict[str, str]]
    sentiment: str
    sentiment_score: float
    language: str


# Intent patterns for detection
INTENT_PATTERNS = {
    'greeting': [r'\b(hi|hello|hey|good morning|good afternoon|good evening|howdy)\b'],
    'farewell': [r'\b(bye|goodbye|see you|later|take care|thanks)\b'],
    'question': [r'\b(what|where|when|who|why|how|which|can you|could you|do you)\b', r'\?$'],
    'pricing': [r'\b(price|cost|pricing|how much|fee|charge|subscription|plan)\b'],
    'support': [r'\b(help|support|issue|problem|error|bug|not working|broken|fix)\b'],
    'contact': [r'\b(contact|email|phone|call|reach|speak to|talk to)\b'],
    'about': [r'\b(about|company|who are you|what are you|tell me about|info|information)\b'],
    'order': [r'\b(order|purchase|buy|checkout|cart|shipping|delivery|track)\b'],
    'account': [r'\b(account|login|password|register|sign up|profile|settings)\b'],
    'refund': [r'\b(refund|return|cancel|money back|exchange)\b'],
}

# Sentiment patterns
POSITIVE_PATTERNS = [r'\b(great|good|excellent|amazing|wonderful|love|thank|appreciate|helpful|best)\b']
NEGATIVE_PATTERNS = [r'\b(bad|terrible|awful|hate|worst|horrible|disappointed|angry|frustrated|useless)\b']


def normalize_text(text: str) -> str:
    """Normalize text for processing."""
    # Convert to lowercase
    normalized = text.lower().strip()
    # Remove extra whitespace
    normalized = re.sub(r'\s+', ' ', normalized)
    # Basic typo corrections
    typo_corrections = {
        'teh': 'the',
        'recieve': 'receive',
        'definately': 'definitely',
        'occured': 'occurred',
        'seperate': 'separate',
    }
    for typo, correction in typo_corrections.items():
        normalized = re.sub(rf'\b{typo}\b', correction, normalized)
    return normalized


def detect_intent(text: str) -> tuple[str, float]:
    """Detect intent from text."""
    text_lower = text.lower()
    
    best_intent = 'general'
    best_score = 0.0
    
    for intent, patterns in INTENT_PATTERNS.items():
        matches = sum(1 for pattern in patterns if re.search(pattern, text_lower, re.IGNORECASE))
        score = matches / len(patterns)
        
        if score > best_score:
            best_score = score
            best_intent = intent
    
    # Adjust confidence
    confidence = min(best_score * 1.5, 1.0) if best_score > 0 else 0.3
    
    return best_intent, confidence


def detect_sentiment(text: str) -> tuple[str, float]:
    """Detect sentiment from text."""
    text_lower = text.lower()
    
    positive_count = sum(1 for pattern in POSITIVE_PATTERNS if re.search(pattern, text_lower))
    negative_count = sum(1 for pattern in NEGATIVE_PATTERNS if re.search(pattern, text_lower))
    
    if positive_count > negative_count:
        score = min(0.5 + (positive_count * 0.1), 1.0)
        return 'positive', score
    elif negative_count > positive_count:
        score = max(0.5 - (negative_count * 0.1), 0.0)
        return 'negative', score
    else:
        return 'neutral', 0.5


def extract_entities(text: str) -> List[Dict[str, str]]:
    """Extract basic entities from text."""
    entities = []
    
    # Email extraction
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    emails = re.findall(email_pattern, text)
    for email in emails:
        entities.append({'type': 'EMAIL', 'value': email})
    
    # Phone number extraction (basic)
    phone_pattern = r'\b(?:\+?1[-.]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}\b'
    phones = re.findall(phone_pattern, text)
    for phone in phones:
        entities.append({'type': 'PHONE', 'value': phone})
    
    # URL extraction
    url_pattern = r'https?://[^\s]+'
    urls = re.findall(url_pattern, text)
    for url in urls:
        entities.append({'type': 'URL', 'value': url})
    
    # Order/Reference number extraction
    order_pattern = r'\b(?:order|ref|reference|#)\s*[:#]?\s*([A-Z0-9]{5,15})\b'
    orders = re.findall(order_pattern, text, re.IGNORECASE)
    for order in orders:
        entities.append({'type': 'ORDER_ID', 'value': order})
    
    return entities


def detect_language(text: str) -> str:
    """Basic language detection."""
    # Very basic heuristic - check for common words
    english_indicators = ['the', 'is', 'are', 'and', 'or', 'but', 'in', 'on', 'at', 'to']
    text_lower = text.lower()
    
    english_count = sum(1 for word in english_indicators if f' {word} ' in f' {text_lower} ')
    
    # Default to English for now (can be extended with proper language detection)
    return 'en' if english_count > 0 else 'unknown'


@app.get("/")
def read_root():
    """Health check endpoint."""
    return {
        "status": "NLP Engine Running",
        "version": "2.0.0",
        "capabilities": ["intent_detection", "sentiment_analysis", "entity_extraction", "text_normalization"]
    }


@app.post("/process", response_model=ProcessedText)
def process_text(request: TextRequest):
    """
    Process text with full NLP pipeline.
    
    Returns:
        Normalized text, detected intent, sentiment, entities, and language.
    """
    try:
        original = request.text
        
        # Normalize
        normalized = normalize_text(original)
        
        # Detect intent
        intent, intent_confidence = detect_intent(normalized)
        
        # Detect sentiment
        sentiment, sentiment_score = detect_sentiment(normalized)
        
        # Extract entities
        entities = extract_entities(original)
        
        # Detect language
        language = detect_language(original)
        
        logger.info(f"Processed query for {request.client_id}: intent={intent}, sentiment={sentiment}")
        
        return ProcessedText(
            original=original,
            normalized=normalized,
            intent=intent,
            intent_confidence=intent_confidence,
            entities=entities,
            sentiment=sentiment,
            sentiment_score=sentiment_score,
            language=language
        )
        
    except Exception as e:
        logger.error(f"Error processing text: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/intent")
def detect_intent_only(request: TextRequest):
    """Detect only the intent from text."""
    normalized = normalize_text(request.text)
    intent, confidence = detect_intent(normalized)
    return {
        "intent": intent,
        "confidence": confidence
    }


@app.post("/sentiment")
def detect_sentiment_only(request: TextRequest):
    """Detect only the sentiment from text."""
    sentiment, score = detect_sentiment(request.text)
    return {
        "sentiment": sentiment,
        "score": score
    }


@app.post("/entities")
def extract_entities_only(request: TextRequest):
    """Extract only entities from text."""
    entities = extract_entities(request.text)
    return {
        "entities": entities,
        "count": len(entities)
    }

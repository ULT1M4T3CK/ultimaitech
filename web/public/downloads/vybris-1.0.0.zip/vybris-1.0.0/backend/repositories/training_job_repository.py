"""
Training Job Repository
Data access for training job tracking.
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from datetime import datetime
import uuid
import json

from .base import TenantAwareRepository


@dataclass
class TrainingJob:
    """Training job entity."""
    id: str
    chatbot_id: str
    chatbot_name: str
    status: str  # 'pending', 'in_progress', 'completed', 'failed'
    progress: float = 0.0
    chunks_processed: int = 0
    chunks_total: int = 0
    error: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class TrainingJobRepository(TenantAwareRepository[TrainingJob]):
    """Repository for Training jobs."""
    
    @property
    def table_name(self) -> str:
        return "training_jobs"
    
    @property
    def tenant_column(self) -> str:
        return "chatbot_id"
    
    def _row_to_entity(self, row: Dict[str, Any]) -> TrainingJob:
        """Convert database row to TrainingJob entity."""
        return TrainingJob(
            id=row['id'],
            chatbot_id=row['chatbot_id'],
            chatbot_name=row.get('chatbot_name', ''),
            status=row.get('status', 'pending'),
            progress=row.get('progress', 0.0),
            chunks_processed=row.get('chunks_processed', 0),
            chunks_total=row.get('chunks_total', 0),
            error=row.get('error'),
            started_at=row.get('started_at'),
            completed_at=row.get('completed_at'),
            created_at=row.get('created_at'),
            metadata=json.loads(row['metadata']) if row.get('metadata') else {}
        )
    
    def create(self, job_data: Dict[str, Any]) -> TrainingJob:
        """Create a new training job."""
        job_id = job_data.get('id', str(uuid.uuid4()))
        now = datetime.utcnow()
        
        query = """
            INSERT INTO training_jobs (
                id, chatbot_id, chatbot_name, status, progress,
                chunks_processed, chunks_total, started_at, created_at, metadata
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING *
        """
        params = (
            job_id,
            job_data['chatbot_id'],
            job_data.get('chatbot_name', ''),
            job_data.get('status', 'pending'),
            job_data.get('progress', 0.0),
            job_data.get('chunks_processed', 0),
            job_data.get('chunks_total', 0),
            now,
            now,
            json.dumps(job_data.get('metadata', {}))
        )
        
        row = self._execute_one(query, params)
        return self._row_to_entity(row) if row else None
    
    def update_progress(self, job_id: str, progress: float, chunks_processed: int) -> None:
        """Update job progress."""
        query = """
            UPDATE training_jobs 
            SET progress = %s, chunks_processed = %s
            WHERE id = %s
        """
        self._execute(query, (progress, chunks_processed, job_id), fetch=False)
    
    def complete(self, job_id: str, success: bool = True, error: Optional[str] = None) -> None:
        """Mark job as completed or failed."""
        query = """
            UPDATE training_jobs 
            SET status = %s, completed_at = %s, progress = %s, error = %s
            WHERE id = %s
        """
        status = 'completed' if success else 'failed'
        progress = 100.0 if success else None
        self._execute(query, (status, datetime.utcnow(), progress, error, job_id), fetch=False)
    
    def find_recent(self, limit: int = 50) -> List[TrainingJob]:
        """Find recent training jobs."""
        query = """
            SELECT * FROM training_jobs 
            ORDER BY created_at DESC 
            LIMIT %s
        """
        rows = self._execute(query, (limit,))
        return [self._row_to_entity(row) for row in rows] if rows else []
    
    def find_by_chatbot(self, chatbot_id: str) -> List[TrainingJob]:
        """Find training jobs for a chatbot."""
        return self.find_by_tenant(chatbot_id)
    
    def find_in_progress(self) -> List[TrainingJob]:
        """Find jobs currently in progress."""
        query = """
            SELECT * FROM training_jobs 
            WHERE status = 'in_progress' 
            ORDER BY started_at DESC
        """
        rows = self._execute(query, ())
        return [self._row_to_entity(row) for row in rows] if rows else []


# Singleton instance
training_job_repository = TrainingJobRepository()

"""
Session Repository
Repository pattern implementation for chat session data access.
Implements interface that can be swapped for testing or alternate storage.
"""

from typing import List, Optional, Dict, Any
from abc import ABC, abstractmethod


class ISessionRepository(ABC):
    """Abstract interface for chat session data access."""

    @abstractmethod
    def get_or_create(self, session_id: str, chatbot_id: str) -> Optional[Dict[str, Any]]:
        """Get existing session or create new one."""
        pass

    @abstractmethod
    def update_activity(self, session_id: str, increment_messages: bool = True) -> None:
        """Update session last activity and optionally increment message count."""
        pass

    @abstractmethod
    def mark_unknown_interaction(self, session_id: str) -> None:
        """Mark session as having an unknown intent interaction."""
        pass

    @abstractmethod
    def update_category(self, session_id: str, category: str) -> None:
        """Update the session's category for analytics."""
        pass

    @abstractmethod
    def get_history(self, session_id: str, limit: int = 10) -> List[Dict[str, str]]:
        """Get recent message history for a session."""
        pass

    @abstractmethod
    def add_message(self, session_id: str, role: str, content: str) -> None:
        """Add a message to the session history."""
        pass

    @abstractmethod
    def get_active_conversations_count(self, chatbot_id: str) -> int:
        """Get count of active conversations."""
        pass

    @abstractmethod
    def get_monthly_stats(self, chatbot_id: str) -> List[Dict[str, Any]]:
        """Get conversation volume grouped by month."""
        pass

    @abstractmethod
    def cleanup_expired_sessions(self) -> int:
        """Remove expired sessions."""
        pass


class SessionRepository(ISessionRepository):
    """
    PostgreSQL implementation of session repository.
    Delegates to SessionDB for backward compatibility.
    """

    def get_or_create(self, session_id: str, chatbot_id: str) -> Optional[Dict[str, Any]]:
        from services.database import SessionDB
        return SessionDB.get_or_create(session_id, chatbot_id)

    def update_activity(self, session_id: str, increment_messages: bool = True) -> None:
        from services.database import SessionDB
        SessionDB.update_activity(session_id, increment_messages=increment_messages)

    def mark_unknown_interaction(self, session_id: str) -> None:
        from services.database import SessionDB
        SessionDB.mark_unknown_interaction(session_id)

    def update_category(self, session_id: str, category: str) -> None:
        from services.database import SessionDB
        SessionDB.update_category(session_id, category)

    def get_history(self, session_id: str, limit: int = 10) -> List[Dict[str, str]]:
        from services.database import SessionDB
        return SessionDB.get_history(session_id, limit=limit)

    def add_message(self, session_id: str, role: str, content: str) -> None:
        from services.database import SessionDB
        SessionDB.add_message(session_id, role, content)

    def get_active_conversations_count(self, chatbot_id: str) -> int:
        from services.database import SessionDB
        return SessionDB.get_active_conversations_count(chatbot_id)

    def get_monthly_stats(self, chatbot_id: str) -> List[Dict[str, Any]]:
        from services.database import SessionDB
        return SessionDB.get_monthly_stats(chatbot_id)

    def cleanup_expired_sessions(self) -> int:
        from services.database import SessionDB
        return SessionDB.cleanup_expired_sessions()


# Singleton for dependency injection
session_repository = SessionRepository()

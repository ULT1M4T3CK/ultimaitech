"""
Knowledge Repository
Data access for Knowledge items (training data, Q&A pairs, etc.).
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from datetime import datetime
import uuid
import json

from .base import TenantAwareRepository


@dataclass
class KnowledgeItem:
    """Knowledge item entity."""
    id: str
    chatbot_id: str
    item_type: str  # 'text', 'qa_pair', 'scraped_page', 'document'
    title: str
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class KnowledgeRepository(TenantAwareRepository[KnowledgeItem]):
    """Repository for Knowledge items."""
    
    @property
    def table_name(self) -> str:
        return "knowledge_items"
    
    @property
    def tenant_column(self) -> str:
        return "chatbot_id"
    
    def _row_to_entity(self, row: Dict[str, Any]) -> KnowledgeItem:
        """Convert database row to KnowledgeItem entity."""
        return KnowledgeItem(
            id=row['id'],
            chatbot_id=row['chatbot_id'],
            item_type=row.get('item_type', 'text'),
            title=row.get('title', ''),
            content=row.get('content', ''),
            metadata=json.loads(row['metadata']) if row.get('metadata') else {},
            created_at=row.get('created_at'),
            updated_at=row.get('updated_at')
        )
    
    def create(self, item_data: Dict[str, Any]) -> KnowledgeItem:
        """Create a new knowledge item."""
        item_id = item_data.get('id', str(uuid.uuid4()))
        now = datetime.utcnow()
        
        query = """
            INSERT INTO knowledge_items (
                id, chatbot_id, item_type, title, content, metadata, created_at, updated_at
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING *
        """
        params = (
            item_id,
            item_data['chatbot_id'],
            item_data.get('item_type', 'text'),
            item_data.get('title', ''),
            item_data.get('content', ''),
            json.dumps(item_data.get('metadata', {})),
            now,
            now
        )
        
        row = self._execute_one(query, params)
        return self._row_to_entity(row) if row else None
    
    def find_by_chatbot(self, chatbot_id: str) -> List[KnowledgeItem]:
        """Find all knowledge items for a chatbot."""
        return self.find_by_tenant(chatbot_id)
    
    def find_by_type(self, chatbot_id: str, item_type: str) -> List[KnowledgeItem]:
        """Find knowledge items by type for a chatbot."""
        query = """
            SELECT * FROM knowledge_items 
            WHERE chatbot_id = %s AND item_type = %s 
            ORDER BY created_at DESC
        """
        rows = self._execute(query, (chatbot_id, item_type))
        return [self._row_to_entity(row) for row in rows] if rows else []
    
    def update(self, item_id: str, updates: Dict[str, Any]) -> Optional[KnowledgeItem]:
        """Update a knowledge item."""
        updates['updated_at'] = datetime.utcnow()
        
        set_clauses = []
        params = []
        
        for key, value in updates.items():
            if key == 'metadata':
                value = json.dumps(value)
            set_clauses.append(f"{key} = %s")
            params.append(value)
        
        params.append(item_id)
        
        query = f"""
            UPDATE knowledge_items 
            SET {', '.join(set_clauses)}
            WHERE id = %s
            RETURNING *
        """
        
        row = self._execute_one(query, tuple(params))
        return self._row_to_entity(row) if row else None
    
    def search(self, chatbot_id: str, query_text: str, limit: int = 10) -> List[KnowledgeItem]:
        """Search knowledge items by content."""
        query = """
            SELECT * FROM knowledge_items 
            WHERE chatbot_id = %s 
            AND (title ILIKE %s OR content ILIKE %s)
            ORDER BY created_at DESC
            LIMIT %s
        """
        search_pattern = f"%{query_text}%"
        rows = self._execute(query, (chatbot_id, search_pattern, search_pattern, limit))
        return [self._row_to_entity(row) for row in rows] if rows else []


# Singleton instance
knowledge_repository = KnowledgeRepository()

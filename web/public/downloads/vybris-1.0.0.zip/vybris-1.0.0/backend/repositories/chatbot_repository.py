"""
Chatbot Repository
Repository pattern implementation for chatbot data access.
Implements interface that can be swapped for testing or alternate storage.
"""

from typing import List, Optional, Dict, Any
from abc import ABC, abstractmethod


class IChatbotRepository(ABC):
    """Abstract interface for chatbot data access."""

    @abstractmethod
    def get_by_id(self, chatbot_id: str, include_deleted: bool = False) -> Optional[Dict[str, Any]]:
        """Get a single chatbot by ID."""
        pass

    @abstractmethod
    def get_by_owner_ids(
        self,
        owner_ids: List[str],
        limit: int = 100,
        offset: int = 0,
        include_deleted: bool = False,
    ) -> List[Dict[str, Any]]:
        """Get chatbots owned by any of the given user IDs."""
        pass

    @abstractmethod
    def get_by_user(
        self,
        user_id: str,
        limit: int = 100,
        offset: int = 0,
        include_deleted: bool = False,
    ) -> List[Dict[str, Any]]:
        """Get all chatbots owned by a user."""
        pass

    @abstractmethod
    def get_all(
        self,
        limit: int = 100,
        offset: int = 0,
        include_deleted: bool = False,
    ) -> List[Dict[str, Any]]:
        """Get all chatbots with pagination."""
        pass

    @abstractmethod
    def create(self, chatbot_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new chatbot."""
        pass

    @abstractmethod
    def update(self, chatbot_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a chatbot."""
        pass

    @abstractmethod
    def delete(self, chatbot_id: str, soft_delete: bool = True) -> bool:
        """Delete a chatbot."""
        pass

    @abstractmethod
    def restore(self, chatbot_id: str) -> bool:
        """Restore a soft-deleted chatbot."""
        pass


class ChatbotRepository(IChatbotRepository):
    """
    PostgreSQL implementation of chatbot repository.
    Delegates to ChatbotDB for backward compatibility.
    """

    def get_by_id(self, chatbot_id: str, include_deleted: bool = False) -> Optional[Dict[str, Any]]:
        from services.database import ChatbotDB
        return ChatbotDB.get_by_id(chatbot_id, include_deleted=include_deleted)

    def get_by_owner_ids(
        self,
        owner_ids: List[str],
        limit: int = 100,
        offset: int = 0,
        include_deleted: bool = False,
    ) -> List[Dict[str, Any]]:
        from services.database import ChatbotDB
        return ChatbotDB.get_by_owner_ids(
            owner_ids=owner_ids,
            limit=limit,
            offset=offset,
            include_deleted=include_deleted,
        )

    def get_by_user(
        self,
        user_id: str,
        limit: int = 100,
        offset: int = 0,
        include_deleted: bool = False,
    ) -> List[Dict[str, Any]]:
        from services.database import ChatbotDB
        return ChatbotDB.get_by_user(
            user_id=user_id,
            limit=limit,
            offset=offset,
            include_deleted=include_deleted,
        )

    def get_all(
        self,
        limit: int = 100,
        offset: int = 0,
        include_deleted: bool = False,
    ) -> List[Dict[str, Any]]:
        from services.database import ChatbotDB
        return ChatbotDB.get_all(limit=limit, offset=offset, include_deleted=include_deleted)

    def create(self, chatbot_data: Dict[str, Any]) -> Dict[str, Any]:
        from services.database import ChatbotDB
        return ChatbotDB.create(chatbot_data)

    def update(self, chatbot_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        from services.database import ChatbotDB
        return ChatbotDB.update(chatbot_id, updates)

    def delete(self, chatbot_id: str, soft_delete: bool = True) -> bool:
        from services.database import ChatbotDB
        return ChatbotDB.delete(chatbot_id, soft_delete=soft_delete)

    def restore(self, chatbot_id: str) -> bool:
        from services.database import ChatbotDB
        return ChatbotDB.restore(chatbot_id)


# Singleton for dependency injection
chatbot_repository = ChatbotRepository()

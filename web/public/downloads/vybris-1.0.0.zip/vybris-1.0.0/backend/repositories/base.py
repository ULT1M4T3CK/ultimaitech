"""
Repository Base Classes
Abstract base class for all repositories, providing common operations.
"""

from abc import ABC, abstractmethod
from typing import Generic, TypeVar, Optional, List, Dict, Any
from contextlib import contextmanager
import psycopg2
from psycopg2.extras import RealDictCursor
import threading
import os

T = TypeVar('T')


class DatabaseConfig:
    """Database configuration from environment."""
    
    HOST = os.getenv("POSTGRES_HOST", "postgres")
    PORT = os.getenv("POSTGRES_PORT", "5434")
    NAME = os.getenv("POSTGRES_DB", "vybris")
    USER = os.getenv("POSTGRES_USER", "user")
    PASSWORD = os.getenv("POSTGRES_PASSWORD", "password")
    
    @classmethod
    def connection_string(cls) -> str:
        return f"postgresql://{cls.USER}:{cls.PASSWORD}@{cls.HOST}:{cls.PORT}/{cls.NAME}"


class ConnectionPool:
    """
    DEPRECATED: Use services.database.pool.get_connection_pool() instead.
    
    This class is kept for backward compatibility but now uses the shared pool.
    """
    
    @classmethod
    def get_pool(cls):
        """Get the shared connection pool."""
        from services.database.pool import get_connection_pool
        return get_connection_pool()

    @classmethod
    @contextmanager
    def get_connection(cls):
        """
        Context manager for database connections.
        
        Uses the shared connection pool and auto-commits on success.
        """
        from services.database.base import get_db_connection
        # Use get_db_connection which now has auto-commit by default
        with get_db_connection(autocommit=True) as conn:
            yield conn


class BaseRepository(ABC, Generic[T]):
    """
    Abstract base repository implementing common CRUD operations.
    
    Concrete repositories should:
    1. Define the table_name property
    2. Implement _row_to_entity for entity mapping
    3. Override methods as needed for specific behavior
    """
    
    @property
    @abstractmethod
    def table_name(self) -> str:
        """Database table name for this repository."""
        pass
    
    @property
    def primary_key(self) -> str:
        """Primary key column name. Override if not 'id'."""
        return "id"
    
    @abstractmethod
    def _row_to_entity(self, row: Dict[str, Any]) -> T:
        """Convert a database row to an entity."""
        pass
    
    def _entity_to_row(self, entity: T) -> Dict[str, Any]:
        """Convert an entity to a database row. Override for custom conversion."""
        if hasattr(entity, '__dict__'):
            return entity.__dict__
        return dict(entity) if isinstance(entity, dict) else {}
    
    # ==================== Query Helpers ====================
    
    def _execute(self, query: str, params: tuple = None, fetch: bool = True) -> Optional[List[Dict]]:
        """Execute a query and optionally fetch results."""
        with ConnectionPool.get_connection() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(query, params)
                if fetch:
                    return [dict(row) for row in cur.fetchall()]
                return None
    
    def _execute_one(self, query: str, params: tuple = None) -> Optional[Dict]:
        """Execute a query and fetch one result."""
        results = self._execute(query, params)
        return results[0] if results else None
    
    # ==================== CRUD Operations ====================
    
    def find_all(self, limit: int = 100, offset: int = 0) -> List[T]:
        """Get all entities with pagination."""
        query = f"SELECT * FROM {self.table_name} ORDER BY created_at DESC LIMIT %s OFFSET %s"
        rows = self._execute(query, (limit, offset))
        return [self._row_to_entity(row) for row in rows] if rows else []
    
    def find_by_id(self, entity_id: str) -> Optional[T]:
        """Get entity by ID."""
        query = f"SELECT * FROM {self.table_name} WHERE {self.primary_key} = %s"
        row = self._execute_one(query, (entity_id,))
        return self._row_to_entity(row) if row else None
    
    def exists(self, entity_id: str) -> bool:
        """Check if entity exists."""
        query = f"SELECT 1 FROM {self.table_name} WHERE {self.primary_key} = %s"
        result = self._execute_one(query, (entity_id,))
        return result is not None
    
    def count(self) -> int:
        """Count all entities."""
        query = f"SELECT COUNT(*) as count FROM {self.table_name}"
        result = self._execute_one(query, ())
        return result['count'] if result else 0
    
    def delete(self, entity_id: str) -> bool:
        """Delete an entity by ID."""
        query = f"DELETE FROM {self.table_name} WHERE {self.primary_key} = %s"
        self._execute(query, (entity_id,), fetch=False)
        return True
    
    def delete_all(self) -> int:
        """Delete all entities. Returns count of deleted rows."""
        count = self.count()
        query = f"DELETE FROM {self.table_name}"
        self._execute(query, fetch=False)
        return count


class TenantAwareRepository(BaseRepository[T]):
    """
    Base repository with tenant isolation.
    
    All queries are automatically scoped to the tenant (e.g., by user_id or chatbot_id).
    """
    
    @property
    @abstractmethod
    def tenant_column(self) -> str:
        """Column name for tenant isolation (e.g., 'user_id', 'chatbot_id')."""
        pass
    
    def find_by_tenant(self, tenant_id: str, limit: int = 100, offset: int = 0) -> List[T]:
        """Get all entities for a tenant."""
        query = f"""
            SELECT * FROM {self.table_name} 
            WHERE {self.tenant_column} = %s 
            ORDER BY created_at DESC 
            LIMIT %s OFFSET %s
        """
        rows = self._execute(query, (tenant_id, limit, offset))
        return [self._row_to_entity(row) for row in rows] if rows else []
    
    def count_by_tenant(self, tenant_id: str) -> int:
        """Count entities for a tenant."""
        query = f"SELECT COUNT(*) as count FROM {self.table_name} WHERE {self.tenant_column} = %s"
        result = self._execute_one(query, (tenant_id,))
        return result['count'] if result else 0
    
    def delete_by_tenant(self, tenant_id: str) -> int:
        """Delete all entities for a tenant."""
        count = self.count_by_tenant(tenant_id)
        query = f"DELETE FROM {self.table_name} WHERE {self.tenant_column} = %s"
        self._execute(query, (tenant_id,), fetch=False)
        return count

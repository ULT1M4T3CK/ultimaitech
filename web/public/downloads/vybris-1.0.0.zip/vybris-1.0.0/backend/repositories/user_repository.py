"""
User Repository
Data access for User entity.
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from datetime import datetime
import uuid
import json

from .base import BaseRepository


@dataclass
class User:
    """User entity."""
    id: str
    username: str
    email: str
    role: str
    hashed_password: str = ""
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    last_login: Optional[datetime] = None
    invite_token: Optional[str] = None
    invite_expires: Optional[datetime] = None
    is_active: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)


class UserRepository(BaseRepository[User]):
    """Repository for User entity."""
    
    @property
    def table_name(self) -> str:
        return "users"
    
    def _row_to_entity(self, row: Dict[str, Any]) -> User:
        """Convert database row to User entity."""
        return User(
            id=row['id'],
            username=row['username'],
            email=row.get('email', ''),
            role=row.get('role', 'user'),
            hashed_password=row.get('hashed_password', ''),
            created_at=row.get('created_at'),
            updated_at=row.get('updated_at'),
            last_login=row.get('last_login'),
            invite_token=row.get('invite_token'),
            invite_expires=row.get('invite_expires'),
            is_active=row.get('is_active', True),
            metadata=json.loads(row['metadata']) if row.get('metadata') else {}
        )
    
    def create(self, user_data: Dict[str, Any]) -> User:
        """Create a new user."""
        user_id = user_data.get('id', str(uuid.uuid4()))
        now = datetime.utcnow()
        
        query = """
            INSERT INTO users (
                id, username, email, role, hashed_password, 
                created_at, updated_at, is_active, invite_token, invite_expires, metadata
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING *
        """
        params = (
            user_id,
            user_data['username'],
            user_data.get('email', ''),
            user_data.get('role', 'user'),
            user_data.get('hashed_password', ''),
            now,
            now,
            user_data.get('is_active', True),
            user_data.get('invite_token'),
            user_data.get('invite_expires'),
            json.dumps(user_data.get('metadata', {}))
        )
        
        row = self._execute_one(query, params)
        return self._row_to_entity(row) if row else None
    
    def find_by_username(self, username: str) -> Optional[User]:
        """Find user by username."""
        query = "SELECT * FROM users WHERE username = %s"
        row = self._execute_one(query, (username,))
        return self._row_to_entity(row) if row else None
    
    def find_by_email(self, email: str) -> Optional[User]:
        """Find user by email."""
        query = "SELECT * FROM users WHERE email = %s"
        row = self._execute_one(query, (email,))
        return self._row_to_entity(row) if row else None
    
    def find_by_invite_token(self, token: str) -> Optional[User]:
        """Find user by invite token."""
        query = "SELECT * FROM users WHERE invite_token = %s"
        row = self._execute_one(query, (token,))
        return self._row_to_entity(row) if row else None
    
    def update(self, user_id: str, updates: Dict[str, Any]) -> Optional[User]:
        """Update a user."""
        updates['updated_at'] = datetime.utcnow()
        
        # Build dynamic update query
        set_clauses = []
        params = []
        
        for key, value in updates.items():
            if key == 'metadata':
                value = json.dumps(value)
            set_clauses.append(f"{key} = %s")
            params.append(value)
        
        params.append(user_id)
        
        query = f"""
            UPDATE users 
            SET {', '.join(set_clauses)}
            WHERE id = %s
            RETURNING *
        """
        
        row = self._execute_one(query, tuple(params))
        return self._row_to_entity(row) if row else None
    
    def update_last_login(self, user_id: str) -> None:
        """Update user's last login timestamp."""
        query = "UPDATE users SET last_login = %s WHERE id = %s"
        self._execute(query, (datetime.utcnow(), user_id), fetch=False)
    
    def find_active(self) -> List[User]:
        """Find all active users."""
        query = "SELECT * FROM users WHERE is_active = true ORDER BY created_at DESC"
        rows = self._execute(query, ())
        return [self._row_to_entity(row) for row in rows] if rows else []


# Singleton instance
user_repository = UserRepository()

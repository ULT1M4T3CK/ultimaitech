"""
Repository Package
Provides data access layer with Repository pattern.
"""

from .base import (
    BaseRepository,
    TenantAwareRepository,
    ConnectionPool,
    DatabaseConfig,
)

from .user_repository import UserRepository, User, user_repository
from .chatbot_repository import ChatbotRepository, IChatbotRepository, chatbot_repository
from .knowledge_repository import KnowledgeRepository, KnowledgeItem, knowledge_repository
from .training_job_repository import TrainingJobRepository, TrainingJob, training_job_repository
from .session_repository import SessionRepository, ISessionRepository, session_repository

__all__ = [
    # Base classes
    'BaseRepository',
    'TenantAwareRepository',
    'ConnectionPool',
    'DatabaseConfig',
    # Entities
    'User',
    'KnowledgeItem',
    'TrainingJob',
    # Repository classes
    'UserRepository',
    'ChatbotRepository',
    'IChatbotRepository',
    'SessionRepository',
    'ISessionRepository',
    'KnowledgeRepository',
    'TrainingJobRepository',
    # Singleton instances
    'user_repository',
    'chatbot_repository',
    'session_repository',
    'knowledge_repository',
    'training_job_repository',
]


"""
Knowledge Base API Router
Provides endpoints for managing knowledge items for chatbots.
"""

import logging
from datetime import datetime
import uuid
import asyncio
from typing import List, Optional, Dict, Any

from fastapi import APIRouter, HTTPException, Depends, UploadFile, File
from pydantic import BaseModel, Field

from routers.auth import get_current_user
from shared.permissions import can_access_chatbot
from services.database import KnowledgeDB, ChatbotDB
from services.nlp_service import nlp_service
from shared.utils.document_parser import extract_text_from_file, parse_qa_pairs_from_text


def _strip_nul(s: str) -> str:
    """Remove NUL (0x00) so PostgreSQL and APIs accept the string."""
    return (s or "").replace("\x00", "")

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/knowledge", tags=["knowledge"])


class KnowledgeItemCreate(BaseModel):
    chatbot_id: str = Field(..., description="Chatbot ID this knowledge belongs to")
    source_type: str = Field(default="manual", description="Source type: manual, url, qa, scraped")
    title: Optional[str] = Field(default=None, description="Title of the knowledge item")
    content: str = Field(..., description="The knowledge content")
    url: Optional[str] = Field(default=None, description="Source URL if applicable")


class KnowledgeItemUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    url: Optional[str] = None


class KnowledgeItemResponse(BaseModel):
    id: str
    chatbot_id: str
    source_type: str
    title: Optional[str]
    content: str
    url: Optional[str]
    word_count: int
    vector_id: Optional[str]
    created_at: str
    updated_at: str


@router.get("/{chatbot_id}", response_model=Dict[str, Any])
async def get_knowledge_items(
    chatbot_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get all knowledge items for a chatbot"""
    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
    if not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to view this chatbot's knowledge")

    items = KnowledgeDB.get_by_chatbot(chatbot_id)
    
    # Convert datetime objects to strings
    for item in items:
        if item.get('created_at'):
            item['created_at'] = str(item['created_at'])
        if item.get('updated_at'):
            item['updated_at'] = str(item['updated_at'])
    
    return {
        "chatbot_id": chatbot_id,
        "items": items,
        "count": len(items)
    }


@router.post("/{chatbot_id}", response_model=Dict[str, Any])
async def create_knowledge_item(
    chatbot_id: str,
    item: KnowledgeItemCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create a new knowledge item and add it to the vector database"""
    from services.database import ChatbotDB
    
    # SEC-017: Verify user owns the chatbot
    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
    if not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to modify this chatbot's knowledge")
    
    # Create the knowledge item in PostgreSQL
    item_data = {
        "chatbot_id": chatbot_id,
        "source_type": item.source_type,
        "title": item.title,
        "content": item.content,
        "url": item.url,
        "word_count": len(item.content.split())
    }
    
    created_item = KnowledgeDB.create(item_data)
    
    if not created_item:
        raise HTTPException(status_code=500, detail="Failed to create knowledge item")
    
    # Also train this content in the vector database for RAG (if learning enabled)
    enable_learning = chatbot.get('config', {}).get('enableLearning', True)
    trained = False
    if enable_learning:
        try:
            if item.source_type == "qa" and item.title:
                point_id = nlp_service.train_qa(chatbot_id, item.title, item.content)
                KnowledgeDB.update(created_item["id"], {"vector_id": point_id})
            else:
                point_id = nlp_service.train_text(chatbot_id, item.content)
                KnowledgeDB.update(created_item["id"], {"vector_id": point_id})
            trained = True
        except Exception as e:
            logger.warning(f"Failed to add to vector database: {e}")
    else:
        logger.info(f"Learning disabled for chatbot {chatbot_id}; skipping vector training.")
    
    # Re-fetch created item (may now include vector_id)
    created_item = KnowledgeDB.get_by_id(created_item["id"]) or created_item
    if created_item.get('created_at'):
        created_item['created_at'] = str(created_item['created_at'])
    if created_item.get('updated_at'):
        created_item['updated_at'] = str(created_item['updated_at'])
    
    return {
        "message": "Knowledge item created successfully",
        "item": created_item,
        "trained": trained
    }


@router.post("/{chatbot_id}/upload", response_model=Dict[str, Any])
async def upload_documents(
    chatbot_id: str,
    files: List[UploadFile] = File(...),
    current_user: dict = Depends(get_current_user)
):
    """
    Upload documents (PDF, DOCX, TEX, CSV, Excel). Content is extracted, saved to the Knowledge Hub,
    and the chatbot is automatically trained on it.
    """
    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
    if not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to modify this chatbot's knowledge")

    allowed_extensions = (".pdf", ".docx", ".tex", ".csv", ".xlsx", ".xls")
    max_size = 20 * 1024 * 1024  # 20 MB per file
    created = 0
    trained = False
    errors = []

    try:
        for file in files:
            if not file.filename:
                errors.append("One or more files have no filename")
                continue
            ext = "." + file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
            if ext not in allowed_extensions:
                errors.append(f"Unsupported format: {file.filename}. Use PDF, DOCX, TEX, CSV, or Excel.")
                continue
            content = await file.read()
            if len(content) > max_size:
                errors.append(f"File too large: {file.filename} (max 20MB)")
                continue
            text, err = extract_text_from_file(content, file.filename, file.content_type)
            if err or not text.strip():
                errors.append(f"{file.filename}: {err or 'No text extracted'}")
                continue
            text = _strip_nul(text)
            title = _strip_nul(file.filename.rsplit(".", 1)[0] if "." in file.filename else file.filename)
            enable_learning = chatbot.get("config", {}).get("enableLearning", True)

            # If document looks like Q&A pairs (Q:/A:, Vraag:/Antwoord:, etc.), train each pair so the bot can answer
            qa_pairs = parse_qa_pairs_from_text(text)
            if qa_pairs and enable_learning:
                try:
                    items_data = [
                        {
                            "id": f"ki_{uuid.uuid4().hex[:12]}",
                            "chatbot_id": chatbot_id,
                            "source_type": "qa",
                            "title": _strip_nul(q),
                            "content": _strip_nul(a),
                            "url": None,
                            "word_count": len(_strip_nul(a).split()),
                        }
                        for q, a in qa_pairs
                    ]
                    created_items = KnowledgeDB.create_batch(items_data)
                    if not created_items:
                        errors.append(f"Failed to save Q&A pairs: {file.filename}")
                        continue
                    for (q, a), item in zip(qa_pairs, created_items):
                        try:
                            point_id = await asyncio.to_thread(
                                nlp_service.train_qa, chatbot_id, q, a
                            )
                            KnowledgeDB.update(item["id"], {"vector_id": point_id})
                        except Exception as e:
                            logger.warning(f"Failed to train Q&A pair: {e}")
                    created += len(qa_pairs)
                    trained = True
                    logger.info(f"Uploaded {file.filename}: {len(qa_pairs)} Q&A pairs trained")
                except Exception as e:
                    logger.warning(f"Q&A parse/train failed for {file.filename}, falling back to document: {e}")
                    qa_pairs = []
            if not qa_pairs:
                # Single document: store as one knowledge item and train as one text block
                item_data = {
                    "chatbot_id": chatbot_id,
                    "source_type": "document",
                    "title": title,
                    "content": text,
                    "url": None,
                    "word_count": len(text.split()),
                }
                created_item = KnowledgeDB.create(item_data)
                if not created_item:
                    errors.append(f"Failed to save: {file.filename}")
                    continue
                created += 1
                if enable_learning:
                    try:
                        point_id = await asyncio.to_thread(
                            nlp_service.train_text, chatbot_id, text, {"title": title}
                        )
                        KnowledgeDB.update(created_item["id"], {"vector_id": point_id})
                        trained = True
                    except Exception as e:
                        logger.warning(f"Failed to train on document {file.filename}: {e}")

        msg = (
            f"Uploaded {created} item(s). Chatbot trained on new content."
            if created and trained
            else f"Uploaded {created} item(s)."
        )
        return {
            "message": msg,
            "files_processed": created,
            "trained": trained,
            "errors": errors if errors else None,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Document upload failed: %s", e)
        err_msg = str(e).strip()[:200]
        raise HTTPException(
            status_code=500,
            detail=f"Document upload failed: {err_msg}" if err_msg else "Document upload failed. Check server logs.",
        )


@router.put("/{item_id}", response_model=Dict[str, Any])
async def update_knowledge_item(
    item_id: str,
    updates: KnowledgeItemUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update a knowledge item"""
    item = KnowledgeDB.get_by_id(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Knowledge item not found")

    chatbot = ChatbotDB.get_by_id(item.get('chatbot_id'))
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
    if not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to modify this chatbot's knowledge")
    
    # Build updates dict with only provided fields
    update_data = {}
    if updates.title is not None:
        update_data['title'] = updates.title
    if updates.content is not None:
        update_data['content'] = updates.content
        update_data['word_count'] = len(updates.content.split())
    if updates.url is not None:
        update_data['url'] = updates.url
    
    if not update_data:
        raise HTTPException(status_code=400, detail="No updates provided")
    
    updated_item = KnowledgeDB.update(item_id, update_data)
    
    if not updated_item:
        raise HTTPException(status_code=404, detail="Knowledge item not found")
    
    # Re-train chatbot on updated content (if learning enabled and content changed)
    enable_learning = chatbot.get('config', {}).get('enableLearning', True)
    if enable_learning and updates.content is not None:
        try:
            old_vector_id = item.get('vector_id')
            if old_vector_id:
                nlp_service.delete_vectors(item['chatbot_id'], [old_vector_id])
            point_id = nlp_service.train_text(item['chatbot_id'], updates.content)
            KnowledgeDB.update(item_id, {"vector_id": point_id})
            updated_item = KnowledgeDB.get_by_id(item_id) or updated_item
            logger.info(f"Re-trained knowledge item {item_id} for chatbot {item['chatbot_id']}")
        except Exception as e:
            logger.warning(f"Failed to re-train on knowledge update: {e}")
    
    if updated_item.get('created_at'):
        updated_item['created_at'] = str(updated_item['created_at'])
    if updated_item.get('updated_at'):
        updated_item['updated_at'] = str(updated_item['updated_at'])
    
    return {
        "message": "Knowledge item updated successfully",
        "item": updated_item,
        "trained": enable_learning and updates.content is not None
    }


@router.delete("/{item_id}")
async def delete_knowledge_item(
    item_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete a knowledge item and its vector embeddings"""
    
    # Get the item first to check if it exists
    item = KnowledgeDB.get_by_id(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Knowledge item not found")

    chatbot = ChatbotDB.get_by_id(item.get('chatbot_id'))
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
    if not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to modify this chatbot's knowledge")
    
    # Get vector_id before deletion for Qdrant cleanup
    vector_id = item.get('vector_id')
    chatbot_id = item.get('chatbot_id')
    
    # Delete from PostgreSQL
    success = KnowledgeDB.delete(item_id)
    
    if not success:
        raise HTTPException(status_code=500, detail="Failed to delete knowledge item")
    
    # Delete from Qdrant vector database if vector_id exists
    if vector_id and chatbot_id:
        try:
            await nlp_service.delete_vectors(chatbot_id, [vector_id])
            logger.info(f"Deleted vector {vector_id} from Qdrant for chatbot {chatbot_id}")
        except Exception as e:
            logger.warning(f"Failed to delete vector from Qdrant: {e}")
    
    return {"message": "Knowledge item deleted successfully", "id": item_id}


@router.delete("/chatbot/{chatbot_id}")
async def delete_all_knowledge(
    chatbot_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete all knowledge items for a chatbot"""
    
    count = KnowledgeDB.delete_by_chatbot(chatbot_id)
    
    # Also clear from vector database
    try:
        await nlp_service.clear_chatbot_data(chatbot_id)
    except Exception as e:
        logger.warning(f"Failed to clear vector database: {e}")
    
    return {
        "message": "All knowledge items deleted",
        "chatbot_id": chatbot_id,
        "deleted_count": count
    }


@router.get("/item/{item_id}", response_model=Dict[str, Any])
async def get_knowledge_item(
    item_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get a single knowledge item by ID"""
    
    item = KnowledgeDB.get_by_id(item_id)
    
    if not item:
        raise HTTPException(status_code=404, detail="Knowledge item not found")
    
    # Convert datetime to string
    if item.get('created_at'):
        item['created_at'] = str(item['created_at'])
    if item.get('updated_at'):
        item['updated_at'] = str(item['updated_at'])
    
    return {"item": item}

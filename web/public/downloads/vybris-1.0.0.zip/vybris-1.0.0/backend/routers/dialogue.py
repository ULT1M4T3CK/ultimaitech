"""
Dialogue Router - DEPRECATED
Use POST /api/v1/nlp/process instead. All conversational traffic is unified through the NLP pipeline.
"""

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from routers.auth import get_current_user

router = APIRouter(prefix="/api/v1/dialogue", tags=["dialogue"])


class DialogueRequest(BaseModel):
    session_id: str
    text: str
    intent: str


@router.get("/")
def read_root():
    return {
        "status": "DEPRECATED - Use /api/v1/nlp/process",
        "version": "1.0.0",
        "migration": "POST /api/v1/nlp/process with chatbot_id, session_id, text",
    }


@router.post("/respond")
async def respond_deprecated(
    request: DialogueRequest,
    current_user: dict = Depends(get_current_user),
):
    """
    DEPRECATED: Use POST /api/v1/nlp/process instead.
    This endpoint returns 410 Gone with migration instructions.
    """
    return JSONResponse(
        status_code=410,
        content={
            "error": "DEPRECATED",
            "message": "This endpoint is deprecated. Use POST /api/v1/nlp/process instead.",
            "migration": {
                "endpoint": "POST /api/v1/nlp/process",
                "body": {
                    "chatbot_id": "<required>",
                    "session_id": request.session_id,
                    "text": request.text,
                },
            },
        },
        headers={
            "X-Deprecated": "Use POST /api/v1/nlp/process",
        },
    )

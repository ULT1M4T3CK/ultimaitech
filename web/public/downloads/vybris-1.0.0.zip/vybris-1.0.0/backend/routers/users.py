"""
Users Router for VYBR!S
Provides user management endpoints with RBAC
"""

from fastapi import APIRouter, HTTPException, Depends, status, UploadFile, File
from pydantic import BaseModel, EmailStr, Field, field_validator
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import uuid
import secrets

from routers.auth import get_current_user, require_role
from services.database import UserDB, LogDB
from services.auth_service import get_password_hash, blacklist_user_sessions
from services.email_service import email_service
from services.usage_service import usage_service
import logging
import os

logger = logging.getLogger(__name__)

# Create logos directory for Partner branding
LOGOS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'logos')
os.makedirs(LOGOS_DIR, exist_ok=True)

router = APIRouter(prefix="/api/v1/users", tags=["users"])


# ============================================================================
# Pydantic Models
# ============================================================================

class UserCreate(BaseModel):
    email: EmailStr
    full_name: str = Field(..., min_length=1, max_length=100)
    role: str = Field(default="viewer", pattern="^(admin|editor|sales|viewer|partner|moderator)$")
    moderator_chatbot_ids: Optional[List[str]] = Field(default=None, description="For moderator role: chatbot IDs this moderator can access")


class UserUpdate(BaseModel):
    full_name: Optional[str] = Field(None, min_length=1, max_length=100)
    role: Optional[str] = Field(None, pattern="^(admin|editor|sales|viewer|partner|moderator)$")
    status: Optional[str] = Field(None, pattern="^(active|inactive|pending)$")
    is_blacklisted: Optional[bool] = None  # Only super_admin can set this
    moderator_chatbot_ids: Optional[List[str]] = Field(None, description="For moderator role: chatbot IDs this moderator can access")


class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    full_name: Optional[str]
    role: str
    status: str
    is_blacklisted: bool = False
    partner_id: Optional[str] = None
    created_at: str
    last_login: Optional[str]
    moderator_chatbot_ids: Optional[List[str]] = None


class AcceptInviteRequest(BaseModel):
    token: str
    password: str = Field(..., min_length=12, max_length=100, description="Password must be at least 12 characters")


class SelfRegisterRequest(BaseModel):
    """Self-registration for Agency Partner purchasers"""
    email: EmailStr
    full_name: str = Field(..., min_length=1, max_length=100)
    password: str = Field(..., min_length=12, max_length=100, description="Password must be at least 12 characters")


class UserListResponse(BaseModel):
    users: List[UserResponse]
    total: int





class BrandingUpdate(BaseModel):
    """Branding settings for Partner tier whitelabel accounts"""
    logo_url: Optional[str] = Field(None, max_length=500)
    company_name: Optional[str] = Field(None, max_length=100)
    primary_color: Optional[str] = Field(None, pattern="^#[0-9A-Fa-f]{6}$")
    secondary_color: Optional[str] = Field(None, pattern="^#[0-9A-Fa-f]{6}$")
    theme: Optional[str] = Field(None, pattern="^(light|dark|system)$")

    @field_validator("logo_url", "company_name", "theme", mode="before")
    @classmethod
    def empty_str_to_none(cls, v):
        """Coerce empty strings to None so optional pattern validation passes"""
        if v == "" or (isinstance(v, str) and not v.strip()):
            return None
        return v

    @field_validator("primary_color", "secondary_color", mode="before")
    @classmethod
    def normalize_color(cls, v):
        """Coerce empty to None; normalize 6-char hex to #RRGGBB"""
        if v is None or v == "" or (isinstance(v, str) and not v.strip()):
            return None
        if isinstance(v, str):
            v = v.strip()
            # If 6 hex chars without #, prepend it
            if len(v) == 6 and all(c in "0123456789abcdefABCDEF" for c in v):
                return "#" + v
        return v


class BrandingResponse(BaseModel):
    """Current branding settings"""
    logo_url: Optional[str] = None
    company_name: Optional[str] = None
    primary_color: Optional[str] = None
    secondary_color: Optional[str] = None
    theme: str = "dark"


# ============================================================================
# Helper Functions
# ============================================================================

def _normalize_moderator_chatbot_ids(raw: Any) -> List[str]:
    """Normalize moderator_chatbot_ids from DB (JSONB list or None) to list of strings."""
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x) for x in raw]
    if isinstance(raw, str):
        try:
            import json
            parsed = json.loads(raw)
            return [str(x) for x in parsed] if isinstance(parsed, list) else []
        except Exception:
            return []
    return []


def user_to_response(user: dict) -> UserResponse:
    """Convert database user dict to response model"""
    mod_ids = _normalize_moderator_chatbot_ids(user.get('moderator_chatbot_ids'))
    return UserResponse(
        id=user['id'],
        username=user['username'],
        email=user['email'],
        full_name=user.get('full_name'),
        role=user['role'],
        status=user['status'],
        is_blacklisted=user.get('is_blacklisted', False),
        partner_id=user.get('partner_id'),
        created_at=user['created_at'].isoformat() if hasattr(user['created_at'], 'isoformat') else str(user['created_at']),
        last_login=user['last_login'].isoformat() if user.get('last_login') and hasattr(user['last_login'], 'isoformat') else None,
        moderator_chatbot_ids=mod_ids if user.get('role') == 'moderator' else None
    )


def log_action(
    action: str,
    message: str,
    user_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> None:
    """Helper to log user management actions"""
    try:
        LogDB.create({
            'level': 'INFO',
            'service': 'User Management',
            'action': action,
            'message': message,
            'user_id': user_id,
            'metadata': metadata or {}
        })
    except Exception as e:
        logger.warning(f"Failed to log action: {e}")




@router.get("/me/branding", response_model=BrandingResponse)
async def get_branding(
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """Get current user's branding settings (Partner, Admin, and Super Admin only)"""
    try:
        # Allow admins, super_admins, and partners to access branding
        user_role = current_user.get('role')
        is_authorized = user_role in ['partner', 'admin', 'super_admin']
        
        # For non-authorized users, return default/empty values instead of 403
        # This allows the frontend to handle the UI gracefully without errors
        if not is_authorized:
            return BrandingResponse(
                logo_url=None,
                company_name=None,
                primary_color=None,
                secondary_color=None,
                theme='dark'
            )
        
        return BrandingResponse(
            logo_url=current_user.get('branding_logo_url'),
            company_name=current_user.get('branding_company_name'),
            primary_color=current_user.get('branding_primary_color'),
            secondary_color=current_user.get('branding_secondary_color'),
            theme=current_user.get('branding_theme', 'dark')
        )
    except Exception as e:
        logger.warning("get_branding failed, returning defaults: %s", e)
        return BrandingResponse(
            logo_url=None,
            company_name=None,
            primary_color=None,
            secondary_color=None,
            theme='dark'
        )


@router.put("/me/branding", response_model=BrandingResponse)
async def update_branding(
    branding: BrandingUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update current user's branding settings (Partner, Admin, and Super Admin only)"""
    # Allow admins, super_admins, and partners to update branding
    user_role = current_user.get('role')
    if user_role not in ['partner', 'admin', 'super_admin']:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Branding settings are only available for Partner, Admin, and Super Admin accounts"
        )
    
    # Build update dict
    update_dict = {}
    if branding.logo_url is not None:
        update_dict['branding_logo_url'] = branding.logo_url
    if branding.company_name is not None:
        update_dict['branding_company_name'] = branding.company_name
    if branding.primary_color is not None:
        update_dict['branding_primary_color'] = branding.primary_color
    if branding.secondary_color is not None:
        update_dict['branding_secondary_color'] = branding.secondary_color
    if branding.theme is not None:
        update_dict['branding_theme'] = branding.theme
    
    if update_dict:
        # Mark branding setup as complete when any branding is saved
        update_dict['branding_setup_complete'] = True
        updated_user = UserDB.update(current_user['id'], update_dict)
        
        # Log the action
        log_action(
            action="branding_updated",
            message=f"User {current_user['email']} updated branding settings",
            user_id=current_user['id'],
            metadata={'updates': list(update_dict.keys())}
        )
    else:
        updated_user = current_user
    
    return BrandingResponse(
        logo_url=updated_user.get('branding_logo_url'),
        company_name=updated_user.get('branding_company_name'),
        primary_color=updated_user.get('branding_primary_color'),
        secondary_color=updated_user.get('branding_secondary_color'),
        theme=updated_user.get('branding_theme', 'dark')
    )


@router.post("/me/branding/logo")
async def upload_logo(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    """Upload a logo for Partner, Admin, and Super Admin branding"""
    # Allow admins, super_admins, and partners to upload logos
    user_role = current_user.get('role')
    if user_role not in ['partner', 'admin', 'super_admin']:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Logo upload is only available for Partner, Admin, and Super Admin accounts"
        )
    
    MAX_FILE_SIZE = 2 * 1024 * 1024  # 2MB max
    
    # Validate file extension
    # SECURITY: SVG removed due to XSS risk (SVG can contain JavaScript)
    allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
    file_ext = file.filename.split('.')[-1].lower() if file.filename else ''
    if file_ext not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail=f"File type not allowed. Use: {', '.join(allowed_extensions)}"
        )
    
    # Read file content
    content = await file.read()
    
    # Validate file size
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"File too large. Maximum size is {MAX_FILE_SIZE // (1024*1024)}MB"
        )
    
    # SECURITY: Sanitize user ID to prevent path traversal attacks
    user_id_clean = os.path.basename(current_user['id']).replace('/', '').replace('\\', '').replace('..', '')
    if not user_id_clean or user_id_clean != current_user['id']:
        raise HTTPException(status_code=400, detail="Invalid user ID format")
    
    # Save file with user ID to ensure uniqueness
    filename = f"logo_{user_id_clean}.{file_ext}"
    file_path = os.path.join(LOGOS_DIR, filename)
    
    # SECURITY: Verify final path is within LOGOS_DIR (prevent path traversal)
    real_path = os.path.realpath(file_path)
    real_dir = os.path.realpath(LOGOS_DIR)
    if not real_path.startswith(real_dir):
        raise HTTPException(status_code=400, detail="Invalid file path")
    
    # Use async file write (non-blocking)
    from services.async_file_ops import async_write_file
    success = await async_write_file(file_path, content)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to save file")
    
    # Update user's branding logo URL
    logo_url = f"/static/logos/{filename}"
    UserDB.update(current_user['id'], {
        'branding_logo_url': logo_url,
        'branding_setup_complete': True
    })
    
    # Log the action
    log_action(
        action="logo_uploaded",
        message=f"User {current_user['email']} uploaded branding logo",
        user_id=current_user['id'],
        metadata={'filename': filename}
    )
    
    return {"logo_url": logo_url, "message": "Logo uploaded successfully"}

@router.get("/me/usage")
async def get_usage(current_user: dict = Depends(get_current_user)):
    """Get current user's usage stats"""
    return usage_service.get_user_usage(current_user['id'])


# ============================================================================
# Endpoints
# ============================================================================

@router.get("/verify-invite")
async def verify_invite(token: str) -> Dict[str, Any]:
    """Verify an invite token and return user info (Public)"""
    user = UserDB.get_by_invite_token(token)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid or expired invite token"
        )
    
    # Check if token is expired
    expires_at = user.get('invite_expires_at')
    if expires_at:
        if hasattr(expires_at, 'replace'):
            if datetime.utcnow() > expires_at:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invite token has expired"
                )
    
    return {
        "valid": True,
        "email": user['email'],
        "full_name": user.get('full_name') or user['username']
    }


@router.post("/accept-invite", response_model=UserResponse)
async def accept_invite(request: AcceptInviteRequest):
    """Accept an invite and set password (Public)"""
    user = UserDB.get_by_invite_token(request.token)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid or expired invite token"
        )
    
    # Check if token is expired
    expires_at = user.get('invite_expires_at')
    if expires_at:
        if hasattr(expires_at, 'replace'):
            # datetime object
            if datetime.utcnow() > expires_at:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invite token has expired"
                )
    
    # Update user with password and activate
    hashed_password = get_password_hash(request.password)
    updated_user = UserDB.update(user['id'], {
        'hashed_password': hashed_password,
        'status': 'active',
        'invite_token': None,
        'invite_expires_at': None
    })
    
    # Log the action
    log_action(
        action="invite_accepted",
        message=f"User {user['email']} accepted invite",
        user_id=user['id']
    )
    
    return user_to_response(updated_user)


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def self_register(
    request: SelfRegisterRequest
) -> Dict[str, str]:
    """
    Public self-registration for Agency Partner purchasers.
    Creates a new partner account without requiring an invite.
    These users are visible in User Management for admins.
    """
    import re
    
    # Check if email already exists
    existing = UserDB.get_by_email(request.email)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A user with this email already exists"
        )
    
    # Generate unique username from full_name
    base_username = re.sub(r'[^a-z0-9]', '', request.full_name.lower())
    if not base_username:
        base_username = request.email.split('@')[0].lower()
    username = base_username
    counter = 1
    while UserDB.get_by_username(username):
        username = f"{base_username}{counter}"
        counter += 1
    
    # Hash the password
    hashed_password = get_password_hash(request.password)
    
    # Create user record as active partner
    user_id = f"user_{uuid.uuid4().hex[:12]}"
    new_user = UserDB.create({
        'id': user_id,
        'username': username,
        'email': request.email,
        'full_name': request.full_name,
        'hashed_password': hashed_password,
        'role': 'partner',  # Agency Partner role
        'status': 'active',  # Immediately active since they paid
        'partner_id': None,  # They ARE the partner (no parent)
    })
    
    if not new_user:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create account. Please try again."
        )
    
    # Log the action
    log_action(
        action="self_registration",
        message=f"Agency Partner {request.email} self-registered after payment",
        user_id=user_id,
        metadata={'registration_type': 'stripe_purchase'}
    )
    
    return user_to_response(new_user)


@router.get("/", response_model=UserListResponse)
async def list_users(
    current_user: dict = Depends(require_role(["admin", "partner"]))
) -> List[Dict[str, Any]]:
    """List all users (Admin: all, Partner: scoped)"""
    
    if current_user['role'] == 'partner':
        # Partners only see their own users + themselves
        users = UserDB.get_by_partner(current_user['id'])
    else:
        # Admins see everyone
        users = UserDB.get_all()
        
    return UserListResponse(
        users=[user_to_response(u) for u in users],
        total=len(users)
    )


@router.get("/sales", response_model=List[UserResponse])
async def list_sales_users(current_user: dict = Depends(require_role("admin"))):
    """List all users with sales role (Admin only) - for admin dropdown"""
    users = UserDB.get_all()
    sales_users = [user_to_response(u) for u in users if u.get('role') == 'sales']
    return sales_users


@router.get("/all")
async def list_all_users_for_superuser(
    current_user: dict = Depends(get_current_user)
) -> List[Dict[str, Any]]:
    """List all users - super user only (for user switching dropdown)"""
    if not current_user.get('is_super_user'):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Super user access required"
        )
    
    users = UserDB.get_all()
    # Return lightweight user info for dropdown
    return [
        {
            "id": u["id"],
            "email": u["email"],
            "full_name": u.get("full_name"),
            "role": u.get("role"),
            "username": u.get("username")
        }
        for u in users
    ]


@router.get("/assignable")
async def list_assignable_users(current_user: dict = Depends(get_current_user)):
    """
    List users that the current user can assign leads to.
    - Super users: can see all users
    - Account owners (admins/partners): see users in their account (partner_id matches)
    - Regular users: see users in their account
    """
    if current_user.get('is_super_user'):
        # Super user can assign to anyone
        users = UserDB.get_all()
    else:
        # Get partner_id - if user is a partner, their ID is the partner_id
        # If user belongs to a partner, use their partner_id
        partner_id = current_user.get('partner_id') or current_user.get('id')
        users = UserDB.get_by_partner(partner_id)
    
    # Return lightweight user info for dropdown
    return [
        {
            "id": u["id"],
            "email": u["email"],
            "full_name": u.get("full_name"),
            "role": u.get("role"),
            "username": u.get("username")
        }
        for u in users
    ]


@router.post("/", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(
    user_data: UserCreate,
    current_user: dict = Depends(require_role(["admin", "partner"]))
):
    """Create a new user and send invite email (Admin and Partner)"""
    # Check if email already exists
    existing = UserDB.get_by_email(user_data.email)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A user with this email already exists"
        )
    
    # Generate unique username from full_name (sanitized, lowercase, no spaces)
    import re
    base_username = re.sub(r'[^a-z0-9]', '', user_data.full_name.lower())
    if not base_username:
        base_username = user_data.email.split('@')[0].lower()
    username = base_username
    counter = 1
    while UserDB.get_by_username(username):
        username = f"{base_username}{counter}"
        counter += 1
    
    # Generate invite token
    invite_token = secrets.token_urlsafe(32)
    invite_expires = datetime.utcnow() + timedelta(hours=36)
    
    # Build create payload
    create_payload = {
        'id': f"user_{uuid.uuid4().hex[:12]}",
        'username': username,
        'email': user_data.email,
        'full_name': user_data.full_name,
        'role': user_data.role,
        'status': 'pending',
        'invite_token': invite_token,
        'invite_expires_at': invite_expires,
        'partner_id': current_user.get('id') if current_user.get('role') == 'partner' else None
    }
    if user_data.role == 'moderator' and user_data.moderator_chatbot_ids is not None:
        create_payload['moderator_chatbot_ids'] = user_data.moderator_chatbot_ids
    user_id = create_payload['id']
    new_user = UserDB.create(create_payload)
    
    if not new_user:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create user"
        )
    
    # Send invite email
    invited_by = current_user.get('full_name') or current_user.get('username') or 'Admin'
    email_sent = email_service.send_invite(
        to_email=user_data.email,
        full_name=user_data.full_name,
        invite_token=invite_token,
        invited_by=invited_by
    )
    
    # Log the action
    log_action(
        action="user_created",
        message=f"User {user_data.email} invited by {invited_by}",
        user_id=current_user.get('id'),
        metadata={'new_user_id': user_id, 'email_sent': email_sent}
    )
    
    return user_to_response(new_user)


@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: str,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """Get a specific user (Admin: all; Partner: users in their account; user: self)"""
    user = UserDB.get_by_id(user_id)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    if current_user.get('id') == user_id:
        pass
    elif current_user.get('role') in ('admin', 'super_admin'):
        pass
    elif current_user.get('role') == 'partner':
        if user.get('partner_id') != current_user.get('id') and user.get('id') != current_user.get('id'):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to view this user")
    else:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to view this user")
    return user_to_response(user)


@router.put("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: str,
    updates: UserUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update a user (Admin/Partner can update users in their scope; users can update own name only)"""
    user = UserDB.get_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    is_admin = current_user.get('role') in ('admin', 'super_admin')
    is_self = current_user.get('id') == user_id
    is_partner_scope = current_user.get('role') == 'partner' and (user.get('partner_id') == current_user.get('id') or user.get('id') == current_user.get('id'))
    
    if not is_admin and not is_self and not is_partner_scope:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to update this user"
        )
    
    can_manage_role_status = is_admin or (current_user.get('role') == 'partner' and is_partner_scope and not is_self)
    
    # Build update dict based on permissions
    update_dict = {}
    
    if updates.full_name is not None:
        update_dict['full_name'] = updates.full_name
    
    if can_manage_role_status:
        if updates.role is not None:
            update_dict['role'] = updates.role
        if updates.status is not None:
            update_dict['status'] = updates.status
        if updates.moderator_chatbot_ids is not None and (user.get('role') == 'moderator' or updates.role == 'moderator'):
            update_dict['moderator_chatbot_ids'] = updates.moderator_chatbot_ids
    elif updates.role is not None or updates.status is not None or updates.moderator_chatbot_ids is not None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admins or account owners can change role, status, or moderator chatbot access"
        )
    
    if not update_dict:
        return user_to_response(user)
    
    updated_user = UserDB.update(user_id, update_dict)
    
    if not updated_user:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update user"
        )
    
    # Log the action
    log_action(
        action="user_updated",
        message=f"User {user['email']} updated",
        user_id=current_user.get('id'),
        metadata={'target_user_id': user_id, 'updates': update_dict}
    )
    
    return user_to_response(updated_user)


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(user_id: str, current_user: dict = Depends(require_role("admin"))):
    """Delete a user (Admin only)"""
    user = UserDB.get_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Prevent self-deletion
    if current_user.get('id') == user_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot delete your own account"
        )
    
    # Delete the user (no auto-blacklisting - use manual blacklist if needed before delete)
    if not UserDB.delete(user_id):
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete user"
        )
    
    # Log the action
    log_action(
        action="user_deleted",
        message=f"User {user['email']} deleted",
        user_id=current_user.get('id'),
        metadata={'deleted_user_id': user_id, 'deleted_email': user['email']}
    )





@router.post("/{user_id}/resend-invite", status_code=status.HTTP_200_OK)
async def resend_invite(
    user_id: str,
    current_user: dict = Depends(require_role("admin"))
) -> Dict[str, str]:
    """Resend invite email to a pending user (Admin only)"""
    try:
        user = UserDB.get_by_id(user_id)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        if user['status'] != 'pending':
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="User has already accepted their invite"
            )
        
        # Generate new invite token
        invite_token = secrets.token_urlsafe(32)
        invite_expires = datetime.utcnow() + timedelta(hours=36)
        
        UserDB.update(user_id, {
            'invite_token': invite_token,
            'invite_expires_at': invite_expires
        })
        
        # Send new invite email (failure is non-fatal; we still return 200 with email_sent: false)
        invited_by = current_user.get('full_name') or current_user.get('username') or 'Admin'
        email_sent = email_service.send_invite(
            to_email=user['email'],
            full_name=user.get('full_name') or user['username'],
            invite_token=invite_token,
            invited_by=invited_by
        )
        
        try:
            log_action(
                action="invite_resent",
                message=f"Invite resent to {user['email']}",
                user_id=current_user.get('id'),
                metadata={'target_user_id': user_id, 'email_sent': email_sent}
            )
        except Exception as log_err:
            logger.warning("Failed to log invite_resent: %s", log_err)
        
        return {"message": "Invite resent successfully", "email_sent": email_sent}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("resend_invite failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to resend invite. Please try again."
        )


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=12, max_length=100, description="Password must be at least 12 characters")


@router.post("/me/change-password", status_code=status.HTTP_200_OK)
async def change_password(
    request: ChangePasswordRequest,
    current_user: dict = Depends(get_current_user)
):
    """Change current user's password"""
    from services.auth_service import verify_password
    
    user = UserDB.get_by_id(current_user['id'])
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Verify current password
    if not verify_password(request.current_password, user.get('hashed_password', '')):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Current password is incorrect"
        )
    
    # Hash and update new password
    new_hash = get_password_hash(request.new_password)
    UserDB.update(user['id'], {'hashed_password': new_hash})
    
    # Log the action (no auto-blacklisting - user can manually blacklist if needed)
    log_action(
        action="password_changed",
        message=f"User {user['email']} changed their password",
        user_id=user['id']
    )
    
    return {"message": "Password changed successfully."}

"""
Analytics Router - intents, handoffs, attribution, LLM audit.
Phase 2.3 of Next-Generation blueprint.
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional, Dict, Any, List
from datetime import datetime, timezone
import logging

from routers.auth import get_current_user

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/analytics", tags=["analytics"])


def _parse_dates(from_date: Optional[str], to_date: Optional[str]):
    from_dt = None
    to_dt = None
    if from_date:
        try:
            from_dt = datetime.fromisoformat(from_date.replace("Z", "+00:00"))
        except ValueError:
            from_dt = datetime.strptime(from_date[:10], "%Y-%m-%d").replace(tzinfo=timezone.utc)
    if to_date:
        try:
            to_dt = datetime.fromisoformat(to_date.replace("Z", "+00:00"))
        except ValueError:
            to_dt = datetime.strptime(to_date[:10], "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return from_dt, to_dt


@router.get("/intents")
async def get_intents(
    chatbot_id: str,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    current_user: dict = Depends(get_current_user),
) -> List[Dict[str, Any]]:
    """Get intent distribution for a chatbot in a date range."""
    from services.analytics.conversation_analytics import get_intent_distribution

    from_dt, to_dt = _parse_dates(from_date, to_date)
    return get_intent_distribution(chatbot_id, from_dt, to_dt)


@router.get("/handoffs")
async def get_handoffs(
    chatbot_id: str,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """Get handoff rate (sessions where last intent = live_chat_*)."""
    from services.analytics.conversation_analytics import get_handoff_rate

    from_dt, to_dt = _parse_dates(from_date, to_date)
    rate = get_handoff_rate(chatbot_id, from_dt, to_dt)
    return {"chatbot_id": chatbot_id, "handoff_rate_percent": rate, "from": from_date, "to": to_date}


@router.get("/attribution")
async def get_attribution_endpoint(
    chatbot_id: str,
    session_id: str,
    current_user: dict = Depends(get_current_user),
) -> List[Dict[str, Any]]:
    """Get attribution (chunk_ids, action_ids, llm_model) per response for a session."""
    from services.analytics.conversation_analytics import get_attribution

    return get_attribution(chatbot_id, session_id)


@router.get("/recent")
async def get_recent_events(
    chatbot_id: Optional[str] = None,
    limit: int = 50,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    current_user: dict = Depends(get_current_user),
) -> List[Dict[str, Any]]:
    """Get recent conversation events for real-time dashboard."""
    from services.analytics.conversation_analytics import get_recent_events as _get

    from_dt, to_dt = _parse_dates(from_date, to_date)
    return _get(chatbot_id=chatbot_id, limit=min(limit, 200), from_date=from_dt, to_date=to_dt)


@router.get("/conversation-audit")
async def get_conversation_audit(
    chatbot_id: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    limit: int = 100,
    current_user: dict = Depends(get_current_user),
) -> List[Dict[str, Any]]:
    """Get conversation audit log (admin/compliance)."""
    from services.analytics.conversation_analytics import get_conversation_audit as _get

    from_dt, to_dt = _parse_dates(from_date, to_date)
    return _get(chatbot_id=chatbot_id, from_date=from_dt, to_date=to_dt, limit=min(limit, 500))


@router.post("/prune-audit")
async def prune_audit(
    retention_days: int = Query(default=90, ge=1, le=365),
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """Prune old audit rows (admin). Uses AUDIT_RETENTION_DAYS env if not specified."""
    import os
    from shared.permissions import is_super_or_admin
    from services.analytics.conversation_analytics import prune_audit_retention

    if not is_super_or_admin(current_user):
        raise HTTPException(status_code=403, detail="Admin required")
    days = int(os.getenv("AUDIT_RETENTION_DAYS", str(retention_days)))
    deleted = prune_audit_retention(days)
    return {"deleted": deleted, "retention_days": days}


@router.get("/satisfaction")
async def get_satisfaction(
    chatbot_id: str,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """Phase 4.2: Get satisfaction rate from thumbs up/down feedback."""
    from services.database.base import get_db_connection

    from_dt, to_dt = _parse_dates(from_date, to_date)
    where_clauses = ["chatbot_id = %s"]
    params: List[Any] = [chatbot_id]
    if from_dt:
        where_clauses.append("created_at >= %s")
        params.append(from_dt)
    if to_dt:
        where_clauses.append("created_at <= %s")
        params.append(to_dt)

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            f"""
            SELECT rating, COUNT(*) as cnt FROM response_feedback
            WHERE {" AND ".join(where_clauses)}
            GROUP BY rating
            """,
            tuple(params),
        )
        rows = cursor.fetchall()

    up = sum(r.get("cnt", 0) for r in rows if r.get("rating") == "thumbs_up")
    down = sum(r.get("cnt", 0) for r in rows if r.get("rating") == "thumbs_down")
    total = up + down
    rate = round(100 * up / total, 1) if total > 0 else None

    return {
        "chatbot_id": chatbot_id,
        "satisfaction_rate_percent": rate,
        "positive_count": up,
        "negative_count": down,
        "total_feedback": total,
        "from": from_date,
        "to": to_date,
    }


@router.get("/llm-audit")
async def get_llm_audit(
    chatbot_id: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    limit: int = 100,
    current_user: dict = Depends(get_current_user),
) -> List[Dict[str, Any]]:
    """Get LLM audit log (admin/compliance)."""
    from services.llm_audit_service import get_llm_audit_log

    from_dt, to_dt = _parse_dates(from_date, to_date)
    return get_llm_audit_log(chatbot_id=chatbot_id, from_date=from_dt, to_date=to_dt, limit=min(limit, 500))

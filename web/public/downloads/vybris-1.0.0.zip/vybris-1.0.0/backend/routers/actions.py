from fastapi import APIRouter, HTTPException, Depends, Body
from typing import List, Dict, Any, Optional
from pydantic import BaseModel
from datetime import datetime
import uuid
import json
import os

from routers.auth import get_current_user
from services.database import CustomActionDB, ChatbotDB
from services.action_service import action_service
from shared.permissions import is_super_or_admin, can_access_chatbot

router = APIRouter(prefix="/api/v1/actions", tags=["custom_actions"])

# Load action templates
TEMPLATES_PATH = os.path.join(os.path.dirname(__file__), '..', 'shared', 'action_templates.json')
ACTION_TEMPLATES = {}
try:
    with open(TEMPLATES_PATH, 'r') as f:
        ACTION_TEMPLATES = json.load(f)
except Exception as e:
    print(f"Warning: Could not load action templates: {e}")

# --- Pydantic Models ---

class ActionParameter(BaseModel):
    name: str
    type: str # string, number, boolean
    description: str
    required: bool = True

class CreateActionRequest(BaseModel):
    chatbot_id: str
    name: str # e.g. "check_availability"
    description: str # e.g. "Check availability for a given date"
    method: str = "GET"
    url: str
    headers: Dict[str, str] = {}
    parameters: List[ActionParameter] = []
    active: bool = True

class UpdateActionRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    method: Optional[str] = None
    url: Optional[str] = None
    headers: Optional[Dict[str, str]] = None
    parameters: Optional[List[ActionParameter]] = None
    active: Optional[bool] = None

class TestActionRequest(BaseModel):
    params: Dict[str, Any]


def _action_to_api(action: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize DB row (url_template, enabled) to API shape (url, active)."""
    if not action:
        return action
    out = dict(action)
    out['url'] = out.get('url_template', out.get('url', ''))
    out['active'] = out.get('enabled', True)
    return out


# --- Endpoints ---

@router.get("/{chatbot_id}", response_model=List[Dict[str, Any]])
async def get_chatbot_actions(
    chatbot_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get all custom actions for a specific chatbot"""
    # Verify ownership
    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
        
    if not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized")
    actions = CustomActionDB.get_by_chatbot(chatbot_id)
    return [_action_to_api(a) for a in actions]


@router.post("/", response_model=Dict[str, Any])
async def create_action(
    request: CreateActionRequest,
    current_user: dict = Depends(get_current_user)
):
    """Create a new custom action"""
    # Verify ownership
    chatbot = ChatbotDB.get_by_id(request.chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
        
    if not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized")

    # Serialize parameters for storage (DB uses url_template and enabled)
    params_list = [p.dict() for p in request.parameters]

    action_data = {
        "id": f"act_{uuid.uuid4().hex[:12]}",
        "chatbot_id": request.chatbot_id,
        "name": request.name,
        "description": request.description,
        "method": request.method,
        "url_template": request.url,
        "headers": request.headers,
        "parameters": params_list,
        "enabled": request.active,
        "created_by": current_user['id']
    }
    
    new_action = CustomActionDB.create(action_data)
    if not new_action:
        raise HTTPException(status_code=500, detail="Failed to create action")
    return _action_to_api(new_action)


@router.put("/{action_id}", response_model=Dict[str, Any])
async def update_action(
    action_id: str,
    request: UpdateActionRequest,
    current_user: dict = Depends(get_current_user)
):
    """Update an existing action"""
    action = CustomActionDB.get_by_id(action_id)
    if not action:
        raise HTTPException(status_code=404, detail="Action not found")
        
    # Verify ownership through chatbot
    chatbot = ChatbotDB.get_by_id(action['chatbot_id'])
    if not chatbot or not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized")
    updates = request.dict(exclude_unset=True)
    # Map API fields to DB columns
    if 'url' in updates:
        updates['url_template'] = updates.pop('url')
    if 'active' in updates:
        updates['enabled'] = updates.pop('active')
    if 'parameters' in updates and updates['parameters']:
        updates['parameters'] = [p.dict() if hasattr(p, 'dict') else p for p in updates['parameters']]
    updated_action = CustomActionDB.update(action_id, updates)
    return _action_to_api(updated_action) if updated_action else updated_action


@router.delete("/{action_id}")
async def delete_action(
    action_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete an action"""
    action = CustomActionDB.get_by_id(action_id)
    if not action:
        raise HTTPException(status_code=404, detail="Action not found")
        
    chatbot = ChatbotDB.get_by_id(action['chatbot_id'])
    if not chatbot or not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized")
        
    success = CustomActionDB.delete(action_id)
    return {"success": success}


@router.post("/{action_id}/test", response_model=Dict[str, Any])
async def test_action(
    action_id: str,
    request: TestActionRequest,
    current_user: dict = Depends(get_current_user)
):
    """Test execute an action (for Admin UI testing)"""
    action = CustomActionDB.get_by_id(action_id)
    if not action:
        raise HTTPException(status_code=404, detail="Action not found")
    chatbot = ChatbotDB.get_by_id(action['chatbot_id'])
    if not chatbot or not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized")
    result = action_service.execute_action(action_id, request.params)
    return result


# --- Action Templates ---

class InstallTemplatesRequest(BaseModel):
    chatbot_id: str
    base_url: str  # Customer's API base URL
    template_ids: Optional[List[str]] = None  # If None, install all
    categories: Optional[List[str]] = None  # Filter by category: public, partial, verified
    include_verification: bool = True  # Include verification actions


@router.get("/templates/list")
async def list_action_templates(
    category: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
):
    """
    List available action templates.
    
    Categories:
    - public: No verification required
    - partial: Basic verification (order ID + email)
    - verified: Full OTP verification required
    """
    if not ACTION_TEMPLATES:
        raise HTTPException(status_code=500, detail="Action templates not loaded")
    
    templates = ACTION_TEMPLATES.get('templates', [])
    
    if category:
        templates = [t for t in templates if t.get('category') == category]
    
    # Return summary without full details
    return {
        "version": ACTION_TEMPLATES.get('version'),
        "categories": ACTION_TEMPLATES.get('categories'),
        "templates": [
            {
                "id": t['id'],
                "name": t['name'],
                "description": t['description'],
                "category": t['category'],
                "method": t['method'],
                "requires_verification": t.get('requires_verification', False),
                "internal": t.get('internal', False),
                "parameter_count": len(t.get('parameters', []))
            }
            for t in templates
        ]
    }


@router.get("/templates/{template_id}")
async def get_action_template(
    template_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get full details of a specific action template"""
    if not ACTION_TEMPLATES:
        raise HTTPException(status_code=500, detail="Action templates not loaded")
    
    templates = ACTION_TEMPLATES.get('templates', [])
    template = next((t for t in templates if t['id'] == template_id), None)
    
    if not template:
        raise HTTPException(status_code=404, detail="Template not found")
    
    return template


@router.post("/templates/install")
async def install_action_templates(
    request: InstallTemplatesRequest,
    current_user: dict = Depends(get_current_user)
):
    """
    Install action templates for a chatbot.
    
    This creates custom actions based on the templates, replacing
    {base_url} with the customer's API base URL.
    """
    if not ACTION_TEMPLATES:
        raise HTTPException(status_code=500, detail="Action templates not loaded")
    
    # Verify chatbot ownership
    chatbot = ChatbotDB.get_by_id(request.chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
    
    if not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    templates = ACTION_TEMPLATES.get('templates', [])
    
    # Filter templates
    if request.template_ids:
        templates = [t for t in templates if t['id'] in request.template_ids]
    
    if request.categories:
        templates = [t for t in templates if t.get('category') in request.categories]
    
    # Optionally exclude verification actions
    if not request.include_verification:
        templates = [t for t in templates if not t.get('internal', False)]
    
    # Get existing actions to avoid duplicates
    existing_actions = CustomActionDB.get_by_chatbot(request.chatbot_id)
    existing_names = {a['name'] for a in existing_actions}
    
    installed = []
    skipped = []
    errors = []
    
    # Ensure base_url doesn't end with /
    base_url = request.base_url.rstrip('/')
    
    for template in templates:
        try:
            # Skip if action with same name exists
            if template['name'] in existing_names:
                skipped.append({
                    "id": template['id'],
                    "name": template['name'],
                    "reason": "Action with same name already exists"
                })
                continue
            
            # Replace {base_url} in URL template
            url_template = template['url_template'].replace('{base_url}', base_url)
            
            # Create action
            action_data = {
                "id": f"act_{uuid.uuid4().hex[:12]}",
                "chatbot_id": request.chatbot_id,
                "name": template['name'],
                "description": template['description'],
                "method": template['method'],
                "url_template": url_template,
                "headers": template.get('headers', {}),
                "parameters": template.get('parameters', []),
                "enabled": True
            }
            
            new_action = CustomActionDB.create(action_data)
            if new_action:
                installed.append({
                    "id": new_action['id'],
                    "name": new_action['name'],
                    "category": template.get('category'),
                    "requires_verification": template.get('requires_verification', False)
                })
            else:
                errors.append({
                    "id": template['id'],
                    "name": template['name'],
                    "error": "Failed to create action"
                })
                
        except Exception as e:
            errors.append({
                "id": template['id'],
                "name": template['name'],
                "error": str(e)
            })
    
    return {
        "success": len(errors) == 0,
        "chatbot_id": request.chatbot_id,
        "base_url": base_url,
        "installed": installed,
        "skipped": skipped,
        "errors": errors,
        "summary": {
            "total_templates": len(templates),
            "installed": len(installed),
            "skipped": len(skipped),
            "errors": len(errors)
        }
    }


@router.delete("/templates/uninstall/{chatbot_id}")
async def uninstall_all_actions(
    chatbot_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Remove all custom actions from a chatbot"""
    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
    
    if not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    actions = CustomActionDB.get_by_chatbot(chatbot_id)
    deleted = 0
    
    for action in actions:
        if CustomActionDB.delete(action['id']):
            deleted += 1
    
    return {
        "success": True,
        "deleted": deleted,
        "message": f"Removed {deleted} actions from chatbot"
    }

"""
Response Optimizer
Utilities for optimizing API response payloads
"""

from typing import List, Dict, Any, Optional, Set


def select_fields(data: Dict[str, Any], fields: Optional[List[str]]) -> Dict[str, Any]:
    """
    Select only specified fields from a data dictionary.
    
    Args:
        data: Original data dictionary
        fields: List of field names to include (None = include all)
    
    Returns:
        Filtered dictionary with only selected fields
    """
    if fields is None:
        return data
    
    return {key: data[key] for key in fields if key in data}


def select_fields_list(items: List[Dict[str, Any]], fields: Optional[List[str]]) -> List[Dict[str, Any]]:
    """
    Select fields from a list of dictionaries.
    
    Args:
        items: List of dictionaries
        fields: List of field names to include (None = include all)
    
    Returns:
        List of filtered dictionaries
    """
    if fields is None:
        return items
    
    return [select_fields(item, fields) for item in items]


def optimize_chatbot_list_response(chatbots: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Optimize chatbot list response by removing heavy fields.
    Only includes fields needed for list view.
    """
    return [
        {
            'id': bot['id'],
            'name': bot['name'],
            'type': bot.get('type', 'General Purpose'),
            'status': bot.get('status', 'Draft'),
            'users': bot.get('users', 0),
            'createdAt': bot.get('createdAt'),
            'updatedAt': bot.get('updatedAt')
        }
        for bot in chatbots
    ]


def optimize_integration_list_response(integrations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Optimize integration list response by sanitizing configs.
    """
    optimized = []
    for integration in integrations:
        opt = {
            'id': integration['id'],
            'integration_type': integration['integration_type'],
            'name': integration['name'],
            'status': integration.get('status', 'inactive'),
            'created_at': integration.get('created_at'),
            'updated_at': integration.get('updated_at')
        }
        # Only include non-sensitive config fields
        config = integration.get('config', {})
        if config:
            opt['config'] = {
                k: v for k, v in config.items()
                if k not in ['api_key', 'secret', 'password', 'token', 'access_token']
            }
        optimized.append(opt)
    return optimized

"""
Qualification Frameworks Router
Manages lead qualification frameworks for Sales chatbots
"""

from fastapi import APIRouter, HTTPException, Depends, status
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime

from services.database import QualificationDB, CRMLeadDB, ChatbotDB
from routers.auth import get_current_user
from shared.permissions import can_access_chatbot

router = APIRouter(prefix="/api/v1/qualifications", tags=["qualifications"])


# ============================================================================
# Pydantic Models
# ============================================================================

class AnswerOption(BaseModel):
    """A single answer option for a qualification question"""
    value: str
    label: str
    score: int = Field(default=0, ge=0, le=100)


class QualificationQuestion(BaseModel):
    """A single qualification question"""
    id: str
    text: str
    type: str = Field(default='multiple_choice')  # multiple_choice, free_text, number
    required: bool = True
    answer_options: Optional[List[AnswerOption]] = None
    max_score: int = Field(default=10, ge=0, le=100)
    default_score: int = Field(default=10, ge=0, le=100)
    category: Optional[str] = None  # BANT: Budget, Authority, Need, Timeline


class QualificationFrameworkCreate(BaseModel):
    """Request model for creating a qualification framework"""
    chatbot_id: str
    framework_type: str = Field(default='Custom')  # BANT, CHAMP, MEDDIC, Custom
    name: str = Field(default='Sales Qualification')
    description: Optional[str] = None
    questions: List[QualificationQuestion] = []
    hot_threshold: int = Field(default=80, ge=0, le=100)
    warm_threshold: int = Field(default=50, ge=0, le=100)
    cold_threshold: int = Field(default=25, ge=0, le=100)
    auto_create_deal: bool = True


class QualificationFrameworkUpdate(BaseModel):
    """Request model for updating a qualification framework"""
    name: Optional[str] = None
    description: Optional[str] = None
    framework_type: Optional[str] = None
    questions: Optional[List[QualificationQuestion]] = None
    hot_threshold: Optional[int] = None
    warm_threshold: Optional[int] = None
    cold_threshold: Optional[int] = None
    auto_create_deal: Optional[bool] = None
    active: Optional[bool] = None


class QualificationAnswer(BaseModel):
    """Answer to a qualification question"""
    question_id: str
    value: Any


class QualificationSubmission(BaseModel):
    """Submission of qualification answers from chatbot"""
    chatbot_id: str
    session_id: Optional[str] = None
    answers: List[QualificationAnswer]
    lead_data: Dict[str, Any] = {}  # name, email, phone, company, etc.
    transcript: Optional[str] = None
    source_url: Optional[str] = None


# ============================================================================
# Framework Templates
# ============================================================================

BANT_TEMPLATE = {
    "framework_type": "BANT",
    "name": "BANT Qualification",
    "description": "Budget, Authority, Need, Timeline qualification framework",
    "questions": [
        {
            "id": "budget",
            "text": "What is your budget for this solution?",
            "type": "multiple_choice",
            "category": "Budget",
            "required": True,
            "answer_options": [
                {"value": "under_500", "label": "Under €500", "score": 5},
                {"value": "500_2k", "label": "€500 - €2,000", "score": 15},
                {"value": "2k_10k", "label": "€2,000 - €10,000", "score": 25},
                {"value": "over_10k", "label": "Over €10,000", "score": 30}
            ]
        },
        {
            "id": "authority",
            "text": "Are you the decision-maker for this purchase?",
            "type": "multiple_choice",
            "category": "Authority",
            "required": True,
            "answer_options": [
                {"value": "yes", "label": "Yes, I make the final decision", "score": 25},
                {"value": "influence", "label": "I influence the decision", "score": 15},
                {"value": "no", "label": "No, someone else decides", "score": 5}
            ]
        },
        {
            "id": "need",
            "text": "What is your primary need or challenge?",
            "type": "free_text",
            "category": "Need",
            "required": True,
            "max_score": 20,
            "default_score": 15
        },
        {
            "id": "timeline",
            "text": "When do you need this solution implemented?",
            "type": "multiple_choice",
            "category": "Timeline",
            "required": True,
            "answer_options": [
                {"value": "asap", "label": "ASAP / Within 30 days", "score": 25},
                {"value": "1_3_months", "label": "1-3 months", "score": 20},
                {"value": "3_6_months", "label": "3-6 months", "score": 10},
                {"value": "exploring", "label": "Just exploring", "score": 5}
            ]
        }
    ],
    "hot_threshold": 80,
    "warm_threshold": 50,
    "cold_threshold": 25
}

CHAMP_TEMPLATE = {
    "framework_type": "CHAMP",
    "name": "CHAMP Qualification",
    "description": "Challenges, Authority, Money, Prioritization framework",
    "questions": [
        {
            "id": "challenges",
            "text": "What is your biggest challenge with your current solution?",
            "type": "free_text",
            "category": "Challenges",
            "required": True,
            "max_score": 30,
            "default_score": 25
        },
        {
            "id": "authority",
            "text": "What is your role in the decision-making process?",
            "type": "multiple_choice",
            "category": "Authority",
            "required": True,
            "answer_options": [
                {"value": "final", "label": "Final decision maker", "score": 25},
                {"value": "key", "label": "Key influencer", "score": 20},
                {"value": "evaluator", "label": "Evaluator/Researcher", "score": 10},
                {"value": "other", "label": "Other", "score": 5}
            ]
        },
        {
            "id": "money",
            "text": "Do you have budget allocated for this project?",
            "type": "multiple_choice",
            "category": "Money",
            "required": True,
            "answer_options": [
                {"value": "yes_approved", "label": "Yes, already approved", "score": 25},
                {"value": "pending", "label": "Yes, pending approval", "score": 15},
                {"value": "exploring", "label": "Still determining budget", "score": 10},
                {"value": "no", "label": "No budget allocated", "score": 0}
            ]
        },
        {
            "id": "priority",
            "text": "How urgent is solving this problem for your business?",
            "type": "multiple_choice",
            "category": "Prioritization",
            "required": True,
            "answer_options": [
                {"value": "critical", "label": "Critical - top priority", "score": 25},
                {"value": "high", "label": "High priority", "score": 20},
                {"value": "medium", "label": "Medium priority", "score": 10},
                {"value": "low", "label": "Low priority / nice to have", "score": 5}
            ]
        }
    ],
    "hot_threshold": 80,
    "warm_threshold": 50,
    "cold_threshold": 25
}


# ============================================================================
# API Endpoints
# ============================================================================

@router.get("/templates")
async def get_framework_templates():
    """Get available qualification framework templates"""
    return {
        "templates": [
            {"type": "BANT", "name": "BANT", "description": "Budget, Authority, Need, Timeline", "template": BANT_TEMPLATE},
            {"type": "CHAMP", "name": "CHAMP", "description": "Challenges, Authority, Money, Prioritization", "template": CHAMP_TEMPLATE},
            {"type": "Custom", "name": "Custom", "description": "Build your own qualification framework", "template": None}
        ]
    }


@router.post("/")
async def create_framework(
    request: QualificationFrameworkCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create a new qualification framework for a chatbot"""
    # Verify chatbot ownership
    chatbot = ChatbotDB.get_by_id(request.chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
    
    if not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to modify this chatbot")
    
    # Deactivate any existing frameworks for this chatbot
    existing = QualificationDB.get_by_chatbot(request.chatbot_id)
    if existing:
        QualificationDB.update(existing['id'], {'active': False})
    
    framework_data = request.dict()
    framework_data['created_by'] = current_user['id']
    framework_data['questions'] = [q.dict() for q in request.questions]
    
    framework = QualificationDB.create(framework_data)
    return framework


@router.get("/chatbot/{chatbot_id}")
async def get_chatbot_framework(
    chatbot_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get the active qualification framework for a chatbot"""
    framework = QualificationDB.get_by_chatbot(chatbot_id)
    if not framework:
        return {"framework": None, "message": "No qualification framework configured"}
    return framework


@router.get("/chatbot/{chatbot_id}/public")
async def get_chatbot_framework_public(chatbot_id: str):
    """Public endpoint for widget to fetch qualification questions"""
    framework = QualificationDB.get_by_chatbot(chatbot_id)
    if not framework:
        return {"framework": None}
    
    # Return only what the widget needs (no thresholds)
    return {
        "id": framework['id'],
        "name": framework['name'],
        "questions": framework['questions']
    }


@router.get("/{framework_id}")
async def get_framework(
    framework_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get a specific qualification framework"""
    framework = QualificationDB.get_by_id(framework_id)
    if not framework:
        raise HTTPException(status_code=404, detail="Framework not found")
    return framework


@router.put("/{framework_id}")
async def update_framework(
    framework_id: str,
    request: QualificationFrameworkUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update a qualification framework"""
    framework = QualificationDB.get_by_id(framework_id)
    if not framework:
        raise HTTPException(status_code=404, detail="Framework not found")
    
    # Verify ownership via chatbot
    chatbot = ChatbotDB.get_by_id(framework.get('chatbot_id'))
    if chatbot and not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    updates = request.dict(exclude_unset=True)
    if 'questions' in updates and updates['questions'] is not None:
        updates['questions'] = [q.dict() if hasattr(q, 'dict') else q for q in updates['questions']]
    
    updated = QualificationDB.update(framework_id, updates)
    return updated


@router.delete("/{framework_id}")
async def delete_framework(
    framework_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete a qualification framework"""
    framework = QualificationDB.get_by_id(framework_id)
    if not framework:
        raise HTTPException(status_code=404, detail="Framework not found")
    
    # Verify ownership via chatbot
    chatbot = ChatbotDB.get_by_id(framework.get('chatbot_id'))
    if chatbot and not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    QualificationDB.delete(framework_id)
    return {"success": True}


@router.post("/submit")
async def submit_qualification(request: QualificationSubmission):
    """
    Submit qualification answers from chatbot widget.
    This is a PUBLIC endpoint called by the widget.
    Creates or updates a lead with qualification score.
    """
    # Get the framework
    framework = QualificationDB.get_by_chatbot(request.chatbot_id)
    if not framework:
        raise HTTPException(status_code=404, detail="No qualification framework for this chatbot")
    
    # Calculate score
    answers = [{"value": a.value, "question_id": a.question_id} for a in request.answers]
    score_result = QualificationDB.calculate_score(answers, framework)
    
    # Prepare lead data
    lead_data = request.lead_data.copy()
    lead_data.update({
        'qualification_score': score_result['score'],
        'lead_tier': score_result['tier'],
        'qualification_data': score_result,
        'chatbot_transcript': request.transcript,
        'source_chatbot_id': request.chatbot_id,
        'source_url': request.source_url,
        'source_campaign': f"Chatbot: {request.chatbot_id}"
    })
    
    # Set initial status based on tier
    if score_result['tier'] == 'Hot':
        lead_data['status'] = 'qualified'
        lead_data['priority'] = 'high'
    elif score_result['tier'] == 'Warm':
        lead_data['status'] = 'interested'
        lead_data['priority'] = 'medium'
    elif score_result['tier'] == 'Cold':
        lead_data['status'] = 'new'
        lead_data['priority'] = 'low'
    else:
        lead_data['status'] = 'new'
        lead_data['priority'] = 'low'
    
    # Ensure required fields
    if 'name' not in lead_data or not lead_data['name']:
        lead_data['name'] = lead_data.get('email', 'Unknown Visitor').split('@')[0]
    
    # Get chatbot owner to assign as account owner
    chatbot = ChatbotDB.get_by_id(request.chatbot_id)
    if chatbot and chatbot.get('owner_id'):
        lead_data['account_owner_id'] = chatbot['owner_id']
    
    # Create the lead
    lead = CRMLeadDB.create(lead_data)
    lead_id = lead.get("id")
    owner_id = lead.get("account_owner_id") or (chatbot.get("owner_id") if chatbot else None)

    # Publish workflow events for async processing
    if lead_id and owner_id:
        try:
            from services.message_broker import publish_workflow_event

            ctx = {"lead_id": lead_id, "qualification_score": score_result["score"], "lead_tier": score_result["tier"]}
            publish_workflow_event("lead_created", ctx, owner_id=owner_id)
            publish_workflow_event("score_threshold", ctx, owner_id=owner_id)
        except Exception:
            pass

    return {
        "success": True,
        "lead_id": lead['id'],
        "score": score_result['score'],
        "tier": score_result['tier'],
        "message": f"Lead qualified as {score_result['tier']} ({score_result['score']}%)"
    }

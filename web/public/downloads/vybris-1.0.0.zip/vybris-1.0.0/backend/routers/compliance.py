"""
Compliance Monitoring Router for VYBR!S
Provides endpoints for SOC 2 compliance monitoring
SOC 2 Compliance: CC4.1, CC6.5, A1.2
"""

from fastapi import APIRouter, Depends, HTTPException, status
from typing import Annotated, Dict, Any
from datetime import datetime
import os
import subprocess
from pathlib import Path

from routers.auth import get_current_user, require_admin

router = APIRouter(prefix="/api/v1/compliance", tags=["compliance"])


@router.get("/backup-status")
async def get_backup_status(
    current_user: Annotated[dict, Depends(require_admin)]
) -> Dict[str, Any]:
    """
    Get backup system status for compliance monitoring.
    Admin-only endpoint.
    
    Returns:
        - Last backup timestamp
        - Number of backups available
        - Backup health status
        - Last restore test result
    """
    backup_dir = Path("/var/backups/vybris")
    
    if not backup_dir.exists():
        return {
            "status": "not_configured",
            "message": "Backup directory not found. Please configure automated backups.",
            "last_backup": None,
            "backup_count": 0,
            "health": "error"
        }
    
    # Find latest backup files
    postgres_backups = sorted(backup_dir.glob("postgres_*.sql.gpg"), key=lambda p: p.stat().st_mtime, reverse=True)
    qdrant_backups = sorted(backup_dir.glob("qdrant_*.tar.gz.gpg"), key=lambda p: p.stat().st_mtime, reverse=True)
    
    if not postgres_backups or not qdrant_backups:
        return {
            "status": "no_backups",
            "message": "No backups found. Run backup script manually to initialize.",
            "last_backup": None,
            "backup_count": 0,
            "health": "warning"
        }
    
    # Get latest backup info
    latest_postgres = postgres_backups[0]
    latest_qdrant = qdrant_backups[0]
    last_backup_time = datetime.fromtimestamp(latest_postgres.stat().st_mtime)
    
    # Check if backup is recent (within 48 hours for daily backups)
    hours_since_backup = (datetime.now() - last_backup_time).total_seconds() / 3600
    health = "healthy" if hours_since_backup < 48 else "warning"
    
    # Check restore test log
    restore_test_log = Path("/var/log/vybris_backup_test.log")
    last_restore_test = None
    if restore_test_log.exists():
        try:
            with open(restore_test_log, 'r') as f:
                lines = f.readlines()
                for line in reversed(lines):
                    if "Backup restore test" in line:
                        if "PASSED" in line:
                            last_restore_test = "passed"
                        elif "FAILED" in line:
                            last_restore_test = "failed"
                        break
        except Exception:
            pass
    
    return {
        "status": "operational",
        "last_backup": last_backup_time.isoformat(),
        "hours_since_backup": round(hours_since_backup, 1),
        "backup_count": {
            "postgres": len(postgres_backups),
            "qdrant": len(qdrant_backups)
        },
        "backup_size": {
            "postgres_mb": round(latest_postgres.stat().st_size / 1024 / 1024, 2),
            "qdrant_mb": round(latest_qdrant.stat().st_size / 1024 / 1024, 2),
        },
        "health": health,
        "last_restore_test": last_restore_test,
        "retention_policy": "30 days"
    }


@router.get("/encryption-status")
async def get_encryption_status(
    current_user: Annotated[dict, Depends(require_admin)]
) -> Dict[str, Any]:
    """
    Check encryption configuration status.
    Admin-only endpoint.
    """
    from services.database import get_db_connection
    
    status = {
        "postgres_ssl": False,
        "postgres_encryption": "unknown",
        "backup_encryption": False,
        "https_enabled": False
    }
    
    # Check PostgreSQL SSL
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SHOW ssl")
            result = cursor.fetchone()
            status["postgres_ssl"] = result['ssl'] == 'on' if result else False
    except Exception as e:
        status["postgres_ssl"] = f"error: {str(e)}"
    
    # Check if backup encryption GPG key exists
    backup_key = os.getenv("BACKUP_ENCRYPTION_KEY")
    status["backup_encryption"] = bool(backup_key)
    
    # Check HTTPS (from environment)
    env = os.getenv("ENVIRONMENT", "development")
    status["https_enabled"] = env == "production"
    
    # Overall compliance
    all_encrypted = all([
        status["postgres_ssl"],
        status["backup_encryption"],
    ])
    
    return {
        **status,
        "overall_status": "compliant" if all_encrypted else "needs_configuration",
        "recommendations": [
            "Enable PostgreSQL SSL" if not status["postgres_ssl"] else None,
            "Configure backup encryption key" if not status["backup_encryption"] else None,
            "Deploy to HTTPS in production" if not status["https_enabled"] and env == "production" else None
        ]
    }


@router.get("/mfa-adoption")
async def get_mfa_adoption(
    current_user: Annotated[dict, Depends(require_admin)]
) -> Dict[str, Any]:
    """
    Get MFA adoption metrics across all users.
    Admin-only endpoint for SOC 2 CC5.2 monitoring.
    """
    from services.database import UserDB
    
    users = UserDB.get_all()
    total_users = len(users)
    active_users = [u for u in users if u.get('status') == 'active']
    mfa_enabled_users = [u for u in active_users if u.get('mfa_enabled')]
    
    admin_users = [u for u in active_users if u.get('role') == 'admin']
    admin_mfa_users = [u for u in admin_users if u.get('mfa_enabled')]
    
    return {
        "total_users": total_users,
        "active_users": len(active_users),
        "mfa_enabled": len(mfa_enabled_users),
        "mfa_adoption_rate": round(len(mfa_enabled_users) / len(active_users) * 100, 1) if active_users else 0,
        "admin_mfa_adoption": {
            "total_admins": len(admin_users),
            "admins_with_mfa": len(admin_mfa_users),
            "admin_mfa_rate": round(len(admin_mfa_users) / len(admin_users) * 100, 1) if admin_users else 0
        },
        "recommendation": "Enforce MFA for all admin users" if len(admin_mfa_users) < len(admin_users) else "Good security posture"
    }


@router.get("/audit-summary")
async def get_audit_summary(
    current_user: Annotated[dict, Depends(require_admin)]
) -> Dict[str, Any]:
    """
    Get overall SOC 2 compliance summary dashboard.
    Aggregates all compliance metrics.
    """
    # Get all sub-statuses
    backup_status = await get_backup_status(current_user)
    encryption_status = await get_encryption_status(current_user)
    mfa_status = await get_mfa_adoption(current_user)
    
    # Calculate compliance score
    checks = {
        "backups_configured": backup_status["status"] == "operational",
        "recent_backup": backup_status.get("health") == "healthy",
        "restore_test_passed": backup_status.get("last_restore_test") == "passed",
        "postgres_ssl": encryption_status["postgres_ssl"] == True,
        "backup_encryption": encryption_status["backup_encryption"],
        "admin_mfa": mfa_status["admin_mfa_adoption"]["admin_mfa_rate"] == 100,
        "mfa_available": True  # MFA system is implemented
    }
    
    passed_checks = sum(1 for v in checks.values() if v)
    total_checks = len(checks)
    compliance_score = round(passed_checks / total_checks * 100)
    
    return {
        "compliance_score": compliance_score,
        "status": "compliant" if compliance_score >= 85 else "partial" if compliance_score >= 60 else "needs_work",
        "checks": checks,
        "passed_checks": passed_checks,
        "total_checks": total_checks,
        "recommendations": [
            rec for rec in [
                "Configure automated backups" if not checks["backups_configured"] else None,
                "Enable PostgreSQL SSL encryption" if not checks["postgres_ssl"] else None,
                "Enforce MFA for admin users" if not checks["admin_mfa"] else None,
                "Run restore test to validate backups" if not checks["restore_test_passed"] else None,
            ] if rec
        ],
        "last_updated": datetime.now().isoformat()
    }


@router.post("/run-backup")
async def trigger_manual_backup(
    current_user: Annotated[dict, Depends(require_admin)]
) -> Dict[str, Any]:
    """
    Manually trigger a backup job.
    Admin-only endpoint.
    """
    script_path = "/home/andre/Desktop/Projects/my-website/VYBR!S/scripts/backup_database.sh"
    
    if not Path(script_path).exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Backup script not found. Please ensure scripts are installed."
        )
    
    try:
        # Run backup script in background
        result = subprocess.Popen(
            [script_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        return {
            "status": "started",
            "message": "Backup job initiated. Check /var/log/vybris_backup.log for progress.",
            "pid": result.pid
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to start backup: {str(e)}"
        )

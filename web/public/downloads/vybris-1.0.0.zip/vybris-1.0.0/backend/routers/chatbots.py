from fastapi import APIRouter, HTTPException, Depends, UploadFile, File, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, field_validator
from typing import List, Optional, Dict, Any
from datetime import datetime
import uuid
import os
import logging
from services.usage_service import usage_service
import shutil
from routers.auth import get_current_user
from services.database import ChatbotDB, IntegrationDB
from shared.permissions import is_super_or_admin, is_sales, can_access_chatbot, get_chatbot_account_owner_ids
from services.integrations import IntegrationManager

logger = logging.getLogger(__name__)

# Create avatars directory
AVATARS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'avatars')
os.makedirs(AVATARS_DIR, exist_ok=True)

# Ensure directory has write permissions
try:
    # Test write permissions
    test_file = os.path.join(AVATARS_DIR, '.write_test')
    with open(test_file, 'w') as f:
        f.write('test')
    os.remove(test_file)
except Exception as e:
    import logging
    logger = logging.getLogger(__name__)
    logger.error(f"Warning: Cannot write to avatars directory {AVATARS_DIR}: {e}")

router = APIRouter(prefix="/api/v1/chatbots", tags=["chatbots"])

# Pydantic Models matching Frontend Interfaces
class ChatbotCustomStyles(BaseModel):
    colorType: str = 'gradient'  # 'solid', 'gradient', 'linear'
    primaryColor: str = '#d148e6'
    secondaryColor: str = '#3b48ae'  # Used for gradient/linear
    gradientAngle: int = 135  # Angle for gradient direction
    avatarUrl: Optional[str] = None  # Profile picture URL
    windowStyle: str = 'modern'  # 'classic', 'modern', 'hyper-modern'
    fontFamily: str = 'Inter, sans-serif'
    borderRadius: str = '12px'

class ChatbotConfig(BaseModel):
    language: str = 'en'  # Primary language
    supportedLanguages: List[str] = ['en']  # All supported languages
    companyName: str = ''  # Company the chatbot represents (distinct from bot name)
    welcomeMessage: str = 'Hello! How can I assist you today?'
    fallbackMessage: str = "I'm sorry, I didn't understand that."
    maxResponseTime: int = 5000
    confidenceThreshold: float = 0.7
    enableLearning: bool = True
    enableKnowledgeBase: bool = True  # Enable knowledge base for RAG
    enableAnalytics: bool = True
    enableLiveChat: bool = False  # Enable live chat; users can request human, moderators at /vybris/chat
    enableFeedbackButtons: bool = False  # Phase 4.2: Show thumbs up/down in widget responses
    detailedLogs: bool = False
    webhookUrl: Optional[str] = None
    maxResponseLength: int = 500
    customStyles: ChatbotCustomStyles = ChatbotCustomStyles()
    # Backend: "rag" (default) or "elias" (OpenClaw gateway)
    backend_type: str = 'rag'

    @field_validator('backend_type')
    @classmethod
    def backend_type_valid(cls, v: str) -> str:
        if not v or v.strip().lower() not in ('rag', 'elias'):
            return 'rag'
        return v.strip().lower()
    # Elias AI (Pro+): per-bot toggle; when enabled, messages are proxied to Elias
    elias_enabled: bool = False
    elias_url: Optional[str] = None  # Base URL, e.g. https://elias.your-vybrs.com
    elias_bot_name: str = 'Elias'
    actions_base_url: Optional[str] = None  # API base URL for custom actions (inventory, bookings, etc.)
    # Orchestration (Phase 2.2): fallback_chain, thresholds, model preset - from Config UI
    orchestrator: Optional[Dict[str, Any]] = None

    @field_validator('elias_url')
    @classmethod
    def elias_url_https(cls, v: Optional[str]) -> Optional[str]:
        if not v or not v.strip():
            return None
        v = v.strip().rstrip('/')
        if not v.startswith(('https://', 'http://')):
            raise ValueError('elias_url must be https:// or http://')
        return v

class ChatbotData(BaseModel):
    conversations: int = 0
    totalMessages: int = 0
    avgResponseTime: int = 0
    lastActive: Optional[str] = None
    trainingData: List[str] = []
    intents: List[str] = []

class Chatbot(BaseModel):
    id: str
    name: str
    type: str
    status: str # 'Active' | 'Inactive' | 'Maintenance' | 'Draft'
    users: int = 0
    accuracy: str = "N/A"
    createdAt: str
    updatedAt: str
    config: ChatbotConfig
    data: ChatbotData

class CreateChatbotRequest(BaseModel):
    """Request model for creating a chatbot with input validation"""
    name: Optional[str] = None
    type: Optional[str] = None
    config: Optional[ChatbotConfig] = None
    integration_setup: Optional[Dict[str, Any]] = None

class UpdateChatbotRequest(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    status: Optional[str] = None
    config: Optional[ChatbotConfig] = None
    data: Optional[ChatbotData] = None


class PatchChatbotEliasRequest(BaseModel):
    """Partial update for Elias AI fields and embed theme (per-bot)."""
    elias_enabled: Optional[bool] = None
    elias_url: Optional[str] = None
    elias_bot_name: Optional[str] = None
    actions_base_url: Optional[str] = None
    embed_theme: Optional[str] = None
    embedTheme: Optional[str] = None  # camelCase alias

    @field_validator('elias_url')
    @classmethod
    def elias_url_https(cls, v: Optional[str]) -> Optional[str]:
        if not v or not str(v).strip():
            return None
        v = str(v).strip().rstrip('/')
        if not v.startswith(('https://', 'http://')):
            raise ValueError('elias_url must be https:// or http://')
        return v


def dict_to_chatbot(data: Dict[str, Any]) -> Chatbot:
    """Convert database dict to Chatbot model"""
    return Chatbot(
        id=data['id'],
        name=data['name'],
        type=data['type'],
        status=data['status'],
        users=data.get('users', 0),
        accuracy=data.get('accuracy', 'N/A'),
        createdAt=data['createdAt'],
        updatedAt=data['updatedAt'],
        config=ChatbotConfig(**data['config']),
        data=ChatbotData(**data['data'])
    )


def chatbot_to_dict(bot: Chatbot) -> Dict[str, Any]:
    """Convert Chatbot model to dict for database"""
    return {
        'id': bot.id,
        'name': bot.name,
        'type': bot.type,
        'status': bot.status,
        'users': bot.users,
        'accuracy': bot.accuracy,
        'createdAt': bot.createdAt,
        'updatedAt': bot.updatedAt,
        'config': bot.config.dict(),
        'data': bot.data.dict()
    }


# Seed initial data if database is empty
def seed_initial_data():
    """Seed database with initial chatbots if empty"""
    existing = ChatbotDB.get_all()
    if len(existing) == 0:
        logger.info("[Chatbots] Seeding initial data...")
        now = datetime.utcnow().isoformat() + "Z"
        
        initial_bots = [
            {
                'id': 'cb_1',
                'name': 'SupportBot',
                'type': 'Customer Service',
                'status': 'Active',
                'users': 1240,
                'accuracy': '94%',
                'createdAt': '2024-01-15T10:30:00Z',
                'updatedAt': now,
                'config': ChatbotConfig().dict(),
                'data': ChatbotData(
                    conversations=15420,
                    totalMessages=89234,
                    avgResponseTime=120,
                    lastActive=now,
                    trainingData=['customer_support_v1', 'faq_data'],
                    intents=['greeting', 'complaint', 'inquiry', 'feedback'],
                ).dict(),
            },
            {
                'id': 'cb_2',
                'name': 'SalesAssistant',
                'type': 'Sales',
                'status': 'Active',
                'users': 850,
                'accuracy': '91%',
                'createdAt': '2024-02-20T14:15:00Z',
                'updatedAt': now,
                'config': ChatbotConfig().dict(),
                'data': ChatbotData(
                    conversations=8920, 
                    totalMessages=45123, 
                    avgResponseTime=95
                ).dict(),
            }
        ]
        
        for bot in initial_bots:
            ChatbotDB.create(bot)
        logger.info(f"[Chatbots] Seeded {len(initial_bots)} initial chatbots")

# Run seed on import
# Run seed on import
seed_initial_data()


@router.get("/analytics")
async def get_analytics_overview(
    view_as_user_id: Optional[str] = Query(default=None, description="Admin only: view as specific user"),
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """Get aggregated analytics for all user's chatbots. Sales users see only their own."""
    from services.database.batch_queries import BatchQueries
    from collections import defaultdict

    # Determine whose chatbots to fetch (partners: account scope only)
    if is_super_or_admin(current_user):
        if view_as_user_id:
            bots = ChatbotDB.get_by_user(view_as_user_id)
        else:
            bots = ChatbotDB.get_all()
    else:
        account_owner_ids = get_chatbot_account_owner_ids(current_user)
        bots = ChatbotDB.get_by_owner_ids(account_owner_ids)
    
    # OPTIMIZATION: Use batch query instead of N+1 pattern
    chatbot_ids = [bot['id'] for bot in bots]
    stats_by_chatbot = BatchQueries.get_chatbot_stats_batch(chatbot_ids)
    
    monthly_volume = defaultdict(int)
    
    # Aggregate stats from batch results
    for chatbot_id, stats in stats_by_chatbot.items():
        for entry in stats:
            month = entry.get('month')
            count = entry.get('count', 0)
            if month:
                monthly_volume[month] += count
    
    # Sort by month
    sorted_volume = [{"month": k, "count": v} for k, v in sorted(monthly_volume.items())]
    
    return {
        "monthly_volume": sorted_volume,
        "total_chatbots": len(bots)
    }


@router.get("/", response_model=List[Dict[str, Any]])
async def get_chatbots(
    view_as_user_id: Optional[str] = Query(default=None, description="Admin only: view as specific user"),
    limit: int = Query(default=50, ge=1, le=100, description="Number of chatbots per page"),
    offset: int = Query(default=0, ge=0, description="Number of chatbots to skip"),
    current_user: dict = Depends(get_current_user)
):
    """Get all chatbots for the current user. Partners see only their account's chatbots. Admins can use view_as_user_id."""
    # Admins: all or view_as
    if is_super_or_admin(current_user):
        if view_as_user_id:
            bots = ChatbotDB.get_by_user(view_as_user_id, limit=limit, offset=offset)
        else:
            bots = ChatbotDB.get_all(limit=limit, offset=offset)
    else:
        # Partners and users: only chatbots from their account (strict isolation)
        account_owner_ids = get_chatbot_account_owner_ids(current_user)
        bots = ChatbotDB.get_by_owner_ids(account_owner_ids, limit=limit, offset=offset)
    
    # Return minimal fields for list view (optimize payload size)
    return [
        {
            'id': bot['id'],
            'name': bot['name'],
            'type': bot.get('type', 'General Purpose'),
            'status': bot.get('status', 'Draft'),
            'users': bot.get('users', 0),
            'createdAt': bot.get('createdAt'),
            'updatedAt': bot.get('updatedAt')
        }
        for bot in bots
    ]


@router.get("/public/{chatbot_id}")
async def get_chatbot_public(chatbot_id: str) -> Dict[str, Any]:
    """Public endpoint for widget to fetch chatbot config - no auth required"""
    bot = ChatbotDB.get_by_id(chatbot_id)
    if bot:
        # SEC-004: Only expose widget-necessary fields, not internal config
        config = bot.get('config') or {}
        if not isinstance(config, dict):
            config = {}
        # Support both camelCase and snake_case so widget always gets enableLiveChat
        enable_live_chat = config.get('enableLiveChat', config.get('enable_live_chat', False))
        embed_theme = config.get('embedTheme', config.get('embed_theme', 'professional'))
        return {
            "id": bot['id'],
            "name": bot['name'],
            "config": {
                "welcomeMessage": config.get('welcomeMessage', 'Hello! How can I assist you today?'),
                "language": config.get('language', 'en'),
                "supportedLanguages": config.get('supportedLanguages', ['en']),
                "customStyles": config.get('customStyles', {}),
                "enableLiveChat": bool(enable_live_chat),
                "embedTheme": embed_theme,
            }
        }
    raise HTTPException(status_code=404, detail="Chatbot not found")


@router.get("/{chatbot_id}", response_model=Chatbot)
async def get_chatbot(chatbot_id: str, current_user: dict = Depends(get_current_user)):
    """Get a single chatbot by ID. Partners can only access chatbots from their account."""
    from shared.router_utils import get_resource_or_404

    bot = get_resource_or_404(ChatbotDB.get_by_id, chatbot_id, "Chatbot")
    if not can_access_chatbot(current_user, bot):
        raise HTTPException(status_code=403, detail="Access denied to this chatbot")
    return dict_to_chatbot(bot)


@router.post("/", response_model=Dict[str, Any])
async def create_chatbot(
    request: CreateChatbotRequest,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """Create a new chatbot"""
    now = datetime.utcnow().isoformat() + "Z"
    
    chatbot_data = {
        "id": f"bot_{uuid.uuid4().hex[:12]}",
        "name": request.name or "My Chatbot",
        "type": request.type or "support",
        "status": "Draft",
        "owner_id": current_user['id'],
        "users": 0,
        "accuracy": "N/A",
        "createdAt": now,
        "updatedAt": now,
        "config": request.config.dict() if request.config else ChatbotConfig().dict(),
        "data": ChatbotData().dict()
    }
    
    new_bot = ChatbotDB.create(chatbot_data)
    
    # Increment usage counter
    usage_service.increment_chatbot_count(current_user['id'])

    # Handle automatic integration setup if provided and bot type matches
    if request.type == "Booking & Reservations" and request.integration_setup:
        try:
            setup_data = request.integration_setup
            base_url = 'http://51.20.126.15/admin/booking-handler.php'
            if setup_data.get('inventoryApiKey'):
                inv_config = {
                    'inventory_api_key': setup_data.get('inventoryApiKey'),
                    'api_base_url': setup_data.get('inventoryApiUrl') or base_url,
                    'inventory_api_url': setup_data.get('inventoryApiUrl') or base_url,
                }
                IntegrationDB.create({
                    'chatbot_id': new_bot['id'],
                    'integration_type': 'universal_inventory',
                    'name': 'Inventory',
                    'config': inv_config,
                    'metadata': {'created_via': 'chatbot_setup_wizard'},
                    'status': 'active'
                })
                print(f"[Chatbots] Auto-created Universal Inventory for bot {new_bot['id']}")
            if setup_data.get('bookingApiKey'):
                book_config = {
                    'booking_api_key': setup_data.get('bookingApiKey'),
                    'api_base_url': setup_data.get('bookingApiUrl') or setup_data.get('inventoryApiUrl') or base_url,
                    'booking_api_url': setup_data.get('bookingApiUrl') or setup_data.get('inventoryApiUrl') or base_url,
                    'checkout_url': setup_data.get('checkoutUrl'),
                }
                IntegrationDB.create({
                    'chatbot_id': new_bot['id'],
                    'integration_type': 'universal_booking',
                    'name': 'Booking',
                    'config': book_config,
                    'metadata': {'created_via': 'chatbot_setup_wizard'},
                    'status': 'active'
                })
                print(f"[Chatbots] Auto-created Universal Booking for bot {new_bot['id']}")
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"[Chatbots] Failed to auto-create integration: {e}")
    
    return new_bot


@router.put("/{chatbot_id}", response_model=Chatbot)
async def update_chatbot(
    chatbot_id: str,
    updates: UpdateChatbotRequest,
    current_user: dict = Depends(get_current_user)
) -> Chatbot:
    """Update an existing chatbot. Partners can only update chatbots from their account."""
    from shared.router_utils import get_resource_or_404

    existing = get_resource_or_404(ChatbotDB.get_by_id, chatbot_id, "Chatbot")
    if not can_access_chatbot(current_user, existing):
        raise HTTPException(status_code=403, detail="Access denied to this chatbot")
    
    update_dict = updates.dict(exclude_unset=True)
    
    # Convert Pydantic models to dicts
    if 'config' in update_dict and update_dict['config'] is not None:
        update_dict['config'] = update_dict['config'].dict() if hasattr(update_dict['config'], 'dict') else update_dict['config']
    if 'data' in update_dict and update_dict['data'] is not None:
        update_dict['data'] = update_dict['data'].dict() if hasattr(update_dict['data'], 'dict') else update_dict['data']
    
    updated = ChatbotDB.update(chatbot_id, update_dict)
    
    if updated:
        # Invalidate caches so widget/NLP get fresh config (e.g. enableLiveChat)
        try:
            from services.database.cached_queries import CachedQueries
            CachedQueries.invalidate_chatbot(chatbot_id)
            from services.cache_service import response_cache
            response_cache.invalidate(chatbot_id)
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning("Chatbot cache invalidation failed: %s", e)
        return dict_to_chatbot(updated)
    raise HTTPException(status_code=404, detail="Chatbot not found")


@router.patch("/{chatbot_id}", response_model=Chatbot)
async def patch_chatbot(
    chatbot_id: str,
    body: PatchChatbotEliasRequest,
    current_user: dict = Depends(get_current_user)
) -> Chatbot:
    """Partial update (e.g. Elias AI fields only). Merges into config. JWT auth."""
    from shared.router_utils import get_resource_or_404

    existing = get_resource_or_404(ChatbotDB.get_by_id, chatbot_id, "Chatbot")
    if not can_access_chatbot(current_user, existing):
        raise HTTPException(status_code=403, detail="Access denied to this chatbot")

    patch_dict = body.dict(exclude_unset=True)
    if not patch_dict:
        return dict_to_chatbot(existing)

    config = dict(existing.get('config') or {})
    if 'elias_enabled' in patch_dict:
        config['elias_enabled'] = patch_dict['elias_enabled']
    if 'elias_url' in patch_dict:
        config['elias_url'] = patch_dict['elias_url']
    if 'elias_bot_name' in patch_dict:
        config['elias_bot_name'] = patch_dict['elias_bot_name']
    if 'actions_base_url' in patch_dict:
        config['actions_base_url'] = patch_dict['actions_base_url']
    if 'embed_theme' in patch_dict:
        config['embed_theme'] = patch_dict['embed_theme']
        config['embedTheme'] = patch_dict['embed_theme']
    if 'embedTheme' in patch_dict:
        config['embedTheme'] = patch_dict['embedTheme']
        config['embed_theme'] = patch_dict['embedTheme']

    updated = ChatbotDB.update(chatbot_id, {'config': config})
    if updated:
        try:
            from services.database.cached_queries import CachedQueries
            CachedQueries.invalidate_chatbot(chatbot_id)
            from services.cache_service import response_cache
            response_cache.invalidate(chatbot_id)
        except Exception as e:
            logging.getLogger(__name__).warning("Chatbot cache invalidation failed: %s", e)
        return dict_to_chatbot(updated)
    raise HTTPException(status_code=404, detail="Chatbot not found")


@router.delete("/{chatbot_id}")
async def delete_chatbot(
    chatbot_id: str,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """Delete a chatbot. Partners can only delete chatbots from their account."""
    from shared.router_utils import get_resource_or_404

    existing = get_resource_or_404(ChatbotDB.get_by_id, chatbot_id, "Chatbot")
    if not can_access_chatbot(current_user, existing):
        raise HTTPException(status_code=403, detail="Access denied to this chatbot")

    success = ChatbotDB.delete(chatbot_id)
    if success:
        # Decrement usage count
        usage_service.decrement_chatbot_count(current_user['id'])
        
    return {"success": success}


# Conversation Studio - flow overrides
class ConversationFlowUpdate(BaseModel):
    flow_json: Dict[str, Any] = Field(default_factory=dict, description="Flow JSON: intentOverrides, nodes, edges")


@router.get("/{chatbot_id}/conversation-flow")
async def get_conversation_flow(
    chatbot_id: str,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """Get conversation flow for a chatbot (Conversation Studio)."""
    from shared.router_utils import get_resource_or_404
    from services.database.conversation_flows import get_flow

    bot = get_resource_or_404(ChatbotDB.get_by_id, chatbot_id, "Chatbot")
    if not can_access_chatbot(current_user, bot):
        raise HTTPException(status_code=403, detail="Access denied to this chatbot")
    flow = get_flow(chatbot_id)
    if not flow:
        return {"chatbot_id": chatbot_id, "flow_json": {}, "version": 1, "updated_at": None}
    return flow


@router.post("/{chatbot_id}/conversation-flow")
async def save_conversation_flow(
    chatbot_id: str,
    body: ConversationFlowUpdate,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """Save conversation flow for a chatbot (Conversation Studio)."""
    from shared.router_utils import get_resource_or_404
    from services.database.conversation_flows import save_flow

    bot = get_resource_or_404(ChatbotDB.get_by_id, chatbot_id, "Chatbot")
    if not can_access_chatbot(current_user, bot):
        raise HTTPException(status_code=403, detail="Access denied to this chatbot")
    return save_flow(chatbot_id, body.flow_json)


@router.post("/{chatbot_id}/avatar")
async def upload_avatar(
    chatbot_id: str,
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
) -> Dict[str, str]:
    """Upload a profile picture/avatar for a chatbot. Partners: account scope only."""
    # SEC-009: File upload security validation
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB max

    from shared.router_utils import get_resource_or_404
    bot = get_resource_or_404(ChatbotDB.get_by_id, chatbot_id, "Chatbot")
    if not can_access_chatbot(current_user, bot):
        raise HTTPException(status_code=403, detail="Access denied to this chatbot")
    
    # Validate file extension
    allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
    
    # Handle Mac-specific file issues (e.g., files with no extension, .DS_Store, etc.)
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided")
    
    # Remove any path components and get just the filename
    filename_clean = os.path.basename(file.filename)
    
    # Skip Mac metadata files
    if filename_clean.startswith('.') or filename_clean == '.DS_Store':
        raise HTTPException(status_code=400, detail="System files are not allowed")
    
    file_ext = filename_clean.split('.')[-1].lower() if '.' in filename_clean else ''
    if not file_ext or file_ext not in allowed_extensions:
        raise HTTPException(
            status_code=400, 
            detail=f"File type '{file_ext}' not allowed. Use: {', '.join(allowed_extensions)}"
        )
    
    # Read file content for size and magic byte validation
    content = await file.read()
    
    # Validate file size
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(status_code=400, detail=f"File too large. Maximum size is {MAX_FILE_SIZE // (1024*1024)}MB")
    
    # Validate magic bytes (file signature)
    magic_bytes = {
        b'\x89PNG': 'png',
        b'\xff\xd8\xff': 'jpg',  # JPEG
        b'GIF87a': 'gif',
        b'GIF89a': 'gif',
        b'RIFF': 'webp'  # WebP starts with RIFF
    }
    
    is_valid_file = False
    for magic, ext_type in magic_bytes.items():
        if content.startswith(magic):
            is_valid_file = True
            break
    
    if not is_valid_file:
        raise HTTPException(status_code=400, detail="Invalid file content. File does not match expected image format.")
    
    # Save file asynchronously (non-blocking)
    from services.async_file_ops import async_write_file
    
    # SECURITY: Sanitize chatbot_id to prevent path traversal attacks
    # Remove any path separators and dangerous characters
    chatbot_id_clean = os.path.basename(chatbot_id).replace('/', '').replace('\\', '').replace('..', '')
    if not chatbot_id_clean or chatbot_id_clean != chatbot_id:
        raise HTTPException(status_code=400, detail="Invalid chatbot ID format")
    
    filename = f"{chatbot_id_clean}.{file_ext}"
    file_path = os.path.join(AVATARS_DIR, filename)
    
    # SECURITY: Verify final path is within AVATARS_DIR (prevent path traversal)
    real_path = os.path.realpath(file_path)
    real_dir = os.path.realpath(AVATARS_DIR)
    if not real_path.startswith(real_dir):
        raise HTTPException(status_code=400, detail="Invalid file path")
    
    # Ensure directory exists (in case it was deleted or volume mount issue)
    os.makedirs(AVATARS_DIR, exist_ok=True)
    
    # Use async file write (non-blocking)
    success = await async_write_file(file_path, content)
    if not success:
        import logging
        logger = logging.getLogger(__name__)
        logger.error(f"Failed to save avatar file: {file_path}")
        raise HTTPException(status_code=500, detail="Failed to save file")
    
    # Verify file was written successfully
    import logging
    logger = logging.getLogger(__name__)
    if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
        logger.error(f"File verification failed: {file_path}")
        raise HTTPException(status_code=500, detail="File was not written correctly")
    
    logger.info(f"Avatar uploaded successfully: {file_path} (size: {len(content)} bytes)")
    
    # Update chatbot config with avatar URL
    avatar_url = f"/static/avatars/{filename}"
    
    # Get current config and update avatarUrl
    current_config = bot.get('config', {})
    current_styles = current_config.get('customStyles', {})
    current_styles['avatarUrl'] = avatar_url
    current_config['customStyles'] = current_styles
    
    ChatbotDB.update(chatbot_id, {'config': current_config})
    
    return {"avatarUrl": avatar_url, "message": "Avatar uploaded successfully"}

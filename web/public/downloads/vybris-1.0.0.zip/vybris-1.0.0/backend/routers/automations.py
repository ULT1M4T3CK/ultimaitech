"""
Automations Router
Manages automation rules for sales pipeline
"""

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from services.database import AutomationDB, CRMLeadDB, PipelineDB
from routers.auth import get_current_user

router = APIRouter(prefix="/api/v1/automations", tags=["automations"])


# ============================================================================
# Trigger and Action Types
# ============================================================================

TRIGGER_TYPES = {
    'stage_change': 'When lead moves to a stage',
    'score_threshold': 'When qualification score reaches threshold',
    'time_in_stage': 'When lead has been in stage for X days',
    'lead_created': 'When new lead is created',
    'lead_tier_change': 'When lead tier changes',
    # Chat-driven triggers (Phase 1.3)
    'on_user_intent': 'When user intent matches',
    'on_handoff': 'When handoff to live agent is requested',
    'on_sentiment': 'When sentiment is negative',
}

ACTION_TYPES = {
    'move_stage': 'Move lead to a different stage',
    'change_priority': 'Change lead priority',
    'send_notification': 'Send notification to owner',
    'assign_owner': 'Assign to specific owner',
    'add_tag': 'Add tag to lead',
    'update_field': 'Update a lead field',
    'run_workflow': 'Run a workflow',
}


# ============================================================================
# Pydantic Models
# ============================================================================

class AutomationRuleCreate(BaseModel):
    """Create an automation rule"""
    name: str
    description: Optional[str] = None
    trigger_type: str
    trigger_config: Dict[str, Any] = {}
    action_type: str
    action_config: Dict[str, Any] = {}
    active: bool = True


class AutomationRuleUpdate(BaseModel):
    """Update an automation rule"""
    name: Optional[str] = None
    description: Optional[str] = None
    trigger_type: Optional[str] = None
    trigger_config: Optional[Dict[str, Any]] = None
    action_type: Optional[str] = None
    action_config: Optional[Dict[str, Any]] = None
    active: Optional[bool] = None


# ============================================================================
# API Endpoints
# ============================================================================

@router.get("/types")
async def get_automation_types():
    """Get available trigger and action types"""
    return {
        "trigger_types": [{"key": k, "label": v} for k, v in TRIGGER_TYPES.items()],
        "action_types": [{"key": k, "label": v} for k, v in ACTION_TYPES.items()]
    }


@router.get("/")
async def get_automations(
    current_user: dict = Depends(get_current_user),
    active_only: bool = False
):
    """Get all automation rules for the current user"""
    rules = AutomationDB.get_by_owner(current_user['id'], active_only=active_only)
    return {"rules": rules}


@router.post("/")
async def create_automation(
    request: AutomationRuleCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create a new automation rule"""
    # Validate trigger type
    if request.trigger_type not in TRIGGER_TYPES:
        raise HTTPException(status_code=400, detail=f"Invalid trigger type: {request.trigger_type}")
    
    # Validate action type
    if request.action_type not in ACTION_TYPES:
        raise HTTPException(status_code=400, detail=f"Invalid action type: {request.action_type}")
    
    rule_data = request.dict()
    rule_data['owner_id'] = current_user['id']
    
    rule = AutomationDB.create(rule_data)
    return rule


@router.get("/{rule_id}")
async def get_automation(
    rule_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get a specific automation rule"""
    rule = AutomationDB.get_by_id(rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    
    if rule.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    return rule


@router.put("/{rule_id}")
async def update_automation(
    rule_id: str,
    request: AutomationRuleUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update an automation rule"""
    rule = AutomationDB.get_by_id(rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    
    if rule.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    updates = request.dict(exclude_unset=True)
    
    # Validate if changing trigger/action types
    if 'trigger_type' in updates and updates['trigger_type'] not in TRIGGER_TYPES:
        raise HTTPException(status_code=400, detail=f"Invalid trigger type")
    if 'action_type' in updates and updates['action_type'] not in ACTION_TYPES:
        raise HTTPException(status_code=400, detail=f"Invalid action type")
    
    updated = AutomationDB.update(rule_id, updates)
    return updated


@router.delete("/{rule_id}")
async def delete_automation(
    rule_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete an automation rule"""
    rule = AutomationDB.get_by_id(rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    
    if rule.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    AutomationDB.delete(rule_id)
    return {"success": True}


@router.post("/{rule_id}/toggle")
async def toggle_automation(
    rule_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Toggle automation rule active state"""
    rule = AutomationDB.get_by_id(rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    
    if rule.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    updated = AutomationDB.update(rule_id, {'active': not rule.get('active', True)})
    return updated


# ============================================================================
# Automation Execution (called internally by other services)
# ============================================================================

def execute_automation_actions(lead_id: str, trigger_type: str, trigger_data: Dict[str, Any]):
    """
    Execute all matching automation rules for a trigger.
    Called internally when events occur (stage changes, etc.)
    """
    lead = CRMLeadDB.get_by_id(lead_id)
    if not lead:
        return
    
    # Get the owner's automation rules for this trigger
    owner_id = lead.get('account_owner_id')
    if not owner_id:
        return

    rules = AutomationDB.get_by_owner(owner_id, active_only=True)
    rules = [r for r in rules if r.get('trigger_type') == trigger_type]

    for rule in rules:
        # Check if trigger conditions match
        if not _check_trigger_conditions(rule, lead, trigger_data):
            continue
        
        # Execute the action
        try:
            result = _execute_action(rule, lead, trigger_data)
            AutomationDB.log_execution(
                rule_id=rule['id'],
                lead_id=lead_id,
                trigger_data=trigger_data,
                action_result=result,
                status='success'
            )
            AutomationDB.increment_run_count(rule['id'])
        except Exception as e:
            AutomationDB.log_execution(
                rule_id=rule['id'],
                lead_id=lead_id,
                trigger_data=trigger_data,
                action_result={},
                status='error',
                error_message=str(e)
            )


def _check_trigger_conditions(rule: Dict, lead: Dict, trigger_data: Dict) -> bool:
    """Check if the trigger conditions match"""
    trigger_config = rule.get('trigger_config') or rule.get('trigger_conditions')
    if isinstance(trigger_config, list):
        trigger_config = trigger_config[0] if trigger_config else {}
    trigger_config = trigger_config or {}
    trigger_type = rule.get('trigger_type')
    
    if trigger_type == 'stage_change':
        # Check if lead moved to the target stage
        target_stage = trigger_config.get('target_stage')
        if target_stage and trigger_data.get('new_stage') != target_stage:
            return False
    
    elif trigger_type == 'score_threshold':
        threshold = trigger_config.get('threshold', 0)
        direction = trigger_config.get('direction', 'above')  # 'above' or 'below'
        score = lead.get('qualification_score', 0)
        if direction == 'above' and score < threshold:
            return False
        if direction == 'below' and score > threshold:
            return False
    
    elif trigger_type == 'lead_tier_change':
        target_tier = trigger_config.get('target_tier')
        if target_tier and trigger_data.get('new_tier') != target_tier:
            return False
    
    return True


def _execute_action(rule: Dict, lead: Dict, trigger_data: Dict[str, Any] = None) -> Dict[str, Any]:
    """Execute an automation action"""
    action_type = rule.get('action_type')
    action_config = rule.get('action_config', {})
    # Support actions stored as list in DB
    actions_list = rule.get('actions', [])
    if actions_list and isinstance(actions_list[0], dict):
        action_type = action_type or actions_list[0].get('action_type')
        action_config = action_config or actions_list[0].get('action_config', {})
    trigger_data = trigger_data or {}
    lead_id = lead['id']
    
    result = {'action': action_type}
    
    if action_type == 'move_stage':
        new_status = action_config.get('target_stage')
        if new_status:
            CRMLeadDB.update(lead_id, {'status': new_status})
            result['new_status'] = new_status
    
    elif action_type == 'change_priority':
        new_priority = action_config.get('priority')
        if new_priority:
            CRMLeadDB.update(lead_id, {'priority': new_priority})
            result['new_priority'] = new_priority
    
    elif action_type == 'update_field':
        field = action_config.get('field')
        value = action_config.get('value')
        if field:
            CRMLeadDB.update(lead_id, {field: value})
            result['updated_field'] = field

    elif action_type == 'run_workflow':
        workflow_id = action_config.get('workflow_id')
        chatbot_id = rule.get('chatbot_id')
        if workflow_id and chatbot_id:
            import asyncio
            from services.workflow_engine import run_workflow
            try:
                wf_result = asyncio.run(run_workflow(
                    workflow_id, chatbot_id,
                    {"lead_id": lead_id, **trigger_data} if trigger_data else {"lead_id": lead_id},
                ))
                result['workflow_result'] = wf_result
            except Exception as e:
                result['workflow_error'] = str(e)
        else:
            result['workflow_skipped'] = 'workflow_id or chatbot_id missing'

    # TODO: Implement notification sending, owner assignment, etc.

    return result

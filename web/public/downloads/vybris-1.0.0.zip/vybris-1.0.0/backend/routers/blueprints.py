"""
Blueprint Router (Phase 4 - Marketplace MVP)
Export/import chatbot templates; list public blueprints.
"""

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List

from routers.auth import get_current_user
from shared.permissions import can_access_chatbot
from services.database import BlueprintDB, ChatbotDB

router = APIRouter(prefix="/api/v1/blueprints", tags=["blueprints"])


class BlueprintCreate(BaseModel):
    name: str
    description: Optional[str] = None
    category: str = "general"
    is_public: bool = False
    chatbot_id: str


class BlueprintUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    is_public: Optional[bool] = None


class BlueprintApply(BaseModel):
    name: Optional[str] = None  # Name for new chatbot


@router.get("/")
async def list_my_blueprints(current_user: dict = Depends(get_current_user)):
    """List blueprints owned by the current user."""
    items = BlueprintDB.get_by_owner(current_user["id"])
    return {"blueprints": items}


@router.get("/public")
async def list_public_blueprints(category: Optional[str] = None, limit: int = 50):
    """List public blueprints (no auth required for read)."""
    items = BlueprintDB.list_public(category=category, limit=limit)
    return {"blueprints": items}


@router.post("/")
async def create_blueprint(
    body: BlueprintCreate,
    current_user: dict = Depends(get_current_user),
):
    """Create a blueprint from an existing chatbot."""
    if not can_access_chatbot(current_user, body.chatbot_id):
        raise HTTPException(status_code=403, detail="Not authorized to access this chatbot")

    bot = ChatbotDB.get_by_id(body.chatbot_id)
    if not bot:
        raise HTTPException(status_code=404, detail="Chatbot not found")

    config = {
        "name": bot.get("name"),
        "type": bot.get("type"),
        "config": bot.get("config", {}),
    }
    bp = BlueprintDB.create({
        "owner_id": current_user["id"],
        "name": body.name,
        "description": body.description,
        "category": body.category,
        "config": config,
        "is_public": body.is_public,
    })
    if not bp:
        raise HTTPException(status_code=500, detail="Failed to create blueprint")
    return bp


@router.get("/{blueprint_id}")
async def get_blueprint(
    blueprint_id: str,
    current_user: dict = Depends(get_current_user),
):
    """Get a blueprint by ID. Must be owner or blueprint must be public."""
    bp = BlueprintDB.get_by_id(blueprint_id)
    if not bp:
        raise HTTPException(status_code=404, detail="Blueprint not found")
    if bp["owner_id"] != current_user["id"] and not bp.get("is_public"):
        raise HTTPException(status_code=403, detail="Not authorized")
    return bp


@router.put("/{blueprint_id}")
async def update_blueprint(
    blueprint_id: str,
    body: BlueprintUpdate,
    current_user: dict = Depends(get_current_user),
):
    """Update a blueprint (owner only)."""
    bp = BlueprintDB.get_by_id(blueprint_id)
    if not bp:
        raise HTTPException(status_code=404, detail="Blueprint not found")
    if bp["owner_id"] != current_user["id"]:
        raise HTTPException(status_code=403, detail="Not authorized")

    updates = {k: v for k, v in body.model_dump(exclude_unset=True).items()}
    if not updates:
        return bp
    updated = BlueprintDB.update(blueprint_id, updates)
    return updated or bp


@router.delete("/{blueprint_id}")
async def delete_blueprint(
    blueprint_id: str,
    current_user: dict = Depends(get_current_user),
):
    """Delete a blueprint (owner only)."""
    bp = BlueprintDB.get_by_id(blueprint_id)
    if not bp:
        raise HTTPException(status_code=404, detail="Blueprint not found")
    if bp["owner_id"] != current_user["id"]:
        raise HTTPException(status_code=403, detail="Not authorized")
    BlueprintDB.delete(blueprint_id)
    return {"message": "Blueprint deleted"}


@router.post("/{blueprint_id}/apply")
async def apply_blueprint(
    blueprint_id: str,
    body: BlueprintApply,
    current_user: dict = Depends(get_current_user),
):
    """Create a new chatbot from a blueprint."""
    import uuid
    bp = BlueprintDB.get_by_id(blueprint_id)
    if not bp:
        raise HTTPException(status_code=404, detail="Blueprint not found")
    if bp["owner_id"] != current_user["id"] and not bp.get("is_public"):
        raise HTTPException(status_code=403, detail="Not authorized")

    config = bp.get("config", {})
    bot_config = config.get("config", {})
    name = body.name or (config.get("name") or "New Chatbot") + " (copy)"

    new_bot = ChatbotDB.create({
        "id": f"bot_{uuid.uuid4().hex[:12]}",
        "owner_id": current_user["id"],
        "name": name,
        "type": config.get("type", "General Purpose"),
        "config": bot_config,
    })
    if not new_bot:
        raise HTTPException(status_code=500, detail="Failed to create chatbot")
    return {"chatbot_id": new_bot["id"], "name": new_bot.get("name")}

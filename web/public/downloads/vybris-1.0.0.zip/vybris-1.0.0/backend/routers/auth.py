"""
Auth Router for VYBR!S
Provides authentication endpoints and RBAC helpers
"""

from fastapi import APIRouter, Depends, HTTPException, status, Response, Request, Cookie
from fastapi.security import OAuth2PasswordRequestForm
from typing import Annotated, Callable, Optional, Union, List
from datetime import datetime, timedelta
from functools import wraps
from pydantic import BaseModel
import os
import logging
import hashlib
import secrets

logger = logging.getLogger(__name__)

from services.auth_service import (
    create_access_token, 
    create_refresh_token,
    get_password_hash, 
    verify_password, 
    decode_access_token,
    decode_refresh_token,
    ACCESS_TOKEN_EXPIRE_MINUTES,
    REFRESH_TOKEN_EXPIRE_DAYS,
    is_user_blacklisted,
    validate_password_strength,
    create_session,
    revoke_all_user_sessions,
    revoke_session,
    get_user_sessions,
    record_auth_failure,
    reset_auth_failures,
    mark_refresh_token_used
)
from services.database import UserDB, LogDB

router = APIRouter(prefix="/api/v1", tags=["auth"])


# ============================================================================
# Initial Admin Setup
# ============================================================================

def ensure_admin_exists():
    """Ensure at least one admin user exists"""
    import os
    
    users = UserDB.get_all()
    admin_exists = any(u.get('role') == 'admin' and u.get('status') == 'active' for u in users)
    
    if not admin_exists:
        # Check if there's a pending admin
        pending_admin = next((u for u in users if u.get('role') == 'admin'), None)
        if not pending_admin:
            logger.info("No admin user found. Creating default admin...")
            
            # SECURITY: Admin password MUST come from environment variable
            admin_password = os.getenv('ADMIN_PASSWORD')
            if not admin_password:
                logger.error("ADMIN_PASSWORD environment variable not set!")
                logger.error("Please set ADMIN_PASSWORD in your .env file")
                logger.error("Generate a secure password with: python scripts/generate_secrets.py")
                raise ValueError("ADMIN_PASSWORD environment variable is required for initial setup")
            
            # Validate password strength
            if len(admin_password) < 12:
                raise ValueError("ADMIN_PASSWORD must be at least 12 characters long")
            
            import uuid
            admin_email = os.getenv('ADMIN_EMAIL', 'admin@ultimaitech.com')
            
            UserDB.create({
                'id': f"user_{uuid.uuid4().hex[:12]}",
                'username': 'admin',
                'email': admin_email,
                'hashed_password': get_password_hash(admin_password),
                'full_name': 'System Administrator',
                'role': 'admin',
                'status': 'active'
            })
            logger.info(f"Default admin created: admin / {admin_email}")
            logger.warning("IMPORTANT: Change the admin password after first login!")
        else:
            logger.info(f"Pending admin exists: {pending_admin.get('email')}")


# Test partner account for testing partner features
# Setup wizards (branding onboarding) restart on every login for this account
TEST_PARTNER_EMAIL = "test@ultimaitech.com"


def ensure_test_partner_exists():
    """Create test partner account if it doesn't exist. Used for testing partner features.
    The setup wizard (branding onboarding) is reset on every login for this account.
    Set ENABLE_TEST_PARTNER=false in .env to disable in production."""
    if os.getenv('ENABLE_TEST_PARTNER', 'true').lower() in ('false', '0', 'no'):
        return
    existing = UserDB.get_by_email(TEST_PARTNER_EMAIL)
    if not existing:
        import uuid
        logger.info("Creating test partner account for partner feature testing...")
        UserDB.create({
            'id': f"user_{uuid.uuid4().hex[:12]}",
            'username': 'testpartner',
            'email': TEST_PARTNER_EMAIL,
            'hashed_password': get_password_hash('test123!'),
            'full_name': 'Test Partner',
            'role': 'partner',
            'status': 'active',
            'partner_id': None,
        })
        logger.info(f"Test partner account created: {TEST_PARTNER_EMAIL} / test123!")


# Run on import
try:
    ensure_admin_exists()
except Exception as e:
    logger.warning(f"Could not check/create admin: {e}")

try:
    ensure_test_partner_exists()
except Exception as e:
    logger.warning(f"Could not check/create test partner: {e}")


# ============================================================================
# Auth Dependencies
# ============================================================================

async def get_current_user(request: Request):
    """
    Get current user from JWT token.
    Checks Authorization header first. If that fails (invalid/expired), 
    falls back to cookie for backward compatibility.
    """
    token = None
    token_from_header = False
    
    # Try Authorization header first (for API clients)
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        token = auth_header.replace("Bearer ", "")
        token_from_header = True
    
    # Validation function
    def validate_token(t):
        if not t: return None
        td = decode_access_token(t)
        if not td or not td.username: return None
        return td

    token_data = validate_token(token)

    # SEC-009: Robust Fallback
    # If header token was present but invalid/expired, try the cookie
    # This fixes issues where frontend has stale localStorage token but valid HttpOnly cookie
    if not token_data and token_from_header:
        token_cookie = request.cookies.get("access_token")
        if token_cookie:
            # Handle quoted cookie values and Bearer prefix
            backup_token = token_cookie.strip('"').replace("Bearer ", "")
            token_data = validate_token(backup_token)

    # Fall back to cookie if no header token was provided at all
    if not token and not token_data:
        token_cookie = request.cookies.get("access_token")
        if token_cookie:
            # Handle quoted cookie values and Bearer prefix
            token = token_cookie.strip('"').replace("Bearer ", "")
            token_data = validate_token(token)
        else:
            # Log when no cookie is found for debugging
            logger.debug(f"No access_token cookie found. Available cookies: {list(request.cookies.keys())}")
            logger.debug(f"Request headers - Origin: {request.headers.get('Origin')}, Host: {request.headers.get('Host')}")
    
    if not token_data:
        logger.warning(f"Authentication failed - no valid token found. Cookies: {list(request.cookies.keys())}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
        )
    
    # Get user from database
    user = UserDB.get_by_username(token_data.username)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )
    
    # Check if user is blacklisted (manual admin action)
    if user.get('is_blacklisted'):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Account has been suspended. Please contact an administrator.",
        )
    
    if user.get('status') != 'active':
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is not active"
        )
    
    return user


def require_role(required_role: Union[str, List[str]]):
    """Dependency factory for role-based access control"""
    
    # Define role hierarchy (higher number = more privileges)
    role_levels = {
        'viewer': 1,
        'sales': 2,
        'editor': 3,
        'partner': 4,
        'admin': 4,
        'super_admin': 5
    }
    
    async def role_checker(request: Request):
        user = await get_current_user(request)
        user_role = user.get('role', 'viewer')
        
        user_level = role_levels.get(user_role, 0)
        
        if isinstance(required_role, list):
            # If list provided, user must have one of these roles OR be super_admin
            if user_role not in required_role and user_level < 5:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"This action requires one of the following roles: {', '.join(required_role)}"
                )
        else:
            # If single string, use hierarchical check
            required_level = role_levels.get(required_role, 999)
            
            if user_level < required_level:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"This action requires {required_role} role or higher"
                )
        
        return user
    
    return role_checker


# Convenience dependencies
require_admin = require_role("admin")
require_editor = require_role("editor")
require_viewer = require_role("viewer")


# ============================================================================
# Auth Endpoints
# ============================================================================

from middleware.rate_limit import rate_limit

def get_client_ip(request: Request) -> str:
    """Get client IP address from request, handling proxies."""
    # Check X-Forwarded-For header (set by reverse proxy)
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        # Take the first IP in the chain
        return forwarded_for.split(",")[0].strip()
    
    # Check X-Real-IP header
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip
    
    # Fallback to direct client
    if request.client:
        return request.client.host
    
    return "unknown"


def get_user_agent(request: Request) -> str:
    """Get user agent from request."""
    return request.headers.get("User-Agent", "unknown")


def _get_cookie_config(request: Request):
    """
    Resolve cookie configuration based on request origin and environment.
    Returns (cookie_kwargs, secure_flag, cookie_domain).
    """
    forwarded_proto = request.headers.get("X-Forwarded-Proto", "")
    url_str = str(request.url)
    host = request.headers.get("Host", "")
    origin = request.headers.get("Origin", "")

    is_https = (
        forwarded_proto == "https" or
        url_str.startswith("https://") or
        origin.startswith("https://")
    )

    is_production = os.getenv("ENVIRONMENT", "development").lower() == "production"
    is_ultimaitech = any("ultimaitech.com" in val for val in [url_str, host, origin] if val)
    secure_flag = is_https or (is_ultimaitech and is_production)

    logger.info(f"Cookie secure flag: {secure_flag} (is_https={is_https}, forwarded_proto={forwarded_proto}, host={host}, origin={origin}, url={url_str})")

    cookie_domain = None
    referer = request.headers.get("Referer", "")

    if any("ultimaitech.com" in val for val in [origin, host, referer, url_str] if val):
        cookie_domain = ".ultimaitech.com"
        logger.info(f"Setting cookie domain to .ultimaitech.com (origin={origin}, host={host}, referer={referer}, url={url_str})")
    elif any("localhost" in val or "127.0.0.1" in val for val in [origin, host, referer, url_str] if val):
        cookie_domain = None
        logger.info(f"No cookie domain for localhost (origin={origin}, host={host})")
    else:
        cookie_domain = None
        logger.info(f"No cookie domain set (origin={origin}, host={host}, url={url_str})")

    cookie_kwargs = {
        "samesite": "lax",
        "secure": secure_flag,
        "path": "/",
    }
    if cookie_domain:
        cookie_kwargs["domain"] = cookie_domain

    return cookie_kwargs, secure_flag, cookie_domain


def set_csrf_cookie(response: Response, request: Request, csrf_token: Optional[str] = None) -> str:
    """Set CSRF token cookie for double-submit protection."""
    cookie_kwargs, secure_flag, cookie_domain = _get_cookie_config(request)
    csrf_value = csrf_token or secrets.token_urlsafe(32)
    response.set_cookie(
        key="csrf_token",
        value=csrf_value,
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        expires=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        httponly=False,
        **cookie_kwargs
    )
    logger.info(f"Set csrf_token cookie: domain={cookie_domain}, secure={secure_flag}, path=/")
    return csrf_value


def set_auth_cookies(
    response: Response,
    request: Request,
    access_token: str,
    refresh_token: str
):
    """
    Helper function to set authentication cookies with consistent configuration.
    Handles domain, path, and security settings based on environment.
    """
    cookie_kwargs, secure_flag, cookie_domain = _get_cookie_config(request)
    auth_cookie_kwargs = {
        **cookie_kwargs,
        "httponly": True
    }
    
    # Set Access Token cookie
    try:
        response.set_cookie(
            key="access_token",
            value=access_token,  # No Bearer prefix to avoid quoting issues
            max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            expires=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            **auth_cookie_kwargs
        )
        logger.info(f"Set access_token cookie: domain={cookie_domain}, secure={secure_flag}, path=/")
    except Exception as e:
        logger.error(f"Failed to set access_token cookie: {e}")
        raise
    
    # Set Refresh Token cookie
    try:
        response.set_cookie(
            key="refresh_token",
            value=refresh_token,
            max_age=REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60,
            expires=REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60,
            **auth_cookie_kwargs
        )
        logger.info(f"Set refresh_token cookie: domain={cookie_domain}, secure={secure_flag}, path=/")
    except Exception as e:
        logger.error(f"Failed to set refresh_token cookie: {e}")
        raise
    
    # Log cookie configuration for debugging
    logger.info(f"Cookies set successfully: domain={cookie_domain}, secure={secure_flag}, path=/, samesite=lax, httponly=True")


@router.post("/login")
@rate_limit(limit=5, window=300, authenticated_limit=10)  # 5 attempts per 5 minutes
async def login(response: Response, form_data: Annotated[OAuth2PasswordRequestForm, Depends()], request: Request):
    """Authenticate user and set session cookies with enhanced security"""
    
    client_ip = get_client_ip(request)
    user_agent = get_user_agent(request)
    identifier = form_data.username  # Use username/email as identifier
    
    # Check progressive rate limiting
    is_locked, lockout_until, attempts_remaining = record_auth_failure(identifier)
    if is_locked:
        logger.warning(f"Login attempt blocked for {identifier} - account locked until {lockout_until}")
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Too many failed login attempts. Account locked until {lockout_until.strftime('%Y-%m-%d %H:%M:%S UTC')}",
            headers={"Retry-After": str(int((lockout_until - datetime.utcnow()).total_seconds()))}
        )
    
    # Try to find user by username or email
    user = UserDB.get_by_username(form_data.username)
    if not user:
        user = UserDB.get_by_email(form_data.username)
    
    if not user:
        # Log failed attempt
        try:
            LogDB.create({
                'level': 'WARNING',
                'service': 'Auth',
                'action': 'login_failed',
                'message': f"Failed login attempt for unknown user: {form_data.username}",
                'metadata': {'ip': client_ip, 'user_agent': user_agent, 'reason': 'user_not_found'}
            })
        except:
            pass
        
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer", "X-Remaining-Attempts": str(attempts_remaining - 1)},
        )
    
    if not user.get('hashed_password'):
        # Log failed attempt
        try:
            LogDB.create({
                'level': 'WARNING',
                'service': 'Auth',
                'action': 'login_failed',
                'message': f"Failed login attempt for user {user['username']} - account setup incomplete",
                'user_id': user['id'],
                'metadata': {'ip': client_ip, 'user_agent': user_agent, 'reason': 'account_incomplete'}
            })
        except:
            pass
        
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Account setup incomplete. Please accept your invite first.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Check if user has a password hash
    if not user.get("hashed_password"):
        logger.error(f"User {user['username']} has no password hash - account may need password reset")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Account password not set. Please reset your password.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not verify_password(form_data.password, user["hashed_password"]):
        # Log failed attempt
        try:
            LogDB.create({
                'level': 'WARNING',
                'service': 'Auth',
                'action': 'login_failed',
                'message': f"Failed login attempt for user {user['username']} - incorrect password",
                'user_id': user['id'],
                'metadata': {'ip': client_ip, 'user_agent': user_agent, 'reason': 'invalid_password', 'attempts_remaining': attempts_remaining - 1}
            })
        except:
            pass
        
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer", "X-Remaining-Attempts": str(attempts_remaining - 1)},
        )
    
    if user.get('status') != 'active':
        # Log failed attempt
        try:
            LogDB.create({
                'level': 'WARNING',
                'service': 'Auth',
                'action': 'login_failed',
                'message': f"Failed login attempt for user {user['username']} - account not active",
                'user_id': user['id'],
                'metadata': {'ip': client_ip, 'user_agent': user_agent, 'reason': 'account_inactive'}
            })
        except:
            pass
        
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is not active"
        )
    
    # Reset auth failures on successful validation
    reset_auth_failures(identifier)

    # Test partner: reset setup wizard on every login so onboarding can be tested repeatedly
    if user.get('email') == TEST_PARTNER_EMAIL:
        UserDB.update(user['id'], {'branding_setup_complete': False})

    # Check if MFA is enabled - return early requiring MFA verification
    if user.get('mfa_enabled'):
        # Create a temporary MFA token (short-lived, only for MFA verification)
        mfa_token = create_access_token(
            data={"sub": user["username"], "mfa_pending": True},
            expires_delta=timedelta(minutes=5)  # 5 minutes to complete MFA
        )
        return {
            "mfa_required": True,
            "mfa_token": mfa_token,
            "message": "MFA verification required"
        }
    
    # Create tokens with session management
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["username"]}, expires_delta=access_token_expires
    )
    refresh_token, jti = create_refresh_token(data={"sub": user["username"]})
    
    # Create session
    token_hash = hashlib.sha256(access_token.encode()).hexdigest()
    session_id = create_session(user['id'], token_hash, client_ip, user_agent)
    
    # SECURITY: Auto-detect HTTPS or use production environment
    # Check X-Forwarded-Proto header (set by reverse proxy) or request scheme
    # Use helper function to set cookies consistently
    set_auth_cookies(response, request, access_token, refresh_token)
    set_csrf_cookie(response, request)
    
    # Log cookie setting for debugging
    logger.info(f"Login successful for {user['username']} - cookies set")
    logger.debug(f"Request headers - Origin: {request.headers.get('Origin')}, Host: {request.headers.get('Host')}, X-Forwarded-Proto: {request.headers.get('X-Forwarded-Proto')}, URL: {request.url}")
    
    # Update last login
    try:
        UserDB.update(user['id'], {'last_login': datetime.utcnow()})
    except Exception as e:
        logger.warning(f"Failed to update last_login: {e}")
    
    # Log the login with enhanced details
    try:
        LogDB.create({
            'level': 'INFO',
            'service': 'Auth',
            'action': 'login',
            'message': f"User {user['username']} logged in successfully",
            'user_id': user['id'],
            'metadata': {
                'ip': client_ip,
                'user_agent': user_agent,
                'session_id': session_id,
                'mfa_used': False
            }
        })
    except Exception as e:
        logger.warning(f"Failed to log login: {e}")
    
    return {
        "message": "Login successful",
        "user": {
            "id": user.get('id'),
            "username": user["username"], 
            "role": user["role"],
            "full_name": user.get("full_name"),
            "email": user.get("email")
        }
    }


class MFALoginRequest(BaseModel):
    mfa_token: str
    code: str

from pydantic import BaseModel

@router.post("/login-mfa")
@rate_limit(limit=5, window=300, authenticated_limit=10)
async def login_with_mfa(request: MFALoginRequest, response: Response, req: Request):
    """Complete login with MFA verification"""
    from services.mfa_service import MFAService
    import json
    
    # Decode the MFA token
    try:
        payload = decode_access_token(request.mfa_token.replace("Bearer ", ""))
        if not payload:
            raise HTTPException(status_code=401, detail="Invalid MFA token")
        
        # TokenData is an object, not a dict
        username = payload.username
        mfa_pending = getattr(payload, 'mfa_pending', None)
        
        if not mfa_pending:
            raise HTTPException(status_code=401, detail="Invalid MFA token - not an MFA session")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Invalid or expired MFA token: {str(e)}")
    
    # Get user
    user = UserDB.get_by_username(username)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    if not user.get('mfa_enabled'):
        raise HTTPException(status_code=400, detail="MFA is not enabled for this user")
    
    mfa_secret = user.get('mfa_secret')
    
    # Try TOTP verification first
    if MFAService.verify_totp(mfa_secret, request.code):
        pass  # Verification successful
    else:
        # Try backup codes
        backup_codes_raw = user.get('backup_codes', '[]')
        if isinstance(backup_codes_raw, str):
            backup_codes = json.loads(backup_codes_raw)
        else:
            backup_codes = backup_codes_raw if backup_codes_raw else []
        
        code_valid = False
        for i, hashed_code in enumerate(backup_codes):
            if MFAService.verify_backup_code(request.code, hashed_code):
                backup_codes.pop(i)
                UserDB.update(user['id'], {'backup_codes': json.dumps(backup_codes)})
                code_valid = True
                break
        
        if not code_valid:
            raise HTTPException(status_code=401, detail="Invalid MFA code")
    
    # MFA verified - issue full tokens
    client_ip = get_client_ip(req)
    user_agent = get_user_agent(req)

    # Test partner: reset setup wizard on every login so onboarding can be tested repeatedly
    if user.get('email') == TEST_PARTNER_EMAIL:
        UserDB.update(user['id'], {'branding_setup_complete': False})

    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["username"]}, expires_delta=access_token_expires
    )
    refresh_token, jti = create_refresh_token(data={"sub": user["username"]})
    
    # Create session
    token_hash = hashlib.sha256(access_token.encode()).hexdigest()
    session_id = create_session(user['id'], token_hash, client_ip, user_agent)
    
    # Use helper function to set cookies consistently
    set_auth_cookies(response, req, access_token, refresh_token)
    set_csrf_cookie(response, req)
    
    # Update last login
    try:
        UserDB.update(user['id'], {'last_login': datetime.utcnow()})
    except Exception as e:
        logger.warning(f"Failed to update last_login: {e}")
    
    # Log the login with enhanced details
    try:
        LogDB.create({
            'level': 'INFO',
            'service': 'Auth',
            'action': 'login_mfa',
            'message': f"User {user['username']} logged in successfully with MFA",
            'user_id': user['id'],
            'metadata': {
                'ip': client_ip,
                'user_agent': user_agent,
                'session_id': session_id,
                'mfa_used': True
            }
        })
    except Exception as e:
        logger.warning(f"Failed to log login: {e}")
    
    return {
        "message": "MFA verification successful",
        "user": {
            "id": user.get('id'),
            "username": user["username"],
            "role": user["role"],
            "full_name": user.get("full_name"),
            "email": user.get("email")
        }
    }


@router.post("/logout")
async def logout(response: Response, request: Request):
    """Clear session cookies and logout, revoking all user sessions"""
    client_ip = get_client_ip(request)
    user_agent = get_user_agent(request)
    
    # Try to get current user for logging and session revocation
    try:
        token_cookie = request.cookies.get("access_token")
        if token_cookie:
            token = token_cookie.replace("Bearer ", "") if token_cookie.startswith("Bearer ") else token_cookie
            token_data = decode_access_token(token)
            if token_data and token_data.username:
                user = UserDB.get_by_username(token_data.username)
                if user:
                    # Revoke all user sessions
                    revoked_count = revoke_all_user_sessions(user['id'])
                    
                    LogDB.create({
                        'level': 'INFO',
                        'service': 'Auth',
                        'action': 'logout',
                        'message': f"User {user['username']} logged out (revoked {revoked_count} sessions)",
                        'user_id': user['id'],
                        'metadata': {
                            'ip': client_ip,
                            'user_agent': user_agent,
                            'sessions_revoked': revoked_count
                        }
                    })
    except Exception as e:
        logger.warning(f"Failed to log logout: {e}")
    
    # Clear both cookies with path /
    response.delete_cookie("access_token", path="/")
    response.delete_cookie("refresh_token", path="/")
    response.delete_cookie("csrf_token", path="/")
    return {"message": "Logout successful"}


@router.post("/refresh")
async def refresh_token(response: Response, request: Request):
    """
    Exchange a refresh token cookie for a new access token cookie.
    Implements token rotation - old refresh token is invalidated after use.
    """
    client_ip = get_client_ip(request)
    user_agent = get_user_agent(request)
    
    # Get refresh token from cookie
    old_refresh_token = request.cookies.get("refresh_token")
    
    if not old_refresh_token:
        # Check Authorization header just in case
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            old_refresh_token = auth_header.replace("Bearer ", "")
    
    if not old_refresh_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token missing"
        )

    # Decode and validate refresh token
    token_payload = decode_refresh_token(old_refresh_token)
    
    if not token_payload or not token_payload.get("sub"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token"
        )
    
    username = token_payload.get("sub")
    jti = token_payload.get("jti")
    
    # Get user and verify they're still active
    user = UserDB.get_by_username(username)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )
    
    if user.get('status') != 'active':
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is not active"
        )
    
    # Check if user is blacklisted
    if is_user_blacklisted(username=username):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session has been invalidated"
        )
    
    # Mark old refresh token as used (token rotation)
    if jti:
        mark_refresh_token_used(jti)
    
    # Create new tokens with rotation
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    new_access_token = create_access_token(
        data={"sub": user["username"]}, expires_delta=access_token_expires
    )
    # Rotate refresh token - old one is now invalid
    new_refresh_token, new_jti = create_refresh_token(data={"sub": user["username"]})
    
    # Update session activity
    token_hash = hashlib.sha256(new_access_token.encode()).hexdigest()
    # Note: In a full implementation, we'd track session_id from the token
    # For now, we'll create/update session based on user_id
    
    # Use helper function to set cookies consistently
    set_auth_cookies(response, request, new_access_token, new_refresh_token)
    set_csrf_cookie(response, request)
    
    # Log the refresh with enhanced details
    try:
        LogDB.create({
            'level': 'INFO',
            'service': 'Auth',
            'action': 'token_refresh',
            'message': f"Token refreshed for user {user['username']}",
            'user_id': user['id'],
            'metadata': {
                'ip': client_ip,
                'user_agent': user_agent,
                'token_rotated': True
            }
        })
    except Exception as e:
        logger.warning(f"Failed to log token refresh: {e}")
    
    return {"message": "Token refreshed"}


@router.get("/me")
async def read_users_me(
    current_user: Annotated[dict, Depends(get_current_user)],
    response: Response,
    request: Request
):
    """Get current user information"""
    if not request.cookies.get("csrf_token"):
        set_csrf_cookie(response, request)
    out = {
        "id": current_user.get("id"),
        "username": current_user["username"],
        "full_name": current_user.get("full_name"),
        "role": current_user["role"],
        "email": current_user.get("email"),
        "status": current_user.get("status"),
        "branding_setup_complete": current_user.get("branding_setup_complete", False),
        "branding_logo_url": current_user.get("branding_logo_url"),
        "branding_company_name": current_user.get("branding_company_name"),
        "branding_theme": current_user.get("branding_theme", "dark"),
        "branding_primary_color": current_user.get("branding_primary_color"),
        "branding_secondary_color": current_user.get("branding_secondary_color"),
        "is_super_user": current_user.get("is_super_user", False)
    }
    if current_user.get("role") == "moderator":
        raw = current_user.get("moderator_chatbot_ids")
        if isinstance(raw, list):
            out["moderator_chatbot_ids"] = [str(x) for x in raw]
        elif isinstance(raw, str):
            try:
                import json
                parsed = json.loads(raw)
                out["moderator_chatbot_ids"] = [str(x) for x in parsed] if isinstance(parsed, list) else []
            except Exception:
                out["moderator_chatbot_ids"] = []
        else:
            out["moderator_chatbot_ids"] = []
    return out


@router.post("/change-password")
async def change_password(
    current_password: str,
    new_password: str,
    current_user: Annotated[dict, Depends(get_current_user)],
    request: Request
):
    """Change the current user's password with enhanced validation"""
    client_ip = get_client_ip(request)
    user_agent = get_user_agent(request)
    
    # Validate password strength
    is_valid, error_message = validate_password_strength(new_password)
    if not is_valid:
        # Log failed password change attempt
        try:
            LogDB.create({
                'level': 'WARNING',
                'service': 'Auth',
                'action': 'password_change_failed',
                'message': f"User {current_user['username']} attempted password change with weak password",
                'user_id': current_user['id'],
                'metadata': {'ip': client_ip, 'user_agent': user_agent, 'reason': error_message}
            })
        except:
            pass
        
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=error_message
        )
    
    # Verify current password
    if not verify_password(current_password, current_user.get("hashed_password", "")):
        # Log failed password change attempt
        try:
            LogDB.create({
                'level': 'WARNING',
                'service': 'Auth',
                'action': 'password_change_failed',
                'message': f"User {current_user['username']} attempted password change with incorrect current password",
                'user_id': current_user['id'],
                'metadata': {'ip': client_ip, 'user_agent': user_agent, 'reason': 'incorrect_current_password'}
            })
        except:
            pass
        
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect"
        )
    
    # Check if new password is same as current
    if verify_password(new_password, current_user.get("hashed_password", "")):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="New password must be different from current password"
        )
    
    # Update password
    new_hashed = get_password_hash(new_password)
    UserDB.update(current_user['id'], {'hashed_password': new_hashed})
    
    # Revoke all existing sessions (force re-login for security)
    revoked_count = revoke_all_user_sessions(current_user['id'])
    
    # Log the action with enhanced details
    try:
        LogDB.create({
            'level': 'INFO',
            'service': 'Auth',
            'action': 'password_changed',
            'message': f"User {current_user['username']} changed their password (revoked {revoked_count} sessions)",
            'user_id': current_user['id'],
            'metadata': {
                'ip': client_ip,
                'user_agent': user_agent,
                'sessions_revoked': revoked_count
            }
        })
    except Exception as e:
        logger.warning(f"Failed to log password change: {e}")
    
    return {"message": "Password changed successfully. All sessions have been revoked for security."}


@router.get("/sessions")
async def get_sessions(current_user: Annotated[dict, Depends(get_current_user)]):
    """Get all active sessions for the current user"""
    sessions = get_user_sessions(current_user['id'])
    return {
        "sessions": sessions,
        "count": len(sessions)
    }


@router.delete("/sessions/{session_id}")
async def revoke_session_endpoint(
    session_id: str,
    current_user: Annotated[dict, Depends(get_current_user)],
    request: Request
):
    """Revoke a specific session"""
    client_ip = get_client_ip(request)
    user_agent = get_user_agent(request)
    
    success = revoke_session(current_user['id'], session_id)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    # Log the action
    try:
        LogDB.create({
            'level': 'INFO',
            'service': 'Auth',
            'action': 'session_revoked',
            'message': f"User {current_user['username']} revoked session {session_id}",
            'user_id': current_user['id'],
            'metadata': {
                'ip': client_ip,
                'user_agent': user_agent,
                'session_id': session_id
            }
        })
    except Exception as e:
        logger.warning(f"Failed to log session revocation: {e}")
    
    return {"message": "Session revoked successfully"}


@router.post("/sessions/revoke-all")
async def revoke_all_sessions_endpoint(
    current_user: Annotated[dict, Depends(get_current_user)],
    request: Request
):
    """Revoke all sessions for the current user (except current one)"""
    client_ip = get_client_ip(request)
    user_agent = get_user_agent(request)
    
    revoked_count = revoke_all_user_sessions(current_user['id'])
    
    # Log the action
    try:
        LogDB.create({
            'level': 'INFO',
            'service': 'Auth',
            'action': 'all_sessions_revoked',
            'message': f"User {current_user['username']} revoked all sessions ({revoked_count} sessions)",
            'user_id': current_user['id'],
            'metadata': {
                'ip': client_ip,
                'user_agent': user_agent,
                'sessions_revoked': revoked_count
            }
        })
    except Exception as e:
        logger.warning(f"Failed to log session revocation: {e}")
    
    return {"message": f"All sessions revoked successfully ({revoked_count} sessions)"}

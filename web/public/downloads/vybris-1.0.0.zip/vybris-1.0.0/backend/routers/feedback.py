"""
Feedback Router - Phase 4.2
Widget-accessible endpoint for thumbs up/down on responses.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Literal
import uuid
import logging

from services.database import ChatbotDB
from services.database.base import get_db_connection

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/feedback", tags=["feedback"])


class FeedbackIn(BaseModel):
    chatbot_id: str
    session_id: str
    rating: Literal["thumbs_up", "thumbs_down"]


@router.post("")
async def record_feedback(body: FeedbackIn) -> dict:
    """
    Record thumbs up/down feedback from the widget.
    No auth - widget is embedded on external sites.
    """
    if not body.chatbot_id or not body.session_id:
        raise HTTPException(status_code=400, detail="chatbot_id and session_id required")
    if body.rating not in ("thumbs_up", "thumbs_down"):
        raise HTTPException(status_code=400, detail="rating must be thumbs_up or thumbs_down")

    bot = ChatbotDB.get_by_id(body.chatbot_id)
    if not bot:
        raise HTTPException(status_code=404, detail="Chatbot not found")

    feedback_id = str(uuid.uuid4())
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO response_feedback (id, chatbot_id, session_id, rating)
            VALUES (%s, %s, %s, %s)
            """,
            (feedback_id, body.chatbot_id, body.session_id, body.rating),
        )
        conn.commit()

    return {"status": "ok", "id": feedback_id}

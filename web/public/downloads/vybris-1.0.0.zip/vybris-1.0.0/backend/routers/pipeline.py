"""
Pipeline Router
Manages pipeline stages for sales CRM
"""

from fastapi import APIRouter, HTTPException, Depends, Query, status
from pydantic import BaseModel, Field
from typing import List, Optional
from services.database import PipelineDB
from routers.auth import get_current_user
from shared.permissions import is_super_or_admin

router = APIRouter(prefix="/api/v1/pipeline", tags=["pipeline"])


# ============================================================================
# Pydantic Models
# ============================================================================

class PipelineStageCreate(BaseModel):
    """Create a new pipeline stage"""
    stage_name: str
    stage_key: str
    stage_order: int
    stage_color: str = Field(default='#6366f1')
    expected_duration_days: Optional[int] = None
    required_fields: List[str] = []
    is_win_stage: bool = False
    is_loss_stage: bool = False


class PipelineStageUpdate(BaseModel):
    """Update a pipeline stage"""
    stage_name: Optional[str] = None
    stage_key: Optional[str] = None
    stage_order: Optional[int] = None
    stage_color: Optional[str] = None
    expected_duration_days: Optional[int] = None
    required_fields: Optional[List[str]] = None
    is_win_stage: Optional[bool] = None
    is_loss_stage: Optional[bool] = None


class StageReorder(BaseModel):
    """Reorder stages"""
    stage_ids: List[str]


# ============================================================================
# API Endpoints
# ============================================================================

@router.get("/stages")
async def get_pipeline_stages(
    user_id: Optional[str] = Query(default=None),
    current_user: dict = Depends(get_current_user)
):
    """
    Get pipeline stages.
    - Standard users: get their own stages
    - Admins: can get stages for any user_id
    """
    target_user_id = current_user['id']
    
    if user_id:
        # If looking up another user, check permissions
        if user_id != current_user['id']:
            if not is_super_or_admin(current_user):
                 raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Not authorized to view other users' pipelines"
                )
            target_user_id = user_id
            
    stages = PipelineDB.get_by_owner(target_user_id)
    
    # If no stages exist, initialize defaults
    if not stages:
        stages = PipelineDB.initialize_defaults(target_user_id)
    
    return {"stages": stages}


@router.post("/stages")
async def create_stage(
    request: PipelineStageCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create a new pipeline stage"""
    stage_data = request.dict()
    stage_data['owner_id'] = current_user['id']
    
    stage = PipelineDB.create(stage_data)
    return stage


@router.get("/stages/{stage_id}")
async def get_stage(
    stage_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get a specific pipeline stage"""
    stage = PipelineDB.get_by_id(stage_id)
    if not stage:
        raise HTTPException(status_code=404, detail="Stage not found")
    
    if stage.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    return stage


@router.put("/stages/{stage_id}")
async def update_stage(
    stage_id: str,
    request: PipelineStageUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update a pipeline stage"""
    stage = PipelineDB.get_by_id(stage_id)
    if not stage:
        raise HTTPException(status_code=404, detail="Stage not found")
    
    if stage.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    updates = request.dict(exclude_unset=True)
    updated = PipelineDB.update(stage_id, updates)
    return updated


@router.delete("/stages/{stage_id}")
async def delete_stage(
    stage_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete a pipeline stage"""
    stage = PipelineDB.get_by_id(stage_id)
    if not stage:
        raise HTTPException(status_code=404, detail="Stage not found")
    
    if stage.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    PipelineDB.delete(stage_id)
    return {"success": True}


@router.post("/stages/reorder")
async def reorder_stages(
    request: StageReorder,
    current_user: dict = Depends(get_current_user)
):
    """Reorder pipeline stages"""
    for i, stage_id in enumerate(request.stage_ids, start=1):
        stage = PipelineDB.get_by_id(stage_id)
        if stage and stage.get('owner_id') == current_user['id']:
            PipelineDB.update(stage_id, {'stage_order': i})
    
    stages = PipelineDB.get_by_owner(current_user['id'])
    return {"stages": stages}


@router.post("/stages/reset-defaults")
async def reset_to_defaults(current_user: dict = Depends(get_current_user)):
    """Reset pipeline stages to defaults"""
    # Delete existing stages
    existing = PipelineDB.get_by_owner(current_user['id'])
    for stage in existing:
        PipelineDB.delete(stage['id'])
    
    # Create defaults
    stages = PipelineDB.initialize_defaults(current_user['id'])
    return {"stages": stages}

"""
Onboarding Router
Manages client onboarding workflows
"""

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from services.database import OnboardingDB, CRMLeadDB
from routers.auth import get_current_user
from datetime import date

router = APIRouter(prefix="/api/v1/onboarding", tags=["onboarding"])


# ============================================================================
# Pydantic Models
# ============================================================================

class OnboardingStage(BaseModel):
    """Onboarding stage definition"""
    name: str
    key: str
    order: int


class ChecklistItem(BaseModel):
    """Checklist item"""
    id: str
    text: str
    stage: str
    completed: bool = False


class OnboardingCreate(BaseModel):
    """Create onboarding workflow"""
    name: str
    lead_id: Optional[str] = None
    template_id: Optional[str] = None
    stages: Optional[List[OnboardingStage]] = None
    checklist_items: Optional[List[ChecklistItem]] = None
    due_date: Optional[date] = None


class OnboardingUpdate(BaseModel):
    """Update onboarding workflow"""
    name: Optional[str] = None
    current_stage: Optional[str] = None
    due_date: Optional[date] = None
    notes: Optional[str] = None


class ChecklistUpdate(BaseModel):
    """Update checklist item"""
    item_id: str
    completed: bool


class CompleteOnboarding(BaseModel):
    """Complete onboarding with NPS"""
    nps_score: Optional[int] = Field(default=None, ge=0, le=10)


# ============================================================================
# API Endpoints
# ============================================================================

@router.get("/")
async def get_onboardings(
    current_user: dict = Depends(get_current_user),
    status: Optional[str] = None
):
    """Get all onboarding workflows for current user"""
    workflows = OnboardingDB.get_by_owner(current_user['id'], status=status)
    return {"workflows": workflows}


@router.post("/")
async def create_onboarding(
    request: OnboardingCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create a new onboarding workflow"""
    data = {
        'owner_id': current_user['id'],
        'name': request.name,
        'lead_id': request.lead_id,
        'template_id': request.template_id,
        'due_date': str(request.due_date) if request.due_date else None
    }
    
    if request.stages:
        data['stages'] = [s.dict() for s in request.stages]
    
    if request.checklist_items:
        data['checklist_items'] = [c.dict() for c in request.checklist_items]
    
    workflow = OnboardingDB.create_workflow(data)
    return workflow


@router.post("/from-lead/{lead_id}")
async def create_from_lead(
    lead_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Create onboarding workflow for a won lead"""
    lead = CRMLeadDB.get_by_id(lead_id)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    
    # Check if onboarding already exists
    existing = OnboardingDB.get_by_lead(lead_id)
    if existing:
        return existing
    
    data = {
        'owner_id': current_user['id'],
        'lead_id': lead_id,
        'name': f"Onboarding: {lead.get('name', 'Client')}"
    }
    
    workflow = OnboardingDB.create_workflow(data)
    return workflow


@router.get("/{workflow_id}")
async def get_onboarding(
    workflow_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get a specific onboarding workflow"""
    workflow = OnboardingDB.get_by_id(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")
    
    if workflow.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    return workflow


@router.get("/lead/{lead_id}")
async def get_by_lead(
    lead_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get onboarding workflow for a specific lead"""
    workflow = OnboardingDB.get_by_lead(lead_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="No onboarding found for this lead")
    
    if workflow.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    return workflow


@router.put("/{workflow_id}")
async def update_onboarding(
    workflow_id: str,
    request: OnboardingUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update an onboarding workflow"""
    workflow = OnboardingDB.get_by_id(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")
    
    if workflow.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    updates = request.dict(exclude_unset=True)
    if 'due_date' in updates and updates['due_date']:
        updates['due_date'] = str(updates['due_date'])
    
    updated = OnboardingDB.update(workflow_id, updates)
    return updated


@router.post("/{workflow_id}/checklist")
async def update_checklist(
    workflow_id: str,
    request: ChecklistUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update a checklist item"""
    workflow = OnboardingDB.get_by_id(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")
    
    if workflow.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    updated = OnboardingDB.update_checklist_item(workflow_id, request.item_id, request.completed)
    return updated


@router.post("/{workflow_id}/advance")
async def advance_stage(
    workflow_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Advance to the next stage"""
    workflow = OnboardingDB.get_by_id(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")
    
    if workflow.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    stages = workflow.get('stages', [])
    current = workflow.get('current_stage')
    
    # Find next stage
    current_order = next((s['order'] for s in stages if s['key'] == current), 0)
    next_stage = next((s for s in stages if s['order'] == current_order + 1), None)
    
    if not next_stage:
        raise HTTPException(status_code=400, detail="Already at final stage")
    
    updated = OnboardingDB.update(workflow_id, {'current_stage': next_stage['key']})
    return updated


@router.post("/{workflow_id}/complete")
async def complete_onboarding(
    workflow_id: str,
    request: CompleteOnboarding,
    current_user: dict = Depends(get_current_user)
):
    """Mark onboarding as complete with optional NPS score"""
    workflow = OnboardingDB.get_by_id(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")
    
    if workflow.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    completed = OnboardingDB.complete(workflow_id, request.nps_score)
    return completed


@router.delete("/{workflow_id}")
async def delete_onboarding(
    workflow_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete an onboarding workflow"""
    workflow = OnboardingDB.get_by_id(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")
    
    if workflow.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    OnboardingDB.delete(workflow_id)
    return {"success": True}


@router.get("/stats/summary")
async def get_stats(current_user: dict = Depends(get_current_user)):
    """Get onboarding statistics"""
    all_workflows = OnboardingDB.get_by_owner(current_user['id'])
    
    active = [w for w in all_workflows if w.get('status') == 'active']
    completed = [w for w in all_workflows if w.get('status') == 'completed']
    
    avg_nps = None
    nps_scores = [w.get('nps_score') for w in completed if w.get('nps_score') is not None]
    if nps_scores:
        avg_nps = round(sum(nps_scores) / len(nps_scores), 1)
    
    return {
        "total": len(all_workflows),
        "active": len(active),
        "completed": len(completed),
        "average_nps": avg_nps,
        "average_completion_percent": round(
            sum(w.get('completion_percent', 0) for w in active) / len(active)
        ) if active else 0
    }

"""
WebSocket Chat Router - Phase 4.2
Streaming chat via WebSocket for lower latency UX.
"""

import json
import logging
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from typing import Optional

logger = logging.getLogger(__name__)

router = APIRouter()


@router.websocket("/api/v1/chat/ws")
async def chat_websocket(
    websocket: WebSocket,
    chatbot_id: Optional[str] = Query(None),
    session_id: Optional[str] = Query(None),
):
    """
    WebSocket endpoint for streaming chat.
    Query params: chatbot_id, session_id.
    Accepts JSON: {"text": "..."}.
    Sends: {"type":"chunk","content":"..."} and {"type":"done","response":"...","intent":"...","sources":[...]}.
    """
    await websocket.accept()
    try:
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send_json({"type": "error", "message": "Invalid JSON"})
                continue

            text = (msg.get("text") or "").strip()
            if not text:
                await websocket.send_json({"type": "error", "message": "Missing text"})
                continue

            cid = msg.get("chatbot_id") or chatbot_id
            sid = msg.get("session_id") or session_id
            if not cid:
                await websocket.send_json({"type": "error", "message": "Missing chatbot_id"})
                continue

            try:
                from services.database import ChatbotDB
                from application.chat.chat_orchestrator import chat_orchestrator

                bot = ChatbotDB.get_by_id(cid)
                if not bot:
                    await websocket.send_json({"type": "error", "message": "Chatbot not found"})
                    continue

                class FakeRequest:
                    state = type("state", (), {"request_id": None})()

                result = await chat_orchestrator.process(
                    text=text,
                    chatbot_id=cid,
                    session_id=sid,
                    context={"session_id": sid},
                    auto_request_live_chat=True,
                    bot=bot,
                    req=FakeRequest(),
                )

                response_text = result.response or ""
                # For MVP: send full response as single chunk, then done
                # TODO: Integrate LLM streaming (generate_response_stream) for token-by-token
                if response_text:
                    await websocket.send_json({"type": "chunk", "content": response_text})
                await websocket.send_json({
                    "type": "done",
                    "response": response_text,
                    "intent": result.intent,
                    "sources": getattr(result, "sources", []) or [],
                    "explanation": getattr(result, "explanation", None),
                })
            except Exception as e:
                logger.exception("WebSocket chat error")
                await websocket.send_json({"type": "error", "message": str(e)})
    except WebSocketDisconnect:
        logger.debug("WebSocket disconnected")
    except Exception as e:
        logger.exception("WebSocket error: %s", e)

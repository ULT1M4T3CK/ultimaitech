
from fastapi import APIRouter, Depends, HTTPException
from typing import Dict, Any, List
from routers.auth import get_current_user


router = APIRouter(prefix="/api/v1/academy", tags=["academy"])

# Static content definition (can be moved to DB later)
ACADEMY_CONTENT = [
    {
        "id": "getting-started",
        "title": "Getting Started with VYBR!S",
        "description": "Learn the basics of creating and deploying your first chatbot.",
        "level": "basic", # starter
        "type": "video",
        "url": "https://example.com/videos/getting-started",
        "thumbnail": "/static/academy/basic_intro.jpg",
        "duration": "5 min"
    },
    {
        "id": "prompt-engineering",
        "title": "Prompt Engineering Basics",
        "description": "How to write effective system prompts for better responses.",
        "level": "basic",
        "type": "article",
        "url": "/academy/articles/prompt-engineering",
        "thumbnail": "/static/academy/prompts.jpg",
        "duration": "10 min"
    },
    {
        "id": "advanced-rag",
        "title": "Advanced RAG Techniques",
        "description": "optimize your knowledge base for higher accuracy.",
        "level": "advanced", # professional
        "type": "video",
        "url": "https://example.com/videos/rag-advanced",
        "thumbnail": "/static/academy/rag_advanced.jpg",
        "duration": "15 min"
    },
    {
        "id": "custom-integrations",
        "title": "Custom API Integrations",
        "description": "Connect your chatbot to external APIs and tools.",
        "level": "premium", # enterprise
        "type": "workshop",
        "url": "https://example.com/workshops/integrations",
        "thumbnail": "/static/academy/integrations.jpg",
        "duration": "45 min"
    }
]

@router.get("/content", response_model=List[Dict[str, Any]])
async def get_content(current_user: dict = Depends(get_current_user)):
    """List all available content with lock status based on user tier"""
    # We return all content, but frontend will show locks based on 'level'
    # Or we can augment it here
    result = []
    for item in ACADEMY_CONTENT:
        item_copy = item.copy()
        item_copy['locked'] = False
        result.append(item_copy)
        
    return result

@router.get("/content/{content_id}")
async def get_content_detail(
    content_id: str, 
    current_user: dict = Depends(get_current_user)
):
    """Get specific content. Enforces access level."""
    content = next((c for c in ACADEMY_CONTENT if c['id'] == content_id), None)
    if not content:
        raise HTTPException(status_code=404, detail="Content not found")
        
    return content

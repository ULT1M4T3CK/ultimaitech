"""
Integration Router for VYBR!S
Handles API endpoints for third-party integrations
"""

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime
import logging

from services.database import IntegrationDB, ChatbotDB
from services.integrations import IntegrationManager, IntegrationError
from routers.auth import get_current_user
from shared.permissions import can_manage_chatbot

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/integrations", tags=["integrations"])


# ============================================================================
# Pydantic Models
# ============================================================================

class IntegrationCreate(BaseModel):
    chatbot_id: str
    integration_type: str
    name: str
    config: Dict[str, Any]
    metadata: Optional[Dict[str, Any]] = {}


class IntegrationUpdate(BaseModel):
    name: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    status: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class IntegrationTest(BaseModel):
    integration_type: str
    config: Dict[str, Any]
    test_data: Optional[Dict[str, Any]] = {}


class InventorySyncRequest(BaseModel):
    replace_existing: Optional[bool] = True
    max_items: Optional[int] = None


# ============================================================================
# Integration CRUD Endpoints
# ============================================================================

@router.post("")
async def create_integration(
    integration: IntegrationCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create a new integration for a chatbot"""
    try:
        # Check chatbot exists and user has permission
        chatbot = ChatbotDB.get_by_id(integration.chatbot_id)
        if not chatbot:
            raise HTTPException(status_code=404, detail="Chatbot not found")
        
        if not can_manage_chatbot(current_user, chatbot):
            raise HTTPException(status_code=403, detail="Not authorized to manage this chatbot")
        
        # Validate integration config
        if not IntegrationManager.validate_config(integration.integration_type, integration.config):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid configuration for {integration.integration_type}"
            )
        
        # Create integration
        integration_data = {
            'chatbot_id': integration.chatbot_id,
            'integration_type': integration.integration_type,
            'name': integration.name,
            'config': integration.config,
            'metadata': integration.metadata,
            'status': 'active'
        }
        
        result = IntegrationDB.create(integration_data)
        
        if not result:
            logger.error(f"Failed to create integration: IntegrationDB.create returned None")
            raise HTTPException(status_code=500, detail="Failed to create integration: database operation returned no result")
        
        logger.info(f"Integration created: {result['id']} ({integration.integration_type}) for chatbot {integration.chatbot_id}")
        
        return {
            'success': True,
            'integration': result
        }
    
    except IntegrationError as e:
        logger.error(f"Integration creation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Unexpected error creating integration: {e}")
        raise HTTPException(status_code=500, detail="Failed to create integration")


@router.get("/chatbot/{chatbot_id}")
async def get_chatbot_integrations(
    chatbot_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get all integrations for a chatbot"""
    try:
        # Check chatbot exists and user has permission
        chatbot = ChatbotDB.get_by_id(chatbot_id)
        if not chatbot:
            raise HTTPException(status_code=404, detail="Chatbot not found")
        
        if not can_manage_chatbot(current_user, chatbot):
            raise HTTPException(status_code=403, detail="Not authorized to view this chatbot's integrations")
        
        integrations = IntegrationDB.get_by_chatbot(chatbot_id) or []
        
        # Optimize response payload (sanitize configs and select only needed fields)
        try:
            from routers.response_optimizer import optimize_integration_list_response
            optimized_integrations = optimize_integration_list_response(integrations)
        except (ImportError, KeyError, TypeError) as e:
            logger.warning("Integration list optimization failed (%s), returning raw list", e)
            optimized_integrations = integrations
        
        return {
            'success': True,
            'integrations': optimized_integrations
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching integrations: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch integrations")


@router.get("/{integration_id}")
async def get_integration(
    integration_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get a specific integration"""
    try:
        integration = IntegrationDB.get_by_id(integration_id)
        if not integration:
            raise HTTPException(status_code=404, detail="Integration not found")
        
        # Check permission
        chatbot = ChatbotDB.get_by_id(integration['chatbot_id'])
        if not chatbot or not can_manage_chatbot(current_user, chatbot):
            raise HTTPException(status_code=403, detail="Not authorized")
        
        # Sanitize config
        integration['config'] = _sanitize_config(integration['config'])
        
        return {
            'success': True,
            'integration': integration
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Error fetching integration: %s", e)
        raise HTTPException(status_code=500, detail="Failed to fetch integration")


@router.put("/{integration_id}")
async def update_integration(
    integration_id: str,
    updates: IntegrationUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update an integration"""
    try:
        integration = IntegrationDB.get_by_id(integration_id)
        if not integration:
            raise HTTPException(status_code=404, detail="Integration not found")
        
        # Check permission
        chatbot = ChatbotDB.get_by_id(integration['chatbot_id'])
        if not chatbot or not can_manage_chatbot(current_user, chatbot):
            raise HTTPException(status_code=403, detail="Not authorized")
        
        # Validate config if being updated
        if updates.config:
            if not IntegrationManager.validate_config(integration['integration_type'], updates.config):
                raise HTTPException(status_code=400, detail="Invalid configuration")
        
        # Update integration
        update_data = updates.dict(exclude_unset=True)
        
        # Normalize status to lowercase if provided
        if 'status' in update_data:
            update_data['status'] = update_data['status'].lower()
            logger.info(f"Updating integration {integration_id} status to: {update_data['status']}")
        
        result = IntegrationDB.update(integration_id, update_data)
        
        if not result:
            raise HTTPException(status_code=500, detail="Failed to update integration")
        
        logger.info(f"Integration updated: {integration_id}, new status: {result.get('status')}")
        
        return {
            'success': True,
            'integration': result
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating integration: {e}")
        raise HTTPException(status_code=500, detail="Failed to update integration")


@router.delete("/{integration_id}")
async def delete_integration(
    integration_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete an integration"""
    try:
        integration = IntegrationDB.get_by_id(integration_id)
        if not integration:
            raise HTTPException(status_code=404, detail="Integration not found")
        
        # Check permission
        chatbot = ChatbotDB.get_by_id(integration['chatbot_id'])
        if not chatbot or not can_manage_chatbot(current_user, chatbot):
            raise HTTPException(status_code=403, detail="Not authorized")
        
        IntegrationDB.delete(integration_id)
        
        logger.info(f"Integration deleted: {integration_id}")
        
        return {
            'success': True,
            'message': 'Integration deleted successfully'
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting integration: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete integration")


# ============================================================================
# Testing & Actions
# ============================================================================

@router.post("/chatbot/{chatbot_id}/inventory/sync")
async def sync_inventory_for_chatbot(
    chatbot_id: str,
    request: InventorySyncRequest,
    current_user: dict = Depends(get_current_user)
):
    """Sync inventory items into the chatbot knowledge base and vector index."""
    from services.cache_service import response_cache
    from services.database import KnowledgeDB
    from services.nlp_service import nlp_service
    from nlp.chunking import semantic_chunk_text

    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")

    if not can_manage_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to manage this chatbot")

    integrations = IntegrationDB.get_by_chatbot(chatbot_id)
    integration = next(
        (i for i in integrations if i['integration_type'] == 'universal_inventory' and i.get('status', '').lower() == 'active'),
        None
    )
    if not integration:
        raise HTTPException(status_code=404, detail="Active universal inventory integration not found")

    response_cache.invalidate(chatbot_id)

    instance = IntegrationManager.get_integration('universal_inventory', integration['config'])
    items = instance.fetch_inventory_items()
    if not items:
        return {
            "success": True,
            "message": "No inventory items returned from integration",
            "items_processed": 0,
            "chunks_created": 0
        }

    if request.max_items:
        items = items[:request.max_items]

    cleared_vectors = 0
    cleared_items = 0
    if request.replace_existing:
        cleared_vectors = nlp_service.clear_inventory_data(chatbot_id)
        cleared_items = KnowledgeDB.delete_by_chatbot_and_source(chatbot_id, "inventory")

    def _get_item_title(item: Dict[str, Any]) -> str:
        return (
            item.get('name') or item.get('title') or item.get('boatName') or
            item.get('model') or item.get('type') or item.get('sku') or item.get('id') or "Inventory Item"
        )

    def _get_item_id(item: Dict[str, Any]) -> Optional[str]:
        return item.get('id') or item.get('sku') or item.get('boatType') or item.get('code')

    texts: List[str] = []
    metas: List[Dict[str, Any]] = []
    knowledge_items_data: List[Dict[str, Any]] = []
    total_chunks = 0

    for item in items:
        if not isinstance(item, dict):
            item = {"value": item}

        text = instance.format_inventory_item_text(item)
        if not text or len(text.strip()) < 30:
            continue

        title = _get_item_title(item)
        inventory_id = _get_item_id(item)
        category = item.get('category') or item.get('type') or item.get('class')
        item_url = item.get('url') or item.get('link')

        base_meta = {
            "source_type": "inventory",
            "type": "inventory",
            "title": title
        }
        if inventory_id:
            base_meta["inventory_id"] = inventory_id
        if category:
            base_meta["category"] = category
        if item_url:
            base_meta["url"] = item_url

        chunks = semantic_chunk_text(text, max_chunk_size=500, overlap=50, metadata=base_meta)
        for idx, chunk in enumerate(chunks):
            texts.append(chunk)
            meta = base_meta.copy()
            meta["chunk_index"] = idx
            metas.append(meta)
        total_chunks += len(chunks)

        knowledge_items_data.append({
            "chatbot_id": chatbot_id,
            "source_type": "inventory",
            "title": title,
            "content": text[:5000],
            "url": item_url,
            "word_count": len(text.split()),
            "metadata": {
                "inventory_id": inventory_id,
                "category": category,
                "chunk_count": len(chunks),
                "source": "inventory_sync",
                "raw_keys": list(item.keys())[:40]
            }
        })

    if texts:
        batch_size = 100
        for i in range(0, len(texts), batch_size):
            nlp_service.train_texts_batch(
                chatbot_id,
                texts[i:i + batch_size],
                metas[i:i + batch_size]
            )

    if knowledge_items_data:
        KnowledgeDB.create_batch(knowledge_items_data)

    IntegrationDB.update_sync_time(integration['id'])

    return {
        "success": True,
        "message": "Inventory synced successfully",
        "items_processed": len(knowledge_items_data),
        "chunks_created": total_chunks,
        "cleared_vectors": cleared_vectors,
        "cleared_items": cleared_items
    }


@router.post("/test")
async def test_integration(
    test_data: IntegrationTest,
    current_user: dict = Depends(get_current_user)
):
    """Test an integration configuration without saving it"""
    try:
        # Validate config
        if not IntegrationManager.validate_config(test_data.integration_type, test_data.config):
            raise HTTPException(status_code=400, detail="Invalid configuration")
        
        # Get integration instance
        integration = IntegrationManager.get_integration(test_data.integration_type, test_data.config)
        
        # Perform type-specific test
        result = _perform_integration_test(integration, test_data.integration_type, test_data.test_data)
        
        return {
            'success': True,
            'test_result': result,
            'message': 'Integration test successful'
        }
    
    except IntegrationError as e:
        logger.error(f"Integration test failed: {e}")
        return {
            'success': False,
            'error': str(e),
            'message': 'Integration test failed'
        }
    except Exception as e:
        logger.error(f"Unexpected test error: {e}")
        raise HTTPException(status_code=500, detail="Test failed unexpectedly")


@router.get("/types/available")
async def get_available_integration_types(current_user: dict = Depends(get_current_user)):
    """Get list of available integration types"""
    return {
        'success': True,
        'types': [
            {
                'id': 'whatsapp',
                'name': 'WhatsApp Business',
                'category': 'messaging',
                'description': 'Connect your chatbot to WhatsApp Business API',
                'fields': ['access_token', 'phone_number_id', 'verify_token']
            },
            {
                'id': 'twilio_whatsapp',
                'name': 'Twilio WhatsApp',
                'category': 'messaging',
                'description': 'Connect via Twilio WhatsApp integration',
                'fields': ['account_sid', 'auth_token', 'from_number']
            },
            {
                'id': 'salesforce',
                'name': 'Salesforce',
                'category': 'crm',
                'description': 'Integrate with Salesforce CRM',
                'fields': ['instance_url', 'access_token']
            },
            {
                'id': 'hubspot',
                'name': 'HubSpot',
                'category': 'crm',
                'description': 'Integrate with HubSpot CRM',
                'fields': ['access_token']
            },
            {
                'id': 'zendesk',
                'name': 'Zendesk',
                'category': 'ticketing',
                'description': 'Create and manage Zendesk support tickets',
                'fields': ['subdomain', 'email', 'api_token']
            },
            {
                'id': 'freshdesk',
                'name': 'Freshdesk',
                'category': 'ticketing',
                'description': 'Create and manage Freshdesk support tickets',
                'fields': ['domain', 'api_key']
            },
            {
                'id': 'slack',
                'name': 'Slack',
                'category': 'messaging',
                'description': 'Send messages to Slack channels',
                'fields': ['bot_token', 'signing_secret']
            },
            {
                'id': 'telegram',
                'name': 'Telegram',
                'category': 'messaging',
                'description': 'Connect your chatbot to Telegram',
                'fields': ['bot_token']
            },
            {
                'id': 'email',
                'name': 'Email',
                'category': 'messaging',
                'description': 'Send emails via SMTP or SendGrid',
                'fields': ['from_email', 'provider']
            },
            {
                'id': 'universal_inventory',
                'name': 'Universal Inventory',
                'category': 'utility',
                'description': 'Connect to any external Inventory API (product/boat listing, stock)',
                'fields': ['inventory_api_key', 'api_base_url', 'inventory_api_url']
            },
            {
                'id': 'universal_booking',
                'name': 'Universal Booking',
                'category': 'utility',
                'description': 'Connect to any external Booking API (availability, reservations, checkout links)',
                'fields': ['booking_api_key', 'api_base_url', 'booking_api_url', 'checkout_url']
            }
        ]
    }


# ============================================================================
# Webhook Endpoints
# ============================================================================

@router.post("/webhook/{integration_id}")
async def handle_webhook(integration_id: str, payload: Dict[str, Any]):
    """Handle incoming webhook from an integration"""
    try:
        from shared.router_utils import get_resource_or_404
        from shared.errors import ValidationError
        integration = get_resource_or_404(IntegrationDB.get_by_id, integration_id, "Integration")
        
        if integration['status'] != 'active':
            raise ValidationError(message="Integration is not active")
        
        # Process based on integration type
        result = await _process_webhook(integration, payload)
        
        # Update last sync time
        IntegrationDB.update_sync_time(integration_id)
        
        return result
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Webhook processing error: {e}")
        raise HTTPException(status_code=500, detail="Webhook processing failed")


# ============================================================================
# Helper Functions
# ============================================================================

def _sanitize_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Remove sensitive fields from config for API responses"""
    sensitive_fields = [
        'access_token', 'api_token', 'api_key', 'auth_token',
        'bot_token', 'signing_secret', 'password', 'smtp_password'
    ]
    
    sanitized = config.copy()
    for field in sensitive_fields:
        if field in sanitized:
            sanitized[field] = '***REDACTED***'
    
    return sanitized


def _perform_integration_test(integration, integration_type: str, test_data: Dict[str, Any]) -> Dict[str, Any]:
    """Perform a test action for the integration"""
    try:
        if integration_type in ['whatsapp', 'twilio_whatsapp']:
            # For messaging, we don't send test messages to avoid spam
            return {'status': 'configuration_valid', 'message': 'Configuration validated successfully'}
        
        elif integration_type in ['salesforce', 'hubspot']:
            # Test by attempting to verify credentials (read-only operation)
            return {'status': 'credentials_valid', 'message': 'CRM credentials validated'}
        
        elif integration_type in ['zendesk', 'freshdesk']:
            # Validate API connection
            return {'status': 'api_connected', 'message': 'Ticketing system API connected'}
        
        elif integration_type in ['slack', 'telegram']:
            # Validate bot token
            return {'status': 'bot_verified', 'message': 'Bot credentials verified'}
        
        elif integration_type == 'email':
            # Test SMTP connection
            return {'status': 'smtp_connected', 'message': 'Email service connected'}
        
        elif integration_type == 'universal_inventory':
            try:
                result = integration._check_inventory()
                if 'Error' in result or 'Failed' in result:
                    return {'status': 'api_error', 'message': 'API connection failed. Please check your API keys and URLs.'}
                return {'status': 'api_connected', 'message': 'Universal Inventory API connected successfully'}
            except Exception as e:
                return {'status': 'api_error', 'message': f'API test failed: {str(e)}'}
        
        elif integration_type == 'universal_booking':
            return {'status': 'api_connected', 'message': 'Universal Booking configuration validated successfully'}
        
        else:
            return {'status': 'unknown', 'message': 'Integration type not testable'}
    
    except Exception as e:
        raise IntegrationError(f"Test failed: {str(e)}")


async def _process_webhook(integration: Dict[str, Any], payload: Dict[str, Any]) -> Dict[str, Any]:
    """Process incoming webhook payload and route through chatbot NLP."""
    integration_type = integration['integration_type']
    chatbot_id = integration['chatbot_id']
    
    try:
        # Get integration instance
        instance = IntegrationManager.get_integration(integration_type, integration['config'])
        
        if integration_type in ['whatsapp', 'twilio_whatsapp']:
            # Handle WhatsApp webhook
            message_data = instance.process_incoming_message(payload)
            if message_data:
                # Route to chatbot NLP processing
                from services.nlp_service import nlp_service
                from services.database import ChatbotDB
                from services.llm import llm_service
                
                user_text = message_data.get('text', '')
                sender = message_data.get('from', 'unknown')
                
                if user_text:
                    # 1. Check for Universal Inventory and/or Booking integrations
                    system_context = ""
                    try:
                        other_integrations = IntegrationDB.get_by_chatbot(chatbot_id)
                        inv_config = next(
                            (i for i in other_integrations if i['integration_type'] == 'universal_inventory' and i.get('status', '').lower() == 'active'),
                            None
                        )
                        book_config = next(
                            (i for i in other_integrations if i['integration_type'] == 'universal_booking' and i.get('status', '').lower() == 'active'),
                            None
                        )
                        parts = []
                        if inv_config:
                            inv_instance = IntegrationManager.get_integration('universal_inventory', inv_config['config'])
                            inv_result = inv_instance.process_text(user_text)
                            if inv_result:
                                parts.append(inv_result)
                        if book_config:
                            book_instance = IntegrationManager.get_integration('universal_booking', book_config['config'])
                            book_result = book_instance.process_text(user_text)
                            if book_result:
                                parts.append(book_result)
                        if parts:
                            joined = "\n".join(parts)
                            system_context = f"\n[REAL-TIME SYSTEM DATA]: {joined}\n"
                            logger.info(f"Injected system data for bot {chatbot_id}")
                    except Exception as uni_err:
                        logger.error(f"Error in universal integration processing: {uni_err}")

                    # 2. Search for relevant context
                    results = nlp_service.search(chatbot_id, user_text, limit=5)
                    
                    # Get chatbot config for response generation
                    bot = ChatbotDB.get_by_id(chatbot_id)
                    fallback_message = "I'm sorry, I couldn't find an answer to that."
                    chatbot_name = "Assistant"
                    
                    if bot:
                        chatbot_name = bot.get('name', 'Assistant')
                        config = bot.get('config', {})
                        fallback_message = config.get('fallbackMessage', fallback_message)
                    
                    # 3. Generate response using Perplexity if available
                    response_text = fallback_message
                    
                    context_chunks = results
                    if system_context:
                         # Add system data as high priority
                         context_chunks.insert(0, {
                             "text": system_context,
                             "score": 1.0, 
                             "source": "System Integration"
                         })

                    # STRICT RAG-ONLY POLICY: Only use Perplexity if we have RAG results
                    # Perplexity is used ONLY as a text synthesizer, NOT for external knowledge
                    if (results and len(results) > 0) or system_context:
                        # Verify we have valid RAG content before calling LLM
                        valid_results = [r for r in context_chunks if r.get('score', 0) >= 0.3 or r.get('source') == 'System Integration']
                        
                        if valid_results and llm_service.is_enabled():
                            response_text = await llm_service.generate_response(
                                user_query=user_text,
                                context_chunks=valid_results,  # Only pass validated RAG results
                                chatbot_name=chatbot_name,
                                temperature=0.3
                            ) or fallback_message
                        else:
                            # No valid RAG results or Perplexity disabled - use RAG content directly
                            if system_context:
                                response_text = system_context + (results[0].get('text', '') if results else '')
                            elif results:
                                response_text = results[0].get('text', fallback_message)
                            else:
                                response_text = fallback_message
                    else:
                        # No RAG results at all - use fallback (STRICT RAG-ONLY)
                        response_text = fallback_message
                    
                    # Send response back through integration
                    try:
                        instance.send_message(sender, response_text)
                        logger.info(f"Sent response via {integration_type} to {sender}")
                    except Exception as send_err:
                        logger.error(f"Failed to send response: {send_err}")
                    
                    return {
                        'status': 'processed',
                        'message_id': message_data.get('message_id'),
                        'response_sent': True
                    }
                
                return {'status': 'received', 'message_id': message_data.get('message_id')}
        
        elif integration_type in ['slack', 'telegram']:
            # Handle messaging platform webhooks similarly
            message_text = payload.get('text') or payload.get('message', {}).get('text', '')
            if message_text:
                # Process through NLP
                from services.nlp_service import nlp_service
                results = nlp_service.search(chatbot_id, message_text, limit=5)
                
                return {
                    'status': 'processed',
                    'results_found': len(results)
                }
        
        return {'status': 'processed'}
    
    except Exception as e:
        logger.error(f"Webhook processing error for {integration_type}: {e}")
        return {'status': 'error', 'message': str(e)}

"""
Verification Router
Handles OTP-based identity verification for secure action access
"""

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks
from pydantic import BaseModel, EmailStr
from typing import Optional
import logging
import re

from services.database import VerificationDB, ChatbotDB
from services.email_service import email_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/verification", tags=["verification"])


# --- Pydantic Models ---

class RequestVerificationRequest(BaseModel):
    """Request to send OTP verification code"""
    chatbot_id: str
    email: Optional[str] = None
    phone: Optional[str] = None
    session_id: Optional[str] = None


class VerifyCodeRequest(BaseModel):
    """Request to verify OTP code"""
    chatbot_id: str
    email: Optional[str] = None
    phone: Optional[str] = None
    code: str
    session_id: Optional[str] = None


class ValidateTokenRequest(BaseModel):
    """Request to validate a verification token"""
    chatbot_id: str
    verification_token: str


# --- Helper Functions ---

def validate_email(email: str) -> bool:
    """Basic email validation"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_phone(phone: str) -> bool:
    """Basic phone validation (international format)"""
    # Remove spaces and dashes
    cleaned = re.sub(r'[\s\-\(\)]', '', phone)
    # Should start with + and have 8-15 digits
    pattern = r'^\+?[0-9]{8,15}$'
    return bool(re.match(pattern, cleaned))


async def send_otp_email(email: str, otp: str, chatbot_name: str):
    """Send OTP via email"""
    try:
        subject = f"Your verification code for {chatbot_name}"
        body = f"""
Hello,

Your verification code is: {otp}

This code will expire in 5 minutes.

If you didn't request this code, please ignore this email.

Best regards,
{chatbot_name}
        """.strip()
        
        await email_service.send_email(
            to_email=email,
            subject=subject,
            body=body
        )
        logger.info(f"OTP email sent to {email[:3]}***")
        return True
    except Exception as e:
        logger.error(f"Failed to send OTP email: {e}")
        return False


# --- Endpoints ---

@router.post("/request")
async def request_verification(
    request: RequestVerificationRequest,
    background_tasks: BackgroundTasks
):
    """
    Request a verification code to be sent to email or phone.
    
    The code will be sent to the provided email/phone and must be
    verified using the /verify endpoint to get a verification token.
    """
    # Validate chatbot exists
    chatbot = ChatbotDB.get_by_id(request.chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
    
    chatbot_name = chatbot.get('name', 'Assistant')
    
    # Determine identifier type
    identifier = None
    identifier_type = None
    
    if request.email:
        if not validate_email(request.email):
            raise HTTPException(status_code=400, detail="Invalid email format")
        identifier = request.email
        identifier_type = 'email'
    elif request.phone:
        if not validate_phone(request.phone):
            raise HTTPException(status_code=400, detail="Invalid phone format")
        identifier = request.phone
        identifier_type = 'phone'
    else:
        raise HTTPException(status_code=400, detail="Email or phone required")
    
    # Create OTP request
    result = VerificationDB.create_otp_request(
        chatbot_id=request.chatbot_id,
        identifier=identifier,
        identifier_type=identifier_type,
        session_id=request.session_id
    )
    
    if not result.get('success'):
        raise HTTPException(status_code=429, detail=result.get('error', 'Failed to create verification'))
    
    # Send OTP in background
    otp = result.pop('otp')  # Remove OTP from response
    
    if identifier_type == 'email':
        background_tasks.add_task(send_otp_email, identifier, otp, chatbot_name)
    else:
        # TODO: Implement SMS sending via Twilio or similar
        logger.warning(f"SMS OTP not implemented. OTP for {identifier}: {otp}")
    
    return {
        "success": True,
        "message": f"Verification code sent to {result['masked_identifier']}",
        "masked_identifier": result['masked_identifier'],
        "identifier_type": result['identifier_type'],
        "expires_in_seconds": result['expires_in_seconds']
    }


@router.post("/verify")
async def verify_code(request: VerifyCodeRequest):
    """
    Verify the OTP code and get a verification token.
    
    The verification token can be used with sensitive actions
    that require identity verification.
    """
    # Validate chatbot exists
    chatbot = ChatbotDB.get_by_id(request.chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
    
    # Determine identifier
    identifier = request.email or request.phone
    if not identifier:
        raise HTTPException(status_code=400, detail="Email or phone required")
    
    # Verify OTP
    result = VerificationDB.verify_otp(
        chatbot_id=request.chatbot_id,
        identifier=identifier,
        code=request.code,
        session_id=request.session_id
    )
    
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error', 'Verification failed'))
    
    return {
        "success": True,
        "verified": True,
        "verification_token": result['verification_token'],
        "expires_at": result['expires_at'],
        "expires_in_seconds": result['expires_in_seconds'],
        "message": "Identity verified successfully. Use the verification_token for sensitive actions."
    }


@router.post("/validate")
async def validate_token(request: ValidateTokenRequest):
    """
    Validate a verification token.
    
    Use this to check if a token is still valid before
    executing sensitive actions.
    """
    result = VerificationDB.validate_token(
        chatbot_id=request.chatbot_id,
        verification_token=request.verification_token
    )
    
    if not result.get('valid'):
        raise HTTPException(status_code=401, detail=result.get('error', 'Invalid token'))
    
    return {
        "valid": True,
        "identifier_type": result['identifier_type'],
        "identifier_masked": result['identifier_masked'],
        "verified_at": result['verified_at'],
        "expires_at": result['expires_at']
    }


@router.post("/invalidate")
async def invalidate_token(request: ValidateTokenRequest):
    """
    Invalidate a verification token (logout).
    """
    success = VerificationDB.invalidate_token(request.verification_token)
    
    return {
        "success": success,
        "message": "Token invalidated" if success else "Token not found"
    }

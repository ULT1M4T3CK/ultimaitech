"""
Email Sequences Router
Manages automated email sequences for leads
"""

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from services.database import EmailSequenceDB
from routers.auth import get_current_user

router = APIRouter(prefix="/api/v1/email-sequences", tags=["email-sequences"])


# ============================================================================
# Pydantic Models
# ============================================================================

class EmailStep(BaseModel):
    """Single email in sequence"""
    delay_days: int = Field(default=0, description="Days after previous email")
    delay_hours: int = Field(default=0, description="Hours after previous email")
    subject: str
    body: str
    template_id: Optional[str] = None


class EmailSequenceCreate(BaseModel):
    """Create email sequence"""
    name: str
    description: Optional[str] = None
    trigger_type: str = "manual"  # manual, lead_created, stage_change, score_threshold
    trigger_config: Dict[str, Any] = {}
    emails: List[EmailStep] = []
    active: bool = True


class EmailSequenceUpdate(BaseModel):
    """Update email sequence"""
    name: Optional[str] = None
    description: Optional[str] = None
    trigger_type: Optional[str] = None
    trigger_config: Optional[Dict[str, Any]] = None
    emails: Optional[List[EmailStep]] = None
    active: Optional[bool] = None


class EnrollLead(BaseModel):
    """Enroll a lead in a sequence"""
    lead_id: str
    delay_hours: int = 0


# ============================================================================
# Email Templates
# ============================================================================

EMAIL_TEMPLATES = {
    "welcome": {
        "name": "Welcome Sequence",
        "description": "5-email welcome series for new leads",
        "emails": [
            {"delay_days": 0, "delay_hours": 0, "subject": "Welcome to {{company_name}}!", 
             "body": "Hi {{lead_name}},\n\nThank you for your interest..."},
            {"delay_days": 2, "delay_hours": 0, "subject": "Getting started with {{company_name}}", 
             "body": "Hi {{lead_name}},\n\nHere's how to get started..."},
            {"delay_days": 5, "delay_hours": 0, "subject": "Have questions?", 
             "body": "Hi {{lead_name}},\n\nI wanted to check in..."},
            {"delay_days": 7, "delay_hours": 0, "subject": "Special offer inside", 
             "body": "Hi {{lead_name}},\n\nAs a valued prospect..."},
            {"delay_days": 14, "delay_hours": 0, "subject": "Last chance!", 
             "body": "Hi {{lead_name}},\n\nDon't miss out..."}
        ]
    },
    "followup": {
        "name": "Sales Follow-up",
        "description": "3-email follow-up after demo/call",
        "emails": [
            {"delay_days": 1, "delay_hours": 0, "subject": "Thanks for connecting!", 
             "body": "Hi {{lead_name}},\n\nIt was great speaking with you..."},
            {"delay_days": 3, "delay_hours": 0, "subject": "Following up", 
             "body": "Hi {{lead_name}},\n\nI wanted to follow up on our conversation..."},
            {"delay_days": 7, "delay_hours": 0, "subject": "Any questions?", 
             "body": "Hi {{lead_name}},\n\nJust checking in to see if you have any questions..."}
        ]
    },
    "nurture": {
        "name": "Lead Nurture",
        "description": "Long-term nurture for cold leads",
        "emails": [
            {"delay_days": 7, "delay_hours": 0, "subject": "Quick tip from {{company_name}}", 
             "body": "Hi {{lead_name}},\n\nHere's a helpful tip..."},
            {"delay_days": 21, "delay_hours": 0, "subject": "Case study: How we helped {{industry}}", 
             "body": "Hi {{lead_name}},\n\nI thought you might find this interesting..."},
            {"delay_days": 45, "delay_hours": 0, "subject": "Still interested?", 
             "body": "Hi {{lead_name}},\n\nI wanted to check if you're still considering..."}
        ]
    }
}


# ============================================================================
# API Endpoints
# ============================================================================

@router.get("/templates")
async def get_templates():
    """Get available email sequence templates"""
    return {"templates": [
        {"id": k, "name": v["name"], "description": v["description"], "email_count": len(v["emails"])}
        for k, v in EMAIL_TEMPLATES.items()
    ]}


@router.get("/templates/{template_id}")
async def get_template(template_id: str):
    """Get a specific template with full email content"""
    if template_id not in EMAIL_TEMPLATES:
        raise HTTPException(status_code=404, detail="Template not found")
    return EMAIL_TEMPLATES[template_id]


@router.get("/")
async def get_sequences(
    current_user: dict = Depends(get_current_user),
    active_only: bool = False
):
    """Get all email sequences for current user"""
    sequences = EmailSequenceDB.get_by_owner(current_user['id'], active_only=active_only)
    return {"sequences": sequences}


@router.post("/")
async def create_sequence(
    request: EmailSequenceCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create a new email sequence"""
    seq_data = request.dict()
    seq_data['owner_id'] = current_user['id']
    seq_data['emails'] = [e.dict() if hasattr(e, 'dict') else e for e in request.emails]
    
    sequence = EmailSequenceDB.create(seq_data)
    return sequence


@router.post("/from-template/{template_id}")
async def create_from_template(
    template_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Create a sequence from a template"""
    if template_id not in EMAIL_TEMPLATES:
        raise HTTPException(status_code=404, detail="Template not found")
    
    template = EMAIL_TEMPLATES[template_id]
    seq_data = {
        'owner_id': current_user['id'],
        'name': template['name'],
        'description': template['description'],
        'trigger_type': 'manual',
        'emails': template['emails']
    }
    
    sequence = EmailSequenceDB.create(seq_data)
    return sequence


@router.get("/{sequence_id}")
async def get_sequence(
    sequence_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get a specific email sequence"""
    sequence = EmailSequenceDB.get_by_id(sequence_id)
    if not sequence:
        raise HTTPException(status_code=404, detail="Sequence not found")
    
    if sequence.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    return sequence


@router.put("/{sequence_id}")
async def update_sequence(
    sequence_id: str,
    request: EmailSequenceUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update an email sequence"""
    sequence = EmailSequenceDB.get_by_id(sequence_id)
    if not sequence:
        raise HTTPException(status_code=404, detail="Sequence not found")
    
    if sequence.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    updates = request.dict(exclude_unset=True)
    if 'emails' in updates and updates['emails']:
        updates['emails'] = [e.dict() if hasattr(e, 'dict') else e for e in updates['emails']]
    
    updated = EmailSequenceDB.update(sequence_id, updates)
    return updated


@router.delete("/{sequence_id}")
async def delete_sequence(
    sequence_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete an email sequence"""
    sequence = EmailSequenceDB.get_by_id(sequence_id)
    if not sequence:
        raise HTTPException(status_code=404, detail="Sequence not found")
    
    if sequence.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    EmailSequenceDB.delete(sequence_id)
    return {"success": True}


@router.post("/{sequence_id}/toggle")
async def toggle_sequence(
    sequence_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Toggle sequence active state"""
    sequence = EmailSequenceDB.get_by_id(sequence_id)
    if not sequence:
        raise HTTPException(status_code=404, detail="Sequence not found")
    
    if sequence.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    updated = EmailSequenceDB.update(sequence_id, {'active': not sequence.get('active', True)})
    return updated


@router.post("/{sequence_id}/enroll")
async def enroll_lead(
    sequence_id: str,
    request: EnrollLead,
    current_user: dict = Depends(get_current_user)
):
    """Manually enroll a lead in a sequence"""
    sequence = EmailSequenceDB.get_by_id(sequence_id)
    if not sequence:
        raise HTTPException(status_code=404, detail="Sequence not found")
    
    if sequence.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    enrollment = EmailSequenceDB.enroll_lead(request.lead_id, sequence_id, request.delay_hours)
    return {"success": True, "enrollment": enrollment}


@router.get("/{sequence_id}/enrollments")
async def get_enrollments(
    sequence_id: str,
    current_user: dict = Depends(get_current_user),
    status: Optional[str] = None
):
    """Get all enrollments for a sequence"""
    sequence = EmailSequenceDB.get_by_id(sequence_id)
    if not sequence:
        raise HTTPException(status_code=404, detail="Sequence not found")
    
    if sequence.get('owner_id') != current_user['id'] and not current_user.get('is_super_user'):
        raise HTTPException(status_code=403, detail="Not authorized")
    
    enrollments = EmailSequenceDB.get_enrollments(sequence_id, status)
    return {"enrollments": enrollments}

"""
CRM Router for VYBR!S Sales Pipeline Management
Provides endpoints for managing leads, companies, and sales activities

Security Controls:
- SEC-023: Rate limiting on write operations
- SEC-024: Audit logging for all CRM modifications
- SEC-025: Input validation with length limits
"""

from fastapi import APIRouter, HTTPException, Depends, Query, status, Request, BackgroundTasks
from pydantic import BaseModel, EmailStr, Field, field_validator
from typing import List, Optional, Dict, Any
from enum import Enum
from decimal import Decimal
from datetime import date, datetime, timedelta
import uuid
import logging

from services.database import CRMLeadDB, CRMCompanyDB, UserDB, LogDB
from routers.auth import get_current_user
from middleware.rate_limit import rate_limit  # SEC-023
from shared.permissions import is_super_or_admin

router = APIRouter(prefix="/api/v1/crm", tags=["crm"])
logger = logging.getLogger(__name__)


# ============================================================================
# Enums for CRM
# ============================================================================

class LeadStatus(str, Enum):
    NEW = "new"  # Lead/New
    INTERESTED = "interested"  # Interested
    QUALIFIED = "qualified"  # Qualified
    DEMO_BOOKED = "demo_booked"  # Demo/Meeting Booked
    OFFER_SENT = "offer_sent"  # Offer Sent
    NEGOTIATION = "negotiation"  # Negotiation
    WON = "won"  # Sold/Won
    LOST = "lost"  # Lost
    DO_NOT_CONTACT = "do_not_contact"  # Do Not Contact


class LeadPriority(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class ContactMethod(str, Enum):
    EMAIL = "email"
    PHONE = "phone"
    LINKEDIN = "linkedin"
    WEBSITE_FORM = "website_form"
    REFERRAL = "referral"
    COLD_OUTREACH = "cold_outreach"
    EVENT = "event"


class Industry(str, Enum):
    WEB_DEVELOPMENT = "web_development"
    MARKETING_AGENCY = "marketing_agency"
    ECOMMERCE = "ecommerce"
    HEALTHCARE = "healthcare"
    EDUCATION = "education"
    SAAS = "saas"
    CONSULTING = "consulting"
    OTHER = "other"


class CompanySize(str, Enum):
    FREELANCER = "freelancer"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"
    ENTERPRISE = "enterprise"


class Package(str, Enum):
    STARTER = "Starter"
    PROFESSIONAL = "Professional"
    ENTERPRISE = "Enterprise"
    PARTNER = "Partner"


# ============================================================================
# Pydantic Models - Companies
# ============================================================================

class CompanyCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    website: Optional[str] = Field(None, max_length=500)
    industry: Optional[Industry] = None
    size: Optional[CompanySize] = None
    location: Optional[str] = Field(None, max_length=200)
    notes: Optional[str] = Field(None, max_length=5000)


class CompanyUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    website: Optional[str] = Field(None, max_length=500)
    industry: Optional[Industry] = None
    size: Optional[CompanySize] = None
    location: Optional[str] = Field(None, max_length=200)
    notes: Optional[str] = Field(None, max_length=5000)


class CompanyResponse(BaseModel):
    id: str
    name: str
    website: Optional[str]
    industry: Optional[str]
    size: Optional[str]
    location: Optional[str]
    notes: Optional[str]
    created_at: str
    updated_at: str
    created_by: Optional[str]


# ============================================================================
# Pydantic Models - Leads
# ============================================================================

class LeadCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    email: Optional[EmailStr] = None
    phone: Optional[str] = Field(None, max_length=50)
    company_id: Optional[str] = None
    company_name: Optional[str] = Field(None, max_length=200)
    status: LeadStatus = LeadStatus.NEW
    priority: LeadPriority = LeadPriority.MEDIUM
    contact_method: Optional[ContactMethod] = None
    source_campaign: Optional[str] = Field(None, max_length=200)
    estimated_value: Optional[Decimal] = Field(None, ge=0, le=999999999.99)
    expected_close_date: Optional[date] = None
    industry: Optional[Industry] = None
    company_size: Optional[CompanySize] = None
    package: Optional[Package] = None
    pain_points: List[str] = Field(default_factory=list, max_length=20)  # SEC-025: Limit array size
    products_interested: List[str] = Field(default_factory=list, max_length=10)  # SEC-025
    notes: Optional[str] = Field(None, max_length=10000)
    contacted: bool = False
    
    # SEC-025: Validate individual string lengths in arrays
    @field_validator('pain_points', 'products_interested')
    @classmethod
    def validate_string_lengths(cls, v):
        if v:
            for item in v:
                if len(item) > 200:
                    raise ValueError('Each item must be 200 characters or less')
        return v


class LeadUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    email: Optional[EmailStr] = None
    phone: Optional[str] = Field(None, max_length=50)
    company_id: Optional[str] = None
    company_name: Optional[str] = Field(None, max_length=200)
    status: Optional[LeadStatus] = None
    priority: Optional[LeadPriority] = None
    contact_method: Optional[ContactMethod] = None
    source_campaign: Optional[str] = Field(None, max_length=200)
    account_owner_id: Optional[str] = None
    account_owner_name: Optional[str] = None
    last_contact_date: Optional[date] = None
    next_followup_date: Optional[date] = None
    expected_close_date: Optional[date] = None
    estimated_value: Optional[Decimal] = Field(None, ge=0, le=999999999.99)
    industry: Optional[Industry] = None
    company_size: Optional[CompanySize] = None
    package: Optional[Package] = None
    pain_points: Optional[List[str]] = None
    products_interested: Optional[List[str]] = None
    products_interested: Optional[List[str]] = None
    notes: Optional[str] = Field(None, max_length=10000)
    contacted: Optional[bool] = None


class LeadResponse(BaseModel):
    id: str
    name: str
    email: Optional[str]
    phone: Optional[str]
    company_id: Optional[str]
    company_name: Optional[str]
    status: str
    priority: str
    contact_method: Optional[str]
    source_campaign: Optional[str]
    account_owner_id: Optional[str]
    account_owner_name: Optional[str]
    first_contact_date: Optional[str]
    last_contact_date: Optional[str]
    next_followup_date: Optional[str]
    expected_close_date: Optional[str]
    closed_date: Optional[str]
    estimated_value: Optional[float]
    industry: Optional[str]
    company_size: Optional[str]
    package: Optional[str]
    pain_points: List[str]
    products_interested: List[str]
    notes: Optional[str]
    created_at: str
    updated_at: str
    created_by: Optional[str]
    contacted: bool = False


class LeadListResponse(BaseModel):
    leads: List[LeadResponse]
    total: int
    limit: int
    offset: int


class CRMStatsResponse(BaseModel):
    status_counts: Dict[str, int]
    priority_counts: Dict[str, int]
    pipeline_value: float
    won_value: float
    overdue_followups: int
    total_leads: int


# ============================================================================
# Helper Functions
# ============================================================================

def apply_status_workflow(lead_data: dict, old_status: str = None, new_status: str = None) -> dict:
    """Apply workflow automations based on status changes"""
    today = date.today()
    
    # If status changed to won, lost, or do_not_contact, set closed_date
    if new_status in ['won', 'lost', 'do_not_contact'] and old_status != new_status:
        lead_data['closed_date'] = today
    
    # If status changed to offer_sent, set next_followup to +3 days
    if new_status == 'offer_sent' and old_status != new_status:
        if 'next_followup_date' not in lead_data or lead_data['next_followup_date'] is None:
            lead_data['next_followup_date'] = today + timedelta(days=3)
    
    return lead_data


def log_action(action: str, message: str, user_id: str = None, lead_id: str = None):
    """SEC-024: Log CRM actions to database for audit trail"""
    logger.info(f"[CRM] {action}: {message} (user={user_id}, lead={lead_id})")
    
    # Also log to database for SOC 2 CC7.2 compliance
    try:
        LogDB.create({
            'level': 'INFO',
            'service': 'crm',
            'user_id': user_id,
            'action': action,
            'message': message,
            'metadata': {
                'lead_id': lead_id,
                'component': 'CRM'
            }
        })
    except Exception as e:
        logger.warning(f"Failed to write audit log: {e}")


# ============================================================================
# Company Endpoints
# ============================================================================

@router.get("/companies", response_model=List[CompanyResponse])
async def list_companies(
    limit: int = Query(default=100, le=500),
    offset: int = Query(default=0, ge=0),
    search: Optional[str] = Query(default=None, max_length=100),
    current_user: dict = Depends(get_current_user)
):
    """List all companies with optional search"""
    companies = CRMCompanyDB.get_all(limit=limit, offset=offset, search=search)
    return companies


@router.get("/companies/{company_id}", response_model=CompanyResponse)
async def get_company(
    company_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get a single company by ID"""
    company = CRMCompanyDB.get_by_id(company_id)
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")
    return company


@router.post("/companies", response_model=CompanyResponse, status_code=status.HTTP_201_CREATED)
@rate_limit(limit=10, window=60, authenticated_limit=50)  # SEC-023: Rate limit writes
async def create_company(
    request: Request,
    company_data: CompanyCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create a new company"""
    data = company_data.model_dump()
    data['created_by'] = current_user['id']
    
    # Convert enums to strings
    if data.get('industry'):
        data['industry'] = data['industry'].value if hasattr(data['industry'], 'value') else data['industry']
    if data.get('size'):
        data['size'] = data['size'].value if hasattr(data['size'], 'value') else data['size']
    
    company = CRMCompanyDB.create(data)
    log_action("CREATE_COMPANY", f"Created company: {company['name']}", current_user['id'])
    return company


@router.put("/companies/{company_id}", response_model=CompanyResponse)
async def update_company(
    company_id: str,
    updates: CompanyUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update a company"""
    existing = CRMCompanyDB.get_by_id(company_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Company not found")
    
    update_data = updates.model_dump(exclude_unset=True)
    
    # Convert enums to strings
    if 'industry' in update_data and update_data['industry']:
        update_data['industry'] = update_data['industry'].value if hasattr(update_data['industry'], 'value') else update_data['industry']
    if 'size' in update_data and update_data['size']:
        update_data['size'] = update_data['size'].value if hasattr(update_data['size'], 'value') else update_data['size']
    
    company = CRMCompanyDB.update(company_id, update_data)
    log_action("UPDATE_COMPANY", f"Updated company: {company_id}", current_user['id'])
    return company


@router.delete("/companies/{company_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_company(
    company_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete a company"""
    existing = CRMCompanyDB.get_by_id(company_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Company not found")
    
    CRMCompanyDB.delete(company_id)
    log_action("DELETE_COMPANY", f"Deleted company: {company_id}", current_user['id'])


# ============================================================================
# Lead Endpoints
# ============================================================================

@router.get("/leads", response_model=LeadListResponse)
async def list_leads(
    limit: int = Query(default=50, le=500),
    offset: int = Query(default=0, ge=0),
    status: Optional[LeadStatus] = Query(default=None),
    priority: Optional[LeadPriority] = Query(default=None),
    account_owner_id: Optional[str] = Query(default=None),
    search: Optional[str] = Query(default=None, max_length=100),
    sort_by: str = Query(default="created_at"),
    sort_order: str = Query(default="desc", pattern="^(asc|desc)$"),
    view_as_user_id: Optional[str] = Query(default=None, description="Admin only: view as specific user"),
    current_user: dict = Depends(get_current_user)
):
    """List all leads with filtering, sorting, and pagination. 
    Partner accounts see only their own leads. Admins can use view_as_user_id to see specific partner's leads."""
    status_val = status.value if status else None
    priority_val = priority.value if priority else None
    
    # Determine effective owner filter based on role
    effective_owner_ids = None  # List of user IDs to filter by
    include_unassigned = False
    
    if is_super_or_admin(current_user):
        # Admins can see all leads, or filter by specific partner account
        if view_as_user_id:
            # Get all users in the partner account (partner + sub-accounts)
            partner_users = UserDB.get_by_partner(view_as_user_id)
            effective_owner_ids = [u['id'] for u in partner_users]
        # Else effective_owner_ids remains None (all leads)
    else:
        # Partner accounts and sub-accounts: only see leads from their partner account
        # Get partner_id - if user is a partner, their ID is the partner_id
        # If user belongs to a partner, use their partner_id
        partner_id = current_user.get('partner_id') or current_user.get('id')
        partner_users = UserDB.get_by_partner(partner_id)
        effective_owner_ids = [u['id'] for u in partner_users]
        
        # Debug logging
        logger.info(f"[CRM] Partner account filtering: partner_id={partner_id}, user_ids={effective_owner_ids}, user_role={current_user.get('role')}")

    
    total = CRMLeadDB.count(
        status=status_val,
        account_owner_ids=effective_owner_ids
    )
    leads = CRMLeadDB.get_all(
        limit=limit,
        offset=offset,
        status=status_val,
        priority=priority_val,
        account_owner_ids=effective_owner_ids,
        search=search,
        sort_by=sort_by,
        sort_order=sort_order
    )
    
    # Debug logging
    logger.info(f"[CRM] list_leads returned {len(leads)} leads (total={total}, limit={limit}, offset={offset})")
    
    return {
        "leads": leads,
        "total": total,
        "limit": limit,
        "offset": offset
    }


@router.get("/leads/overdue", response_model=List[LeadResponse])
async def get_overdue_leads(
    current_user: dict = Depends(get_current_user)
):
    """Get leads with overdue follow-ups"""
    leads = CRMLeadDB.get_overdue_followups()
    return leads


@router.get("/leads/followups", response_model=List[LeadResponse])
async def get_upcoming_followups(
    days: int = Query(default=7, ge=1, le=30),
    current_user: dict = Depends(get_current_user)
):
    """Get leads with follow-ups due in the next N days"""
    leads = CRMLeadDB.get_followups_due(days_ahead=days)
    return leads


@router.get("/leads/{lead_id}", response_model=LeadResponse)
async def get_lead(
    lead_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get a single lead by ID"""
    lead = CRMLeadDB.get_by_id(lead_id)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    return lead


@router.post("/leads", response_model=LeadResponse, status_code=status.HTTP_201_CREATED)
@rate_limit(limit=10, window=60, authenticated_limit=50)  # SEC-023: Rate limit writes
async def create_lead(
    request: Request,
    lead_data: LeadCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create a new lead"""
    data = lead_data.model_dump()
    
    # Set created_by and account owner
    data['created_by'] = current_user['id']
    data['account_owner_id'] = current_user['id']
    data['account_owner_name'] = current_user.get('full_name') or current_user.get('username')
    
    # Set first contact date to today
    data['first_contact_date'] = date.today()
    
    # Convert enums to strings
    for field in ['status', 'priority', 'contact_method', 'industry', 'company_size', 'package']:
        if data.get(field) and hasattr(data[field], 'value'):
            data[field] = data[field].value
    
    # Convert Decimal to float for database
    if data.get('estimated_value'):
        data['estimated_value'] = float(data['estimated_value'])
    
    # Apply workflow automations
    data = apply_status_workflow(data, old_status=None, new_status=data.get('status', 'new'))
    
    lead = CRMLeadDB.create(data)
    log_action("CREATE_LEAD", f"Created lead: {lead['name']}", current_user['id'], lead['id'])

    # Publish lead_created workflow event for async processing
    owner_id = lead.get("account_owner_id") or current_user.get("id")
    if owner_id:
        try:
            from services.message_broker import publish_workflow_event

            ctx = {"lead_id": lead["id"], "qualification_score": lead.get("qualification_score", 0)}
            publish_workflow_event("lead_created", ctx, owner_id=owner_id)
        except Exception:
            pass

    return lead


@router.put("/leads/{lead_id}", response_model=LeadResponse)
async def update_lead(
    lead_id: str,
    updates: LeadUpdate,
    request: Request,
    background_tasks: BackgroundTasks,
    current_user: dict = Depends(get_current_user)
):
    """Update a lead"""
    existing = CRMLeadDB.get_by_id(lead_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Lead not found")
    
    update_data = updates.model_dump(exclude_unset=True)
    logger.info(f"[CRM] DEBUG update_lead received: {update_data}")
    
    # Convert enums to strings
    for field in ['status', 'priority', 'contact_method', 'industry', 'company_size', 'package']:
        if field in update_data and update_data[field] and hasattr(update_data[field], 'value'):
            update_data[field] = update_data[field].value
    
    # Convert Decimal to float
    if 'estimated_value' in update_data and update_data['estimated_value']:
        update_data['estimated_value'] = float(update_data['estimated_value'])
    
    # Apply workflow automations
    if 'status' in update_data:
        update_data = apply_status_workflow(
            update_data, 
            old_status=existing['status'], 
            new_status=update_data['status']
        )
    
    # Auto-resolve company_id if name provided but ID missing
    if 'company_name' in update_data and update_data['company_name']:
        nm = update_data['company_name'].strip()
        if nm:
            # Check if company exists
            existing_company = None
            # Simple linear search or optimized query (assuming get_all supports search)
            # ideally we need get_by_name but for now:
            all_companies = CRMCompanyDB.get_all(limit=1000) # Safety limit
            for c in all_companies:
                if c['name'].lower() == nm.lower():
                    existing_company = c
                    break
            
            if existing_company:
                update_data['company_id'] = existing_company['id']
            else:
                # Create new company
                new_company_id = f"comp_{uuid.uuid4().hex[:8]}"
                CRMCompanyDB.create({
                    'id': new_company_id,
                    'name': nm,
                    'created_by': current_user['id']
                })
                update_data['company_id'] = new_company_id
                logger.info(f"[CRM] Auto-created company {nm} ({new_company_id}) for lead {lead_id}")

    lead = CRMLeadDB.update(lead_id, update_data)

    # Workflow triggers: when status changes, publish to message broker for async processing
    if "status" in update_data and update_data["status"] != existing.get("status"):
        owner_id = lead.get("account_owner_id") or existing.get("account_owner_id")
        if owner_id:
            try:
                from services.message_broker import publish_workflow_event

                ctx = {
                    "lead_id": lead_id,
                    "old_stage": existing.get("status"),
                    "new_stage": update_data["status"],
                }
                publish_workflow_event("stage_change", ctx, owner_id=owner_id)
            except Exception as e:
                logger.warning(f"Workflow event publish failed: {e}")

        # Automation rules: execute matching automation actions
        try:
            from routers.automations import execute_automation_actions
            execute_automation_actions(
                lead_id,
                "stage_change",
                {"old_stage": existing.get("status"), "new_stage": update_data["status"]},
            )
        except Exception as e:
            logger.warning(f"Automation execution failed: {e}")

    # Workflow triggers: when qualification_score changes, publish score_threshold event
    if "qualification_score" in update_data and update_data["qualification_score"] != existing.get("qualification_score"):
        owner_id = lead.get("account_owner_id") or existing.get("account_owner_id")
        if owner_id:
            try:
                from services.message_broker import publish_workflow_event

                ctx = {
                    "lead_id": lead_id,
                    "qualification_score": update_data["qualification_score"],
                    "old_score": existing.get("qualification_score", 0),
                }
                publish_workflow_event("score_threshold", ctx, owner_id=owner_id)
            except Exception as e:
                logger.warning(f"Workflow event publish failed: {e}")

    log_action("UPDATE_LEAD", f"Updated lead: {lead_id}", current_user['id'], lead_id)
    return lead


@router.delete("/leads/{lead_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_lead(
    lead_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete a lead"""
    existing = CRMLeadDB.get_by_id(lead_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Lead not found")
    
    CRMLeadDB.delete(lead_id)
    log_action("DELETE_LEAD", f"Deleted lead: {lead_id}", current_user['id'], lead_id)


# ============================================================================
# Statistics Endpoints
# ============================================================================

@router.get("/stats", response_model=CRMStatsResponse)
async def get_crm_stats(
    view_as_user_id: Optional[str] = Query(default=None, description="Admin only: view as specific user"),
    current_user: dict = Depends(get_current_user)
):
    """Get CRM statistics for dashboard. Partner accounts see only their own stats."""
    # Determine effective owner filter based on role
    effective_owner_ids = None  # List of user IDs to filter by
    
    if is_super_or_admin(current_user):
        if view_as_user_id:
            # Get all users in the partner account (partner + sub-accounts)
            partner_users = UserDB.get_by_partner(view_as_user_id)
            effective_owner_ids = [u['id'] for u in partner_users]
    else:
        # Partner accounts and sub-accounts: only see stats from their partner account
        partner_id = current_user.get('partner_id') or current_user.get('id')
        partner_users = UserDB.get_by_partner(partner_id)
        effective_owner_ids = [u['id'] for u in partner_users]
    
    stats = CRMLeadDB.get_stats(
        owner_ids=effective_owner_ids
    )
    return stats


@router.get("/stats/by-owner")
async def get_stats_by_owner(
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """Get lead counts grouped by account owner (Admin only)"""
    # Only admins can see stats by owner
    if not is_super_or_admin(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required to view stats by owner"
        )
    
    # Get all users for names
    users = UserDB.get_all()
    user_map = {u['id']: u.get('full_name') or u.get('username') for u in users}
    
    # Get leads grouped by owner
    owner_stats = {}
    for user_id, user_name in user_map.items():
        count = CRMLeadDB.count(account_owner_id=user_id)
        if count > 0:
            owner_stats[user_id] = {
                'name': user_name,
                'lead_count': count
            }
    
    return owner_stats


# ============================================================================
# Bulk/Utility Endpoints
# ============================================================================

@router.post("/leads/{lead_id}/update-contact")
async def log_contact(
    lead_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Log a contact/touchpoint with a lead (updates last_contact_date)"""
    existing = CRMLeadDB.get_by_id(lead_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Lead not found")
    
    lead = CRMLeadDB.update(lead_id, {'last_contact_date': date.today()})
    log_action("LOG_CONTACT", f"Logged contact for lead: {lead_id}", current_user['id'], lead_id)
    return lead

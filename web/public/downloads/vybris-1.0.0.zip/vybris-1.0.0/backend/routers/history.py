"""
Chat history API.

Access control: only the account owner (chatbot owner) or users granted access by email
can access chat history. Super users have no bypass—even the software owner cannot
access partner account history.

Chat message content is not stored on the server; it lives client-side only (widget
localStorage) for full data privacy. Sessions metadata (e.g. counts, categories) may
still be stored for listing.
"""

from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends, Query
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

from services.database import (
    ChatbotDB,
    MessageDB,
    get_db_connection,
    HistoryAccessGrantsDB,
    HistoryStorageConfigDB,
)
from routers.auth import get_current_user

router = APIRouter(prefix="/api/v1/history", tags=["history"])


def _normalize_email(s: str) -> str:
    return (s or "").strip().lower()


def _allowed_owner_ids_for_history(user: dict) -> List[str]:
    """
    Owner IDs whose chat history this user can access.
    - Own account: user['id'].
    - Granted: any owner_id where user's email is in history_access_grants.
    Super_user is never given elevated access to history.
    """
    allowed = [user["id"]]
    email = _normalize_email(user.get("email") or "")
    if not email:
        return allowed
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT DISTINCT owner_id FROM history_access_grants
            WHERE granted_email = %s
            """,
            (email,),
        )
        for row in cursor.fetchall():
            oid = row.get("owner_id")
            if oid and oid not in allowed:
                allowed.append(oid)
    return allowed


def _check_can_access_chatbot(user: dict, chatbot: dict) -> None:
    """Raise 403 if user cannot access this chatbot's history. No super_user bypass."""
    owner_id = chatbot.get("owner_id")
    if owner_id == user["id"]:
        return
    if HistoryAccessGrantsDB.has_grant(owner_id, user.get("email") or ""):
        return
    raise HTTPException(status_code=403, detail="Access denied to this chatbot's history")


@router.get("/sessions")
async def list_chat_sessions(
    chatbot_id: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    only_unknown: bool = Query(False, description="Filter for sessions with unknown/failed interactions"),
    limit: int = 50,
    offset: int = 0,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    List chat sessions. Only owner or granted users can access; no super_user bypass.
    """
    if chatbot_id:
        chatbot = ChatbotDB.get_by_id(chatbot_id)
        if not chatbot:
            raise HTTPException(status_code=404, detail="Chatbot not found")
        _check_can_access_chatbot(current_user, chatbot)

    allowed = _allowed_owner_ids_for_history(current_user)
    if not allowed:
        return {"sessions": [], "total": 0, "limit": limit, "offset": offset}

    placeholders = ",".join(["%s"] * len(allowed))
    params: List[Any] = list(allowed)

    with get_db_connection() as conn:
        cursor = conn.cursor()
        query = f"""
            SELECT cs.* FROM chat_sessions cs
            INNER JOIN chatbots c ON cs.chatbot_id = c.id
            WHERE c.owner_id IN ({placeholders})
        """
        if chatbot_id:
            query += " AND cs.chatbot_id = %s"
            params.append(chatbot_id)
        if category:
            query += " AND cs.category = %s"
            params.append(category)
        if only_unknown:
            query += " AND cs.has_unknown_interaction = TRUE"
        query += " ORDER BY cs.last_activity DESC LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        cursor.execute(query, tuple(params))
        sessions = [dict(row) for row in cursor.fetchall()]

        count_query = f"""
            SELECT COUNT(*) as count FROM chat_sessions cs
            INNER JOIN chatbots c ON cs.chatbot_id = c.id
            WHERE c.owner_id IN ({placeholders})
        """
        count_params: List[Any] = list(allowed)
        if chatbot_id:
            count_query += " AND cs.chatbot_id = %s"
            count_params.append(chatbot_id)
        if category:
            count_query += " AND cs.category = %s"
            count_params.append(category)
        if only_unknown:
            count_query += " AND cs.has_unknown_interaction = TRUE"
        cursor.execute(count_query, tuple(count_params))
        total = cursor.fetchone()["count"]

    return {"sessions": sessions, "total": total, "limit": limit, "offset": offset}


@router.get("/sessions/{session_id}/messages")
async def get_session_messages(
    session_id: str,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Get message history for a session. Only owner or granted users.
    Message content is stored client-side only; this returns empty when
    server-side storage is disabled for privacy.
    """
    allowed = _allowed_owner_ids_for_history(current_user)
    if not allowed:
        raise HTTPException(status_code=404, detail="Session not found or access denied")

    placeholders = ",".join(["%s"] * len(allowed))
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            f"""
            SELECT cs.*, c.owner_id
            FROM chat_sessions cs
            INNER JOIN chatbots c ON cs.chatbot_id = c.id
            WHERE cs.session_id = %s AND c.owner_id IN ({placeholders})
            """,
            (session_id, *allowed),
        )
        session = cursor.fetchone()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found or access denied")

    owner_id = session.get("owner_id")
    storage = HistoryStorageConfigDB.get(owner_id) if owner_id else "local"
    if storage in ("cloud", "owner_device"):
        messages = MessageDB.get_by_session(session_id, limit=200)
        return {"messages": messages, "client_only_storage": False}
    return {"messages": [], "client_only_storage": True}


@router.get("/categories")
async def get_categories(
    chatbot_id: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
) -> Dict[str, List[str]]:
    """Categories from chat sessions. Only owner or granted users."""
    if chatbot_id:
        chatbot = ChatbotDB.get_by_id(chatbot_id)
        if not chatbot:
            raise HTTPException(status_code=404, detail="Chatbot not found")
        _check_can_access_chatbot(current_user, chatbot)

    allowed = _allowed_owner_ids_for_history(current_user)
    if not allowed:
        return {"categories": []}

    placeholders = ",".join(["%s"] * len(allowed))
    params: List[Any] = list(allowed)
    if chatbot_id:
        params.append(chatbot_id)

    with get_db_connection() as conn:
        cursor = conn.cursor()
        query = f"""
            SELECT DISTINCT cs.category FROM chat_sessions cs
            INNER JOIN chatbots c ON cs.chatbot_id = c.id
            WHERE cs.category IS NOT NULL AND c.owner_id IN ({placeholders})
        """
        if chatbot_id:
            query += " AND cs.chatbot_id = %s"
        query += " ORDER BY cs.category"
        cursor.execute(query, tuple(params))
        rows = cursor.fetchall()
    return {"categories": [r["category"] for r in rows]}


@router.get("/unknown-questions")
async def get_unknown_questions(
    chatbot_id: Optional[str] = Query(None),
    limit: int = 500,
    offset: int = 0,
    format: str = Query("json", pattern="^(json|csv)$"),
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Unknown questions (user Q preceding unknown assistant reply).
    Only owner or granted users. Populated only when storage is cloud; empty for local.
    """
    if chatbot_id:
        chatbot = ChatbotDB.get_by_id(chatbot_id)
        if not chatbot:
            raise HTTPException(status_code=404, detail="Chatbot not found")
        _check_can_access_chatbot(current_user, chatbot)

    allowed = _allowed_owner_ids_for_history(current_user)
    cloud_owners = [o for o in allowed if HistoryStorageConfigDB.get(o) in ("cloud", "owner_device")]
    if not cloud_owners:
        def empty_csv():
            yield "chatbot_id,session_id,user_message_id,user_question,user_created_at,assistant_message_id,assistant_response,assistant_created_at\n"
        if format == "csv":
            return StreamingResponse(
                empty_csv(),
                media_type="text/csv",
                headers={"Content-Disposition": "attachment; filename=unknown_questions.csv"},
            )
        return {"items": [], "total": 0, "limit": limit, "offset": offset}

    placeholders = ",".join(["%s"] * len(cloud_owners))
    params: List[Any] = list(cloud_owners)
    if chatbot_id:
        params.append(chatbot_id)
    base_query = f"""
        SELECT
            m.id AS assistant_message_id,
            m.session_id,
            m.chatbot_id,
            m.created_at AS assistant_created_at,
            m.content AS assistant_response,
            u.id AS user_message_id,
            u.content AS user_question,
            u.created_at AS user_created_at
        FROM chat_messages m
        INNER JOIN chatbots c ON m.chatbot_id = c.id
        JOIN LATERAL (
            SELECT u2.*
            FROM chat_messages u2
            WHERE u2.session_id = m.session_id
              AND u2.chatbot_id = m.chatbot_id
              AND u2.role = 'user'
              AND u2.created_at <= m.created_at
            ORDER BY u2.created_at DESC
            LIMIT 1
        ) u ON TRUE
        WHERE m.role = 'assistant'
          AND m.is_unknown = TRUE
          AND c.owner_id IN ({placeholders})
    """
    if chatbot_id:
        base_query += " AND m.chatbot_id = %s"

    with get_db_connection() as conn:
        cursor = conn.cursor()
        count_query = f"SELECT COUNT(*) AS count FROM ({base_query}) sub"
        cursor.execute(count_query, tuple(params))
        total = cursor.fetchone()["count"]
        base_query += " ORDER BY m.created_at DESC LIMIT %s OFFSET %s"
        cursor.execute(base_query, tuple(params + [limit, offset]))
        rows = [dict(r) for r in cursor.fetchall()]

    if format == "csv":
        def gen_csv():
            yield "chatbot_id,session_id,user_message_id,user_question,user_created_at,assistant_message_id,assistant_response,assistant_created_at\n"
            for r in rows:
                q = (r.get("user_question") or "").replace('"', '""')
                a = (r.get("assistant_response") or "").replace('"', '""')
                yield f'{r.get("chatbot_id")},{r.get("session_id")},{r.get("user_message_id")},"{q}",{r.get("user_created_at")},{r.get("assistant_message_id")},"{a}",{r.get("assistant_created_at")}\n'
        return StreamingResponse(
            gen_csv(),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=unknown_questions.csv"},
        )
    return {"items": rows, "total": total, "limit": limit, "offset": offset}


# ---------- Export to owner's folder (quality/evaluation) ----------


@router.get("/export")
async def export_chat_history(
    chatbot_id: Optional[str] = Query(None),
    format: str = Query("json", pattern="^(json|csv)$"),
    limit: int = Query(5000, ge=1, le=50000),
    current_user: dict = Depends(get_current_user),
):
    """
    Export all chat history for the account owner. Use with "Export to folder" in the UI.
    Returns data to save to the owner's chosen folder (quality/evaluation).
    """
    allowed = _allowed_owner_ids_for_history(current_user)
    if not allowed:
        return {"sessions": [], "total": 0}

    placeholders = ",".join(["%s"] * len(allowed))
    params: List[Any] = list(allowed)
    if chatbot_id:
        params.append(chatbot_id)
    params.append(limit)

    with get_db_connection() as conn:
        cursor = conn.cursor()
        query = f"""
            SELECT cs.session_id, cs.chatbot_id, cs.started_at, cs.last_activity, cs.message_count, cs.category, cs.has_unknown_interaction
            FROM chat_sessions cs
            INNER JOIN chatbots c ON cs.chatbot_id = c.id
            WHERE c.owner_id IN ({placeholders})
        """
        if chatbot_id:
            query += " AND cs.chatbot_id = %s"
        query += " ORDER BY cs.last_activity DESC LIMIT %s"
        cursor.execute(query, tuple(params))
        sessions = [dict(row) for row in cursor.fetchall()]

    # Only include messages for owners with cloud/owner_device storage
    cloud_owners = [o for o in allowed if HistoryStorageConfigDB.get(o) in ("cloud", "owner_device")]
    export_data: Dict[str, Any] = {"exported_at": datetime.utcnow().isoformat() + "Z", "sessions": []}

    for sess in sessions:
        owner_id = None
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT owner_id FROM chatbots WHERE id = %s", (sess["chatbot_id"],))
            row = cursor.fetchone()
            if row:
                owner_id = row.get("owner_id")
        if owner_id and owner_id not in cloud_owners:
            export_data["sessions"].append({**sess, "messages": [], "client_only": True})
            continue
        messages = MessageDB.get_by_session(sess["session_id"], limit=500)
        export_data["sessions"].append({**sess, "messages": [{"role": m["role"], "content": m["content"], "created_at": str(m.get("created_at", "")), "is_unknown": m.get("is_unknown")} for m in messages], "client_only": False})

    if format == "csv":
        lines = ["session_id,chatbot_id,role,content,created_at,is_unknown"]
        for sess in export_data["sessions"]:
            for m in sess.get("messages", []):
                c = (m.get("content") or "").replace('"', '""')
                lines.append(f'{sess["session_id"]},{sess["chatbot_id"]},{m.get("role")},"{c}",{m.get("created_at")},{m.get("is_unknown")}')
        return Response(content="\n".join(lines), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=chat_history_export.csv"})
    return export_data


# ---------- History access grants (owner only) ----------


class AddGrantRequest(BaseModel):
    email: str


class StorageConfigUpdate(BaseModel):
    storage_type: str  # 'local' | 'cloud'


@router.get("/storage-config")
async def get_storage_config(
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """Get chat-history storage config for your account. Owner only."""
    storage = HistoryStorageConfigDB.get(current_user["id"])
    return {"storage_type": storage}


@router.put("/storage-config")
async def update_storage_config(
    body: StorageConfigUpdate,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """Set where chat history is saved. Owner only."""
    st = (body.storage_type or "").strip().lower()
    if st not in ("local", "cloud", "owner_device"):
        raise HTTPException(status_code=400, detail="storage_type must be 'local', 'cloud', or 'owner_device'")
    HistoryStorageConfigDB.set(current_user["id"], st)
    return {"storage_type": st}


@router.get("/access-grants")
async def list_access_grants(
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """List emails granted access to your chat history. Owner only (your grants)."""
    grants = HistoryAccessGrantsDB.list_for_owner(current_user["id"])
    return {"grants": grants}


@router.post("/access-grants")
async def add_access_grant(
    body: AddGrantRequest,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """Grant chat-history access to an email. Owner only."""
    try:
        grant = HistoryAccessGrantsDB.add(current_user["id"], body.email)
        return {"grant": grant}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/access-grants")
async def remove_access_grant(
    email: str = Query(..., description="Granted email to revoke"),
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """Revoke chat-history access for an email. Owner only."""
    removed = HistoryAccessGrantsDB.remove(current_user["id"], email)
    if not removed:
        raise HTTPException(status_code=404, detail="Grant not found")
    return {"ok": True}

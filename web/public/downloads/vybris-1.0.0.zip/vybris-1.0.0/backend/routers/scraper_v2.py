"""
Scraper Router (Refactored)
HTTP endpoints for web scraping, delegating to ScraperService.

This router handles:
- Starting scrape jobs
- Getting job status/results
- Saving content to chatbots
"""

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import logging

from routers.auth import get_current_user
from shared.permissions import can_access_chatbot
from services.database import ChatbotDB
from services.scraper_service import scraper_service, ScrapeStatus
from services.usage_service import usage_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/scraper", tags=["scraper"])


# ==================== Request/Response Models ====================

class ScrapeRequest(BaseModel):
    """Request model for starting a scrape job."""
    url: str = Field(..., description="The website URL to scrape")
    depth: int = Field(default=3, ge=1, le=10, description="How many levels deep to crawl (1-10)")
    max_pages: int = Field(default=100, ge=1, le=10000, description="Maximum number of pages to scrape (safety limit)")
    include_subpages: bool = Field(default=True, description="Include links from the same domain")
    extract_metadata: bool = Field(default=True, description="Extract page metadata")
    chatbot_id: Optional[str] = Field(default=None, description="Chatbot ID to associate content with")
    use_sitemap: bool = Field(default=True, description="Try to discover pages from sitemap.xml")
    render_js: bool = Field(default=False, description="Use Playwright for JavaScript rendering")
    wait_for_selector: Optional[str] = Field(default=None, description="CSS selector to wait for")
    page_timeout: Optional[int] = Field(default=None, ge=10, le=120, description="Timeout per page in seconds (10-120)")
    concurrency: Optional[int] = Field(default=None, ge=1, le=10, description="Concurrent pages for static scraping (1-10, default 5)")
    delay: Optional[float] = Field(default=None, ge=0.05, le=2.0, description="Delay between requests in seconds (0.05-2.0, default 0.1)")


class ScrapeStatusResponse(BaseModel):
    """Response model for scrape job status."""
    job_id: str
    status: str
    progress: float
    pages_scraped: int
    current_url: Optional[str]
    error: Optional[str]


class ScrapedContentPreview(BaseModel):
    """Response model for scraped content preview."""
    url: str
    title: str
    preview: str
    word_count: int


# ==================== Endpoints ====================

@router.get("/capabilities")
async def get_scraper_capabilities():
    """Get scraper capabilities including whether JS rendering is available."""
    return scraper_service.get_capabilities()


@router.post("/start", response_model=Dict[str, Any])
async def start_scrape(
    request: ScrapeRequest,
    background_tasks: BackgroundTasks,
    current_user: dict = Depends(get_current_user)
):
    """Start a web scraping job."""
    
    # Limit check removed
    # Check removed - unlimited access
    
    # Validate URL
    valid, url_or_error = scraper_service.validate_url(request.url)
    if not valid:
        raise HTTPException(status_code=400, detail=url_or_error)
    
    url = url_or_error
    
    # Check Playwright availability
    if request.render_js and not scraper_service.playwright_available:
        raise HTTPException(
            status_code=400,
            detail="JavaScript rendering requested but Playwright is not installed."
        )
    
    # Automatically add scraped domain to CORS allowed origins when scraping starts
    # This allows the widget to be embedded on the scraped website immediately
    if request.chatbot_id:
        try:
            from services.cors_service import cors_service
            added_origins = cors_service.add_domain_from_url(url, request.chatbot_id)
            if added_origins:
                logger.info(f"Auto-added {len(added_origins)} CORS origins for scraped domain at scrape start: {added_origins}")
        except Exception as e:
            logger.warning(f"Failed to auto-add CORS origins for scraped URL {url} at scrape start: {e}")
    
    # Create job
    job = scraper_service.create_job(
        url=url,
        depth=request.depth,
        max_pages=request.max_pages,
        chatbot_id=request.chatbot_id,
        render_js=request.render_js
    )
    
    # Start background crawl
    background_tasks.add_task(
        scraper_service.crawl_website,
        job.job_id,
        url,
        request.depth,
        request.max_pages,
        request.include_subpages,
        request.use_sitemap,
        request.render_js,
        request.wait_for_selector,
        request.page_timeout,
        request.concurrency,
        request.delay
    )
    
    js_mode = " with JavaScript rendering" if request.render_js else ""
    concurrency_info = f" (concurrent: {request.concurrency or 5})" if not request.render_js else ""
    return {"job_id": job.job_id, "message": f"Scrape job started{js_mode}{concurrency_info}"}


@router.get("/status/{job_id}", response_model=ScrapeStatusResponse)
async def get_scrape_status(
    job_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get the status of a scraping job."""
    status = scraper_service.get_job_status(job_id)
    
    if not status:
        raise HTTPException(status_code=404, detail="Scrape job not found")
    
    return ScrapeStatusResponse(**status)


@router.get("/result/{job_id}")
async def get_scrape_result(
    job_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get the full result of a completed scraping job."""
    job = scraper_service.get_job(job_id)
    
    if not job:
        raise HTTPException(status_code=404, detail="Scrape job not found")
    
    if job.status in (ScrapeStatus.PENDING, ScrapeStatus.IN_PROGRESS):
        return {"status": job.status.value, "message": "Scrape job still in progress"}
    
    return scraper_service.get_job_result(job_id)


@router.get("/preview/{job_id}", response_model=List[ScrapedContentPreview])
async def get_scrape_preview(
    job_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get a preview of scraped content."""
    job = scraper_service.get_job(job_id)
    
    if not job:
        raise HTTPException(status_code=404, detail="Scrape job not found")
    
    if job.status != ScrapeStatus.COMPLETED:
        raise HTTPException(status_code=400, detail="Scrape job not completed yet")
    
    previews = scraper_service.get_job_preview(job_id)
    return [ScrapedContentPreview(**p) for p in previews]


@router.post("/save/{job_id}/{chatbot_id}")
async def save_scraped_content_endpoint(
    job_id: str,
    chatbot_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Save scraped content to a chatbot for training."""
    from services.database import ScrapedContentDB, KnowledgeDB
    import logging
    logger = logging.getLogger(__name__)

    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot or not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to access this chatbot")
    
    job = scraper_service.get_job(job_id)
    
    if not job:
        raise HTTPException(status_code=404, detail="Scrape job not found")
    
    if job.status != ScrapeStatus.COMPLETED:
        raise HTTPException(status_code=400, detail="Scrape job not completed yet")
    
    # Combine content for training
    combined_content = []
    for page in job.pages:
        combined_content.append({
            'url': page.url,
            'title': page.title,
            'content': page.content,
            'word_count': page.word_count
        })
    
    content_data = {
        'source_url': job.url,
        'scraped_at': job.completed_at,
        'pages': combined_content,
        'total_words': sum(p['word_count'] for p in combined_content),
        'total_pages': len(combined_content)
    }
    
    # Save to database
    ScrapedContentDB.save(chatbot_id, content_data)
    
    # Automatically add scraped domain to CORS allowed origins
    # This allows clients to embed the widget on their scraped website
    try:
        from services.cors_service import cors_service
        added_origins = cors_service.add_domain_from_url(job.url, chatbot_id)
        if added_origins:
            logger.info(f"Auto-added {len(added_origins)} CORS origins for scraped domain: {added_origins}")
    except Exception as e:
        logger.warning(f"Failed to auto-add CORS origins for scraped URL {job.url}: {e}")
    
    # Update usage stats
    page_count = content_data.get('total_pages', 0)
    if page_count > 0:
        usage_service.increment_page_count(current_user['id'], page_count)
    
    try:
        # Save to knowledge_items for Knowledge Hub (optimized batch insert)
        knowledge_items_data = []
        for page in job.pages:
            if page.content and len(page.content) > 50:
                content_preview = page.content[:500] + ('...' if len(page.content) > 500 else '')
                
                knowledge_items_data.append({
                    'chatbot_id': chatbot_id,
                    'source_type': 'scraped_page',
                    'title': page.title or f"Page: {page.url}",
                    'content': page.content,
                    'url': page.url,
                    'word_count': page.word_count,
                    'metadata': {
                        'source_url': page.url,
                        'word_count': page.word_count,
                        'scraped_at': page.scraped_at,
                        'preview': content_preview
                    }
                })

        # Batch insert all items in one transaction
        if knowledge_items_data:
            created = KnowledgeDB.create_batch(knowledge_items_data)
            logger.info(f"Created {len(knowledge_items_data)} knowledge items for chatbot {chatbot_id}")

            # Auto-train chatbot on new content (if learning enabled)
            from services.database import ChatbotDB
            from services.nlp_service import nlp_service
            chatbot = ChatbotDB.get_by_id(chatbot_id)
            enable_learning = chatbot.get('config', {}).get('enableLearning', True) if chatbot else True
            if enable_learning and knowledge_items_data:
                try:
                    texts = [item['content'] for item in knowledge_items_data]
                    metas = [{'title': item.get('title'), 'source_url': item.get('url')} for item in knowledge_items_data]
                    nlp_service.train_texts_batch(chatbot_id, texts, metas)
                    logger.info(f"Auto-trained chatbot {chatbot_id} on {len(texts)} scraped items")
                except Exception as train_err:
                    logger.warning(f"Auto-train after scrape save failed: {train_err}")
        
        return {
            "status": "success",
            "message": f"Saved {len(combined_content)} pages to chatbot",
            "total_words": content_data['total_words'],
            "knowledge_items_created": len(knowledge_items_data)
        }
        
    except Exception as e:
        logger.error(f"Error saving scraped content: {e}", exc_info=True)  # Logs traceback safely
        raise HTTPException(status_code=500, detail=f"Failed to save content: {str(e)}")


@router.get("/content/{chatbot_id}")
async def get_chatbot_scraped_content(
    chatbot_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get scraped content associated with a chatbot."""
    from services.database import ScrapedContentDB

    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot or not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to access this chatbot")
    content = ScrapedContentDB.get(chatbot_id)
    return {"chatbot_id": chatbot_id, "content": content}


@router.delete("/content/{chatbot_id}")
async def delete_chatbot_scraped_content(
    chatbot_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Delete scraped content associated with a chatbot."""
    from services.database import ScrapedContentDB

    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot or not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to access this chatbot")
    ScrapedContentDB.delete_by_chatbot(chatbot_id)
    return {"status": "success", "message": "Scraped content deleted"}

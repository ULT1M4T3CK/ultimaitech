"""
Logs Router for VYBR!S
API endpoints for viewing system logs
"""

from fastapi import APIRouter, Depends, Query, HTTPException, status
from typing import Optional
from routers.auth import get_current_user, require_admin
from services.database import LogDB
from shared.error_tracking import error_tracker

router = APIRouter(prefix="/api/v1/logs", tags=["logs"])


@router.get("/")
async def get_logs(
    limit: int = Query(default=100, le=500),
    offset: int = Query(default=0, ge=0),
    level: Optional[str] = Query(default=None),
    service: Optional[str] = Query(default=None),
    chatbot_id: Optional[str] = Query(default=None),
    current_user: dict = Depends(get_current_user)
):
    """Get system logs with optional filtering"""
    
    logs = LogDB.get_all(
        limit=limit,
        offset=offset,
        level=level,
        service=service,
        chatbot_id=chatbot_id
    )
    
    total_count = LogDB.count(level=level, service=service)
    
    return {
        "logs": logs,
        "total": total_count,
        "limit": limit,
        "offset": offset
    }


@router.delete("/")
async def clear_logs(current_user: dict = Depends(get_current_user)):
    """Clear all logs (admin only)"""
    
    # Check if user is admin
    if current_user.get('role') != 'admin':
        from fastapi import HTTPException, status
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admins can clear logs"
        )
    
    count = LogDB.clear_all()
    
    return {
        "message": f"Cleared {count} log entries",
        "count": count
    }


@router.get("/errors/analytics")
async def get_error_analytics(
    hours: int = Query(default=24, ge=1, le=168, description="Hours to analyze (1-168)"),
    current_user: dict = Depends(require_admin)
):
    """Get error analytics and statistics (admin only)"""
    stats = error_tracker.get_error_statistics(hours=hours)
    return stats


@router.get("/errors/systemic")
async def get_systemic_errors(
    threshold: int = Query(default=10, ge=1, description="Minimum error count to consider systemic"),
    current_user: dict = Depends(require_admin)
):
    """Get systemic error issues (admin only)"""
    issues = error_tracker.detect_systemic_issues(threshold=threshold)
    return {
        "systemic_issues": issues,
        "count": len(issues),
        "threshold": threshold
    }

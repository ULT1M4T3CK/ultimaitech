"""
Elias Smart Assistant API
Summaries, to-dos, and ask endpoint for the Elias tab.
All endpoints require authentication; admin required for full access.
"""

import logging
import os
from typing import Optional, List

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field

from routers.auth import get_current_user, require_admin
from services.database import EliasSummariesDB, EliasTodosDB
from services.elias_client import try_elias_reply
from services.llm import llm_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/elias", tags=["elias"])

# Input limits (security and UX)
MESSAGE_MAX_LEN = 4_000
SUMMARY_CONTENT_MAX_LEN = 50_000
TODO_TITLE_MAX_LEN = 500

ELIAS_GATEWAY_URL = os.getenv("ELIAS_GATEWAY_URL", "").strip().rstrip("/")
ELEVENLABS_API_KEY = (os.getenv("ELEVENLABS_API_KEY") or os.getenv("XI_API_KEY") or "").strip()
ELEVENLABS_ELIAS_VOICE_ID = (os.getenv("ELEVENLABS_ELIAS_VOICE_ID") or "1B9HBaNSKytIo32oMdsh").strip()
TTS_TEXT_MAX_LEN = 500


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------

class AskRequest(BaseModel):
    """Request body for POST /ask"""
    message: str = Field(..., min_length=1, max_length=MESSAGE_MAX_LEN)


class AskResponse(BaseModel):
    """Response for POST /ask"""
    reply: Optional[str] = None
    error: Optional[str] = None


class SummaryCreate(BaseModel):
    """Create a summary (backend or future parsing)"""
    type: str = Field(..., pattern="^(daily|session)$")
    content: str = Field(..., min_length=1, max_length=SUMMARY_CONTENT_MAX_LEN)
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    session_id: Optional[str] = None


class TodoCreate(BaseModel):
    """Create a to-do"""
    title: str = Field(..., min_length=1, max_length=TODO_TITLE_MAX_LEN)
    due_at: Optional[str] = None


class TodoUpdate(BaseModel):
    """Update a to-do"""
    title: Optional[str] = Field(None, min_length=1, max_length=TODO_TITLE_MAX_LEN)
    status: Optional[str] = Field(None, pattern="^(pending|done|cancelled)$")
    due_at: Optional[str] = None


# ---------------------------------------------------------------------------
# Summaries
# ---------------------------------------------------------------------------

@router.get("/summaries")
async def list_summaries(
    type: Optional[str] = None,
    limit: int = 50,
    current_user: dict = Depends(require_admin),
):
    """List summaries for the current user. Admin only."""
    if type and type not in ("daily", "session"):
        raise HTTPException(status_code=400, detail="type must be daily or session")
    items = EliasSummariesDB.get_by_user(current_user["id"], summary_type=type, limit=limit)
    return {"summaries": items}


@router.get("/summaries/latest")
async def get_latest_summary(
    type: Optional[str] = None,
    current_user: dict = Depends(require_admin),
):
    """Get the most recent summary. Admin only."""
    if type and type not in ("daily", "session"):
        raise HTTPException(status_code=400, detail="type must be daily or session")
    summary = EliasSummariesDB.get_latest(current_user["id"], summary_type=type)
    return {"summary": summary}


@router.post("/summaries")
async def create_summary(
    body: SummaryCreate,
    current_user: dict = Depends(require_admin),
):
    """Create a summary. Admin only."""
    try:
        row = EliasSummariesDB.create(
            current_user["id"],
            body.type,
            body.content,
            period_start=body.period_start,
            period_end=body.period_end,
            session_id=body.session_id,
        )
        return row
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/summaries/{summary_id}")
async def get_summary(
    summary_id: str,
    current_user: dict = Depends(require_admin),
):
    """Get a summary by id. Returns 404 if not found or not owned."""
    summary = EliasSummariesDB.get_by_id(summary_id, current_user["id"])
    if not summary:
        raise HTTPException(status_code=404, detail="Summary not found")
    return summary


@router.delete("/summaries/{summary_id}")
async def delete_summary(
    summary_id: str,
    current_user: dict = Depends(require_admin),
):
    """Delete a summary. Returns 404 if not found or not owned."""
    deleted = EliasSummariesDB.delete(summary_id, current_user["id"])
    if not deleted:
        raise HTTPException(status_code=404, detail="Summary not found")
    return {"success": True}


# ---------------------------------------------------------------------------
# To-dos
# ---------------------------------------------------------------------------

@router.get("/todos")
async def list_todos(
    status: Optional[str] = None,
    limit: int = 100,
    current_user: dict = Depends(require_admin),
):
    """List to-dos for the current user. Admin only."""
    if status and status not in ("pending", "done", "cancelled"):
        raise HTTPException(status_code=400, detail="status must be pending, done, or cancelled")
    items = EliasTodosDB.get_by_user(current_user["id"], status=status, limit=limit)
    return {"todos": items}


@router.post("/todos")
async def create_todo(
    body: TodoCreate,
    current_user: dict = Depends(require_admin),
):
    """Create a to-do. Admin only."""
    try:
        row = EliasTodosDB.create(
            current_user["id"],
            body.title,
            due_at=body.due_at,
        )
        return row
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/todos/{todo_id}")
async def get_todo(
    todo_id: str,
    current_user: dict = Depends(require_admin),
):
    """Get a to-do by id. Returns 404 if not found or not owned."""
    todo = EliasTodosDB.get_by_id(todo_id, current_user["id"])
    if not todo:
        raise HTTPException(status_code=404, detail="To-do not found")
    return todo


@router.patch("/todos/{todo_id}")
async def update_todo(
    todo_id: str,
    body: TodoUpdate,
    current_user: dict = Depends(require_admin),
):
    """Update a to-do. Returns 404 if not found or not owned."""
    updates = body.model_dump(exclude_unset=True)
    if not updates:
        todo = EliasTodosDB.get_by_id(todo_id, current_user["id"])
        if not todo:
            raise HTTPException(status_code=404, detail="To-do not found")
        return todo
    try:
        updated = EliasTodosDB.update(todo_id, current_user["id"], updates)
        if not updated:
            raise HTTPException(status_code=404, detail="To-do not found")
        return updated
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/todos/{todo_id}")
async def delete_todo(
    todo_id: str,
    current_user: dict = Depends(require_admin),
):
    """Delete a to-do. Returns 404 if not found or not owned."""
    deleted = EliasTodosDB.delete(todo_id, current_user["id"])
    if not deleted:
        raise HTTPException(status_code=404, detail="To-do not found")
    return {"success": True}


# ---------------------------------------------------------------------------
# Ask (Elias reply via OpenClaw hook)
# ---------------------------------------------------------------------------

@router.post("/ask", response_model=AskResponse)
async def ask_elias(
    body: AskRequest,
    current_user: dict = Depends(require_admin),
):
    """
    Send a message to Elias (OpenClaw) and return the reply.
    Admin only. Requires ELIAS_GATEWAY_URL and ELIAS_HOOK_TOKEN to be set.
    """
    if not ELIAS_GATEWAY_URL or not ELIAS_GATEWAY_URL.startswith(("http://", "https://")):
        raise HTTPException(
            status_code=503,
            detail="Elias assistant is not configured. Set ELIAS_GATEWAY_URL and ELIAS_HOOK_TOKEN.",
        )
    message = (body.message or "").strip()
    if not message:
        raise HTTPException(status_code=400, detail="message is required")

    success, reply_text = await try_elias_reply(
        message=message,
        chatbot_id="elias-tab",
        tenant_id=current_user["id"],
        session_id="default",
        elias_url=ELIAS_GATEWAY_URL,
        elias_bot_name="Elias",
    )
    # Prefer real reply from gateway (sync); skip 202 placeholder text
    if success and reply_text and "will appear in the conversation or voice panel shortly" not in (reply_text or ""):
        return AskResponse(reply=reply_text)
    # Fallback: direct Perplexity so the user gets an actual response in the chat
    if llm_service.is_enabled():
        direct_reply = await llm_service.generate_simple_reply(
            message,
            system_prompt="You are Elias, a helpful assistant for VYBR!S. Answer concisely and clearly in the same language as the user.",
        )
        if direct_reply and direct_reply.strip():
            return AskResponse(reply=direct_reply.strip())
    if not success:
        return AskResponse(
            reply=None,
            error="Elias is temporarily unavailable. Try again later.",
        )
    return AskResponse(reply=None, error="No reply from assistant.")


# ---------------------------------------------------------------------------
# Dashboard payload (for Elias tab panel - one call to load state)
# ---------------------------------------------------------------------------

@router.get("/dashboard")
async def get_dashboard(
    current_user: dict = Depends(require_admin),
):
    """
    Get summary + to-dos for the Elias tab panel (Today, To-dos, Last summary).
    Admin only.
    """
    latest_summary = EliasSummariesDB.get_latest(current_user["id"])
    todos = EliasTodosDB.get_by_user(current_user["id"], status=None, limit=50)
    pending = [t for t in todos if t.get("status") == "pending"]
    return {
        "summary": latest_summary,
        "todos": todos,
        "pending_count": len(pending),
    }


# ---------------------------------------------------------------------------
# TTS (ElevenLabs) for Elias voice – greeting and spoken replies
# ---------------------------------------------------------------------------

@router.get("/tts")
async def elias_tts(
    text: str = Query(..., min_length=1, max_length=TTS_TEXT_MAX_LEN),
    current_user: dict = Depends(require_admin),
):
    """
    Convert text to speech using ElevenLabs (Elias voice). Returns MP3 audio.
    Admin only. Requires ELEVENLABS_API_KEY and optional ELEVENLABS_ELIAS_VOICE_ID.
    """
    if not ELEVENLABS_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="Elias TTS is not configured. Set ELEVENLABS_API_KEY.",
        )
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{ELEVENLABS_ELIAS_VOICE_ID}"
    headers = {
        "xi-api-key": ELEVENLABS_API_KEY,
        "Content-Type": "application/json",
        "Accept": "audio/mpeg",
    }
    payload = {"text": text, "model_id": "eleven_multilingual_v2"}
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(url, json=payload, headers=headers)
    except Exception as e:
        logger.warning("Elias TTS request failed: %s", e)
        raise HTTPException(status_code=502, detail="TTS service unavailable.")
    if resp.status_code != 200:
        logger.warning("Elias TTS non-200: status=%s body=%s", resp.status_code, resp.text[:200])
        raise HTTPException(status_code=502, detail="TTS request failed.")
    return Response(content=resp.content, media_type="audio/mpeg")

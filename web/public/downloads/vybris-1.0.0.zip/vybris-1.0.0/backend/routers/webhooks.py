from fastapi import APIRouter, HTTPException, Request, Depends
from typing import Dict, Any
import logging
from routers.auth import get_current_user
from services.database import ChatbotDB

router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])
logger = logging.getLogger(__name__)

@router.post("/{chatbot_id}/{secret}")
async def receive_webhook(
    chatbot_id: str,
    secret: str,
    request: Request
):
    """
    Receive webhook events from external systems (e.g. Booking System updates).
    
    The 'secret' is a simple security measure to prevent unauthorized calls.
    Ideally this should match a configured secret on the chatbot.
    """
    # 1. Verify existence
    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot:
        raise HTTPException(status_code=404, detail="Chatbot not found")
        
    # 2. Verify secret
    # For now we check if it matches a stored webhook secret in config
    # If not configured, we might deny or checking if it matches the chatbot ID as a fallback (weak security)
    # Ideally: config['webhookSecret']
    
    config = chatbot.get('config', {})
    stored_secret = config.get('webhookSecret')
    
    # SECURITY: Require explicit secret configuration - no weak fallbacks
    if not stored_secret:
        raise HTTPException(
            status_code=400, 
            detail="Webhook secret not configured. Please configure webhookSecret in chatbot config."
        )
    
    if secret != stored_secret:
        raise HTTPException(status_code=401, detail="Invalid webhook secret")
        
    # 3. Parse Payload
    try:
        payload = await request.json()
    except Exception:
        payload = await request.body()
        
    logger.info(f"Received webhook for chatbot {chatbot_id}: {payload}")
    
    # 4. Process Event
    # This is highly dependent on the external system.
    # Implementation options:
    # A) Log it to an events table for analysis
    # B) Trigger a notification to active users (WebSocket)
    # C) Update internal state/database
    
    # For MVP: We just log it. Real-time updates would require WebSocket infrastructure linked to session.
    
    return {"status": "received", "timestamp": str(logging.Formatter.converter)}

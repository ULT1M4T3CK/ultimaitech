"""
Live Chat: human handoff and moderator queue.
- Widget users request a human via POST /request (no auth).
- Moderators poll GET /queue and accept chats (auth required); full UI at /vybris/chat.
- All requests are securely stored in database for persistence and audit.
"""
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone
import uuid
import logging
import time
from urllib.parse import urlparse

from routers.auth import get_current_user
from services.database import ChatbotDB, MessageDB, SessionDB, get_db_connection, UserDB
from services.database.live_chat import LiveChatDB
from shared.permissions import can_access_live_chat, get_moderator_allowed_chatbot_ids
import os

logger = logging.getLogger(__name__)

def _safe_debug_log(data):
    """Write debug log only when VYBRIS_DEBUG_LOG=1 or DEBUG_LOG_PATH is set (avoid file I/O in production)."""
    if not os.getenv('VYBRIS_DEBUG_LOG') and not os.getenv('DEBUG_LOG_PATH'):
        return
    try:
        import json
        log_path = os.getenv('DEBUG_LOG_PATH', '/tmp/vybris_debug.log')
        with open(log_path, 'a') as f:
            f.write(json.dumps(data) + '\n')
    except Exception:
        pass  # Silently fail - don't crash the app

router = APIRouter(prefix="/api/v1/live-chat", tags=["live-chat"])


class LiveChatRequestIn(BaseModel):
    chatbot_id: str
    session_id: str
    message: Optional[str] = None
    page_url: Optional[str] = None  # URL of the page where the user requested (connected website)


class LiveChatRequestOut(BaseModel):
    request_id: str
    status: str = "queued"


class AcceptRequestIn(BaseModel):
    request_id: str


class LiveChatHistoryItem(BaseModel):
    role: str
    content: str
    timestamp: Optional[int] = None


class LiveChatHistoryIn(BaseModel):
    chatbot_id: str
    session_id: str
    messages: List[LiveChatHistoryItem]


class LiveChatMessageIn(BaseModel):
    chatbot_id: str
    session_id: str
    content: str
    request_id: Optional[str] = None
    client_timestamp: Optional[int] = None


class LiveChatCloseIn(BaseModel):
    chatbot_id: str
    session_id: str
    request_id: str


@router.post("/request", response_model=LiveChatRequestOut)
async def request_human(data: LiveChatRequestIn, request: Request) -> LiveChatRequestOut:
    """
    Widget calls this when the user clicks "Talk to a human?".
    No auth. Adds to queue for moderators at /vybris/chat.
    """
    # #region agent log
    _safe_debug_log({
        'sessionId': 'debug-session',
        'runId': 'run1',
        'hypothesisId': 'B',
        'location': 'live_chat.py:40',
        'message': 'Live chat request endpoint called',
        'data': {
            'chatbot_id': data.chatbot_id,
            'session_id': data.session_id,
            'has_message': bool(data.message),
            'message_preview': data.message[:50] if data.message else None
        },
        'timestamp': int(time.time() * 1000)
    })
    # #endregion
    
    # Validate that live chat is enabled for this chatbot
    bot = ChatbotDB.get_by_id(data.chatbot_id)
    if not bot:
        # #region agent log
        _safe_debug_log({
            'sessionId': 'debug-session',
            'runId': 'run1',
            'hypothesisId': 'B',
            'location': 'live_chat.py:48',
            'message': 'Live chat: Bot not found',
            'data': {'chatbot_id': data.chatbot_id},
            'timestamp': int(time.time() * 1000)
        })
        # #endregion
        raise HTTPException(status_code=404, detail="Chatbot not found")
    
    config = bot.get('config') or {}
    enable_live_chat = config.get('enableLiveChat', config.get('enable_live_chat', False))
    
    # #region agent log
    _safe_debug_log({
        'sessionId': 'debug-session',
        'runId': 'run1',
        'hypothesisId': 'B',
        'location': 'live_chat.py:52',
        'message': 'Live chat: Config check',
        'data': {
            'enable_live_chat': enable_live_chat,
            'config_keys': list(config.keys()) if config else []
        },
        'timestamp': int(time.time() * 1000)
    })
    # #endregion
    
    if not enable_live_chat:
        # #region agent log
        _safe_debug_log({
            'sessionId': 'debug-session',
            'runId': 'run1',
            'hypothesisId': 'B',
            'location': 'live_chat.py:53',
            'message': 'Live chat: Not enabled - rejecting',
            'data': {},
            'timestamp': int(time.time() * 1000)
        })
        # #endregion
        raise HTTPException(
            status_code=400, 
            detail="Live chat is not enabled for this chatbot"
        )
    
    request_id = f"lc_{uuid.uuid4().hex[:12]}"

    # Resolve page URL from request headers if missing or mismatched
    origin = request.headers.get("Origin")
    referer = request.headers.get("Referer")
    resolved_page_url = (data.page_url or "").strip() or None

    def _norm_host(url: Optional[str]) -> str:
        if not url:
            return ""
        try:
            host = urlparse(url).hostname or ""
        except Exception:
            return ""
        host = host.lower()
        return host[4:] if host.startswith("www.") else host

    api_host = _norm_host(request.url.hostname or request.headers.get("host", "").split(":")[0])
    origin_host = _norm_host(origin)
    referer_host = _norm_host(referer)
    page_host = _norm_host(resolved_page_url)

    if not resolved_page_url:
        resolved_page_url = referer or origin
    elif page_host and api_host and page_host == api_host and referer_host and referer_host != api_host:
        # If the page URL points to this API host but a different referrer exists,
        # prefer the referrer (common when embedded in an iframe).
        resolved_page_url = referer
    elif origin_host and page_host and page_host != origin_host:
        # If provided page URL doesn't match the request origin, prefer referrer/origin
        resolved_page_url = referer if referer_host == origin_host else origin
    
    # #region agent log
    _safe_debug_log({
        'sessionId': 'debug-session',
        'runId': 'run1',
        'hypothesisId': 'C',
        'location': 'live_chat.py:61',
        'message': 'Live chat: Before database insert',
        'data': {'request_id': request_id},
        'timestamp': int(time.time() * 1000)
    })
    # #endregion
    
    # Store securely in database
    entry = LiveChatDB.create_request(
        request_id=request_id,
        chatbot_id=data.chatbot_id,
        session_id=data.session_id,
        message=data.message,
        page_url=resolved_page_url
    )
    
    # #region agent log
    _safe_debug_log({
        'sessionId': 'debug-session',
        'runId': 'run1',
        'hypothesisId': 'C',
        'location': 'live_chat.py:70',
        'message': 'Live chat: After database insert',
        'data': {
            'request_id': request_id,
            'entry_created': entry is not None,
            'entry_status': entry.get('status') if entry else None
        },
        'timestamp': int(time.time() * 1000)
    })
    # #endregion
    
    if not entry:
        # #region agent log
        _safe_debug_log({
            'sessionId': 'debug-session',
            'runId': 'run1',
            'hypothesisId': 'C',
            'location': 'live_chat.py:71',
            'message': 'Live chat: Database insert failed',
            'data': {},
            'timestamp': int(time.time() * 1000)
        })
        # #endregion
        raise HTTPException(status_code=500, detail="Failed to create live chat request")
    
    logger.info("Live chat request queued: %s (chatbot_id=%s, session_id=%s, message=%s)", 
                request_id, data.chatbot_id, data.session_id, 
                data.message[:50] if data.message else "None")

    # Emit event for analytics/audit
    from services.conversation_events import emit_live_chat_requested
    emit_live_chat_requested(
        chatbot_id=data.chatbot_id,
        session_id=data.session_id,
        user_message=data.message or "",
        page_url=resolved_page_url,
    )
    
    # #region agent log
    _safe_debug_log({
        'sessionId': 'debug-session',
        'runId': 'run1',
        'hypothesisId': 'B',
        'location': 'live_chat.py:75',
        'message': 'Live chat: Request queued successfully',
        'data': {'request_id': request_id, 'status': 'queued'},
        'timestamp': int(time.time() * 1000)
    })
    # #endregion
    
    entry_request_id = entry.get("request_id") if isinstance(entry, dict) else request_id
    entry_status = entry.get("status") if isinstance(entry, dict) else "queued"
    return LiveChatRequestOut(request_id=entry_request_id, status=entry_status or "queued")


@router.get("/status")
async def get_live_chat_status(
    chatbot_id: str,
    session_id: str,
    request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Public status check for a live chat request.
    Used by the widget to show "waiting for agent" across reloads.
    """
    entry = None
    if request_id:
        entry = LiveChatDB.get_by_id(request_id)
        if entry and (entry.get("chatbot_id") != chatbot_id or entry.get("session_id") != session_id):
            entry = None

    if not entry:
        entry = LiveChatDB.get_open_request(chatbot_id, session_id)

    if not entry:
        return {"found": False}

    # Convert datetime objects to ISO strings
    for key in ["created_at", "accepted_at", "closed_at"]:
        if entry.get(key) and isinstance(entry[key], datetime):
            entry[key] = entry[key].isoformat() + "Z"

    status = entry.get("status") or "queued"
    result = {
        "found": True,
        "request_id": entry.get("request_id"),
        "status": status,
        "created_at": entry.get("created_at"),
        "accepted_at": entry.get("accepted_at"),
        "closed_at": entry.get("closed_at"),
    }
    if status == "active":
        moderator_id = entry.get("moderator_id")
        if moderator_id:
            user = UserDB.get_by_id(moderator_id)
            full = (user.get("full_name") or user.get("username") or "Agent") if user else "Agent"
            result["moderator_name"] = full.split()[0] if full else "Agent"
        else:
            result["moderator_name"] = "Agent"
    return result


def _require_live_chat_access(current_user: dict) -> None:
    """Raise 403 if user cannot access live chat at all."""
    if not can_access_live_chat(current_user):
        raise HTTPException(status_code=403, detail="You do not have access to Live Chat")


def _moderator_can_access_chatbot(current_user: dict, chatbot_id: str) -> bool:
    """True if user can access this chatbot (admin/partner: always; moderator: if in allowed list)."""
    allowed = get_moderator_allowed_chatbot_ids(current_user)
    if allowed is None:
        return True  # admin/partner
    return chatbot_id in allowed


@router.post("/end")
async def end_chat_by_agent(
    body: AcceptRequestIn,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Agent ends the chat. Auth required. Moderators can only end chats for their allowed chatbots.
    """
    _require_live_chat_access(current_user)
    entry = LiveChatDB.get_by_id(body.request_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Chat not found or already closed")
    if not _moderator_can_access_chatbot(current_user, entry.get("chatbot_id") or ""):
        raise HTTPException(status_code=403, detail="You do not have access to this chatbot")
    success = LiveChatDB.close_request(body.request_id, moderator_id=current_user["id"])
    if not success:
        raise HTTPException(status_code=404, detail="Chat not found or already closed")
    return {"closed": True}


@router.post("/close")
async def close_live_chat_by_user(body: LiveChatCloseIn) -> Dict[str, Any]:
    """
    Widget calls this when the user closes the chat.
    - If agent has the chat (active): mark user_closed_at so agent gets notified; chat stays open for agent.
    - If queued (no agent): close the request.
    """
    entry = LiveChatDB.get_by_id(body.request_id)
    if not entry:
        return {"closed": False, "error": "Request not found"}
    if entry.get("chatbot_id") != body.chatbot_id or entry.get("session_id") != body.session_id:
        return {"closed": False, "error": "Mismatch"}
    status = entry.get("status") or "queued"
    if status not in ("queued", "active"):
        return {"closed": True}
    if status == "active":
        # Agent has it: notify agent, keep chat open until agent ends
        success = LiveChatDB.mark_user_closed(body.request_id)
        return {"closed": True, "user_left": True}
    # Queued: user left before anyone accepted, close it
    success = LiveChatDB.close_request(body.request_id, moderator_id=None)
    return {"closed": success}


@router.post("/messages/ingest")
async def ingest_live_chat_history(body: LiveChatHistoryIn) -> Dict[str, Any]:
    """
    Public endpoint used by the widget to upload client-side history
    when a human handoff is requested.
    """
    if not body.messages:
        return {"ingested": 0, "skipped": True}

    SessionDB.get_or_create(body.session_id, body.chatbot_id)

    existing = MessageDB.get_by_session(body.session_id, limit=1)
    if existing:
        return {"ingested": 0, "skipped": True}

    ingested = 0
    for idx, msg in enumerate(body.messages):
        role = "assistant" if msg.role in ("assistant", "bot", "agent") else "user"
        metadata = {
            "source": "widget_history",
            "client_index": idx,
        }
        if msg.timestamp:
            metadata["client_timestamp"] = msg.timestamp
        created = MessageDB.create({
            "session_id": body.session_id,
            "chatbot_id": body.chatbot_id,
            "role": role,
            "content": msg.content,
            "metadata": metadata,
        })
        if created:
            ingested += 1
    if ingested:
        SessionDB.update_activity(body.session_id, increment_messages=False)
    return {"ingested": ingested, "skipped": False}


@router.post("/messages/user")
async def post_live_chat_user_message(body: LiveChatMessageIn) -> Dict[str, Any]:
    """Public endpoint for widget user messages during live chat."""
    SessionDB.get_or_create(body.session_id, body.chatbot_id)
    metadata = {"source": "widget"}
    if body.request_id:
        metadata["request_id"] = body.request_id
    if body.client_timestamp:
        metadata["client_timestamp"] = body.client_timestamp
    message = MessageDB.create({
        "session_id": body.session_id,
        "chatbot_id": body.chatbot_id,
        "role": "user",
        "content": body.content,
        "metadata": metadata,
    })
    if message:
        SessionDB.update_activity(body.session_id, increment_messages=True)
    return {"message": message}


@router.post("/messages/agent")
async def post_live_chat_agent_message(
    body: LiveChatMessageIn,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """Agent sends a message to the live chat session. Moderators only for allowed chatbots."""
    _require_live_chat_access(current_user)
    if not _moderator_can_access_chatbot(current_user, body.chatbot_id):
        raise HTTPException(status_code=403, detail="You do not have access to this chatbot")
    SessionDB.get_or_create(body.session_id, body.chatbot_id)
    metadata = {"source": "agent", "moderator_id": current_user.get("id")}
    if body.request_id:
        metadata["request_id"] = body.request_id
    message = MessageDB.create({
        "session_id": body.session_id,
        "chatbot_id": body.chatbot_id,
        "role": "assistant",
        "content": body.content,
        "metadata": metadata,
    })
    if message:
        SessionDB.update_activity(body.session_id, increment_messages=True)
    return {"message": message}


@router.get("/messages")
async def get_live_chat_messages(
    chatbot_id: str,
    session_id: str,
    since: Optional[int] = None,
    limit: int = 200,
) -> Dict[str, Any]:
    """
    Public endpoint for widget polling and agent UI.
    Returns messages for a session, optionally filtered by timestamp (ms).
    """
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            SELECT session_id, chatbot_id FROM chat_sessions
            WHERE session_id = %s
        ''', (session_id,))
        row = cursor.fetchone()
        if not row or row.get("chatbot_id") != chatbot_id:
            return {"messages": []}

    since_dt = None
    if since:
        try:
            since_dt = datetime.fromtimestamp(int(since) / 1000, tz=timezone.utc)
        except Exception:
            since_dt = None

    messages = MessageDB.get_by_session_since(session_id, since=since_dt, limit=limit)
    return {"messages": messages}


@router.get("/queue")
async def get_queue(
    current_user: dict = Depends(get_current_user),
    chatbot_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    List queued live-chat requests. Auth required. Admin/Partner: all; Moderator: only allowed chatbots.
    Optionally filter by chatbot_id.
    """
    _require_live_chat_access(current_user)
    # #region agent log
    _safe_debug_log({
        'sessionId': 'debug-session',
        'runId': 'run1',
        'hypothesisId': 'D',
        'location': 'live_chat.py:78',
        'message': 'Queue endpoint called',
        'data': {
            'user_id': current_user.get('id'),
            'chatbot_id_filter': chatbot_id
        },
        'timestamp': int(time.time() * 1000)
    })
    # #endregion
    
    items = LiveChatDB.get_queue_items(moderator_id=current_user.get("id"))
    allowed_ids = get_moderator_allowed_chatbot_ids(current_user)
    if allowed_ids is not None:
        items = [item for item in items if item.get("chatbot_id") in allowed_ids]
    
    # #region agent log
    _safe_debug_log({
        'sessionId': 'debug-session',
        'runId': 'run1',
        'hypothesisId': 'D',
        'location': 'live_chat.py:87',
        'message': 'Queue: Retrieved from database',
        'data': {
            'items_count': len(items),
            'item_ids': [item.get('request_id') for item in items[:5]]
        },
        'timestamp': int(time.time() * 1000)
    })
    # #endregion
    
    # Filter by chatbot_id if provided
    if chatbot_id:
        items = [item for item in items if item.get('chatbot_id') == chatbot_id]
    
    # #region agent log
    _safe_debug_log({
        'sessionId': 'debug-session',
        'runId': 'run1',
        'hypothesisId': 'D',
        'location': 'live_chat.py:92',
        'message': 'Queue: After filtering',
        'data': {'items_count': len(items)},
        'timestamp': int(time.time() * 1000)
    })
    # #endregion
    
    # Enrich with chatbot names
    chatbot_cache = {}
    for item in items:
        chatbot_id_val = item.get('chatbot_id')
        if chatbot_id_val and chatbot_id_val not in chatbot_cache:
            bot = ChatbotDB.get_by_id(chatbot_id_val)
            chatbot_cache[chatbot_id_val] = bot.get("name", "Unknown") if bot else "Unknown"
        item["chatbot_name"] = chatbot_cache.get(chatbot_id_val, "Unknown")
        
        # Convert datetime objects to ISO strings for JSON serialization
        if item.get('created_at'):
            if isinstance(item['created_at'], datetime):
                item['created_at'] = item['created_at'].isoformat() + "Z"
    
    # #region agent log
    _safe_debug_log({
        'sessionId': 'debug-session',
        'runId': 'run1',
        'hypothesisId': 'D',
        'location': 'live_chat.py:107',
        'message': 'Queue: Returning response',
        'data': {'items_count': len(items), 'count': len(items)},
        'timestamp': int(time.time() * 1000)
    })
    # #endregion
    
    return {"items": items, "count": len(items)}


@router.post("/accept")
async def accept_chat(
    body: AcceptRequestIn,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Accept a queued chat. Moderators can only accept chats for their allowed chatbots.
    """
    _require_live_chat_access(current_user)
    request_id = body.request_id
    entry = LiveChatDB.get_by_id(request_id)
    if entry and not _moderator_can_access_chatbot(current_user, entry.get("chatbot_id") or ""):
        raise HTTPException(status_code=403, detail="You do not have access to this chatbot")
    
    # Accept the request in database
    entry = LiveChatDB.accept_request(request_id, current_user["id"])
    if not entry:
        raise HTTPException(status_code=404, detail="Request not found or already accepted")
    
    # Convert datetime objects to ISO strings
    if entry.get("accepted_at") and isinstance(entry["accepted_at"], datetime):
        entry["accepted_at"] = entry["accepted_at"].isoformat() + "Z"
    if entry.get("created_at") and isinstance(entry["created_at"], datetime):
        entry["created_at"] = entry["created_at"].isoformat() + "Z"

    chatbot = ChatbotDB.get_by_id(entry["chatbot_id"]) if entry.get("chatbot_id") else None
    chatbot_name = chatbot.get("name", "Chatbot") if chatbot else "Chatbot"
    return {
        "request_id": request_id,
        "entry": entry,
        "chatbot_name": chatbot_name,
        "website_url": entry.get("page_url") or (chatbot.get("config") or {}).get("companyWebsite") or None,
    }


@router.get("/request/{request_id}")
async def get_request_status(
    request_id: str,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Get request status for moderator's active chat (to detect user_closed_at).
    Auth required. Returns only if current user is the moderator and has access to the chatbot.
    """
    _require_live_chat_access(current_user)
    entry = LiveChatDB.get_by_id(request_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Request not found")
    if entry.get("moderator_id") != current_user["id"]:
        raise HTTPException(status_code=403, detail="Not your chat")
    if not _moderator_can_access_chatbot(current_user, entry.get("chatbot_id") or ""):
        raise HTTPException(status_code=403, detail="You do not have access to this chatbot")
    if entry.get("status") != "active":
        return {"request_id": request_id, "status": entry.get("status")}
    result = {
        "request_id": request_id,
        "status": "active",
        "user_closed_at": None,
    }
    if entry.get("user_closed_at"):
        uc = entry["user_closed_at"]
        result["user_closed_at"] = uc.isoformat() + "Z" if isinstance(uc, datetime) else uc
    return result


@router.get("/active")
async def get_my_active_chat(
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Get the current moderator's active chat (for restoring after page refresh).
    Moderators only see active chats for their allowed chatbots.
    """
    _require_live_chat_access(current_user)
    chats, _ = LiveChatDB.get_all_agent_chats(
        limit=1,
        offset=0,
        moderator_id=current_user["id"],
        status="active",
    )
    if not chats:
        return {"active": False}
    entry = chats[0]
    allowed_ids = get_moderator_allowed_chatbot_ids(current_user)
    if allowed_ids is not None and entry.get("chatbot_id") not in allowed_ids:
        return {"active": False}
    for key in ["created_at", "accepted_at", "closed_at", "user_closed_at"]:
        if entry.get(key) and isinstance(entry[key], datetime):
            entry[key] = entry[key].isoformat() + "Z"
    chatbot = ChatbotDB.get_by_id(entry.get("chatbot_id"))
    chatbot_name = (chatbot.get("name", "Chatbot") if chatbot else "Chatbot")
    return {
        "active": True,
        "request_id": entry.get("request_id"),
        "entry": entry,
        "chatbot_name": chatbot_name,
        "website_url": entry.get("page_url") or ((chatbot or {}).get("config") or {}).get("companyWebsite") or None,
    }


@router.get("/agent-chats")
async def get_agent_chats(
    current_user: dict = Depends(get_current_user),
    limit: int = 50,
    offset: int = 0,
    chatbot_id: Optional[str] = None,
    status: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Get all agent chats (accepted/closed) with pagination and filters.
    Auth required. Admin/Partner: all or filter; Moderator: only their chats for allowed chatbots.
    """
    _require_live_chat_access(current_user)
    moderator_id = None if current_user.get("role") in ("admin", "super_admin") else current_user["id"]
    
    chats, total = LiveChatDB.get_all_agent_chats(
        limit=limit,
        offset=offset,
        chatbot_id=chatbot_id,
        moderator_id=moderator_id,
        status=status
    )
    allowed_ids = get_moderator_allowed_chatbot_ids(current_user)
    if allowed_ids is not None:
        chats = [c for c in chats if c.get("chatbot_id") in allowed_ids]
        total = len(chats)
    
    # Convert datetime objects to ISO strings
    for chat in chats:
        for key in ["created_at", "accepted_at", "closed_at", "user_closed_at"]:
            if chat.get(key) and isinstance(chat[key], datetime):
                chat[key] = chat[key].isoformat() + "Z"
    
    # Enrich with chatbot names
    chatbot_cache = {}
    for chat in chats:
        chatbot_id = chat.get("chatbot_id")
        if chatbot_id and chatbot_id not in chatbot_cache:
            bot = ChatbotDB.get_by_id(chatbot_id)
            chatbot_cache[chatbot_id] = bot.get("name", "Unknown") if bot else "Unknown"
        chat["chatbot_name"] = chatbot_cache.get(chatbot_id, "Unknown")
    
    return {
        "chats": chats,
        "total": total,
        "limit": limit,
        "offset": offset
    }


@router.get("/debug/status")
async def debug_status(current_user: dict = Depends(get_current_user)) -> Dict[str, Any]:
    """
    Diagnostic endpoint to check live chat system status.
    Admin only. Returns queue count, recent requests, and system health.
    """
    from routers.auth import require_admin
    require_admin(current_user)
    
    try:
        # Get all requests (not just queued) for diagnostics
        from services.database.base import get_db_connection
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            # Count by status
            cursor.execute('''
                SELECT status, COUNT(*) as count 
                FROM live_chat_requests 
                GROUP BY status
            ''')
            status_counts = {row['status']: row['count'] for row in cursor.fetchall()}
            
            # Get recent requests (last 10)
            cursor.execute('''
                SELECT request_id, chatbot_id, session_id, status, created_at, message
                FROM live_chat_requests 
                ORDER BY created_at DESC 
                LIMIT 10
            ''')
            recent = [dict(row) for row in cursor.fetchall()]
            
            # Convert datetime objects
            for req in recent:
                if req.get('created_at') and isinstance(req['created_at'], datetime):
                    req['created_at'] = req['created_at'].isoformat() + "Z"
            
            return {
                "status": "ok",
                "status_counts": status_counts,
                "recent_requests": recent,
                "queued_count": status_counts.get('queued', 0),
                "total_count": sum(status_counts.values())
            }
    except Exception as e:
        logger.error(f"Debug status error: {e}")
        return {
            "status": "error",
            "error": str(e)
        }

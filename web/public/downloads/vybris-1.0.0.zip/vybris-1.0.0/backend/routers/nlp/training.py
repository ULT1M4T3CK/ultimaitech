"""
NLP Training Router
Handles chatbot training endpoints
"""

from fastapi import APIRouter, HTTPException, Depends, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any, AsyncGenerator
import json
import asyncio
import logging
import os
from services.nlp_service import nlp_service
from routers.auth import get_current_user
from shared.errors import NotFoundError, ValidationError
from datetime import datetime

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/nlp", tags=["nlp"])

# Import semantic chunking for training
from nlp.chunking import SemanticChunker, semantic_chunk_text

USE_SEMANTIC_CHUNKING = os.getenv("USE_SEMANTIC_CHUNKING", "true").lower() == "true"
semantic_chunker = SemanticChunker(max_chunk_size=500, overlap=50, min_chunk_size=100)


class TrainRequest(BaseModel):
    chatbot_id: str
    documents: List[str]


def chunk_text_for_training(text: str, metadata: Dict[str, Any] = None) -> List[Dict[str, Any]]:
    """Chunk text for training using semantic or simple chunking."""
    if USE_SEMANTIC_CHUNKING:
        results = semantic_chunker.chunk_text(text, metadata)
        return [{'text': r.text, 'metadata': r.metadata, 'type': r.chunk_type} for r in results]
    else:
        chunks = simple_chunk_text(text)
        return [{'text': chunk, 'metadata': metadata or {}} for chunk in chunks]


def simple_chunk_text(text: str, chunk_size: int = 250, overlap: int = 50) -> List[str]:
    """Legacy simple chunking function for backward compatibility."""
    if not text:
        return []
    
    text = " ".join(text.split())
    
    chunks = []
    stride = chunk_size - overlap
    for i in range(0, len(text), stride):
        chunk = text[i:i + chunk_size]
        if len(chunk) > 50:
            chunks.append(chunk)
    
    return chunks


@router.post("/train")
async def train_chatbot(
    request: TrainRequest,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """Train a chatbot with direct documents"""
    count = 0
    for doc in request.documents:
        chunks = simple_chunk_text(doc)
        for chunk in chunks:
            nlp_service.train_text(request.chatbot_id, chunk)
            count += 1
    
    return {"message": f"Successfully processed documents into {count} chunks", "chatbot_id": request.chatbot_id}


USE_BACKGROUND_JOBS = os.getenv("USE_BACKGROUND_JOBS", "false").lower() == "true"


@router.get("/jobs/{job_id}")
async def get_training_job_status(
    job_id: str,
    current_user: dict = Depends(get_current_user),
):
    """Get training job status (for background job polling)."""
    from services.database import TrainingJobDB

    job = TrainingJobDB.get_by_id(job_id)
    if not job:
        raise NotFoundError(resource="TrainingJob", resource_id=job_id)

    # Ensure user can access this chatbot
    from shared.permissions import can_access_chatbot
    if not can_access_chatbot(current_user, job["chatbot_id"]):
        raise NotFoundError(resource="TrainingJob", resource_id=job_id)

    return {
        "job_id": job["id"],
        "chatbot_id": job["chatbot_id"],
        "status": job["status"],
        "metadata": job.get("metadata", {}),
        "pages_processed": job.get("pages_processed"),
        "error": job.get("error"),
        "completed_at": job.get("completed_at"),
    }


@router.post("/train/{chatbot_id}")
async def train_chatbot_by_id(chatbot_id: str, current_user: dict = Depends(get_current_user)):
    """Train a chatbot using its stored scraped content.
    When USE_BACKGROUND_JOBS=true, enqueues to RQ and returns immediately with job_id."""
    from services.database import ChatbotDB, ScrapedContentDB, TrainingJobDB, KnowledgeDB
    from services.cache_service import response_cache

    response_cache.invalidate(chatbot_id)

    bot = ChatbotDB.get_by_id(chatbot_id)
    if not bot:
        raise NotFoundError(resource="Chatbot", resource_id=chatbot_id)

    content = ScrapedContentDB.get(chatbot_id)
    if not content or not content.get("pages"):
        raise ValidationError(message="No training data found. Please scrape a website first.")

    job = TrainingJobDB.create({
        "chatbot_id": chatbot_id,
        "status": "in_progress",
        "metadata": {
            "total_pages": len(content["pages"]),
            "source_url": content.get("source_url", ""),
        },
    })
    job_id = job["id"] if job else None

    # Phase 3: Enqueue to RQ when background jobs enabled
    if USE_BACKGROUND_JOBS and job_id:
        from jobs.queue import enqueue_training
        rq_id = enqueue_training(chatbot_id, job_id)
        if rq_id:
            return {
                "message": "Training job queued. Poll GET /api/v1/nlp/jobs/{job_id} for status.",
                "chatbot_id": chatbot_id,
                "job_id": job_id,
                "status": "queued",
            }

    # Inline execution (default)
    try:
        count = 0
        knowledge_items_created = 0
        seen_urls = set()
        
        try:
            existing_items = KnowledgeDB.get_by_chatbot(chatbot_id)
            for item in existing_items:
                if item.get('source_type') == 'scraped':
                    KnowledgeDB.delete(item['id'])
        except Exception as clear_err:
            logger.warning(f"Failed to clear existing scraped items: {clear_err}")
        
        # Use content enhancer for better understanding
        from services.content_enhancer import content_enhancer
        USE_CONTENT_ENHANCEMENT = os.getenv("USE_CONTENT_ENHANCEMENT", "true").lower() == "true"
        USE_SEMANTIC_CHUNKING = os.getenv("USE_SEMANTIC_CHUNKING", "true").lower() == "true"
        
        for page in content['pages']:
            url = page.get('url', '')
            title = page.get('title', 'Untitled')
            
            if url and url in seen_urls:
                continue
            seen_urls.add(url)
            
            # Enhance content for better understanding
            chunks_count = 0
            if USE_CONTENT_ENHANCEMENT:
                try:
                    # Get original HTML if available (for better enhancement)
                    # For now, use the scraped content structure
                    enhanced = content_enhancer.enhance_page_content(
                        html='',  # HTML not stored, but enhancement can work with structured data
                        url=url,
                        title=title,
                        description=page.get('description', ''),
                        headings=page.get('headings', []),
                        raw_content=page.get('content', '')
                    )
                    
                    # Prepare training chunks with enhancement
                    training_chunks = content_enhancer.prepare_for_training(
                        enhanced,
                        use_semantic_chunking=USE_SEMANTIC_CHUNKING
                    )
                    
                    # Train each enhanced chunk
                    for chunk_data in training_chunks:
                        nlp_service.train_text(
                            chatbot_id,
                            chunk_data['text'],
                            chunk_data.get('metadata', {})
                        )
                        count += 1
                    chunks_count = len(training_chunks)
                    
                except Exception as enhance_err:
                    logger.warning(f"Content enhancement failed for {url}, using fallback: {enhance_err}")
                    # Fallback to simple training
                    raw_text = f"{title}. {page.get('content', '')}"
                    chunks = simple_chunk_text(raw_text)
                    for i, chunk in enumerate(chunks):
                        meta = {"url": url, "title": title, "chunk_index": i}
                        nlp_service.train_text(chatbot_id, chunk, meta)
                        count += 1
                    chunks_count = len(chunks)
            else:
                # Original simple training (fallback)
                raw_text = f"{title}. {page.get('content', '')}"
                chunks = simple_chunk_text(raw_text)
                for i, chunk in enumerate(chunks):
                    meta = {"url": url, "title": title, "chunk_index": i}
                    nlp_service.train_text(chatbot_id, chunk, meta)
                    count += 1
                chunks_count = len(chunks)
            
            try:
                KnowledgeDB.create({
                    "chatbot_id": chatbot_id,
                    "source_type": "scraped",
                    "title": title,
                    "content": page['content'][:5000] if page['content'] else '',
                    "url": url,
                    "word_count": len(page['content'].split()) if page['content'] else 0,
                    "metadata": {"source_url": content.get('source_url', ''), "chunk_count": chunks_count}
                })
                knowledge_items_created += 1
            except Exception as kb_err:
                logger.warning(f"Failed to save to knowledge_items: {kb_err}")
        
        if bot['status'] == 'Draft':
            updates = {"status": "Active"}
            updates["updatedAt"] = datetime.utcnow().isoformat() + "Z"
            ChatbotDB.update(chatbot_id, updates)
        
        if job_id:
            TrainingJobDB.update(job_id, {
                "status": "completed",
                "completed_at": datetime.utcnow().isoformat() + "Z",
                "pages_processed": len(content['pages'])
            })
        
        return {
            "message": f"Successfully trained on {len(content['pages'])} pages ({count} chunks)",
            "chatbot_id": chatbot_id,
            "pages_processed": len(content['pages']),
            "chunks_created": count,
            "knowledge_items_created": knowledge_items_created
        }
    except Exception as e:
        if job_id:
            TrainingJobDB.update(job_id, {
                "status": "failed",
                "completed_at": datetime.utcnow().isoformat() + "Z",
                "error": str(e)
            })
        raise


@router.get("/train/{chatbot_id}/stream")
async def train_chatbot_stream(
    chatbot_id: str,
    request: Request,
    current_user: dict = Depends(get_current_user)
):
    """SSE endpoint for real-time training status updates."""
    from services.database import ChatbotDB, ScrapedContentDB
    
    async def generate_training_events():
        try:
            yield f"data: {json.dumps({'status': 'starting', 'message': 'Initializing training...', 'progress': 0})}\n\n"
            await asyncio.sleep(0.1)
            
            from shared.router_utils import get_resource_or_404
            try:
                bot = get_resource_or_404(ChatbotDB.get_by_id, chatbot_id, "Chatbot")
            except NotFoundError:
                yield f"data: {json.dumps({'status': 'error', 'message': 'Chatbot not found', 'progress': 0})}\n\n"
                return
            
            yield f"data: {json.dumps({'status': 'loading', 'message': 'Loading training data...', 'progress': 5})}\n\n"
            await asyncio.sleep(0.1)
            
            content = ScrapedContentDB.get(chatbot_id)
            if not content or not content.get('pages'):
                yield f"data: {json.dumps({'status': 'error', 'message': 'No training data found. Please scrape a website first.', 'progress': 0})}\n\n"
                return
            
            pages = content['pages']
            total_pages = len(pages)
            
            yield f"data: {json.dumps({'status': 'clearing', 'message': 'Clearing old training data (preserving Q&A corrections)...', 'progress': 8})}\n\n"
            await asyncio.sleep(0.1)
            
            cleared_count = nlp_service.clear_scraped_data(chatbot_id)
            if cleared_count > 0:
                yield f"data: {json.dumps({'status': 'clearing', 'message': f'Cleared {cleared_count} old vectors (Q&A pairs preserved)', 'progress': 10})}\n\n"
            else:
                yield f"data: {json.dumps({'status': 'processing', 'message': f'Found {total_pages} pages to process', 'progress': 10, 'total_pages': total_pages})}\n\n"
            await asyncio.sleep(0.1)
            
            total_chunks = 0
            
            for i, page in enumerate(pages):
                if await request.is_disconnected():
                    return
                
                current_progress = 10 + int((i / total_pages) * 85)
                page_title = page.get('title', 'Untitled')[:50]
                page_url = page.get('url', '')
                
                yield f"data: {json.dumps({'status': 'training', 'message': f'Processing: {page_title}', 'progress': current_progress, 'current_page': i + 1, 'total_pages': total_pages, 'current_url': page_url})}\n\n"
                
                # Use content enhancement if available
                from services.content_enhancer import content_enhancer
                USE_CONTENT_ENHANCEMENT = os.getenv("USE_CONTENT_ENHANCEMENT", "true").lower() == "true"
                
                if USE_CONTENT_ENHANCEMENT:
                    try:
                        enhanced = content_enhancer.enhance_page_content(
                            html='',
                            url=page['url'],
                            title=page['title'],
                            description=page.get('description', ''),
                            headings=page.get('headings', []),
                            raw_content=page['content']
                        )
                        
                        training_chunks = content_enhancer.prepare_for_training(
                            enhanced,
                            use_semantic_chunking=USE_SEMANTIC_CHUNKING
                        )
                        
                        for chunk_data in training_chunks:
                            nlp_service.train_text(
                                chatbot_id,
                                chunk_data['text'],
                                chunk_data.get('metadata', {})
                            )
                            total_chunks += 1
                    except Exception as enhance_err:
                        logger.warning(f"Content enhancement failed, using fallback: {enhance_err}")
                        # Fallback
                        raw_text = f"{page['title']}. {page['content']}"
                        chunks = simple_chunk_text(raw_text)
                        for j, chunk in enumerate(chunks):
                            meta = {"url": page['url'], "title": page['title'], "chunk_index": j}
                            nlp_service.train_text(chatbot_id, chunk, meta)
                            total_chunks += 1
                else:
                    # Original simple training
                    raw_text = f"{page['title']}. {page['content']}"
                    chunks = simple_chunk_text(raw_text)
                    for j, chunk in enumerate(chunks):
                        meta = {"url": page['url'], "title": page['title'], "chunk_index": j}
                        nlp_service.train_text(chatbot_id, chunk, meta)
                        total_chunks += 1
                
                await asyncio.sleep(0.05)
            
            yield f"data: {json.dumps({'status': 'finalizing', 'message': 'Finalizing training...', 'progress': 95})}\n\n"
            
            if bot['status'] == 'Draft':
                updates = {"status": "Active", "updatedAt": datetime.utcnow().isoformat() + "Z"}
                ChatbotDB.update(chatbot_id, updates)
            
            yield f"data: {json.dumps({'status': 'completed', 'message': f'Successfully trained on {total_pages} pages ({total_chunks} chunks)!', 'progress': 100, 'pages_processed': total_pages})}\n\n"
            
        except Exception as e:
            yield f"data: {json.dumps({'status': 'error', 'message': str(e), 'progress': 0})}\n\n"
    
    return StreamingResponse(
        generate_training_events(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )


@router.get("/jobs")
async def get_training_jobs(
    current_user: dict = Depends(get_current_user)
) -> List[Dict[str, Any]]:
    """Get recent training jobs for all chatbots"""
    from services.database import TrainingJobDB
    
    try:
        jobs = TrainingJobDB.get_all(limit=10)
        
        if not jobs:
            return []
        
        formatted_jobs = []
        for job in jobs:
            formatted_jobs.append({
                "id": job.get("id"),
                "chatbot_id": job.get("chatbot_id"),
                "status": job.get("status", "completed"),
                "pages_processed": job.get("pages_processed", 0),
                "started_at": job.get("started_at"),
                "completed_at": job.get("completed_at"),
                "error": job.get("error")
            })
        
        return formatted_jobs
    except Exception as e:
        logger.error(f"Error fetching training jobs: {e}")
        return []

"""
NLP Q&A Router
Handles Question-Answer pair management
"""

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional, Dict, Any
import logging
from services.nlp_service import nlp_service
from routers.auth import get_current_user
from shared.errors import NotFoundError
from shared.permissions import can_access_chatbot
from services.database import ChatbotDB

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/nlp", tags=["nlp"])


class TrainQARequest(BaseModel):
    chatbot_id: str
    question: str
    answer: str


@router.post("/train/qa")
async def train_chatbot_qa(
    request: TrainQARequest,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, str]:
    """Add a supervised Question-Answer pair to the knowledge base"""
    from services.cache_service import response_cache

    chatbot = ChatbotDB.get_by_id(request.chatbot_id)
    if not chatbot or not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to access this chatbot")
    
    nlp_service.train_qa(request.chatbot_id, request.question, request.answer)
    response_cache.invalidate(request.chatbot_id)
    
    return {
        "message": "Successfully learned Q&A pair",
        "chatbot_id": request.chatbot_id
    }


@router.get("/qa/{chatbot_id}")
async def get_qa_history(chatbot_id: str, current_user: dict = Depends(get_current_user)):
    """Get all Q&A pairs (corrections) for a chatbot"""
    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot or not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to access this chatbot")
    qa_pairs = nlp_service.get_qa_pairs(chatbot_id)
    return {
        "chatbot_id": chatbot_id,
        "qa_pairs": qa_pairs,
        "count": len(qa_pairs)
    }


@router.delete("/qa/{chatbot_id}/{point_id}")
async def delete_qa_pair(
    chatbot_id: str,
    point_id: str,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, str]:
    """Delete a specific Q&A pair"""
    chatbot = ChatbotDB.get_by_id(chatbot_id)
    if not chatbot or not can_access_chatbot(current_user, chatbot):
        raise HTTPException(status_code=403, detail="Not authorized to access this chatbot")
    success = nlp_service.delete_qa_pair(point_id)
    if success:
        return {"message": "Q&A pair deleted successfully", "point_id": point_id}
    raise NotFoundError(resource="Q&A pair", resource_id=point_id)

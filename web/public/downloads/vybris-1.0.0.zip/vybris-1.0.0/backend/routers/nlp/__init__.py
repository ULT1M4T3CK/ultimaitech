"""
NLP Router Module
Combines all NLP-related endpoints
"""

from fastapi import APIRouter
from . import processing, training, qa, analytics

# Create main router
router = APIRouter()

# Include all sub-routers
# IMPORTANT: qa.router MUST come before training.router because
# /train/qa must be matched before /train/{chatbot_id}
router.include_router(processing.router)
router.include_router(qa.router)
router.include_router(training.router)
router.include_router(analytics.router)

__all__ = ['router']

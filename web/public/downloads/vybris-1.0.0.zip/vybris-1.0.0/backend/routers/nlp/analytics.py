"""
NLP Analytics Router
Handles analytics and statistics endpoints
"""

from fastapi import APIRouter, Depends
from typing import Optional, Dict, Any
import logging
from routers.auth import get_current_user

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/nlp", tags=["nlp"])

UNKNOWN_INTENTS = {
    "unknown",
    "low_confidence_fallback",
    "no_results_fallback",
    "validation_failed_fallback",
    "llm_failed_fallback",
    "llm_error_fallback",
    "no_valid_rag_results",
}

def is_unknown_intent(intent: str) -> bool:
    """Determine if an intent should be treated as unknown."""
    if not intent:
        return False
    if intent in UNKNOWN_INTENTS:
        return True
    return intent.endswith("_fallback")


def _source_tag_from_intent_and_sources(intent: str, sources: list) -> tuple:
    """Return (source_tag, chunk_ids) for Phase 4.3 attribution."""
    intent_lower = (intent or "").lower()
    if "action" in intent_lower or "action_execution" in intent_lower:
        return ("Action", [])
    if "llm" in intent_lower or "elias" in intent_lower:
        return ("LLM", [])
    if sources:
        chunk_ids = [
            s.get("chunk_id") or s.get("id")
            for s in sources
            if s.get("chunk_id") or s.get("id")
        ]
        return ("RAG", chunk_ids[:5])
    return ("Fallback", [])


async def _update_analytics_background(
    chatbot_id: str,
    session_id: Optional[str],
    chatbot_name: str,
    query_text: str,
    intent: str,
    confidence: float,
    relevance_score: float,
    grounding_score: float,
    response_time: int,
    response_text: str,
    bot: Optional[dict],
    enable_analytics: bool = True,
    sources: Optional[list] = None,
):
    """Background task to update analytics and session tracking."""
    try:
        from services.database import ChatbotDB, SessionDB, LogDB, MessageDB, HistoryStorageConfigDB
        from services.llm import llm_service
        from datetime import datetime
        
        is_new_conversation = False
        session = None
        
        if session_id:
            logger.debug(f"[Analytics] Processing session: {session_id} for chatbot: {chatbot_id}")
            session = SessionDB.get_or_create(session_id, chatbot_id)
            
            if session:
                msg_count = session.get('message_count', 0)
                if msg_count == 0:
                    is_new_conversation = True
                    logger.debug(f"[Analytics] New conversation detected for chatbot: {chatbot_id}")
                
                SessionDB.update_activity(session_id, increment_messages=True)
            else:
                is_new_conversation = True
        
        is_unknown = is_unknown_intent(intent)
        
        store_messages = False
        if session_id and bot:
            owner_id = bot.get("owner_id")
            if owner_id and HistoryStorageConfigDB.get(owner_id) in ("cloud", "owner_device"):
                store_messages = True
        if session_id:
            if is_unknown:
                SessionDB.mark_unknown_interaction(session_id)
            if store_messages:
                MessageDB.create({
                    "session_id": session_id,
                    "chatbot_id": chatbot_id,
                    "role": "user",
                    "content": query_text,
                    "metadata": {},
                })
                source_tag, chunk_ids = _source_tag_from_intent_and_sources(intent, sources or [])
                meta = {
                    "relevance_score": relevance_score,
                    "grounding_score": grounding_score,
                    "response_time": response_time,
                    "source": source_tag,
                    "chunk_ids": chunk_ids,
                }
                MessageDB.create({
                    "session_id": session_id,
                    "chatbot_id": chatbot_id,
                    "role": "assistant",
                    "content": response_text,
                    "intent": intent,
                    "confidence": confidence,
                    "is_unknown": is_unknown,
                    "metadata": meta,
                })
            
            if enable_analytics:
                current_category = session.get('category', 'General') if session else 'General'
                if current_category == 'General' and llm_service.is_enabled():
                    try:
                        category_prompt = f"Categorize the following user query into a single short topic (max 3 words). Query: '{query_text}'"
                        if len(query_text) > 10:
                            category = await llm_service.generate_simple_reply(
                                user_message=category_prompt,
                                system_prompt="You are a categorization assistant. Reply with only the category, max 3 words."
                            )
                            if category:
                                category = category.replace('"', '').replace("'", "").strip().split('\n')[0]
                                if len(category) < 50:
                                    SessionDB.update_category(session_id, category)
                    except Exception as cat_err:
                        logger.warning(f"Categorization failed: {cat_err}")

        if not enable_analytics:
            return

        current_data = bot.get('data', {}) if bot else {}
        
        total_messages = current_data.get('totalMessages', 0) + 1
        total_conversations = current_data.get('conversations', 0)
        if is_new_conversation:
            total_conversations += 1
        
        def update_avg(old_avg, new_val, count):
            if count == 1:
                return new_val
            return (old_avg * 0.9) + (new_val * 0.1)

        new_avg_time = int(update_avg(current_data.get('avgResponseTime', 0), response_time, total_messages))
        new_avg_conf = update_avg(current_data.get('avgConfidence', 0.0), confidence, total_messages)
        new_avg_rel = update_avg(current_data.get('avgRelevance', 0.0), relevance_score, total_messages)
        new_avg_ground = update_avg(current_data.get('avgGrounding', 0.0), grounding_score, total_messages)
        
        active_users = SessionDB.get_active_conversations_count(chatbot_id) if session_id else 1
        
        if bot:
            ChatbotDB.update(chatbot_id, {
                'data': {
                    **current_data,
                    'totalMessages': total_messages,
                    'conversations': total_conversations,
                    'avgResponseTime': new_avg_time,
                    'avgConfidence': new_avg_conf,
                    'avgRelevance': new_avg_rel,
                    'avgGrounding': new_avg_ground,
                    'lastActive': datetime.utcnow().isoformat() + 'Z'
                },
                'users': max(active_users, 1)
            })
            
            LogDB.create({
                'level': 'INFO',
                'service': 'NLP',
                'action': 'process_message',
                'message': f"Chatbot '{chatbot_name}' processed query: '{query_text[:50]}{'...' if len(query_text) > 50 else ''}'",
                'chatbot_id': chatbot_id,
                'metadata': {
                    'intent': intent,
                    'confidence': float(confidence),
                    'relevance': float(relevance_score),
                    'grounding': float(grounding_score),
                    'response_time_ms': response_time,
                    'query_length': len(query_text),
                    'session_id': session_id or 'unknown',
                    'is_new_conversation': is_new_conversation,
                    'is_unknown': is_unknown
                }
            })
    except Exception as e:
        logger.warning(f"Background analytics update failed: {e}")


@router.get("/conversation")
async def get_conversation_analytics(
    chatbot_id: str,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    current_user: dict = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Get conversation analytics: intent distribution, resolution rate, escalation rate.
    """
    from datetime import datetime, timezone
    from services.analytics.conversation_analytics import get_conversation_analytics as _get

    from_dt = None
    to_dt = None
    if from_date:
        try:
            from_dt = datetime.fromisoformat(from_date.replace("Z", "+00:00"))
        except ValueError:
            from_dt = datetime.strptime(from_date[:10], "%Y-%m-%d").replace(tzinfo=timezone.utc)
    if to_date:
        try:
            to_dt = datetime.fromisoformat(to_date.replace("Z", "+00:00"))
        except ValueError:
            to_dt = datetime.strptime(to_date[:10], "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return _get(chatbot_id, from_dt, to_dt)


@router.get("/stats")
async def get_nlp_stats(
    chatbot_id: str,
    current_user: dict = Depends(get_current_user)
) -> Dict[str, Any]:
    """Get performance statistics for a chatbot from real data"""
    from services.database import ChatbotDB, SessionDB
    
    try:
        bot = ChatbotDB.get_by_id(chatbot_id)
        
        if bot:
            data = bot.get('data', {})
            total_messages = data.get('totalMessages', 0)
            conversations = data.get('conversations', 0)
            avg_response_time = data.get('avgResponseTime', 0)
            
            volume_history = SessionDB.get_monthly_stats(chatbot_id)
            
            avg_confidence = data.get('avgConfidence', 0.0)
            avg_relevance = data.get('avgRelevance', 0.0)
            avg_grounding = data.get('avgGrounding', 0.0)
            
            if total_messages == 0:
                avg_confidence = 0.0
                avg_relevance = 0.0
                avg_grounding = 0.0
            
            return {
                "total_queries": total_messages,
                "conversations": conversations,
                "avg_confidence": avg_confidence,
                "response_accuracy": avg_relevance,
                "intent_accuracy": avg_grounding,
                "avg_response_time_ms": avg_response_time,
                "top_intents": data.get('intents', []),
                "last_active": data.get('lastActive'),
                "volume_history": volume_history
            }
        
        return {
            "total_queries": 0,
            "conversations": 0,
            "avg_confidence": 0.0,
            "response_accuracy": 0.0,
            "intent_accuracy": 0.0,
            "avg_response_time_ms": 0,
            "top_intents": []
        }
    except Exception as e:
        logger.warning(f"Error fetching stats: {e}")
        return {
            "total_queries": 0,
            "conversations": 0,
            "avg_confidence": 0.0,
            "response_accuracy": 0.0,
            "intent_accuracy": 0.0,
            "avg_response_time_ms": 0
        }

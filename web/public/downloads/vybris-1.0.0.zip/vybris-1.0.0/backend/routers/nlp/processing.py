"""
NLP Processing Router
Handles text processing with RAG pipeline via ChatOrchestrator.
"""

from fastapi import APIRouter, Request, BackgroundTasks, Depends, Response
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import time
import logging
import os
from services.nlp_service import nlp_service
from middleware.rate_limit import rate_limit

logger = logging.getLogger(__name__)

USE_ORCHESTRATOR = os.getenv("USE_ORCHESTRATOR", "true").lower() == "true"
USE_ASYNC_CHAT = os.getenv("USE_ASYNC_CHAT", "false").lower() == "true"

router = APIRouter(prefix="/api/v1/nlp", tags=["nlp"])


class TextRequest(BaseModel):
    """Request model for text processing (Phase 4: multimodal support)"""
    text: str
    chatbot_id: str
    session_id: Optional[str] = None
    context: Optional[Dict[str, Any]] = None
    auto_request_live_chat: bool = False
    # Phase 4: Optional multimodal inputs (audio transcribed to text and merged)
    audio_base64: Optional[str] = None
    audio_mime_type: Optional[str] = None
    image_base64: Optional[str] = None  # Future: vision context
    image_mime_type: Optional[str] = None


class IntentResponse(BaseModel):
    """Response model for NLP processing (Phase 4: explainability)"""
    intent: str
    confidence: float
    response: str
    sources: List[Dict[str, Any]] = []
    live_chat_request_id: Optional[str] = None
    live_chat_status: Optional[str] = None
    explanation: Optional[str] = None  # Phase 4: "Why did you say this?"


@router.get("/")
def read_root():
    from services.llm import llm_service
    advanced_rag = os.getenv("USE_ADVANCED_RAG", "true").lower() == "true"
    return {
        "status": "NLP Engine Running",
        "version": "3.0.0",
        "backend": "Qdrant",
        "advanced_rag": advanced_rag,
        "orchestrator": USE_ORCHESTRATOR,
        "llm_enabled": llm_service.is_enabled(),
        "llm_provider": llm_service.get_provider_name() if llm_service.is_enabled() else None
    }


@router.get("/result/{job_id}")
async def get_async_result(job_id: str):
    """
    Poll result of async chat processing (when USE_ASYNC_CHAT=true).
    Returns 202 until worker completes, then 200 with IntentResponse.
    """
    from services.message_broker import get_result
    result = get_result(job_id)
    if result is None:
        return Response(content='{"status":"pending"}', status_code=202, media_type="application/json")
    return result


@router.post("/process", response_model=IntentResponse)
@rate_limit(limit=30, window=60, authenticated_limit=100)
async def process_text(
    request: TextRequest,
    req: Request,
    background_tasks: BackgroundTasks
) -> IntentResponse:
    """
    Process user text with enhanced RAG pipeline.
    Phase 4: Supports optional audio (transcribed via Whisper) and content filtering.
    
    STRICT RAG-ONLY POLICY:
    - Responses MUST ONLY come from scraped website content or manually trained data
    - NO external search or general knowledge allowed
    - If no RAG results found, use fallback message (do NOT call external APIs)
    """
    start_time = time.time()

    # Phase 4: Multimodal - transcribe audio and merge with text
    text = request.text
    if request.audio_base64:
        from services.speech_to_text_service import transcribe_audio, is_available
        if is_available():
            transcribed = transcribe_audio(request.audio_base64, request.audio_mime_type or "audio/webm")
            if transcribed:
                text = f"{transcribed}. {text}".strip() if text else transcribed
        else:
            text = (text or "") + " [Audio transcription unavailable]"

    # Phase 4.1: Vision - describe image and append context
    if request.image_base64:
        from services.vision_service import describe_image
        desc = describe_image(request.image_base64, request.image_mime_type)
        if desc:
            text = f"[User attached image: {desc}]. {text}".strip() if text else f"[User attached image: {desc}]"

    # Phase 4: Content filter - moderation (optional)
    from services.content_filter_service import check_moderation
    from services.content_filter_service import redact_pii
    safe, mod_details = check_moderation(text)
    if not safe:
        return IntentResponse(
            intent="content_moderated",
            confidence=0.0,
            response="Your message could not be processed. Please rephrase.",
            sources=[],
            explanation="Content moderation flagged this input.",
        )
    text, _ = redact_pii(text)

    # Optional async path: publish to Redis Stream, return 202 for client to poll
    if USE_ASYNC_CHAT:
        try:
            from services.message_broker import publish_message, get_result
            job_id = publish_message(
                request.chatbot_id,
                request.session_id or "",
                text,
                metadata={"context": request.context, "auto_request_live_chat": request.auto_request_live_chat},
            )
            if job_id:
                return Response(
                    content='{"job_id":"%s","message":"Processing. Poll GET /api/v1/nlp/result/%s"}' % (job_id, job_id),
                    status_code=202,
                    media_type="application/json",
                )
        except Exception as e:
            logger.warning(f"Async chat publish failed, falling back to sync: {e}")

    from services.database import ChatbotDB, SessionDB, HistoryStorageConfigDB
    from services.llm import llm_service
    from services.cache_service import response_cache
    from services.conversation_events import emit_user_message_received, emit_response_generated
    from services.database.cached_queries import CachedQueries
    
    # Emit user message event (for analytics, audit, replay)
    request_id = getattr(req.state, "request_id", None)
    emit_user_message_received(
        chatbot_id=request.chatbot_id,
        session_id=request.session_id,
        user_message=text,
        request_id=request_id,
    )

    # Load bot
    bot = ChatbotDB.get_by_id(request.chatbot_id)
    _bot_config = bot.get("config", {}) if bot else {}
    chatbot_name = bot.get("name", "Assistant") if bot else "Assistant"

    # Orchestrator path (Phase 2.1 - delegates to orchestrator service)
    if USE_ORCHESTRATOR:
        from application.chat.intent_router import IntentRouter, RouteType
        from services.orchestrator import orchestrator_service

        route = IntentRouter().route(text=text, bot_config=_bot_config, bot=bot)

        # Cache only for non-live-chat (live chat returns immediately)
        if route.route != RouteType.LIVE_CHAT:
            cached_response = response_cache.get(request.chatbot_id, text)
            if cached_response:
                logger.debug(f"Cache HIT for chatbot {request.chatbot_id}")
                return cached_response

        orch_result = await orchestrator_service.orchestrate(
            text=text,
            chatbot_id=request.chatbot_id,
            session_id=request.session_id,
            context=request.context,
            auto_request_live_chat=request.auto_request_live_chat,
            bot=bot or {},
            req=req,
        )

        response_time = int((time.time() - start_time) * 1000)
        intent = orch_result.intent
        # Record latency metrics
        try:
            from monitoring.health import metrics
            metrics.record_request("/api/v1/nlp/process")
            metrics.record_response_time("/api/v1/nlp/process", float(response_time))
        except Exception:
            pass
        try:
            from monitoring.prometheus import record_nlp_query
            record_nlp_query(request.chatbot_id, intent, "success", response_time / 1000.0)
        except Exception:
            pass
        confidence = orch_result.confidence
        response_text = orch_result.response
        sources = orch_result.sources or []

        # Background tasks (analytics, metrics)
        from services.evaluation_service import evaluation_service
        relevance_score = confidence
        grounding_score = confidence if sources else 0.0

        async def calculate_metrics_background():
            try:
                relevance = await evaluation_service.calculate_relevance(text, response_text)
                grounding = 0.0
                if sources:
                    grounding = await evaluation_service.calculate_grounding(response_text, sources[:3])
                logger.info(f"Quality Metrics - Relevance: {relevance:.4f}, Grounding: {grounding:.4f}, Confidence: {confidence:.4f}")
            except Exception as e:
                logger.error(f"Error calculating evaluation metrics: {e}")

        background_tasks.add_task(calculate_metrics_background)

        from routers.nlp.analytics import _update_analytics_background
        background_tasks.add_task(
            _update_analytics_background,
            chatbot_id=request.chatbot_id,
            session_id=request.session_id,
            chatbot_name=chatbot_name,
            query_text=text,
            intent=intent,
            confidence=confidence,
            relevance_score=relevance_score,
            grounding_score=grounding_score,
            response_time=response_time,
            response_text=response_text,
            bot=bot,
            sources=sources,
        )

        response_obj = {
            "intent": intent,
            "confidence": confidence,
            "response": response_text,
            "sources": sources,
            "live_chat_request_id": orch_result.live_chat_request_id,
            "live_chat_status": orch_result.live_chat_status,
            "explanation": orch_result.explanation,
        }

        if route.route != RouteType.LIVE_CHAT and confidence >= 0.4:
            response_cache.set(request.chatbot_id, text, {
                "intent": intent,
                "confidence": confidence,
                "response": response_text,
                "sources": sources,
            })

        emit_response_generated(
            chatbot_id=request.chatbot_id,
            session_id=request.session_id,
            user_message=text,
            response=response_text,
            intent=intent,
            confidence=confidence,
            sources_count=len(sources),
            processing_time_ms=response_time,
            request_id=request_id,
            metadata={"grounding_score": grounding_score, "relevance_score": relevance_score},
        )

        # Publish on_user_intent workflow event for chat-driven automations
        try:
            from services.message_broker import publish_workflow_event

            ctx = {"intent": intent, "confidence": confidence, "session_id": request.session_id or ""}
            publish_workflow_event("on_user_intent", ctx, chatbot_id=request.chatbot_id)
        except Exception:
            pass

        if request.session_id and bot:
            owner_id = bot.get("owner_id")
            if owner_id and HistoryStorageConfigDB.get(owner_id) in ("cloud", "owner_device"):
                SessionDB.add_message(request.session_id, "user", text)
                SessionDB.add_message(request.session_id, "assistant", response_text)

        # Persist dialog state for conversation context (all orchestration paths)
        if request.session_id:
            try:
                from services.dialog_state_service import set_dialog_state
                set_dialog_state(request.session_id, intent, {"last_query": text[:200]})
            except Exception:
                pass

        return IntentResponse(**response_obj)

    # Legacy path (USE_ORCHESTRATOR=false)
    from nlp.query_processor import DomainQueryProcessor
    from nlp.retrieval import HybridRetriever
    from nlp.reranker import ChunkReranker

    USE_ADVANCED_RAG = os.getenv("USE_ADVANCED_RAG", "true").lower() == "true"
    query_processor = DomainQueryProcessor()
    hybrid_retriever = HybridRetriever(nlp_service, semantic_weight=0.7, keyword_weight=0.3)
    reranker = ChunkReranker(top_k=5, use_cross_encoder=True)

    enable_live_chat = bool(_bot_config.get("enableLiveChat"))
    elias_enabled = bool(_bot_config.get("elias_enabled"))

    if enable_live_chat and text:
        import uuid
        _t = text.strip().lower()
        _request_human_phrases = (
            "talk to a human", "talk to human", "speak to human", "speak to a human",
            "connect to a human", "connect to human", "human agent", "real person",
            "real human", "speak to agent", "talk to agent", "human support",
            "live agent", "live chat", "human please", "want a human", "need a human",
            "contact human", "reach human", "verbinding met mens", "mens spreken",
            "human praten", "agent spreken", "echte persoon", "can i speak to",
            "get a human", "speak with human", "talk with human", "connect me to",
            "transfer to human", "transfer to agent", "i want to talk to",
            "need to speak to", "want to speak to", "speak to someone", "talk to someone",
        )
        _short_request = _t in ("human", "agent", "person", "live", "support", "human please", "agent please")
        _has_phrase = any(p in _t for p in _request_human_phrases)
        _short_and_keyword = len(_t.split()) <= 8 and any(
            k in _t for k in ("human", "agent", "real person", "live chat", "live agent", "human support")
        )
        if _short_request or _has_phrase or _short_and_keyword:
            logger.info(f"Live chat prompt: chatbot_id={request.chatbot_id}, query={text[:80]}")
            live_msg = "I'm connecting you to a human agent now. Please hold on while I find someone available to help you."
            live_chat_request_id = None
            live_chat_status = None
            origin = req.headers.get("Origin")
            referer = req.headers.get("Referer")
            should_auto_request = bool(request.auto_request_live_chat)
            if not should_auto_request:
                should_auto_request = bool(request.session_id and (origin or referer))
            if should_auto_request and request.session_id:
                try:
                    from services.database.live_chat import LiveChatDB
                    rid = f"lc_{uuid.uuid4().hex[:12]}"
                    context_page_url = (request.context or {}).get("page_url") or referer or origin
                    entry = LiveChatDB.create_request(
                        request_id=rid, chatbot_id=request.chatbot_id, session_id=request.session_id,
                        message=text, page_url=context_page_url
                    )
                    if entry:
                        live_chat_request_id = entry.get("request_id")
                        live_chat_status = entry.get("status") or "queued"
                except Exception as e:
                    logger.error(f"Auto live chat request failed: {e}")
            return IntentResponse(
                intent="live_chat_auto_forward", confidence=1.0, response=live_msg, sources=[],
                live_chat_request_id=live_chat_request_id, live_chat_status=live_chat_status,
            )

    cached_response = response_cache.get(request.chatbot_id, text)
    if cached_response:
        logger.debug(f"Cache HIT for chatbot {request.chatbot_id}")
        return cached_response

    fallback_message = _bot_config.get("fallbackMessage", "I'm sorry, I didn't understand that.")
    company_name = (_bot_config.get("companyName") or chatbot_name or "").strip()
    supported_languages = _bot_config.get("supportedLanguages") or [_bot_config.get("language", "en")]
    chatbot_type = bot.get("type", "General Purpose") if bot else "General Purpose"
    personality = _bot_config.get("personality", "Professional")
    results = []
    intent = "unknown"
    history = SessionDB.get_history(request.session_id) if request.session_id else []

    from services.database import IntegrationDB
    active_integrations = IntegrationDB.get_by_chatbot(request.chatbot_id)
    inv_integration = next((i for i in active_integrations if i["integration_type"] == "universal_inventory" and i.get("status", "").lower() == "active"), None)
    book_integration = next((i for i in active_integrations if i["integration_type"] == "universal_booking" and i.get("status", "").lower() == "active"), None)
    integration_results = []
    try:
        from services.integrations import IntegrationManager
        if inv_integration:
            inv_instance = IntegrationManager.get_integration("universal_inventory", inv_integration.get("config", {}))
            r = inv_instance.process_text(text)
            if r:
                integration_results.append(r)
        if book_integration:
            book_instance = IntegrationManager.get_integration("universal_booking", book_integration.get("config", {}))
            r = book_instance.process_text(text)
            if r:
                integration_results.append(r)
    except Exception as e:
        logger.error(f"Universal Integration processing failed: {e}")

    if integration_results:
        combined = "\n".join(integration_results)
        logger.info(f"Universal Integration Result: {combined}")
        results.insert(0, {
            "text": f"SYSTEM DATA [Real-time]: {combined}",
            "score": 1.5, "semantic_score": 1.0, "keyword_score": 1.0,
            "payload": {"type": "system", "source": "integration"},
        })
        if "Booking Successfully Created" in combined or "Click Here to Complete Booking" in combined:
            intent = "booking_confirmed"

    if USE_ADVANCED_RAG:
        processed_query = query_processor.process_with_synonyms(text)
        search_results = hybrid_retriever.search(request.chatbot_id, processed_query.expanded_query, limit=10)
        results = [{"text": r.text, "score": r.score, "semantic_score": r.semantic_score, "keyword_score": r.keyword_score, "payload": r.payload} for r in search_results]
        if results:
            results = reranker.rerank(text, results)
            for r in results:
                if r.get("payload", {}).get("type") == "qa":
                    r["score"] = min(r["score"] * 1.5, 1.0)
            results.sort(key=lambda x: x["score"], reverse=True)
    else:
        results = nlp_service.search(request.chatbot_id, text, limit=5)

    confidence = 0.0
    response_text = fallback_message
    sources = []
    if results:
        best_match = results[0]
        confidence = best_match["score"]
        sources = results
        if llm_service.is_enabled():
            valid_results = [r for r in results if r.get("score", 0) >= 0.3]
            if valid_results:
                try:
                    if elias_enabled:
                        from services.rag_service import rag_service
                        rag_response = await rag_service.generate_response(
                            chatbot_id=request.chatbot_id, query=text,
                            context={"session_id": request.session_id, "chatbot_name": chatbot_name, "company_name": company_name, "chatbot_type": chatbot_type, "personality": personality},
                            use_llm=True,
                        )
                        if rag_response and rag_response.response:
                            llm_response = rag_response.response
                            intent = rag_response.intent or "elias_enhanced_response"
                            confidence = rag_response.confidence
                        else:
                            llm_response = None
                    else:
                        llm_response = await llm_service.generate_response(
                            user_query=text, context_chunks=valid_results,
                            chatbot_name=chatbot_name, company_name=company_name,
                            chatbot_type=chatbot_type, personality=personality,
                            supported_languages=supported_languages, temperature=0.3, history=history,
                        )
                    if llm_response:
                        from services.response_validator import response_validator
                        validation = response_validator.validate_response(
                            response=llm_response, query=text, context_chunks=valid_results, confidence=confidence
                        )
                        if validation["valid"] and not validation["should_use_fallback"]:
                            response_text = llm_response
                            intent = "elias_enhanced_response" if elias_enabled else "llm_enhanced_response" if intent != "action_execution" else intent
                        elif confidence >= 0.5:
                            response_text = best_match["text"]
                            intent = "information_retrieval"
                        else:
                            intent = "validation_failed_fallback"
                    elif confidence >= 0.5:
                        response_text = best_match["text"]
                        intent = "information_retrieval"
                    else:
                        intent = "llm_failed_fallback"
                except Exception as e:
                    logger.error(f"LLM API error: {e}")
                    if confidence >= 0.5:
                        response_text = best_match["text"]
                        intent = "information_retrieval"
                    else:
                        intent = "llm_error_fallback"
            else:
                intent = "no_valid_rag_results"
        elif confidence >= 0.5:
            response_text = best_match["text"]
            intent = "information_retrieval"
        elif confidence >= 0.3:
            response_text = "I found something that might help: " + best_match["text"]
            intent = "low_confidence_match"
    else:
        intent = "no_results_fallback"

    response_time = int((time.time() - start_time) * 1000)
    relevance_score = confidence
    grounding_score = confidence if results else 0.0

    # Record latency metrics (legacy path)
    try:
        from monitoring.health import metrics
        metrics.record_request("/api/v1/nlp/process")
        metrics.record_response_time("/api/v1/nlp/process", float(response_time))
    except Exception:
        pass
    try:
        from monitoring.prometheus import record_nlp_query
        record_nlp_query(request.chatbot_id, intent, "success", response_time / 1000.0)
    except Exception:
        pass

    async def _legacy_metrics():
        try:
            rel = await evaluation_service.calculate_relevance(text, response_text)
            gr = await evaluation_service.calculate_grounding(response_text, results[:3]) if results else 0.0
            logger.info(f"Quality Metrics - Relevance: {rel:.4f}, Grounding: {gr:.4f}")
        except Exception as e:
            logger.error(f"Error calculating evaluation metrics: {e}")

    from services.evaluation_service import evaluation_service
    background_tasks.add_task(_legacy_metrics)

    from routers.nlp.analytics import _update_analytics_background
    background_tasks.add_task(
        _update_analytics_background,
        chatbot_id=request.chatbot_id, session_id=request.session_id, chatbot_name=chatbot_name,
        query_text=text, intent=intent, confidence=confidence,
        relevance_score=relevance_score, grounding_score=grounding_score,
        response_time=response_time, response_text=response_text, bot=bot,
        sources=sources,
    )

    explanation = None
    if sources:
        top = sources[:3]
        titles = [s.get("payload", {}).get("title") or str(s.get("text", ""))[:50] for s in top]
        explanation = f"Response based on {len(sources)} knowledge base result(s). Top sources: {', '.join(str(t) for t in titles if t)[:200]}."
    response_obj = {"intent": intent, "confidence": confidence, "response": response_text, "sources": sources, "explanation": explanation}
    if confidence >= 0.4:
        response_cache.set(request.chatbot_id, text, response_obj)

    emit_response_generated(
        chatbot_id=request.chatbot_id, session_id=request.session_id, user_message=text,
        response=response_text, intent=intent, confidence=confidence, sources_count=len(sources),
        processing_time_ms=response_time, request_id=request_id,
        metadata={"grounding_score": grounding_score, "relevance_score": relevance_score},
    )

    if request.session_id and bot:
        owner_id = bot.get("owner_id")
        if owner_id and HistoryStorageConfigDB.get(owner_id) in ("cloud", "owner_device"):
            SessionDB.add_message(request.session_id, "user", text)
            SessionDB.add_message(request.session_id, "assistant", response_text)

    # Persist dialog state (legacy path)
    if request.session_id:
        try:
            from services.dialog_state_service import set_dialog_state
            set_dialog_state(request.session_id, intent, {"last_query": text[:200]})
        except Exception:
            pass

    return IntentResponse(**response_obj)

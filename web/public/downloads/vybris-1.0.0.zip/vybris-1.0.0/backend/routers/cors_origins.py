"""
CORS Origins Management Router
Admin endpoints for managing allowed CORS origins
"""

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from routers.auth import get_current_user, require_admin
from services.database.cors_origins import CORSOriginsDB
from services.cors_service import cors_service
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/admin/cors", tags=["admin", "cors"])


class AddOriginRequest(BaseModel):
    """Request model for adding a CORS origin"""
    origin: str = Field(..., description="Full origin URL (e.g., https://example.com)")
    notes: Optional[str] = Field(None, description="Optional notes about this origin")


@router.get("/origins", response_model=List[Dict[str, Any]])
async def get_cors_origins(
    current_user: dict = Depends(require_admin)
):
    """Get all CORS origins (admin only)"""
    try:
        origins = CORSOriginsDB.get_all()
        return origins
    except Exception as e:
        logger.error(f"Failed to get CORS origins: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve CORS origins")


@router.post("/origins", response_model=Dict[str, Any])
async def add_cors_origin(
    request: AddOriginRequest,
    current_user: dict = Depends(require_admin)
):
    """Add a CORS origin manually (admin only)"""
    from urllib.parse import urlparse
    
    try:
        # Validate origin format
        parsed = urlparse(request.origin)
        if not parsed.scheme or not parsed.netloc:
            raise HTTPException(status_code=400, detail="Invalid origin format. Must be a full URL (e.g., https://example.com)")
        
        domain = parsed.netloc.lower()
        if ':' in domain:
            domain = domain.split(':')[0]
        
        # Remove www prefix for consistency
        base_domain = domain[4:] if domain.startswith('www.') else domain
        
        # Add origin
        success = CORSOriginsDB.add_origin(
            origin=request.origin,
            domain=base_domain,
            notes=request.notes or f"Manually added by admin {current_user.get('email', 'unknown')}"
        )
        
        if success:
            # Invalidate cache
            cors_service.invalidate_cache()
            return {
                "status": "success",
                "message": f"Added CORS origin: {request.origin}",
                "origin": request.origin,
                "domain": base_domain
            }
        else:
            raise HTTPException(status_code=400, detail="Origin already exists or failed to add")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to add CORS origin: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to add CORS origin: {str(e)}")


@router.delete("/origins/{origin:path}", response_model=Dict[str, Any])
async def delete_cors_origin(
    origin: str,
    current_user: dict = Depends(require_admin)
):
    """Delete a CORS origin (admin only)"""
    try:
        success = CORSOriginsDB.delete(origin)
        if success:
            cors_service.invalidate_cache()
            return {
                "status": "success",
                "message": f"Deleted CORS origin: {origin}"
            }
        else:
            raise HTTPException(status_code=404, detail="CORS origin not found")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete CORS origin: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete CORS origin: {str(e)}")


@router.post("/origins/{origin:path}/deactivate", response_model=Dict[str, Any])
async def deactivate_cors_origin(
    origin: str,
    current_user: dict = Depends(require_admin)
):
    """Deactivate a CORS origin (admin only)"""
    try:
        success = CORSOriginsDB.deactivate(origin)
        if success:
            cors_service.invalidate_cache()
            return {
                "status": "success",
                "message": f"Deactivated CORS origin: {origin}"
            }
        else:
            raise HTTPException(status_code=404, detail="CORS origin not found")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to deactivate CORS origin: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to deactivate CORS origin: {str(e)}")

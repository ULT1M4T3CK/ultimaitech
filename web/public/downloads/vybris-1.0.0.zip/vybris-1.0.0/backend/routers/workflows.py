"""
Workflows Router (Phase 4 - Multi-step automations)
"""

import hmac
import hashlib
import os
from fastapi import APIRouter, HTTPException, Depends, Header, Request
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

from routers.auth import get_current_user
from shared.permissions import can_access_chatbot
from services.database import WorkflowDB
from services.workflow_engine import run_workflow

router = APIRouter(prefix="/api/v1/workflows", tags=["workflows"])


class WorkflowStep(BaseModel):
    type: str = Field(..., description="action | condition | delay")
    config: Dict[str, Any] = Field(default_factory=dict)


class WorkflowTrigger(BaseModel):
    type: str = Field(..., description="stage_change, score_threshold, time_in_stage, on_user_intent, on_handoff, on_sentiment")
    config: Dict[str, Any] = Field(default_factory=dict)


class WorkflowCreate(BaseModel):
    chatbot_id: str
    name: str
    steps: List[WorkflowStep] = Field(default_factory=list)
    triggers: List[WorkflowTrigger] = Field(default_factory=list)
    enabled: bool = True


class WorkflowUpdate(BaseModel):
    name: Optional[str] = None
    steps: Optional[List[WorkflowStep]] = None
    triggers: Optional[List[WorkflowTrigger]] = None
    enabled: Optional[bool] = None


@router.get("/")
async def list_workflows(
    chatbot_id: str,
    enabled_only: bool = False,
    current_user: dict = Depends(get_current_user),
):
    """List workflows for a chatbot."""
    if not can_access_chatbot(current_user, chatbot_id):
        raise HTTPException(status_code=403, detail="Not authorized")
    items = WorkflowDB.get_by_chatbot(chatbot_id, enabled_only=enabled_only)
    return {"workflows": items}


@router.post("/")
async def create_workflow(
    body: WorkflowCreate,
    current_user: dict = Depends(get_current_user),
):
    """Create a workflow."""
    if not can_access_chatbot(current_user, body.chatbot_id):
        raise HTTPException(status_code=403, detail="Not authorized")
    steps = [s.model_dump() for s in body.steps]
    triggers = [t.model_dump() for t in body.triggers] if body.triggers else []
    wf = WorkflowDB.create({
        "chatbot_id": body.chatbot_id,
        "name": body.name,
        "steps": steps,
        "triggers": triggers,
        "enabled": body.enabled,
    })
    if not wf:
        raise HTTPException(status_code=500, detail="Failed to create workflow")
    return wf


@router.get("/{workflow_id}")
async def get_workflow(
    workflow_id: str,
    current_user: dict = Depends(get_current_user),
):
    """Get a workflow by ID."""
    wf = WorkflowDB.get_by_id(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    if not can_access_chatbot(current_user, wf["chatbot_id"]):
        raise HTTPException(status_code=403, detail="Not authorized")
    return wf


@router.put("/{workflow_id}")
async def update_workflow(
    workflow_id: str,
    body: WorkflowUpdate,
    current_user: dict = Depends(get_current_user),
):
    """Update a workflow."""
    wf = WorkflowDB.get_by_id(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    if not can_access_chatbot(current_user, wf["chatbot_id"]):
        raise HTTPException(status_code=403, detail="Not authorized")
    updates = body.model_dump(exclude_unset=True)
    if "steps" in updates:
        steps = updates["steps"]
        updates["steps"] = [s if isinstance(s, dict) else (s.model_dump() if hasattr(s, "model_dump") else s) for s in steps]
    if "triggers" in updates:
        triggers = updates["triggers"]
        updates["triggers"] = [t if isinstance(t, dict) else (t.model_dump() if hasattr(t, "model_dump") else t) for t in triggers]
    updated = WorkflowDB.update(workflow_id, updates)
    return updated or wf


@router.delete("/{workflow_id}")
async def delete_workflow(
    workflow_id: str,
    current_user: dict = Depends(get_current_user),
):
    """Delete a workflow."""
    wf = WorkflowDB.get_by_id(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    if not can_access_chatbot(current_user, wf["chatbot_id"]):
        raise HTTPException(status_code=403, detail="Not authorized")
    WorkflowDB.delete(workflow_id)
    return {"message": "Workflow deleted"}


class WorkflowTriggerRequest(BaseModel):
    """Webhook trigger request."""
    workflow_id: str
    chatbot_id: str
    context: Dict[str, Any] = Field(default_factory=dict)


def _verify_webhook_signature(body: bytes, signature: str) -> bool:
    """Verify HMAC-SHA256 signature of webhook body."""
    secret = os.getenv("WORKFLOW_WEBHOOK_SECRET", "").encode()
    if not secret:
        return False
    expected = hmac.new(secret, body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


@router.post("/trigger")
async def trigger_workflow(
    body: WorkflowTriggerRequest,
    request: Request,
    x_webhook_signature: Optional[str] = Header(None),
):
    """
    Trigger a workflow via webhook (e.g. from external systems).
    Requires X-Webhook-Signature: HMAC-SHA256 hex of request body.
    Set WORKFLOW_WEBHOOK_SECRET in env.
    """
    raw_body = await request.body()
    sig = x_webhook_signature or request.headers.get("X-Webhook-Signature")
    if not _verify_webhook_signature(raw_body, sig or ""):
        raise HTTPException(status_code=401, detail="Invalid or missing webhook signature")
    wf = WorkflowDB.get_by_id(body.workflow_id)
    if not wf or wf.get("chatbot_id") != body.chatbot_id:
        raise HTTPException(status_code=404, detail="Workflow not found")
    if not wf.get("enabled"):
        raise HTTPException(status_code=400, detail="Workflow is disabled")
    context = body.context or {}
    result = await run_workflow(body.workflow_id, body.chatbot_id, context)
    return {"success": result.get("success", False), "result": result}

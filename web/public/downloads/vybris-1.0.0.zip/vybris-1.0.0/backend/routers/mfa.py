"""
MFA Router for VYBR!S
Provides endpoints for MFA enrollment and verification
SOC 2 Compliance: CC5.2
"""

from fastapi import APIRouter, Depends, HTTPException, status, Request
from pydantic import BaseModel
from typing import Annotated, Optional
import json

from services.mfa_service import MFAService
from services.database import UserDB
from routers.auth import get_current_user, require_admin

router = APIRouter(prefix="/api/v1/mfa", tags=["mfa"])


# ============================================================================
# Request/Response Models
# ============================================================================

class MFAEnrollRequest(BaseModel):
    """Request to enroll in MFA"""
    pass  # No additional data needed, uses current user from JWT


class MFAEnrollResponse(BaseModel):
    """Response containing QR code for MFA enrollment"""
    secret: str
    qr_code: str
    backup_codes: list[str]


class MFAVerifyRequest(BaseModel):
    """Request to verify MFA code"""
    code: str


class MFADisableRequest(BaseModel):
    """Request to disable MFA"""
    password: str


# ============================================================================
# MFA Endpoints
# ============================================================================

@router.post("/enroll", response_model=MFAEnrollResponse)
async def enroll_mfa(
    current_user: Annotated[dict, Depends(get_current_user)]
):
    """
    Enroll current user in MFA.
    Returns QR code and backup codes for setup.
    """
    # Check if MFA is already enabled
    if current_user.get('mfa_enabled'):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is already enabled for this account"
        )
    
    # Generate secret and QR code
    secret = MFAService.generate_secret()
    qr_code = MFAService.generate_qr_code(
        username=current_user['email'],
        secret=secret
    )
    
    # Generate backup codes
    backup_codes = MFAService.generate_backup_codes(count=10)
    
    # Hash backup codes for storage
    hashed_codes = [MFAService.hash_backup_code(code) for code in backup_codes]
    
    # Temporarily store secret (will be final after verification)
    UserDB.update(current_user['id'], {
        'mfa_secret': secret,
        'backup_codes': json.dumps(hashed_codes)
    })
    
    return MFAEnrollResponse(
        secret=secret,
        qr_code=qr_code,
        backup_codes=backup_codes
    )


@router.post("/verify-enrollment")
async def verify_mfa_enrollment(
    request: MFAVerifyRequest,
    current_user: Annotated[dict, Depends(get_current_user)]
):
    """
    Verify MFA enrollment by confirming TOTP code.
    Enables MFA on successful verification.
    """
    # Get stored secret
    mfa_secret = current_user.get('mfa_secret')
    if not mfa_secret:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA enrollment not started. Call /mfa/enroll first."
        )
    
    # Verify code
    if not MFAService.verify_totp(mfa_secret, request.code):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid verification code"
        )
    
    # Enable MFA
    UserDB.update(current_user['id'], {
        'mfa_enabled': True
    })
    
    return {"message": "MFA enabled successfully"}


@router.post("/verify")
async def verify_mfa_code(
    request: MFAVerifyRequest,
    current_user: Annotated[dict, Depends(get_current_user)]
):
    """
    Verify MFA code during login or sensitive operations.
    """
    if not current_user.get('mfa_enabled'):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is not enabled for this account"
        )
    
    mfa_secret = current_user.get('mfa_secret')
    
    # Try TOTP verification first
    if MFAService.verify_totp(mfa_secret, request.code):
        return {"message": "MFA verification successful", "method": "totp"}
    
    # Try backup codes - handle both string and list types
    backup_codes_raw = current_user.get('backup_codes', '[]')
    if isinstance(backup_codes_raw, str):
        backup_codes = json.loads(backup_codes_raw)
    else:
        backup_codes = backup_codes_raw if backup_codes_raw else []
    for i, hashed_code in enumerate(backup_codes):
        if MFAService.verify_backup_code(request.code, hashed_code):
            # Remove used backup code
            backup_codes.pop(i)
            UserDB.update(current_user['id'], {
                'backup_codes': json.dumps(backup_codes)
            })
            return {
                "message": "MFA verification successful (backup code used)",
                "method": "backup_code",
                "remaining_codes": len(backup_codes)
            }
    
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid MFA code or backup code"
    )


@router.post("/disable")
async def disable_mfa(
    request: MFADisableRequest,
    current_user: Annotated[dict, Depends(get_current_user)]
):
    """
    Disable MFA for current user.
    Requires password confirmation.
    """
    from services.auth_service import verify_password
    
    if not current_user.get('mfa_enabled'):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is not enabled for this account"
        )
    
    # Verify password
    if not verify_password(request.password, current_user.get('hashed_password', '')):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect password"
        )
    
    # Disable MFA and clear secrets
    UserDB.update(current_user['id'], {
        'mfa_enabled': False,
        'mfa_secret': None,
        'backup_codes': json.dumps([])
    })
    
    return {"message": "MFA disabled successfully"}


@router.get("/status")
async def get_mfa_status(
    current_user: Annotated[dict, Depends(get_current_user)]
):
    """
    Get MFA status for current user.
    """
    backup_codes_raw = current_user.get('backup_codes', '[]')
    # Handle both string (from JSON) and list (from JSONB column)
    if isinstance(backup_codes_raw, str):
        backup_codes = json.loads(backup_codes_raw)
    else:
        backup_codes = backup_codes_raw if backup_codes_raw else []
    
    return {
        "mfa_enabled": current_user.get('mfa_enabled', False),
        "backup_codes_remaining": len(backup_codes) if current_user.get('mfa_enabled') else 0
    }


@router.post("/regenerate-backup-codes", response_model=dict)
async def regenerate_backup_codes(
    current_user: Annotated[dict, Depends(get_current_user)]
):
    """
    Regenerate backup codes for user.
    Returns new plaintext codes (user must save them).
    """
    if not current_user.get('mfa_enabled'):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is not enabled for this account"
        )
    
    # Generate new backup codes
    backup_codes = MFAService.generate_backup_codes(count=10)
    hashed_codes = [MFAService.hash_backup_code(code) for code in backup_codes]
    
    # Update database
    UserDB.update(current_user['id'], {
        'backup_codes': json.dumps(hashed_codes)
    })
    
    return {
        "message": "Backup codes regenerated",
        "backup_codes": backup_codes
    }


import logging
import json
from services.database import CRMLeadDB
from datetime import date, datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# JSON serializer for date objects
def json_serial(obj):
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")

if __name__ == "__main__":
    try:
        logger.info("--- LEAD FULL DIAGNOSTIC ---")
        leads = CRMLeadDB.get_all(limit=1000)
        logger.info(f"Found {len(leads)} leads in total.")
        
        for lead in leads:
            logger.info(f"Lead ID: {lead.get('id')}")
            logger.info(json.dumps(lead, default=json_serial, indent=2))
            
    except Exception as e:
        logger.error(f"Error: {e}")

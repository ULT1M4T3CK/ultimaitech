"""
Type-Specific Intent Detection
Detects user intent based on chatbot type for better query routing and response generation.
"""

import re
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class DetectedIntent:
    """Detected intent with confidence."""
    intent: str
    confidence: float
    entities: Dict[str, any] = None


class TypeIntentDetector:
    """
    Intent detector that adapts to chatbot type.
    Provides type-specific intent patterns and entity extraction.
    """
    
    # Type-specific intent patterns
    TYPE_INTENT_PATTERNS = {
        "Booking & Reservations": {
            "booking": {
                "patterns": [
                    r"\b(book|reserve|schedule|appointment|make a reservation)\b",
                    r"\b(available|availability|when can|what time)\b",
                    r"\b(check|checkout|complete booking)\b"
                ],
                "entities": ["date", "time", "duration", "service_type"]
            },
            "modify_booking": {
                "patterns": [
                    r"\b(change|modify|update|reschedule|cancel)\b.*\b(booking|reservation|appointment)\b",
                    r"\b(cancel|delete|remove)\b.*\b(booking|reservation)\b"
                ],
                "entities": ["booking_id", "date", "time"]
            },
            "pricing": {
                "patterns": [
                    r"\b(price|cost|rate|fee|pricing|how much)\b",
                    r"\b(cheap|expensive|affordable|budget)\b"
                ],
                "entities": ["service_type", "duration"]
            },
            "availability": {
                "patterns": [
                    r"\b(available|availability|free|open|when)\b",
                    r"\b(slot|time slot|appointment slot)\b"
                ],
                "entities": ["date", "time", "service_type"]
            }
        },
        "Sales": {
            "buying_intent": {
                "patterns": [
                    r"\b(buy|purchase|order|get|interested in|looking for)\b",
                    r"\b(price|pricing|cost|how much|quote)\b",
                    r"\b(demo|trial|try|test|sample)\b"
                ],
                "entities": ["product", "quantity", "budget"]
            },
            "comparison": {
                "patterns": [
                    r"\b(compare|difference|vs|versus|better|best)\b",
                    r"\b(which|what's the difference|pros and cons)\b"
                ],
                "entities": ["products"]
            },
            "qualification": {
                "patterns": [
                    r"\b(company|business|team|budget|requirements|use case)\b",
                    r"\b(how many|team size|employees)\b"
                ],
                "entities": ["company_size", "budget", "use_case"]
            },
            "objection": {
                "patterns": [
                    r"\b(expensive|cost|too much|cheaper|alternative)\b",
                    r"\b(not sure|maybe|later|think about it)\b"
                ],
                "entities": ["concern_type"]
            }
        },
        "Technical Support": {
            "troubleshooting": {
                "patterns": [
                    r"\b(error|issue|problem|bug|broken|not working|failed)\b",
                    r"\b(fix|solve|resolve|help with|how to fix)\b",
                    r"\b(error code|error message|exception)\b"
                ],
                "entities": ["error_type", "error_code", "component"]
            },
            "configuration": {
                "patterns": [
                    r"\b(setup|configure|install|settings|config)\b",
                    r"\b(how to|guide|tutorial|steps)\b"
                ],
                "entities": ["component", "configuration_type"]
            },
            "documentation": {
                "patterns": [
                    r"\b(documentation|docs|manual|guide|reference)\b",
                    r"\b(api|endpoint|method|function)\b"
                ],
                "entities": ["topic", "component"]
            },
            "status_check": {
                "patterns": [
                    r"\b(status|check|verify|is it|working)\b",
                    r"\b(up|down|online|offline|available)\b"
                ],
                "entities": ["service", "component"]
            }
        },
        "E-Commerce": {
            "product_search": {
                "patterns": [
                    r"\b(find|search|looking for|show me)\b.*\b(product|item)\b",
                    r"\b(what|which|do you have)\b.*\b(product|item)\b"
                ],
                "entities": ["product_type", "category", "features"]
            },
            "product_info": {
                "patterns": [
                    r"\b(details|specs|specifications|features|about)\b.*\b(product|item)\b",
                    r"\b(what is|tell me about|describe)\b"
                ],
                "entities": ["product_name", "attribute"]
            },
            "purchase": {
                "patterns": [
                    r"\b(buy|purchase|add to cart|checkout|order)\b",
                    r"\b(how to buy|where to buy|get it)\b"
                ],
                "entities": ["product", "quantity"]
            },
            "comparison": {
                "patterns": [
                    r"\b(compare|difference|vs|versus|better|best)\b",
                    r"\b(which|recommend|suggest)\b"
                ],
                "entities": ["products"]
            }
        },
        "Healthcare": {
            "appointment": {
                "patterns": [
                    r"\b(appointment|schedule|visit|consultation|checkup)\b",
                    r"\b(book|make an appointment|see a doctor)\b"
                ],
                "entities": ["provider_type", "date", "time"]
            },
            "symptom": {
                "patterns": [
                    r"\b(symptom|symptoms|feeling|pain|ache)\b",
                    r"\b(what|should|do I|concerned about)\b"
                ],
                "entities": ["symptom_type", "severity"]
            },
            "medication": {
                "patterns": [
                    r"\b(medication|medicine|prescription|drug|pill)\b",
                    r"\b(side effects|dosage|how to take)\b"
                ],
                "entities": ["medication_name", "question_type"]
            },
            "general_info": {
                "patterns": [
                    r"\b(information|about|what is|tell me)\b",
                    r"\b(condition|disease|treatment|diagnosis)\b"
                ],
                "entities": ["topic", "condition_type"]
            }
        },
        "Customer Service": {
            "faq": {
                "patterns": [
                    r"\b(what|how|when|where|why|can|do you)\b",
                    r"\b(question|help|information|tell me)\b"
                ],
                "entities": ["topic"]
            },
            "complaint": {
                "patterns": [
                    r"\b(problem|issue|complaint|dissatisfied|unhappy)\b",
                    r"\b(bad|wrong|broken|not working|poor)\b"
                ],
                "entities": ["issue_type", "severity"]
            },
            "order_status": {
                "patterns": [
                    r"\b(order|track|status|where is|when will)\b",
                    r"\b(shipping|delivery|arrive|dispatch)\b"
                ],
                "entities": ["order_id", "status_type"]
            },
            "refund": {
                "patterns": [
                    r"\b(refund|return|money back|cancel order)\b",
                    r"\b(not satisfied|want to return|get my money)\b"
                ],
                "entities": ["order_id", "reason"]
            }
        }
    }
    
    def __init__(self, chatbot_type: str = "General Purpose"):
        """
        Initialize intent detector for a specific chatbot type.
        
        Args:
            chatbot_type: The type of chatbot (e.g., "Booking & Reservations")
        """
        self.chatbot_type = chatbot_type
        self.intent_patterns = self.TYPE_INTENT_PATTERNS.get(chatbot_type, {})
    
    def detect_intent(self, query: str) -> DetectedIntent:
        """
        Detect intent from user query.
        
        Args:
            query: User query text
        
        Returns:
            DetectedIntent with intent name, confidence, and extracted entities
        """
        query_lower = query.lower()
        best_intent = None
        best_confidence = 0.0
        best_entities = {}
        
        # Check each intent pattern
        for intent_name, intent_config in self.intent_patterns.items():
            patterns = intent_config.get("patterns", [])
            confidence = 0.0
            matches = 0
            
            for pattern in patterns:
                if re.search(pattern, query_lower, re.IGNORECASE):
                    matches += 1
                    confidence += 0.3  # Each pattern match adds confidence
            
            # Normalize confidence (max 1.0)
            confidence = min(confidence, 1.0)
            
            # Extract entities if patterns matched
            entities = {}
            if matches > 0:
                entities = self._extract_entities(query, intent_config.get("entities", []))
            
            # Update best intent if this one is better
            if confidence > best_confidence:
                best_confidence = confidence
                best_intent = intent_name
                best_entities = entities
        
        # Default to general if no specific intent detected
        if not best_intent or best_confidence < 0.3:
            return DetectedIntent(
                intent="general",
                confidence=0.5,
                entities={}
            )
        
        return DetectedIntent(
            intent=best_intent,
            confidence=best_confidence,
            entities=best_entities
        )
    
    def _extract_entities(self, query: str, entity_types: List[str]) -> Dict[str, any]:
        """
        Extract entities from query based on entity types.
        
        This is a simplified entity extraction. For production, consider using
        NER models or more sophisticated extraction.
        """
        entities = {}
        query_lower = query.lower()
        
        # Date extraction (simplified)
        if "date" in entity_types:
            date_patterns = [
                r"\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})\b",  # MM/DD/YYYY
                r"\b(today|tomorrow|next week|next month)\b",
                r"\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b"
            ]
            for pattern in date_patterns:
                match = re.search(pattern, query_lower)
                if match:
                    entities["date"] = match.group(1)
                    break
        
        # Time extraction
        if "time" in entity_types:
            time_patterns = [
                r"\b(\d{1,2}:\d{2}\s*(am|pm)?)\b",  # HH:MM AM/PM
                r"\b(morning|afternoon|evening|night)\b"
            ]
            for pattern in time_patterns:
                match = re.search(pattern, query_lower)
                if match:
                    entities["time"] = match.group(1)
                    break
        
        # Product/service extraction (simplified - looks for quoted strings or common patterns)
        if "product" in entity_types or "service_type" in entity_types:
            # Look for quoted strings
            quoted = re.search(r'"([^"]+)"', query)
            if quoted:
                entities["product"] = quoted.group(1)
            # Look for "the X" or "a X" patterns
            else:
                product_match = re.search(r"\b(the|a|an)\s+([a-z]+(?:\s+[a-z]+)?)", query_lower)
                if product_match:
                    entities["product"] = product_match.group(2)
        
        return entities


# Factory function
def create_intent_detector(chatbot_type: str) -> TypeIntentDetector:
    """Create an intent detector for a specific chatbot type."""
    return TypeIntentDetector(chatbot_type)

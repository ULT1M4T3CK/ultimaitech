"""
Query Processor Module for VYBR!S
Handles query preprocessing, normalization, and expansion.
"""

import re
import unicodedata
from typing import Dict, List, Optional, Set
from dataclasses import dataclass


import difflib

@dataclass
class ProcessedQuery:
    """Result of query processing."""
    original_query: str
    normalized_query: str
    expanded_query: str
    corrections: List[str]  # List of corrections made
    expansions: List[str]   # List of expansions applied


class QueryProcessor:
    """
    Query preprocessing pipeline for improved retrieval.
    
    Features:
    - Text normalization (case, whitespace, unicode)
    - Abbreviation expansion
    - Spell checking and typo correction (Exact + Fuzzy)
    - Query rephrasing for ambiguous queries
    """
    
    # Default abbreviations (can be extended per-domain)
    DEFAULT_ABBREVIATIONS = {
        # Tech abbreviations
        'ai': 'artificial intelligence',
        'ml': 'machine learning',
        'nlp': 'natural language processing',
        'api': 'application programming interface',
        'ui': 'user interface',
        'ux': 'user experience',
        'db': 'database',
        'sql': 'structured query language',
        'seo': 'search engine optimization',
        'crm': 'customer relationship management',
        'saas': 'software as a service',
        'b2b': 'business to business',
        'b2c': 'business to consumer',
        'roi': 'return on investment',
        'kpi': 'key performance indicator',
        
        # Common abbreviations
        'info': 'information',
        'msg': 'message',
        'dept': 'department',
        'mgmt': 'management',
        'hr': 'human resources',
        'faq': 'frequently asked questions',
        'asap': 'as soon as possible',
        'etc': 'et cetera',
        'vs': 'versus',
    }
    
    # Common typos and their corrections
    COMMON_TYPOS = {
        'teh': 'the',
        'adn': 'and',
        'taht': 'that',
        'wiht': 'with',
        'hte': 'the',
        'yuo': 'you',
        'waht': 'what',
        'jsut': 'just',
        'dont': "don't",
        'cant': "can't",
        'wont': "won't",
        'whats': "what's",
        'hows': "how's",
        'thats': "that's",
        'youre': "you're",
        'theyre': "they're",
    }
    
    def __init__(
        self,
        abbreviations: Optional[Dict[str, str]] = None,
        enable_spell_check: bool = True,
        enable_expansion: bool = True,
        custom_typos: Optional[Dict[str, str]] = None,
        fuzzy_threshold: float = 0.6
    ):
        """
        Initialize the query processor.
        
        Args:
            abbreviations: Custom abbreviation mappings (merged with defaults)
            enable_spell_check: Whether to perform spell checking
            enable_expansion: Whether to expand abbreviations
            custom_typos: Custom typo corrections (merged with defaults)
            fuzzy_threshold: Similarity threshold for fuzzy matching (0.0-1.0)
        """
        self.abbreviations = {**self.DEFAULT_ABBREVIATIONS}
        if abbreviations:
            self.abbreviations.update(abbreviations)
        
        self.typos = {**self.COMMON_TYPOS}
        if custom_typos:
            self.typos.update(custom_typos)
        
        self.enable_spell_check = enable_spell_check
        self.enable_expansion = enable_expansion
        self.fuzzy_threshold = fuzzy_threshold
        
        # Compile patterns for efficiency
        self._word_pattern = re.compile(r'\b\w+\b')
        self._multi_space = re.compile(r'\s+')
        
        # Build vocabulary for fuzzy matching
        # We match against keys of abbreviations (e.g. 'ai') and explicit vocabulary if added
        self.fuzzy_vocabulary = set(self.abbreviations.keys())
        # Also add common english words if we had a dictionary, but here we focus on domain terms
    
    def process(self, query: str) -> ProcessedQuery:
        """
        Process a query through the full pipeline.
        
        Args:
            query: Raw user query
            
        Returns:
            ProcessedQuery with original, normalized, and expanded versions
        """
        if not query:
            return ProcessedQuery(
                original_query='',
                normalized_query='',
                expanded_query='',
                corrections=[],
                expansions=[]
            )
        
        corrections = []
        expansions = []
        
        # Step 1: Normalize
        normalized = self._normalize(query)
        
        # Step 2: Fix typos (Exact + Fuzzy)
        if self.enable_spell_check:
            normalized, typo_corrections = self._correct_typos(normalized)
            corrections.extend(typo_corrections)
        
        # Step 3: Expand abbreviations
        expanded = normalized
        if self.enable_expansion:
            expanded, abbrev_expansions = self._expand_abbreviations(normalized)
            expansions.extend(abbrev_expansions)
        
        return ProcessedQuery(
            original_query=query,
            normalized_query=normalized,
            expanded_query=expanded,
            corrections=corrections,
            expansions=expansions
        )
    
    def _normalize(self, text: str) -> str:
        """
        Normalize text for consistent processing.
        
        - Convert to lowercase
        - Normalize unicode characters
        - Collapse whitespace
        - Remove special characters (keep alphanumeric and basic punctuation)
        """
        # Unicode normalization (NFC form)
        text = unicodedata.normalize('NFC', text)
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove HTML entities if any
        text = re.sub(r'&\w+;', ' ', text)
        
        # Keep alphanumeric, spaces, and basic punctuation
        text = re.sub(r"[^\w\s\-'.?!]", ' ', text)
        
        # Collapse multiple spaces/newlines
        text = self._multi_space.sub(' ', text)
        
        return text.strip()
    
    def _correct_typos(self, text: str) -> tuple:
        """
        Fix common typos in the text using exact and fuzzy matching.
        
        Returns:
            Tuple of (corrected_text, list_of_corrections)
        """
        corrections = []
        words = text.split()
        corrected_words = []
        
        for word in words:
            # Strip punctuation for matching
            clean_word = word.strip(".,!?;:'\"")
            trailing = word[len(clean_word):] if len(word) > len(clean_word) else ""
            leading = word[:-len(clean_word)] if clean_word and word.startswith(word[:-len(clean_word)]) else ""
            
            # 1. Exact match in typos list
            if clean_word in self.typos:
                correction = self.typos[clean_word]
                corrections.append(f"{clean_word} -> {correction}")
                corrected_words.append(leading + correction + trailing)
                
            # 2. Fuzzy match against vocabulary if word is long enough
            elif len(clean_word) > 3: 
                match = self._fuzzy_match(clean_word)
                if match and match != clean_word:
                    corrections.append(f"{clean_word} -> {match} (fuzzy)")
                    corrected_words.append(leading + match + trailing)
                else:
                    corrected_words.append(word)
            else:
                corrected_words.append(word)
        
        return ' '.join(corrected_words), corrections
        
    def _fuzzy_match(self, word: str) -> Optional[str]:
        """Find close matches in vocabulary."""
        matches = difflib.get_close_matches(word, self.fuzzy_vocabulary, n=1, cutoff=self.fuzzy_threshold)
        return matches[0] if matches else None
    
    def _expand_abbreviations(self, text: str) -> tuple:
        """
        Expand known abbreviations in the text.
        
        The expansion is appended in parentheses to preserve the original
        while adding context for the embedding model.
        
        Returns:
            Tuple of (expanded_text, list_of_expansions)
        """
        expansions = []
        words = text.split()
        expanded_words = []
        
        for word in words:
            clean_word = word.strip(".,!?;:'\"").lower()
            
            if clean_word in self.abbreviations:
                expansion = self.abbreviations[clean_word]
                expansions.append(f"{clean_word} = {expansion}")
                # Keep original but add expansion for context
                expanded_words.append(f"{word} ({expansion})")
            else:
                expanded_words.append(word)
        
        return ' '.join(expanded_words), expansions
    
    def add_abbreviation(self, abbrev: str, expansion: str):
        """Add a custom abbreviation."""
        self.abbreviations[abbrev.lower()] = expansion.lower()
        self.fuzzy_vocabulary.add(abbrev.lower())
    
    def add_typo_correction(self, typo: str, correction: str):
        """Add a custom typo correction."""
        self.typos[typo.lower()] = correction


class DomainQueryProcessor(QueryProcessor):
    """
    Domain-specific query processor with additional capabilities.
    
    Extends the base processor with:
    - Synonym expansion
    - Query intent detection
    - Domain-specific abbreviations
    """
    
    DEFAULT_SYNONYMS = {
        # Pricing related
        'cost': ['price', 'pricing', 'fee', 'charge', 'rate', 'package', 'plan', 'tier'],
        'price': ['cost', 'pricing', 'fee', 'rate', 'package', 'plan'],
        'pricing': ['cost', 'price', 'rates', 'packages', 'plans', 'tiers'],
        'cheap': ['affordable', 'budget', 'economical', 'inexpensive', 'low cost'],
        
        # Services related
        'services': ['offerings', 'solutions', 'products', 'what you do', 'capabilities', 'features'],
        'offer': ['provide', 'have', 'services', 'solutions', 'do'],
        'do': ['offer', 'provide', 'work', 'specialize'],
        'product': ['service', 'solution', 'offering', 'feature'],
        
        # Action related
        'buy': ['purchase', 'order', 'acquire', 'get', 'subscribe'],
        'start': ['begin', 'get started', 'sign up', 'try', 'demo'],
        'demo': ['trial', 'try', 'test', 'sample', 'preview'],
        
        # Support related
        'help': ['support', 'assistance', 'aid', 'service', 'customer service'],
        'contact': ['reach', 'call', 'email', 'message', 'get in touch', 'speak'],
        
        # Quality related
        'fast': ['quick', 'rapid', 'speedy', 'swift', 'efficient'],
        'good': ['great', 'excellent', 'quality', 'best', 'top'],
        
        # Company related
        'about': ['company', 'who are', 'history', 'background', 'team'],
        'team': ['staff', 'people', 'employees', 'company'],
    }

    
    def __init__(
        self,
        synonyms: Optional[Dict[str, List[str]]] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        
        self.synonyms = {**self.DEFAULT_SYNONYMS}
        if synonyms:
            self.synonyms.update(synonyms)
            
        # Add synonym keys to fuzzy vocabulary
        # This allows matching "priccig" -> "pricing" because "pricing" is a key in synonyms
        self.fuzzy_vocabulary.update(self.synonyms.keys())
    
    def process_with_synonyms(self, query: str) -> ProcessedQuery:
        """
        Process query and add relevant synonyms for better retrieval.
        Enhanced with domain-specific knowledge and contextual expansion.
        """
        result = self.process(query)
        
        # Add synonym expansions
        words = result.normalized_query.split()
        synonym_additions = []
        
        for word in words:
            clean_word = word.strip(".,!?;:'\"").lower()
            if clean_word in self.synonyms:
                # Add first 2 synonyms to avoid over-expansion
                for syn in self.synonyms[clean_word][:2]:
                    if syn not in result.expanded_query:
                        synonym_additions.append(syn)
                        result.expansions.append(f"{clean_word} ~ {syn}")
        
        # Add domain-specific expansions based on query context
        # Detect domain keywords and expand accordingly
        domain_expansions = self._detect_domain_expansions(result.normalized_query)
        synonym_additions.extend(domain_expansions)
        
        if synonym_additions:
            result.expanded_query += " " + " ".join(synonym_additions)
        
        return result
    
    def _detect_domain_expansions(self, query: str) -> List[str]:
        """
        Detect domain-specific terms and add relevant expansions.
        
        This helps with queries like "pricing" -> also search for "cost", "plans", "packages"
        """
        expansions = []
        query_lower = query.lower()
        
        # Domain-specific patterns
        domain_patterns = {
            # Pricing domain
            r'\b(price|pricing|cost|fee)\b': ['package', 'plan', 'tier', 'subscription'],
            # Support domain
            r'\b(help|support|assistance)\b': ['contact', 'customer service', 'reach out'],
            # Product domain
            r'\b(what|do you|offer|provide)\b': ['service', 'solution', 'product', 'feature'],
            # Getting started domain
            r'\b(start|begin|get started|sign up)\b': ['trial', 'demo', 'try', 'onboard'],
        }
        
        for pattern, terms in domain_patterns.items():
            if re.search(pattern, query_lower):
                # Add 1-2 most relevant terms
                for term in terms[:2]:
                    if term not in query_lower:
                        expansions.append(term)
        
        return expansions


# Singleton instances
default_processor = QueryProcessor()
domain_processor = DomainQueryProcessor()

"""
Re-ranking Module for VYBR!S
Post-retrieval re-ranking to improve result quality before LLM context.
"""

import time
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
import logging

# Set up logging for metrics
logger = logging.getLogger(__name__)


@dataclass
class RerankedResult:
    """Result after re-ranking."""
    text: str
    original_score: float
    rerank_score: float
    final_score: float
    payload: Dict[str, Any]
    rank_change: int  # Positive = moved up, negative = moved down


@dataclass
class RetrievalMetrics:
    """Metrics for tracking retrieval quality."""
    query: str
    original_top_scores: List[float]
    reranked_top_scores: List[float]
    rerank_time_ms: float
    num_results: int
    avg_rank_change: float


class ChunkReranker:
    """
    Re-ranking layer for retrieved chunks.
    
    Features:
    - Cross-encoder style relevance scoring (simplified, no external model)
    - Term overlap analysis
    - Semantic coherence checking
    - Quality metrics logging
    """
    
    def __init__(
        self,
        top_k: int = 5,
        use_cross_encoder: bool = False,
        model_name: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"
    ):
        """
        Initialize the re-ranker.
        
        Args:
            top_k: Number of top results to return after re-ranking
            use_cross_encoder: Whether to use a cross-encoder model (slower but more accurate)
            model_name: Cross-encoder model name (if use_cross_encoder=True)
        """
        self.top_k = top_k
        self.use_cross_encoder = use_cross_encoder
        self.cross_encoder = None
        
        if use_cross_encoder:
            try:
                from sentence_transformers import CrossEncoder
                self.cross_encoder = CrossEncoder(model_name)
                logger.info(f"Loaded cross-encoder model: {model_name}")
            except ImportError:
                logger.warning("sentence-transformers not installed. Using fallback re-ranking.")
                self.use_cross_encoder = False
            except Exception as e:
                logger.warning(f"Failed to load cross-encoder: {e}. Using fallback re-ranking.")
                self.use_cross_encoder = False
    
    def rerank(
        self,
        query: str,
        chunks: List[Dict[str, Any]],
        return_metrics: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Re-rank chunks by relevance to query.
        
        Args:
            query: The user query
            chunks: Retrieved chunks with 'text' and 'score' fields
            return_metrics: Whether to return metrics along with results
            
        Returns:
            Top-k re-ranked chunks
        """
        if not chunks:
            return []
        
        start_time = time.time()
        
        # Store original rankings
        original_rankings = {i: chunk.get('score', 0) for i, chunk in enumerate(chunks)}
        
        # Re-rank based on method
        if self.use_cross_encoder and self.cross_encoder:
            reranked = self._rerank_with_cross_encoder(query, chunks)
        else:
            reranked = self._rerank_with_heuristics(query, chunks)
        
        # Calculate rank changes
        for i, chunk in enumerate(reranked):
            original_idx = next(
                (j for j, c in enumerate(chunks) if c['text'] == chunk['text']),
                i
            )
            chunk['rank_change'] = original_idx - i
        
        rerank_time = (time.time() - start_time) * 1000
        
        # Log metrics
        if return_metrics or logger.isEnabledFor(logging.INFO):
            metrics = self._compute_metrics(
                query, 
                chunks, 
                reranked[:self.top_k], 
                rerank_time
            )
            logger.info(f"Re-ranking metrics: {metrics}")
        
        return reranked[:self.top_k]
    
    def _rerank_with_cross_encoder(
        self,
        query: str,
        chunks: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Re-rank using cross-encoder model."""
        pairs = [(query, chunk['text']) for chunk in chunks]
        scores = self.cross_encoder.predict(pairs)
        
        # Combine with original scores
        for i, chunk in enumerate(chunks):
            chunk['rerank_score'] = float(scores[i])
            chunk['final_score'] = (
                0.4 * chunk.get('score', 0) +  # Original semantic score
                0.6 * chunk['rerank_score']     # Cross-encoder score
            )
        
        return sorted(chunks, key=lambda x: x['final_score'], reverse=True)
    
    def _rerank_with_heuristics(
        self,
        query: str,
        chunks: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Re-rank using heuristic scoring (no external model).
        
        Scoring based on:
        1. Term overlap (exact matches)
        2. Phrase matching (consecutive terms)
        3. Position bias (terms appearing early)
        4. Length normalization
        5. Q&A pair special handling (compare against original question)
        """
        query_terms = self._tokenize(query)
        query_phrases = self._extract_phrases(query, n=2)
        
        for chunk in chunks:
            payload = chunk.get('payload', {})
            is_qa_pair = payload.get('type') == 'qa'
            
            # For Q&A pairs, compare against the original question, not the answer
            if is_qa_pair and payload.get('original_question'):
                text = payload.get('original_question', '')
            else:
                text = chunk.get('text', '')
            
            text_terms = self._tokenize(text)
            text_lower = text.lower()
            
            # Term overlap score
            term_overlap = len(set(query_terms) & set(text_terms))
            term_score = term_overlap / max(len(query_terms), 1)
            
            # Phrase matching score
            phrase_matches = sum(1 for phrase in query_phrases if phrase in text_lower)
            phrase_score = phrase_matches / max(len(query_phrases), 1)
            
            # Position score (are query terms early in the text?)
            position_score = 0
            for term in query_terms:
                pos = text_lower.find(term)
                if pos >= 0:
                    # Score decreases with position
                    position_score += max(0, 1 - (pos / len(text)))
            position_score = position_score / max(len(query_terms), 1)
            
            # Length penalty (prefer medium-length chunks)
            ideal_length = 300
            length_diff = abs(len(text) - ideal_length)
            length_score = max(0, 1 - (length_diff / 500))
            
            # Compute final rerank score
            rerank_score = (
                0.4 * term_score +
                0.3 * phrase_score +
                0.2 * position_score +
                0.1 * length_score
            )
            
            chunk['rerank_score'] = rerank_score
            
            # Combine with original semantic score
            original_score = chunk.get('score', 0)
            chunk['final_score'] = (
                0.5 * original_score +
                0.5 * rerank_score
            )
        
        return sorted(chunks, key=lambda x: x['final_score'], reverse=True)
    
    def _tokenize(self, text: str) -> List[str]:
        """Simple word tokenization."""
        import re
        words = re.findall(r'\b\w{2,}\b', text.lower())
        stop_words = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been',
                      'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
                      'could', 'should', 'to', 'of', 'in', 'for', 'on', 'with',
                      'at', 'by', 'from', 'as', 'and', 'but', 'or', 'this', 'that'}
        return [w for w in words if w not in stop_words]
    
    def _extract_phrases(self, text: str, n: int = 2) -> List[str]:
        """Extract n-grams for phrase matching."""
        words = self._tokenize(text)
        if len(words) < n:
            return [' '.join(words)] if words else []
        
        return [' '.join(words[i:i+n]) for i in range(len(words) - n + 1)]
    
    def _compute_metrics(
        self,
        query: str,
        original_chunks: List[Dict[str, Any]],
        reranked_chunks: List[Dict[str, Any]],
        rerank_time_ms: float
    ) -> RetrievalMetrics:
        """Compute retrieval quality metrics."""
        original_scores = [c.get('score', 0) for c in original_chunks[:self.top_k]]
        reranked_scores = [c.get('final_score', 0) for c in reranked_chunks]
        
        # Calculate average rank change
        rank_changes = [c.get('rank_change', 0) for c in reranked_chunks]
        avg_rank_change = sum(abs(r) for r in rank_changes) / len(rank_changes) if rank_changes else 0
        
        return RetrievalMetrics(
            query=query[:100],  # Truncate for logging
            original_top_scores=original_scores,
            reranked_top_scores=reranked_scores,
            rerank_time_ms=rerank_time_ms,
            num_results=len(reranked_chunks),
            avg_rank_change=avg_rank_change
        )


class DiversityReranker:
    """
    Re-ranker that promotes diversity in results.
    
    Useful when you want to avoid returning chunks that are too similar
    to each other (e.g., from the same paragraph).
    """
    
    def __init__(self, similarity_threshold: float = 0.8):
        self.similarity_threshold = similarity_threshold
    
    def diversify(
        self,
        chunks: List[Dict[str, Any]],
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Select diverse chunks while maintaining relevance.
        
        Uses Maximal Marginal Relevance (MMR) approach.
        """
        if len(chunks) <= top_k:
            return chunks
        
        selected = [chunks[0]]  # Start with highest scored
        remaining = chunks[1:]
        
        while len(selected) < top_k and remaining:
            best_score = -1
            best_idx = -1
            
            for i, candidate in enumerate(remaining):
                # Check similarity with already selected
                max_similarity = max(
                    self._text_similarity(candidate['text'], s['text'])
                    for s in selected
                )
                
                if max_similarity < self.similarity_threshold:
                    # MMR score: relevance - lambda * max_similarity
                    mmr_score = candidate.get('score', 0) * (1 - max_similarity)
                    
                    if mmr_score > best_score:
                        best_score = mmr_score
                        best_idx = i
            
            if best_idx >= 0:
                selected.append(remaining.pop(best_idx))
            else:
                # No diverse candidates, take highest scored remaining
                selected.append(remaining.pop(0))
        
        return selected
    
    def _text_similarity(self, text1: str, text2: str) -> float:
        """Simple Jaccard similarity between texts."""
        import re
        words1 = set(re.findall(r'\b\w+\b', text1.lower()))
        words2 = set(re.findall(r'\b\w+\b', text2.lower()))
        
        if not words1 or not words2:
            return 0.0
        
        intersection = len(words1 & words2)
        union = len(words1 | words2)
        return intersection / union if union > 0 else 0.0


# Singleton instances
default_reranker = ChunkReranker(top_k=5)
diversity_reranker = DiversityReranker()

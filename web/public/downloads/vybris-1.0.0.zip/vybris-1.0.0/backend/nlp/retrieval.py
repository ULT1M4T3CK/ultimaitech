"""
Hybrid Search Retrieval Module for VYBR!S
Combines vector similarity search with keyword matching.
"""

import re
import math
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from collections import Counter


@dataclass
class SearchResult:
    """Result of hybrid search."""
    text: str
    score: float
    semantic_score: float
    keyword_score: float
    payload: Dict[str, Any]


class HybridRetriever:
    """
    Hybrid search that combines semantic (vector) similarity with keyword matching.
    
    Features:
    - Weighted scoring: configurable semantic vs keyword weights
    - BM25-style keyword scoring
    - Query preprocessing integration
    - Fallback to pure semantic when hybrid returns insufficient results
    """
    
    def __init__(
        self,
        nlp_service,
        semantic_weight: float = 0.7,
        keyword_weight: float = 0.3,
        min_results: int = 3,
        bm25_k1: float = 1.5,
        bm25_b: float = 0.75
    ):
        """
        Initialize the hybrid retriever.
        
        Args:
            nlp_service: The NLP service with vector search capabilities
            semantic_weight: Weight for semantic similarity (0-1)
            keyword_weight: Weight for keyword matching (0-1)
            min_results: Minimum results before falling back to pure semantic
            bm25_k1: BM25 term frequency saturation parameter
            bm25_b: BM25 length normalization parameter
        """
        self.nlp_service = nlp_service
        self.semantic_weight = semantic_weight
        self.keyword_weight = keyword_weight
        self.min_results = min_results
        self.bm25_k1 = bm25_k1
        self.bm25_b = bm25_b
        
        # Precompile patterns
        self._word_pattern = re.compile(r'\b\w{2,}\b')
        self._stop_words = {
            'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
            'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
            'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'dare',
            'ought', 'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by',
            'from', 'as', 'into', 'through', 'during', 'before', 'after', 'above',
            'below', 'between', 'under', 'again', 'further', 'then', 'once', 'here',
            'there', 'when', 'where', 'why', 'how', 'all', 'each', 'few', 'more',
            'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own',
            'same', 'so', 'than', 'too', 'very', 'just', 'and', 'but', 'if', 'or',
            'because', 'until', 'while', 'this', 'that', 'these', 'those', 'i',
            'me', 'my', 'we', 'our', 'you', 'your', 'he', 'him', 'his', 'she',
            'her', 'it', 'its', 'they', 'them', 'their', 'what', 'which', 'who'
        }
    
    def search(
        self,
        chatbot_id: str,
        query: str,
        limit: int = 10,
        semantic_limit: int = 20
    ) -> List[SearchResult]:
        """
        Execute hybrid search combining semantic and keyword matching.
        
        Args:
            chatbot_id: ID of the chatbot to search
            query: Search query
            limit: Maximum results to return
            semantic_limit: How many semantic results to fetch for re-scoring
            
        Returns:
            List of SearchResult sorted by combined score
        """
        # Get more semantic results than needed for keyword re-ranking
        semantic_results = self.nlp_service.search(
            chatbot_id, 
            query, 
            limit=semantic_limit
        )
        
        if not semantic_results:
            return []
        
        # Extract query terms for keyword matching
        query_terms = self._extract_terms(query)
        
        if not query_terms:
            # No meaningful keywords, return pure semantic results
            return [
                SearchResult(
                    text=r['text'],
                    score=r['score'],
                    semantic_score=r['score'],
                    keyword_score=0.0,
                    payload=r.get('payload', {})
                )
                for r in semantic_results[:limit]
            ]
        
        # Calculate keyword scores for all results
        scored_results = []
        
        # For Q&A pairs, use the original question for keyword matching
        def get_text_for_matching(r: Dict[str, Any]) -> str:
            payload = r.get('payload', {})
            if payload.get('type') == 'qa' and payload.get('original_question'):
                return payload['original_question']
            return r['text']
        
        match_texts = [get_text_for_matching(r) for r in semantic_results]
        doc_lengths = [len(t.split()) for t in match_texts]
        avg_doc_length = sum(doc_lengths) / len(doc_lengths) if doc_lengths else 100
        
        for i, result in enumerate(semantic_results):
            keyword_score = self._compute_bm25_score(
                query_terms,
                match_texts[i],
                doc_lengths[i],
                avg_doc_length
            )
            
            # Normalize keyword score (BM25 scores can be > 1)
            normalized_keyword_score = min(keyword_score / 10.0, 1.0)
            
            # Combine scores
            combined_score = (
                self.semantic_weight * result['score'] +
                self.keyword_weight * normalized_keyword_score
            )
            
            scored_results.append(SearchResult(
                text=result['text'],
                score=combined_score,
                semantic_score=result['score'],
                keyword_score=normalized_keyword_score,
                payload=result.get('payload', {})
            ))
        
        # Sort by combined score
        scored_results.sort(key=lambda x: x.score, reverse=True)
        
        # Check if we have enough high-quality results
        high_quality_results = [r for r in scored_results if r.score >= 0.3]
        
        if len(high_quality_results) < self.min_results:
            # Fall back to pure semantic ranking
            scored_results.sort(key=lambda x: x.semantic_score, reverse=True)
        
        return scored_results[:limit]
    
    def _extract_terms(self, text: str) -> List[str]:
        """Extract meaningful terms from text, removing stop words."""
        words = self._word_pattern.findall(text.lower())
        return [w for w in words if w not in self._stop_words and len(w) > 2]
    
    def _compute_bm25_score(
        self,
        query_terms: List[str],
        document: str,
        doc_length: int,
        avg_doc_length: float
    ) -> float:
        """
        Compute BM25-style keyword match score.
        
        BM25 formula:
        score = sum(IDF * (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl/avgdl)))
        
        Since we don't have corpus-wide IDF, we use a simplified version
        that focuses on term frequency with length normalization.
        """
        doc_terms = self._extract_terms(document)
        if not doc_terms:
            return 0.0
        
        doc_term_counts = Counter(doc_terms)
        total_score = 0.0
        
        for term in query_terms:
            if term in doc_term_counts:
                tf = doc_term_counts[term]
                
                # Simplified BM25 scoring
                numerator = tf * (self.bm25_k1 + 1)
                denominator = tf + self.bm25_k1 * (
                    1 - self.bm25_b + 
                    self.bm25_b * (doc_length / avg_doc_length)
                )
                
                # Add a small IDF-like boost for less common terms
                term_score = numerator / denominator
                total_score += term_score
        
        return total_score
    
    def search_with_fallback(
        self,
        chatbot_id: str,
        query: str,
        limit: int = 10
    ) -> List[SearchResult]:
        """
        Search with automatic fallback strategies.
        
        If hybrid search returns poor results, tries:
        1. Pure semantic search
        2. Search with query expansion
        """
        results = self.search(chatbot_id, query, limit)
        
        # Check result quality
        if results and results[0].score >= 0.5:
            return results
        
        # Try pure semantic search
        semantic_results = self.nlp_service.search(chatbot_id, query, limit=limit)
        
        if semantic_results and semantic_results[0]['score'] > (results[0].score if results else 0):
            return [
                SearchResult(
                    text=r['text'],
                    score=r['score'],
                    semantic_score=r['score'],
                    keyword_score=0.0,
                    payload=r.get('payload', {})
                )
                for r in semantic_results
            ]
        
        return results


class KeywordSearcher:
    """
    Simple keyword-only search for debugging and comparison.
    """
    
    def __init__(self):
        self._word_pattern = re.compile(r'\b\w{2,}\b')
    
    def search(
        self,
        documents: List[Dict[str, Any]],
        query: str,
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Simple TF-based keyword search.
        
        Args:
            documents: List of documents with 'text' field
            query: Search query
            limit: Max results
            
        Returns:
            Documents sorted by keyword relevance
        """
        query_terms = set(self._word_pattern.findall(query.lower()))
        if not query_terms:
            return documents[:limit]
        
        scored = []
        for doc in documents:
            doc_terms = set(self._word_pattern.findall(doc.get('text', '').lower()))
            
            # Jaccard similarity
            intersection = len(query_terms & doc_terms)
            union = len(query_terms | doc_terms)
            score = intersection / union if union > 0 else 0
            
            scored.append((score, doc))
        
        scored.sort(key=lambda x: x[0], reverse=True)
        return [doc for score, doc in scored[:limit] if score > 0]

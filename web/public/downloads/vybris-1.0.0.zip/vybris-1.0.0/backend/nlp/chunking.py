"""
Semantic Chunking Module for VYBR!S
Replaces fixed-size chunking with intelligent boundary detection.
"""

import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass


@dataclass
class ChunkResult:
    """Result of chunking operation."""
    text: str
    start_pos: int
    end_pos: int
    metadata: Dict[str, Any]
    chunk_type: str  # 'paragraph', 'heading_section', 'fallback'


class SemanticChunker:
    """
    Semantic text chunker that respects natural content boundaries.
    
    Features:
    - Paragraph boundary detection
    - Heading preservation (keeps headings with their content)
    - Configurable chunk size and overlap
    - Fallback to character-based splitting for edge cases
    """
    
    def __init__(
        self, 
        max_chunk_size: int = 500,
        min_chunk_size: int = 100,
        overlap: int = 50,
        respect_sentences: bool = True
    ):
        """
        Initialize the semantic chunker.
        
        Args:
            max_chunk_size: Maximum characters per chunk
            min_chunk_size: Minimum characters per chunk (smaller chunks are merged)
            overlap: Character overlap between chunks for context preservation
            respect_sentences: If True, avoid breaking mid-sentence
        """
        self.max_chunk_size = max_chunk_size
        self.min_chunk_size = min_chunk_size
        self.overlap = overlap
        self.respect_sentences = respect_sentences
        
        # Patterns for boundary detection
        self.heading_patterns = [
            r'^#{1,6}\s+.+$',           # Markdown headings
            r'^[A-Z][A-Z\s]{3,}$',       # ALL CAPS lines (likely headings)
            r'^[\d]+\.\s+[A-Z]',         # Numbered sections
            r'^[•\-\*]\s+',              # Bullet points
        ]
        
        self.sentence_end_pattern = re.compile(r'[.!?]\s+')
        self.paragraph_pattern = re.compile(r'\n\s*\n')
    
    def chunk_text(
        self, 
        text: str, 
        metadata: Optional[Dict[str, Any]] = None
    ) -> List[ChunkResult]:
        """
        Split text into semantic chunks preserving natural boundaries.
        
        Args:
            text: The text to chunk
            metadata: Optional metadata to attach to all chunks
            
        Returns:
            List of ChunkResult objects
        """
        if not text or not text.strip():
            return []
        
        # Clean and normalize text
        text = self._normalize_text(text)
        
        # If text is small enough, return as single chunk
        if len(text) <= self.max_chunk_size:
            return [ChunkResult(
                text=text.strip(),
                start_pos=0,
                end_pos=len(text),
                metadata=metadata or {},
                chunk_type='single'
            )]
        
        # First, try to split by paragraphs
        paragraphs = self._split_paragraphs(text)
        
        # Process paragraphs into appropriately sized chunks
        chunks = self._process_paragraphs(paragraphs, metadata or {})
        
        # Add overlap between chunks
        if self.overlap > 0 and len(chunks) > 1:
            chunks = self._add_overlap(chunks, text)
        
        return chunks
    
    def _normalize_text(self, text: str) -> str:
        """Normalize text by cleaning up whitespace while preserving structure."""
        # Replace multiple spaces with single space (but preserve newlines)
        text = re.sub(r'[ \t]+', ' ', text)
        # Normalize multiple newlines to double newline (paragraph break)
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()
    
    def _split_paragraphs(self, text: str) -> List[Tuple[str, int]]:
        """
        Split text into paragraphs, returning (text, start_position) tuples.
        """
        paragraphs = []
        current_pos = 0
        
        for match in self.paragraph_pattern.finditer(text):
            para_text = text[current_pos:match.start()].strip()
            if para_text:
                paragraphs.append((para_text, current_pos))
            current_pos = match.end()
        
        # Don't forget the last paragraph
        remaining = text[current_pos:].strip()
        if remaining:
            paragraphs.append((remaining, current_pos))
        
        # If no paragraphs found, treat entire text as one paragraph
        if not paragraphs:
            paragraphs = [(text.strip(), 0)]
        
        return paragraphs
    
    def _process_paragraphs(
        self, 
        paragraphs: List[Tuple[str, int]], 
        metadata: Dict[str, Any]
    ) -> List[ChunkResult]:
        """Process paragraphs into appropriately sized chunks."""
        chunks = []
        current_chunk_text = ""
        current_chunk_start = 0
        
        for para_text, para_start in paragraphs:
            # Check if this paragraph is a heading
            is_heading = self._is_heading(para_text)
            
            # If adding this paragraph would exceed max size
            if current_chunk_text and len(current_chunk_text) + len(para_text) + 2 > self.max_chunk_size:
                # Save current chunk
                if len(current_chunk_text) >= self.min_chunk_size:
                    chunks.append(ChunkResult(
                        text=current_chunk_text.strip(),
                        start_pos=current_chunk_start,
                        end_pos=current_chunk_start + len(current_chunk_text),
                        metadata=metadata.copy(),
                        chunk_type='paragraph'
                    ))
                    current_chunk_text = ""
                    current_chunk_start = para_start
            
            # If single paragraph is too large, split it
            if len(para_text) > self.max_chunk_size:
                # First save any accumulated text
                if current_chunk_text:
                    chunks.append(ChunkResult(
                        text=current_chunk_text.strip(),
                        start_pos=current_chunk_start,
                        end_pos=current_chunk_start + len(current_chunk_text),
                        metadata=metadata.copy(),
                        chunk_type='paragraph'
                    ))
                    current_chunk_text = ""
                
                # Split large paragraph by sentences
                sub_chunks = self._split_large_paragraph(para_text, para_start, metadata)
                chunks.extend(sub_chunks)
                current_chunk_start = para_start + len(para_text)
            else:
                # Add paragraph to current chunk
                if not current_chunk_text:
                    current_chunk_start = para_start
                    current_chunk_text = para_text
                else:
                    current_chunk_text += "\n\n" + para_text
        
        # Don't forget the last chunk
        if current_chunk_text and len(current_chunk_text) >= self.min_chunk_size:
            chunks.append(ChunkResult(
                text=current_chunk_text.strip(),
                start_pos=current_chunk_start,
                end_pos=current_chunk_start + len(current_chunk_text),
                metadata=metadata.copy(),
                chunk_type='paragraph'
            ))
        elif current_chunk_text and chunks:
            # Merge small final chunk with previous
            last_chunk = chunks[-1]
            chunks[-1] = ChunkResult(
                text=last_chunk.text + "\n\n" + current_chunk_text.strip(),
                start_pos=last_chunk.start_pos,
                end_pos=current_chunk_start + len(current_chunk_text),
                metadata=last_chunk.metadata,
                chunk_type=last_chunk.chunk_type
            )
        
        return chunks
    
    def _split_large_paragraph(
        self, 
        text: str, 
        start_pos: int, 
        metadata: Dict[str, Any]
    ) -> List[ChunkResult]:
        """Split a large paragraph by sentences."""
        chunks = []
        
        if self.respect_sentences:
            # Split by sentence boundaries
            sentences = self.sentence_end_pattern.split(text)
            current_chunk = ""
            current_start = start_pos
            
            for i, sentence in enumerate(sentences):
                sentence = sentence.strip()
                if not sentence:
                    continue
                
                # Restore sentence ending if not last
                if i < len(sentences) - 1:
                    # Find the original ending
                    match = self.sentence_end_pattern.search(text[len(current_chunk):])
                    if match:
                        sentence += match.group()[0]  # Add back the punctuation
                
                if len(current_chunk) + len(sentence) + 1 > self.max_chunk_size:
                    if current_chunk:
                        chunks.append(ChunkResult(
                            text=current_chunk.strip(),
                            start_pos=current_start,
                            end_pos=current_start + len(current_chunk),
                            metadata=metadata.copy(),
                            chunk_type='sentence'
                        ))
                        current_start = current_start + len(current_chunk) + 1
                        current_chunk = sentence
                    else:
                        # Single sentence too long, force split
                        chunks.append(ChunkResult(
                            text=sentence[:self.max_chunk_size].strip(),
                            start_pos=current_start,
                            end_pos=current_start + self.max_chunk_size,
                            metadata=metadata.copy(),
                            chunk_type='fallback'
                        ))
                        current_start += self.max_chunk_size
                else:
                    current_chunk += (" " if current_chunk else "") + sentence
            
            if current_chunk:
                chunks.append(ChunkResult(
                    text=current_chunk.strip(),
                    start_pos=current_start,
                    end_pos=current_start + len(current_chunk),
                    metadata=metadata.copy(),
                    chunk_type='sentence'
                ))
        else:
            # Simple character-based split
            for i in range(0, len(text), self.max_chunk_size - self.overlap):
                chunk_text = text[i:i + self.max_chunk_size]
                chunks.append(ChunkResult(
                    text=chunk_text.strip(),
                    start_pos=start_pos + i,
                    end_pos=start_pos + i + len(chunk_text),
                    metadata=metadata.copy(),
                    chunk_type='fallback'
                ))
        
        return chunks
    
    def _is_heading(self, text: str) -> bool:
        """Check if text appears to be a heading."""
        text = text.strip()
        if len(text) > 100:  # Headings are usually short
            return False
        
        for pattern in self.heading_patterns:
            if re.match(pattern, text, re.MULTILINE):
                return True
        return False
    
    def _add_overlap(self, chunks: List[ChunkResult], original_text: str) -> List[ChunkResult]:
        """Add overlap context from previous chunks."""
        if len(chunks) <= 1 or self.overlap <= 0:
            return chunks
        
        overlapped_chunks = [chunks[0]]  # First chunk stays the same
        
        for i in range(1, len(chunks)):
            prev_chunk = chunks[i - 1]
            curr_chunk = chunks[i]
            
            # Get overlap text from end of previous chunk
            overlap_text = prev_chunk.text[-self.overlap:] if len(prev_chunk.text) > self.overlap else prev_chunk.text
            
            # Find a good break point (end of sentence or word)
            break_pos = overlap_text.rfind('. ')
            if break_pos == -1:
                break_pos = overlap_text.rfind(' ')
            if break_pos > 0:
                overlap_text = overlap_text[break_pos + 1:].strip()
            
            # Prepend overlap to current chunk
            if overlap_text:
                new_text = f"...{overlap_text} {curr_chunk.text}"
                overlapped_chunks.append(ChunkResult(
                    text=new_text,
                    start_pos=curr_chunk.start_pos - len(overlap_text),
                    end_pos=curr_chunk.end_pos,
                    metadata=curr_chunk.metadata,
                    chunk_type=curr_chunk.chunk_type
                ))
            else:
                overlapped_chunks.append(curr_chunk)
        
        return overlapped_chunks


# Convenience function for backward compatibility
def semantic_chunk_text(
    text: str, 
    max_chunk_size: int = 500,
    overlap: int = 50,
    metadata: Optional[Dict[str, Any]] = None
) -> List[str]:
    """
    Convenience function that returns just the chunk texts.
    
    This provides backward compatibility with the old simple_chunk_text function.
    """
    chunker = SemanticChunker(max_chunk_size=max_chunk_size, overlap=overlap)
    results = chunker.chunk_text(text, metadata)
    return [chunk.text for chunk in results]


# Singleton instance with default settings
default_chunker = SemanticChunker()

"""
Background job tasks (run by RQ workers).

These run in a separate worker process - avoid heavy imports at module level.
"""

import os
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


def run_training_job(chatbot_id: str, job_id: str) -> dict:
    """
    Train a chatbot using its stored scraped content. Runs in RQ worker.
    """
    from services.database import ChatbotDB, ScrapedContentDB, TrainingJobDB, KnowledgeDB
    from services.cache_service import response_cache
    from services.nlp_service import nlp_service
    from services.content_enhancer import content_enhancer
    from routers.nlp.training import simple_chunk_text

    response_cache.invalidate(chatbot_id)

    bot = ChatbotDB.get_by_id(chatbot_id)
    if not bot:
        TrainingJobDB.update(job_id, {"status": "failed", "error": "Chatbot not found"})
        return {"error": "Chatbot not found"}

    content = ScrapedContentDB.get(chatbot_id)
    if not content or not content.get("pages"):
        TrainingJobDB.update(
            job_id,
            {"status": "failed", "error": "No training data found. Please scrape a website first."},
        )
        return {"error": "No training data found"}

    USE_CONTENT_ENHANCEMENT = os.getenv("USE_CONTENT_ENHANCEMENT", "true").lower() == "true"
    USE_SEMANTIC_CHUNKING = os.getenv("USE_SEMANTIC_CHUNKING", "true").lower() == "true"

    count = 0
    knowledge_items_created = 0
    seen_urls = set()

    try:
        existing_items = KnowledgeDB.get_by_chatbot(chatbot_id)
        for item in existing_items:
            if item.get("source_type") == "scraped":
                KnowledgeDB.delete(item["id"])
    except Exception as e:
        logger.warning(f"Failed to clear existing scraped items: {e}")

    for page in content["pages"]:
        url = page.get("url", "")
        title = page.get("title", "Untitled")

        if url and url in seen_urls:
            continue
        seen_urls.add(url)

        chunks_count = 0
        if USE_CONTENT_ENHANCEMENT:
            try:
                enhanced = content_enhancer.enhance_page_content(
                    html="",
                    url=url,
                    title=title,
                    description=page.get("description", ""),
                    headings=page.get("headings", []),
                    raw_content=page.get("content", ""),
                )
                training_chunks = content_enhancer.prepare_for_training(
                    enhanced, use_semantic_chunking=USE_SEMANTIC_CHUNKING
                )
                for chunk_data in training_chunks:
                    nlp_service.train_text(
                        chatbot_id,
                        chunk_data["text"],
                        chunk_data.get("metadata", {}),
                    )
                    count += 1
                chunks_count = len(training_chunks)
            except Exception as enhance_err:
                logger.warning(f"Content enhancement failed for {url}, using fallback: {enhance_err}")
                raw_text = f"{title}. {page.get('content', '')}"
                chunks = simple_chunk_text(raw_text)
                for i, chunk in enumerate(chunks):
                    meta = {"url": url, "title": title, "chunk_index": i}
                    nlp_service.train_text(chatbot_id, chunk, meta)
                    count += 1
                chunks_count = len(chunks)
        else:
            raw_text = f"{title}. {page.get('content', '')}"
            chunks = simple_chunk_text(raw_text)
            for i, chunk in enumerate(chunks):
                meta = {"url": url, "title": title, "chunk_index": i}
                nlp_service.train_text(chatbot_id, chunk, meta)
                count += 1
            chunks_count = len(chunks)

        try:
            KnowledgeDB.create({
                "chatbot_id": chatbot_id,
                "source_type": "scraped",
                "title": title,
                "content": (page["content"] or "")[:5000],
                "url": url,
                "word_count": len((page.get("content") or "").split()),
                "metadata": {"source_url": content.get("source_url", ""), "chunk_count": chunks_count},
            })
            knowledge_items_created += 1
        except Exception as kb_err:
            logger.warning(f"Failed to save to knowledge_items: {kb_err}")

    if bot["status"] == "Draft":
        ChatbotDB.update(
            chatbot_id,
            {"status": "Active", "updatedAt": datetime.utcnow().isoformat() + "Z"},
        )

    TrainingJobDB.update(
        job_id,
        {
            "status": "completed",
            "completed_at": datetime.utcnow().isoformat() + "Z",
            "pages_processed": len(content["pages"]),
        },
    )

    return {
        "chatbot_id": chatbot_id,
        "pages_processed": len(content["pages"]),
        "chunks_created": count,
        "knowledge_items_created": knowledge_items_created,
    }

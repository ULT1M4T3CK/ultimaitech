"""
Background job queue (RQ) for long-running tasks.

Phase 3: Move training and other heavy work off request handlers.
"""

from jobs.queue import get_queue, enqueue_training

__all__ = ["get_queue", "enqueue_training"]

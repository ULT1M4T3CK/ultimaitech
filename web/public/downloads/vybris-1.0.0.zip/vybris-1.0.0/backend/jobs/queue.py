"""
RQ Queue setup for VYBR!S background jobs.

Uses the same Redis instance as cache, auth, and rate limiting.
Queue name: vybris_training (avoids collisions when sharing Redis).
"""

import os
import logging
from typing import Optional

logger = logging.getLogger(__name__)

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
QUEUE_NAME = os.getenv("RQ_QUEUE_NAME", "vybris_training")

_queue = None


def get_redis_connection():
    """Get Redis connection for RQ (decode_responses=False for RQ compatibility)."""
    import redis
    return redis.from_url(REDIS_URL, decode_responses=False)


def get_queue():
    """Get or create the RQ queue. Returns None if Redis is unavailable."""
    global _queue
    if _queue is not None:
        return _queue
    try:
        from rq import Queue
        conn = get_redis_connection()
        conn.ping()
        _queue = Queue(QUEUE_NAME, connection=conn, default_timeout=3600)  # 1h timeout
        logger.info(f"RQ queue '{QUEUE_NAME}' connected at {REDIS_URL}")
        return _queue
    except Exception as e:
        logger.warning(f"RQ queue unavailable: {e}")
        return None


def enqueue_training(chatbot_id: str, job_id: str) -> Optional[str]:
    """
    Enqueue a training job. Returns RQ job_id if enqueued, else None.
    """
    queue = get_queue()
    if not queue:
        return None
    try:
        from jobs.tasks import run_training_job
        rq_job = queue.enqueue(run_training_job, chatbot_id, job_id)
        return rq_job.id if rq_job else None
    except Exception as e:
        logger.error(f"Failed to enqueue training job: {e}")
        return None

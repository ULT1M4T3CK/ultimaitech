"""
Input Validation Middleware
Provides secure base models with automatic input sanitization to prevent XSS and injection attacks.
"""

from pydantic import BaseModel, validator
import html
import re
from typing import Any, Optional


class SecureBaseModel(BaseModel):
    """
    Base model with automatic input sanitization.
    
    Features:
    - HTML escaping for XSS prevention
    - Null byte removal
    - Length limits
    - SQL injection pattern detection (for logging)
    """
    
    class Config:
        # Allow extra fields but validate them
        extra = "forbid"
    
    @validator('*', pre=True)
    def sanitize_strings(cls, v, field):
        """Sanitize string inputs to prevent XSS and injection attacks"""
        if isinstance(v, str):
            # Remove null bytes (important for PostgreSQL and security)
            v = v.replace('\x00', '')
            
            # HTML escape for XSS prevention
            # Note: This escapes all HTML, which is safe but may affect intended formatting
            # For fields that need HTML (like rich text), override this validator
            v = html.escape(v)
            
            # Limit length (configurable per field via Field(max_length))
            # Default max is 10000 characters
            max_length = getattr(field, 'max_length', 10000)
            if len(v) > max_length:
                raise ValueError(f"Input too long. Maximum length is {max_length} characters")
        
        return v
    
    @validator('*', pre=True)
    def detect_sql_injection_patterns(cls, v):
        """Detect common SQL injection patterns (for logging/monitoring)"""
        if isinstance(v, str):
            # Common SQL injection patterns
            sql_patterns = [
                r"(\bOR\b|\bAND\b)\s+\d+\s*=\s*\d+",  # OR 1=1, AND 1=1
                r"(\bUNION\b|\bSELECT\b).*(\bFROM\b|\bWHERE\b)",  # UNION SELECT
                r"(\bDROP\b|\bDELETE\b|\bINSERT\b|\bUPDATE\b)\s+\bTABLE\b",  # DROP TABLE
                r"('|(\\')|(;)|(\\;)|(--)|(\\--))",  # Quote and comment patterns
            ]
            
            for pattern in sql_patterns:
                if re.search(pattern, v, re.IGNORECASE):
                    # Log suspicious input but don't block (could be false positive)
                    import logging
                    logger = logging.getLogger(__name__)
                    logger.warning(f"Potential SQL injection pattern detected in input: {v[:100]}")
                    # Note: We don't block because parameterized queries protect us
                    break
        
        return v


class SanitizedString(str):
    """String type that automatically sanitizes input"""
    
    @classmethod
    def __get_validators__(cls):
        yield cls.validate
    
    @classmethod
    def validate(cls, v):
        if not isinstance(v, str):
            raise TypeError('String required')
        
        # Remove null bytes
        v = v.replace('\x00', '')
        
        # HTML escape
        v = html.escape(v)
        
        return cls(v)


def sanitize_for_database(text: str, max_length: Optional[int] = None) -> str:
    """
    Sanitize text for safe database storage.
    
    Args:
        text: Text to sanitize
        max_length: Optional maximum length
        
    Returns:
        Sanitized text
    """
    if not text:
        return ""
    
    # Remove null bytes
    text = text.replace('\x00', '')
    
    # Truncate if needed
    if max_length and len(text) > max_length:
        text = text[:max_length]
    
    return text


def sanitize_for_html(text: str) -> str:
    """
    Sanitize text for safe HTML display (prevents XSS).
    
    Args:
        text: Text to sanitize
        
    Returns:
        HTML-escaped text
    """
    if not text:
        return ""
    
    return html.escape(text)

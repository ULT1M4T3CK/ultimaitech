"""
Security Headers Middleware
Adds security headers to all responses for better security posture
"""

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
import logging
import os

logger = logging.getLogger(__name__)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Middleware to add security headers to all responses"""
    
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        
        # Add security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        
        # HSTS (HTTP Strict Transport Security) - only for HTTPS
        if request.url.scheme == "https":
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains; preload"
        
        # Content Security Policy (CSP) - stricter in production
        is_production = os.getenv("ENVIRONMENT", "development").lower() == "production"
        # Allow LiveChat ingest / dev tools (e.g. 127.0.0.1:7243) via env, e.g. CSP_CONNECT_SRC_EXTRA="http://127.0.0.1:7243 http://127.0.0.1"
        connect_extra = os.getenv("CSP_CONNECT_SRC_EXTRA", "").strip()
        connect_src_base = "'self' https://api.perplexity.ai"
        if connect_extra:
            connect_src_base = f"{connect_src_base} {connect_extra}"
        if is_production:
            csp = (
                "default-src 'self'; "
                "script-src 'self'; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: https:; "
                "font-src 'self' data: https://r2cdn.perplexity.ai; "
                f"connect-src {connect_src_base}; "
                "frame-ancestors 'none';"
            )
        else:
            # Development mode: Allow localhost connections for local development and LiveChat ingest
            dev_connect = "http://localhost:5000 http://localhost:5002 http://127.0.0.1 http://127.0.0.1:7243"
            if connect_extra:
                dev_connect = f"{dev_connect} {connect_extra}"
            csp = (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "  # unsafe-eval needed for React dev
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: https:; "
                "font-src 'self' data: https://r2cdn.perplexity.ai; "
                f"connect-src 'self' {dev_connect} https://api.perplexity.ai; "
                "frame-ancestors 'none';"
            )
        response.headers["Content-Security-Policy"] = csp
        
        # Permissions Policy (formerly Feature Policy)
        response.headers["Permissions-Policy"] = (
            "geolocation=(), "
            "microphone=(), "
            "camera=(), "
            "payment=(), "
            "usb=()"
        )
        
        return response

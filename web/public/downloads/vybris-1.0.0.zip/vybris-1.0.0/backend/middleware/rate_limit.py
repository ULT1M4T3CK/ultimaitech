"""
Rate Limiting & DDoS Protection for VYBR!S
In-memory rate limiting with exponential backoff.
"""

import time
import os
from collections import defaultdict
from functools import wraps
from typing import Dict, Optional, Callable, Set
from fastapi import HTTPException, Request, Response, status
from fastapi.responses import JSONResponse
import logging

logger = logging.getLogger(__name__)

# Redis connection for distributed rate limiting
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
ENVIRONMENT = os.getenv("ENVIRONMENT", "development").lower()
redis_client = None

try:
    import redis
    redis_client = redis.from_url(
        REDIS_URL,
        decode_responses=True,
        socket_timeout=2.0,
        socket_connect_timeout=2.0
    )
    redis_client.ping()
    logger.info(f"Redis connected for distributed rate limiting at {REDIS_URL}")
except Exception as e:
    # In production, Redis is required for rate limiting
    if ENVIRONMENT in ("production", "prod", "staging"):
        from shared.errors import ConfigurationError
        raise ConfigurationError(
            f"Redis is REQUIRED for rate limiting in {ENVIRONMENT} environment. "
            f"Failed to connect: {e}. Set REDIS_URL environment variable."
        )
    logger.warning(f"Redis not available for distributed rate limiting, using in-memory only: {e}")
    redis_client = None


class RateLimiter:
    """
    Rate limiter with Redis backend support and sliding window.
    
    Features:
    - Distributed rate limiting via Redis (with in-memory fallback)
    - Sliding window algorithm (smoother limits)
    - User-based and IP-based tracking
    - Exponential backoff for repeat offenders
    - Whitelist/blacklist support
    """
    
    def __init__(self, use_redis: bool = True):
        # IP/User -> list of request timestamps (for sliding window)
        self.requests: Dict[str, list] = defaultdict(list)
        # IP/User -> violation count
        self.violations: Dict[str, int] = defaultdict(int)
        # IP/User -> backoff expiry timestamp
        self.backoff_until: Dict[str, float] = {}
        # Cleanup interval tracking
        self._last_cleanup = time.time()
        self._cleanup_interval = 300  # 5 minutes
        
        # Whitelist and blacklist
        self.whitelist: Set[str] = set()
        self.blacklist: Set[str] = set()
        
        # Redis support
        self._use_redis = use_redis and redis_client is not None
        
        # Load whitelist/blacklist from environment
        whitelist_env = os.getenv("RATE_LIMIT_WHITELIST", "")
        if whitelist_env:
            self.whitelist.update(ip.strip() for ip in whitelist_env.split(",") if ip.strip())
        
        blacklist_env = os.getenv("RATE_LIMIT_BLACKLIST", "")
        if blacklist_env:
            self.blacklist.update(ip.strip() for ip in blacklist_env.split(",") if ip.strip())
    
    def is_allowed(
        self, 
        identifier: str, 
        limit: int, 
        window_seconds: int = 60
    ) -> tuple[bool, int, int]:
        """
        Check if a request is allowed under the rate limit using sliding window.
        
        Args:
            identifier: Client identifier (IP or user ID)
            limit: Maximum requests allowed in the window
            window_seconds: Time window in seconds
            
        Returns:
            Tuple of (is_allowed, remaining_requests, reset_time)
        """
        # Check whitelist
        if identifier in self.whitelist:
            return True, limit, int(time.time() + window_seconds)
        
        # Check blacklist
        if identifier in self.blacklist:
            return False, 0, int(time.time() + window_seconds)
        
        now = time.time()
        
        # Periodic cleanup
        if now - self._last_cleanup > self._cleanup_interval:
            self._cleanup_old_entries(now)
        
        # Check if identifier is in backoff period
        if identifier in self.backoff_until and now < self.backoff_until[identifier]:
            retry_after = int(self.backoff_until[identifier] - now)
            return False, 0, int(self.backoff_until[identifier])
        
        # Try Redis first (if enabled)
        if self._use_redis:
            try:
                return self._check_redis_sliding_window(identifier, limit, window_seconds, now)
            except Exception as e:
                logger.warning(f"Redis rate limit check failed: {e}, falling back to in-memory")
        
        # In-memory sliding window
        return self._check_memory_sliding_window(identifier, limit, window_seconds, now)
    
    def _check_redis_sliding_window(
        self,
        identifier: str,
        limit: int,
        window_seconds: int,
        now: float
    ) -> tuple[bool, int, int]:
        """Check rate limit using Redis with sliding window."""
        from shared.redis_keys import rate_limit_key
        redis_key = rate_limit_key(identifier)
        
        # Use sorted set for sliding window
        # Remove old entries (outside window)
        redis_client.zremrangebyscore(redis_key, 0, now - window_seconds)
        
        # Count current requests in window
        current_count = redis_client.zcard(redis_key)
        
        if current_count >= limit:
            # Rate limited
            self.violations[identifier] += 1
            backoff_seconds = self.get_backoff_seconds(identifier)
            self.backoff_until[identifier] = now + backoff_seconds
            logger.warning(f"Rate limit exceeded for {identifier}. Backoff: {backoff_seconds}s")
            return False, 0, int(now + window_seconds)
        
        # Add current request
        redis_client.zadd(redis_key, {str(now): now})
        redis_client.expire(redis_key, window_seconds)
        
        # Get oldest request to calculate reset time
        oldest = redis_client.zrange(redis_key, 0, 0, withscores=True)
        reset_time = int(oldest[0][1] + window_seconds) if oldest else int(now + window_seconds)
        
        remaining = limit - current_count - 1
        return True, remaining, reset_time
    
    def _check_memory_sliding_window(
        self,
        identifier: str,
        limit: int,
        window_seconds: int,
        now: float
    ) -> tuple[bool, int, int]:
        """Check rate limit using in-memory sliding window."""
        # Clean old entries (sliding window)
        self.requests[identifier] = [
            t for t in self.requests[identifier]
            if now - t < window_seconds
        ]
        
        # Check limit
        current_count = len(self.requests[identifier])
        
        if current_count >= limit:
            # Rate limited
            self.violations[identifier] += 1
            backoff_seconds = self.get_backoff_seconds(identifier)
            self.backoff_until[identifier] = now + backoff_seconds
            logger.warning(f"Rate limit exceeded for {identifier}. Backoff: {backoff_seconds}s")
            return False, 0, int(now + window_seconds)
        
        # Record this request
        self.requests[identifier].append(now)
        
        # Calculate reset time (oldest request + window)
        if self.requests[identifier]:
            oldest = min(self.requests[identifier])
            reset_time = int(oldest + window_seconds)
        else:
            reset_time = int(now + window_seconds)
        
        remaining = limit - current_count - 1
        return True, remaining, reset_time
    
    def get_backoff_seconds(self, ip: str) -> int:
        """
        Get exponential backoff time in seconds for an IP.
        
        Backoff increases exponentially with violations:
        - 1st violation: 2 seconds
        - 2nd violation: 4 seconds
        - 3rd violation: 8 seconds
        - Max: 3600 seconds (1 hour)
        """
        violations = self.violations.get(ip, 0)
        backoff = min(2 ** violations, 3600)
        return backoff
    
    def get_retry_after(self, identifier: str) -> int:
        """Get seconds until the identifier can retry."""
        if identifier in self.backoff_until:
            remaining = self.backoff_until[identifier] - time.time()
            return max(0, int(remaining))
        return 0
    
    def reset_violations(self, identifier: str):
        """Reset violation count for an identifier (e.g., after successful auth)."""
        if identifier in self.violations:
            del self.violations[identifier]
        if identifier in self.backoff_until:
            del self.backoff_until[identifier]
        
        # Also reset in Redis if enabled
        if self._use_redis:
            try:
                from shared.redis_keys import rate_limit_key
                redis_client.delete(rate_limit_key(identifier))
            except Exception as e:
                logger.warning(f"Failed to reset Redis rate limit: {e}")
    
    def add_to_whitelist(self, identifier: str):
        """Add an identifier to the whitelist (bypasses rate limiting)."""
        self.whitelist.add(identifier)
        logger.info(f"Added {identifier} to rate limit whitelist")
    
    def remove_from_whitelist(self, identifier: str):
        """Remove an identifier from the whitelist."""
        self.whitelist.discard(identifier)
        logger.info(f"Removed {identifier} from rate limit whitelist")
    
    def add_to_blacklist(self, identifier: str):
        """Add an identifier to the blacklist (always rate limited)."""
        self.blacklist.add(identifier)
        logger.info(f"Added {identifier} to rate limit blacklist")
    
    def remove_from_blacklist(self, identifier: str):
        """Remove an identifier from the blacklist."""
        self.blacklist.discard(identifier)
        logger.info(f"Removed {identifier} from rate limit blacklist")
    
    def _cleanup_old_entries(self, now: float):
        """Cleanup old tracking data to prevent memory buildup."""
        self._last_cleanup = now
        
        # Remove entries older than 1 hour
        cutoff = now - 3600
        
        # Cleanup requests
        ips_to_remove = []
        for ip, timestamps in self.requests.items():
            self.requests[ip] = [t for t in timestamps if t > cutoff]
            if not self.requests[ip]:
                ips_to_remove.append(ip)
        
        for ip in ips_to_remove:
            del self.requests[ip]
        
        # Cleanup expired backoffs
        expired_backoffs = [
            ip for ip, expiry in self.backoff_until.items() 
            if now > expiry + 3600  # Keep record for 1 hour after expiry
        ]
        for ip in expired_backoffs:
            del self.backoff_until[ip]
            # Also clear violations for these IPs
            if ip in self.violations:
                del self.violations[ip]


# Singleton rate limiter instance
rate_limiter = RateLimiter()


def rate_limit(
    limit: int = 10,
    window: int = 60,
    authenticated_limit: int = 100,
    key_func: Optional[Callable[[Request], str]] = None
):
    """
    Decorator for rate limiting FastAPI endpoints.
    
    Usage:
        @router.post("/endpoint")
        @rate_limit(limit=10, window=60)
        async def my_endpoint(request: Request):
            ...
    
    Args:
        limit: Requests per window for unauthenticated users
        window: Time window in seconds
        authenticated_limit: Requests per window for authenticated users
        key_func: Optional function to extract rate limit key (default: IP)
    """
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Find the Request object in args or kwargs
            request = None
            response_obj = None
            for arg in args:
                if isinstance(arg, Request):
                    request = arg
                    break
                if isinstance(arg, Response):
                    response_obj = arg
            
            # If not found in args, search all kwargs values
            if request is None:
                for value in kwargs.values():
                    if isinstance(value, Request):
                        request = value
                        break
            if response_obj is None:
                for value in kwargs.values():
                    if isinstance(value, Response):
                        response_obj = value
                        break
            
            if request is None:
                # Can't rate limit without request, proceed anyway
                logger.debug("Rate limit skipped: No Request object found")
                return await func(*args, **kwargs)
            
            # Get client identifier (IP or user ID)
            if key_func:
                key = key_func(request)
            else:
                # Default to IP address, but prefer user ID if authenticated
                key = "unknown"
                if hasattr(request.state, 'user') and request.state.user:
                    # Use user ID for authenticated users (better tracking)
                    key = f"user:{request.state.user.get('id', 'unknown')}"
                else:
                    # Use IP for unauthenticated users
                    key = request.client.host if request.client else "unknown"
            
            # Check if user is authenticated (more lenient limits)
            is_authenticated = hasattr(request.state, 'user') and request.state.user
            current_limit = authenticated_limit if is_authenticated else limit
            
            # Check rate limit (sliding window)
            is_allowed, remaining, reset_time = rate_limiter.is_allowed(key, current_limit, window)
            
            if not is_allowed:
                retry_after = rate_limiter.get_retry_after(key)
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail=f"Rate limit exceeded. Try again in {retry_after} seconds.",
                    headers={
                        "Retry-After": str(retry_after),
                        "X-RateLimit-Limit": str(current_limit),
                        "X-RateLimit-Remaining": "0",
                        "X-RateLimit-Reset": str(reset_time)
                    }
                )
            
            # Execute the function
            result = await func(*args, **kwargs)
            
            # Try to add headers to response
            # Check if result is a Response object
            if isinstance(result, Response):
                result.headers["X-RateLimit-Limit"] = str(current_limit)
                result.headers["X-RateLimit-Remaining"] = str(remaining)
                result.headers["X-RateLimit-Reset"] = str(reset_time)
            elif isinstance(result, dict):
                # For dict responses, wrap in JSONResponse to add headers
                response = JSONResponse(
                    content=result,
                    headers={
                        "X-RateLimit-Limit": str(current_limit),
                        "X-RateLimit-Remaining": str(remaining),
                        "X-RateLimit-Reset": str(reset_time)
                    }
                )
                # Preserve any cookies set on the original Response (e.g. login)
                if response_obj is not None:
                    for key, value in response_obj.raw_headers:
                        if key.lower() == b"set-cookie":
                            response.headers.append("set-cookie", value.decode())
                return response
            else:
                # For other response types, try to add headers via request state
                # This will be picked up by middleware if needed
                if hasattr(request.state, 'rate_limit_headers'):
                    request.state.rate_limit_headers = {
                        "X-RateLimit-Limit": str(current_limit),
                        "X-RateLimit-Remaining": str(remaining),
                        "X-RateLimit-Reset": str(reset_time)
                    }
            
            return result
        return wrapper
    return decorator


class RateLimitMiddleware:
    """
    ASGI middleware for global rate limiting.
    
    Use this for server-wide rate limiting, not endpoint-specific.
    """
    
    def __init__(
        self, 
        app, 
        limit: int = 100, 
        window: int = 60,
        exclude_paths: list = None
    ):
        self.app = app
        self.limit = limit
        self.window = window
        self.exclude_paths = exclude_paths or ["/health", "/metrics"]
    
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        
        # Check if path is excluded
        path = scope.get("path", "")
        if any(path.startswith(exc) for exc in self.exclude_paths):
            await self.app(scope, receive, send)
            return
        
        # Get client IP
        client = scope.get("client")
        ip = client[0] if client else "unknown"
        
        # Check rate limit
        if not rate_limiter.is_allowed(ip, self.limit, self.window):
            retry_after = rate_limiter.get_retry_after(ip)
            
            # Send 429 response
            await send({
                "type": "http.response.start",
                "status": 429,
                "headers": [
                    [b"content-type", b"application/json"],
                    [b"retry-after", str(retry_after).encode()]
                ]
            })
            await send({
                "type": "http.response.body",
                "body": b'{"detail":"Rate limit exceeded"}'
            })
            return
        
        await self.app(scope, receive, send)

"""
Request Timeout Middleware
Adds timeout protection to prevent long-running requests from blocking the server.
"""

import os
import asyncio
import logging
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from fastapi import status

logger = logging.getLogger(__name__)

# Default timeout (30 seconds)
DEFAULT_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT_SECONDS", "30"))

# Endpoints that should be excluded from timeout (long-running operations)
EXCLUDED_PATHS = [
    "/api/v1/scraper/",
    "/v1/scraper/",
    "/api/v1/training/",
    "/v1/training/",
    "/api/v1/academy/upload",
    "/v1/academy/upload",
    "/health",
    "/metrics"
]


class TimeoutMiddleware(BaseHTTPMiddleware):
    """
    Middleware that adds timeout protection to requests.
    
    Long-running endpoints (training, scraping) are excluded from timeout.
    """
    
    def __init__(self, app, timeout: int = DEFAULT_TIMEOUT, excluded_paths: list = None):
        super().__init__(app)
        self.timeout = timeout
        self.excluded_paths = excluded_paths or EXCLUDED_PATHS
    
    def _is_excluded(self, path: str) -> bool:
        """Check if path should be excluded from timeout."""
        return any(path.startswith(excluded) for excluded in self.excluded_paths)
    
    async def dispatch(self, request: Request, call_next):
        # Check if this endpoint should be excluded
        if self._is_excluded(request.url.path):
            return await call_next(request)
        
        try:
            # Run request with timeout
            response = await asyncio.wait_for(
                call_next(request),
                timeout=self.timeout
            )
            return response
        except asyncio.TimeoutError:
            logger.warning(
                f"Request timeout after {self.timeout}s: {request.method} {request.url.path}",
                extra={
                    "path": request.url.path,
                    "method": request.method,
                    "timeout": self.timeout
                }
            )
            return JSONResponse(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                content={
                    "detail": f"Request timed out after {self.timeout} seconds",
                    "timeout_seconds": self.timeout
                }
            )

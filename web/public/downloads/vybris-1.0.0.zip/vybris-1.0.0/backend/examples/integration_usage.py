"""
Example: Using VYBR!S Integrations in NLP Processing
This demonstrates how to integrate third-party platforms into chatbot responses
"""

from services.database import IntegrationDB, ChatbotDB
from services.integrations import IntegrationManager, IntegrationError
import logging

logger = logging.getLogger(__name__)


class IntegrationActionHandler:
    """
    Handler for integration-based actions in chatbot responses
    Use this in your NLP processing pipeline to trigger integrations
    """
    
    @staticmethod
    def handle_create_ticket(chatbot_id: str, user_data: dict, message: str) -> dict:
        """
        Create a support ticket when user requests help
        
        Args:
            chatbot_id: ID of the chatbot
            user_data: Dict with user information (name, email, etc.)
            message: The user's message/issue description
            
        Returns:
            dict: Result with ticket information
        """
        try:
            # Get ticketing integrations (Zendesk or Freshdesk)
            zendesk_integrations = IntegrationDB.get_by_type(chatbot_id, 'zendesk')
            freshdesk_integrations = IntegrationDB.get_by_type(chatbot_id, 'freshdesk')
            
            integrations = zendesk_integrations or freshdesk_integrations
            
            if not integrations:
                return {
                    'success': False,
                    'message': 'No ticketing system configured'
                }
            
            integration = integrations[0]  # Use first active integration
            
            if integration['status'] != 'active':
                return {
                    'success': False,
                    'message': 'Ticketing integration is not active'
                }
            
            # Create integration instance
            ticketing = IntegrationManager.get_integration(
                integration['integration_type'],
                integration['config']
            )
            
            # Create ticket
            ticket_data = {
                'subject': f"Support Request from {user_data.get('name', 'Chatbot User')}",
                'description': message,
                'requester_name': user_data.get('name', 'Unknown'),
                'requester_email': user_data.get('email', 'noreply@example.com'),
                'priority': 'normal',
                'tags': ['chatbot', 'automated']
            }
            
            if integration['integration_type'] == 'zendesk':
                result = ticketing.create_ticket(ticket_data)
            else:  # freshdesk
                ticket_data.pop('requester_name', None)  # Freshdesk doesn't have this field
                ticket_data['email'] = user_data.get('email', 'noreply@example.com')
                ticket_data['priority'] = 1  # Freshdesk uses numeric priority
                ticket_data['status'] = 2  # Open
                result = ticketing.create_ticket(ticket_data)
            
            # Update last sync time
            IntegrationDB.update_sync_time(integration['id'])
            
            logger.info(f"Ticket created: {result['id']} for chatbot {chatbot_id}")
            
            return {
                'success': True,
                'ticket_id': result['id'],
                'message': f"Support ticket #{result['id']} has been created. Our team will contact you shortly."
            }
            
        except IntegrationError as e:
            logger.error(f"Integration error creating ticket: {e}")
            return {
                'success': False,
                'message': 'Failed to create support ticket. Please try again later.'
            }
    
    @staticmethod
    def handle_create_lead(chatbot_id: str, lead_data: dict) -> dict:
        """
        Create a lead in CRM when user shows interest
        
        Args:
            chatbot_id: ID of the chatbot
            lead_data: Dict with lead information
            
        Returns:
            dict: Result with lead information
        """
        try:
            # Get CRM integrations (Salesforce or HubSpot)
            salesforce_integrations = IntegrationDB.get_by_type(chatbot_id, 'salesforce')
            hubspot_integrations = IntegrationDB.get_by_type(chatbot_id, 'hubspot')
            
            integrations = salesforce_integrations or hubspot_integrations
            
            if not integrations:
                return {
                    'success': False,
                    'message': 'No CRM configured'
                }
            
            integration = integrations[0]
            
            if integration['status'] != 'active':
                return {
                    'success': False,
                    'message': 'CRM integration is not active'
                }
            
            # Create integration instance
            crm = IntegrationManager.get_integration(
                integration['integration_type'],
                integration['config']
            )
            
            # Create lead/contact
            if integration['integration_type'] == 'salesforce':
                # Salesforce lead format
                sf_lead = {
                    'FirstName': lead_data.get('first_name', ''),
                    'LastName': lead_data.get('last_name', 'Unknown'),
                    'Company': lead_data.get('company', 'Unknown'),
                    'Email': lead_data.get('email', ''),
                    'Phone': lead_data.get('phone', ''),
                    'LeadSource': 'Chatbot',
                    'Description': lead_data.get('notes', '')
                }
                result = crm.create_lead(sf_lead)
            else:  # hubspot
                # HubSpot contact format
                hs_contact = {
                    'firstname': lead_data.get('first_name', ''),
                    'lastname': lead_data.get('last_name', ''),
                    'email': lead_data.get('email', ''),
                    'phone': lead_data.get('phone', ''),
                    'company': lead_data.get('company', ''),
                    'hs_lead_status': 'NEW',
                    'lifecyclestage': 'lead'
                }
                result = crm.create_contact(hs_contact)
            
            # Update last sync time
            IntegrationDB.update_sync_time(integration['id'])
            
            logger.info(f"Lead created: {result['id']} for chatbot {chatbot_id}")
            
            return {
                'success': True,
                'lead_id': result['id'],
                'message': 'Thank you! Your information has been recorded.'
            }
            
        except IntegrationError as e:
            logger.error(f"Integration error creating lead: {e}")
            return {
                'success': False,
                'message': 'Failed to save your information. Please try again.'
            }
    
    @staticmethod
    def handle_send_notification(chatbot_id: str, channel: str, message: str) -> dict:
        """
        Send notification to messaging platform (Slack, Telegram, etc.)
        
        Args:
            chatbot_id: ID of the chatbot
            channel: Target channel/chat ID
            message: Message to send
            
        Returns:
            dict: Result of the notification
        """
        try:
            # Get messaging integrations
            slack_integrations = IntegrationDB.get_by_type(chatbot_id, 'slack')
            telegram_integrations = IntegrationDB.get_by_type(chatbot_id, 'telegram')
            
            integrations = slack_integrations or telegram_integrations
            
            if not integrations:
                return {
                    'success': False,
                    'message': 'No messaging platform configured'
                }
            
            integration = integrations[0]
            
            if integration['status'] != 'active':
                return {
                    'success': False,
                    'message': 'Messaging integration is not active'
                }
            
            # Create integration instance
            messenger = IntegrationManager.get_integration(
                integration['integration_type'],
                integration['config']
            )
            
            # Send message
            if integration['integration_type'] == 'slack':
                result = messenger.send_message(channel, message)
            else:  # telegram
                result = messenger.send_message(channel, message)
            
            # Update last sync time
            IntegrationDB.update_sync_time(integration['id'])
            
            logger.info(f"Notification sent via {integration['integration_type']} for chatbot {chatbot_id}")
            
            return {
                'success': True,
                'message_id': result.get('message_id') or result.get('ts'),
                'message': 'Notification sent successfully'
            }
            
        except IntegrationError as e:
            logger.error(f"Integration error sending notification: {e}")
            return {
                'success': False,
                'message': 'Failed to send notification'
            }


# Example usage in NLP processing
def process_chatbot_message_with_integrations(chatbot_id: str, user_message: str, user_data: dict):
    """
    Example of how to use integrations in chatbot message processing
    """
    
    # Example 1: User wants to create a support ticket
    if 'help' in user_message.lower() or 'support' in user_message.lower():
        ticket_result = IntegrationActionHandler.handle_create_ticket(
            chatbot_id=chatbot_id,
            user_data={
                'name': user_data.get('name', 'Anonymous'),
                'email': user_data.get('email', 'noreply@example.com')
            },
            message=user_message
        )
        
        if ticket_result['success']:
            return f"✅ {ticket_result['message']}"
        else:
            return "I understand you need help. Let me connect you with our support team."
    
    # Example 2: User shows interest (wants to be contacted)
    elif 'contact me' in user_message.lower() or 'interested' in user_message.lower():
        lead_result = IntegrationActionHandler.handle_create_lead(
            chatbot_id=chatbot_id,
            lead_data={
                'first_name': user_data.get('first_name', ''),
                'last_name': user_data.get('last_name', ''),
                'email': user_data.get('email', ''),
                'phone': user_data.get('phone', ''),
                'company': user_data.get('company', ''),
                'notes': user_message
            }
        )
        
        if lead_result['success']:
            return f"✅ {lead_result['message']}"
        else:
            return "Thank you for your interest! Someone from our team will reach out soon."
    
    # Example 3: Send notification to internal team
    elif 'urgent' in user_message.lower() or 'vip' in user_data.get('tags', []):
        notification_result = IntegrationActionHandler.handle_send_notification(
            chatbot_id=chatbot_id,
            channel='#customer-alerts',  # or Telegram chat ID
            message=f"🚨 Urgent message from {user_data.get('name', 'User')}: {user_message}"
        )
    
    # Continue with normal NLP processing
    return "How else can I help you today?"


# Example: Automated workflow trigger
def trigger_welcome_sequence(chatbot_id: str, new_user: dict):
    """
    Example of triggering automated workflows with integrations
    """
    
    # 1. Create contact in CRM
    lead_result = IntegrationActionHandler.handle_create_lead(
        chatbot_id=chatbot_id,
        lead_data=new_user
    )
    
    # 2. Send welcome email (if email integration configured)
    # ... implementation here
    
    # 3. Notify sales team in Slack
    IntegrationActionHandler.handle_send_notification(
        chatbot_id=chatbot_id,
        channel='#new-leads',
        message=f"🎉 New contact: {new_user.get('name')} ({new_user.get('email')})"
    )
    
    return {
        'workflow': 'welcome_sequence',
        'completed': True,
        'lead_id': lead_result.get('lead_id')
    }

#!/usr/bin/env python3
"""
Chat Worker - consumes Redis Stream and processes messages via chat orchestrator.
Run as: python -m worker.chat_worker
Or: cd backend && python worker/chat_worker.py
"""

import asyncio
import os
import sys
import logging

# Add parent to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

CONSUMER_ID = os.getenv("CHAT_WORKER_CONSUMER_ID", f"worker-{os.getpid()}")
BLOCK_MS = int(os.getenv("CHAT_WORKER_BLOCK_MS", "5000"))


async def process_one(msg_id: str, data: dict) -> None:
    """Process a single message."""
    from services.message_broker import acknowledge_message, set_result, CONSUMER_GROUP
    from application.chat.chat_orchestrator import chat_orchestrator
    from services.database import ChatbotDB

    chatbot_id = data.get("chatbot_id")
    session_id = data.get("session_id")
    text = data.get("text", "")
    job_id = data.get("job_id")
    metadata = data.get("metadata") or {}

    if not chatbot_id or not text:
        logger.warning(f"Skipping invalid message {msg_id}")
        acknowledge_message(CONSUMER_GROUP, msg_id)
        return

    bot = ChatbotDB.get_by_id(chatbot_id)
    if not bot:
        result = {"intent": "error", "confidence": 0, "response": "Chatbot not found.", "sources": []}
    else:
        try:
            from starlette.datastructures import Headers
            from starlette.datastructures import URL

            class MockRequest:
                def __init__(self):
                    self.headers = Headers({})
                    self.scope = {"path": "/api/v1/nlp/process"}
                @property
                def url(self):
                    return URL("/api/v1/nlp/process")
            req = MockRequest()
            orch_result = await chat_orchestrator.process(
                text=text,
                chatbot_id=chatbot_id,
                session_id=session_id or None,
                context=metadata,
                auto_request_live_chat=bool(metadata.get("auto_request_live_chat")),
                bot=bot,
                req=req,
            )
            result = {
                "intent": orch_result.intent,
                "confidence": orch_result.confidence,
                "response": orch_result.response,
                "sources": orch_result.sources or [],
                "explanation": getattr(orch_result, "explanation", None),
                "live_chat_request_id": getattr(orch_result, "live_chat_request_id", None),
                "live_chat_status": getattr(orch_result, "live_chat_status", None),
            }
        except Exception as e:
            logger.exception(f"Orchestrator failed for {msg_id}: {e}")
            result = {
                "intent": "error",
                "confidence": 0,
                "response": "An error occurred. Please try again.",
                "sources": [],
                "error": str(e),
            }

    if job_id:
        set_result(job_id, result)
    acknowledge_message(CONSUMER_GROUP, msg_id)


async def run_worker():
    """Main worker loop."""
    from services.message_broker import consume_messages, CONSUMER_GROUP

    logger.info(f"Chat worker started. Consumer={CONSUMER_ID}")
    while True:
        try:
            messages = consume_messages(
                group=CONSUMER_GROUP,
                consumer=CONSUMER_ID,
                block_ms=BLOCK_MS,
            )
            for msg_id, data in messages:
                await process_one(msg_id, data)
        except KeyboardInterrupt:
            logger.info("Worker shutting down")
            break
        except Exception as e:
            logger.exception(f"Worker error: {e}")
            await asyncio.sleep(5)


def main():
    asyncio.run(run_worker())


if __name__ == "__main__":
    main()

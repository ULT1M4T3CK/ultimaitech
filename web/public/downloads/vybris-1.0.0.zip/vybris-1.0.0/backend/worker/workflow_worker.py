#!/usr/bin/env python3
"""
Workflow Worker - consumes workflow events from Redis Stream and executes matching workflows.
Run as: python -m worker.workflow_worker
Or: cd backend && python worker/workflow_worker.py
"""

import asyncio
import os
import sys
import logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

CONSUMER_ID = os.getenv("WORKFLOW_WORKER_CONSUMER_ID", f"wf-worker-{os.getpid()}")
BLOCK_MS = int(os.getenv("WORKFLOW_WORKER_BLOCK_MS", "5000"))


async def process_workflow_event(msg_id: str, data: dict) -> None:
    """Process a single workflow event."""
    from services.message_broker import (
        acknowledge_workflow_event,
        WORKFLOW_CONSUMER_GROUP,
    )
    from services.workflow_trigger_service import evaluate_triggers_for_owner

    event_type = data.get("event_type")
    context = data.get("context") or {}
    owner_id = data.get("owner_id")
    chatbot_id = data.get("chatbot_id")

    if not event_type:
        logger.warning(f"Skipping invalid workflow event {msg_id}: no event_type")
        acknowledge_workflow_event(WORKFLOW_CONSUMER_GROUP, msg_id)
        return

    try:
        if owner_id:
            results = await evaluate_triggers_for_owner(owner_id, event_type, context)
        elif chatbot_id:
            from services.workflow_trigger_service import evaluate_triggers

            results = await evaluate_triggers(chatbot_id, event_type, context)
        else:
            logger.warning(f"Skipping workflow event {msg_id}: no owner_id or chatbot_id")
            acknowledge_workflow_event(WORKFLOW_CONSUMER_GROUP, msg_id)
            return

        for r in results:
            wf_name = r.get("workflow_name", "?")
            success = r.get("result", {}).get("success", False)
            logger.info(
                f"Workflow {wf_name} executed for {event_type}: success={success}"
            )
    except Exception as e:
        logger.exception(f"Workflow event processing failed for {msg_id}: {e}")
    finally:
        acknowledge_workflow_event(WORKFLOW_CONSUMER_GROUP, msg_id)


async def run_worker():
    """Main worker loop."""
    from services.message_broker import (
        consume_workflow_events,
        WORKFLOW_CONSUMER_GROUP,
    )

    logger.info(f"Workflow worker started. Consumer={CONSUMER_ID}")
    while True:
        try:
            events = consume_workflow_events(
                group=WORKFLOW_CONSUMER_GROUP,
                consumer=CONSUMER_ID,
                block_ms=BLOCK_MS,
            )
            for msg_id, data in events:
                await process_workflow_event(msg_id, data)
        except KeyboardInterrupt:
            logger.info("Workflow worker shutting down")
            break
        except Exception as e:
            logger.exception(f"Workflow worker error: {e}")
            await asyncio.sleep(5)


def main():
    asyncio.run(run_worker())


if __name__ == "__main__":
    main()

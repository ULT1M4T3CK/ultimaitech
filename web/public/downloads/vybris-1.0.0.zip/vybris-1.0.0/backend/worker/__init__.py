# Worker package for async chat processing

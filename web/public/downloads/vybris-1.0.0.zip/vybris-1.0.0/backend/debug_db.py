import os
import psycopg2
import json

try:
    conn = psycopg2.connect(
        host=os.environ.get("POSTGRES_HOST", "postgres"),
        port=os.environ.get("POSTGRES_PORT", "5432"),
        dbname=os.environ.get("POSTGRES_DB", "vybris"),
        user=os.environ.get("POSTGRES_USER", "user"),
        password=os.environ.get("POSTGRES_PASSWORD", "password")
    )
    cur = conn.cursor()
    
    print("--- CHATBOTS ---")
    cur.execute("SELECT id, name FROM chatbots")
    bots = cur.fetchall()
    print(f"Found {len(bots)} chatbots:")
    for bot in bots:
        print(f"- {bot[1]} (ID: {bot[0]})")

    print("\n--- INTEGRATIONS ---")
    cur.execute("SELECT id, chatbot_id, integration_type, status, config FROM integrations")
    integrations = cur.fetchall()
    print(f"Found {len(integrations)} integrations:")
    for integration in integrations:
        print(f"- Type: {integration[2]}, Status: {integration[3]}, BotID: {integration[1]}")
        # print config keys only to avoid leaking sensitive data if any, but universal_inventory URLs are needed
        if integration[2] == 'universal_inventory':
            print(f"  Config: {json.dumps(integration[4], indent=2)}")

except Exception as e:
    print(f"Error: {e}")

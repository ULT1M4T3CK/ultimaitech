import sys
import os
# Add current directory to path so we can import services
sys.path.append(os.getcwd())

from services.nlp_service import nlp_service

print("--- DIAGNOSTIC START ---")
print(f"Model Loaded: {nlp_service.model is not None}")
print(f"Tokenizer Loaded: {nlp_service.tokenizer is not None}")

# Check embedding consistency
text = "hello world"
vec1 = nlp_service._get_embedding_sync(text)
vec2 = nlp_service._get_embedding_sync(text)

print(f"Vector Length: {len(vec1)}")
print(f"Vector 1 First 3 values: {vec1[:3]}")
print(f"Vector 2 First 3 values: {vec2[:3]}")

if vec1 == vec2:
    print("Vectors are DETERMINISTIC (Good)")
else:
    print("Vectors are RANDOM (BAD - Mock Mode)")
print("--- DIAGNOSTIC END ---")

"""
Prometheus Metrics for VYBR!S
Provides metrics collection for monitoring and observability
"""

from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from fastapi import Response
from typing import Optional
import time

# Request metrics
http_requests_total = Counter(
    'http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status_code']
)

http_request_duration_seconds = Histogram(
    'http_request_duration_seconds',
    'HTTP request duration in seconds',
    ['method', 'endpoint'],
    buckets=[0.1, 0.5, 1.0, 2.5, 5.0, 10.0]
)

# Business metrics
nlp_queries_total = Counter(
    'nlp_queries_total',
    'Total NLP queries processed',
    ['chatbot_id', 'intent', 'status']
)

nlp_query_duration_seconds = Histogram(
    'nlp_query_duration_seconds',
    'NLP query processing duration',
    ['chatbot_id'],
    buckets=[0.1, 0.5, 1.0, 2.5, 5.0]
)

rag_results_count = Histogram(
    'rag_results_count',
    'Number of RAG results returned',
    ['chatbot_id'],
    buckets=[0, 1, 3, 5, 10, 20]
)

# System metrics
active_sessions = Gauge(
    'active_sessions_total',
    'Number of active chat sessions',
    ['chatbot_id']
)

active_chatbots = Gauge(
    'active_chatbots_total',
    'Number of active chatbots'
)

database_connections = Gauge(
    'database_connections_active',
    'Number of active database connections'
)

cache_hits_total = Counter(
    'cache_hits_total',
    'Total cache hits',
    ['cache_type']
)

cache_misses_total = Counter(
    'cache_misses_total',
    'Total cache misses',
    ['cache_type']
)


class PrometheusMiddleware:
    """Middleware to collect Prometheus metrics"""
    
    def __init__(self, app):
        self.app = app
    
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        
        method = scope["method"]
        path = scope["path"]
        
        # Normalize path (remove IDs for better aggregation)
        endpoint = self._normalize_path(path)
        
        start_time = time.time()
        
        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                status_code = message["status"]
                http_requests_total.labels(
                    method=method,
                    endpoint=endpoint,
                    status_code=status_code
                ).inc()
            
            await send(message)
        
        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            duration = time.time() - start_time
            http_request_duration_seconds.labels(
                method=method,
                endpoint=endpoint
            ).observe(duration)
    
    def _normalize_path(self, path: str) -> str:
        """Normalize path by replacing IDs with placeholders"""
        import re
        # Replace UUIDs and IDs with placeholders
        path = re.sub(r'/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}', '/{id}', path)
        path = re.sub(r'/[a-z0-9_]{12,}', '/{id}', path)
        return path


def get_metrics() -> Response:
    """Get Prometheus metrics endpoint"""
    return Response(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST
    )


def record_nlp_query(chatbot_id: str, intent: str, status: str, duration: float):
    """Record NLP query metrics"""
    nlp_queries_total.labels(
        chatbot_id=chatbot_id,
        intent=intent,
        status=status
    ).inc()
    
    nlp_query_duration_seconds.labels(
        chatbot_id=chatbot_id
    ).observe(duration)


def record_rag_results(chatbot_id: str, count: int):
    """Record RAG results count"""
    rag_results_count.labels(
        chatbot_id=chatbot_id
    ).observe(count)


def record_cache_hit(cache_type: str):
    """Record cache hit"""
    cache_hits_total.labels(cache_type=cache_type).inc()


def record_cache_miss(cache_type: str):
    """Record cache miss"""
    cache_misses_total.labels(cache_type=cache_type).inc()


def update_active_sessions(chatbot_id: str, count: int):
    """Update active sessions gauge"""
    active_sessions.labels(chatbot_id=chatbot_id).set(count)


def update_active_chatbots(count: int):
    """Update active chatbots gauge"""
    active_chatbots.set(count)


def update_database_connections(count: int):
    """Update database connections gauge"""
    database_connections.set(count)

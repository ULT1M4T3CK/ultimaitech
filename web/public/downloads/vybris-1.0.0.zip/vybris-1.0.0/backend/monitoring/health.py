"""
Health Check & Metrics Endpoints for VYBR!S
Provides /health and /metrics endpoints for monitoring.
"""

import time
from datetime import datetime
from typing import Dict, Any
from collections import defaultdict
from fastapi import APIRouter
import logging

logger = logging.getLogger(__name__)

router = APIRouter(tags=["monitoring"])

# Import Prometheus metrics if available
try:
    from monitoring.prometheus import get_metrics
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    logger.warning("Prometheus not available. Install prometheus_client to enable metrics.")


# ============================================================================
# Metrics Collection
# ============================================================================

class MetricsCollector:
    """
    Simple in-memory metrics collector.
    Tracks request counts, response times, and error rates.
    """
    
    def __init__(self):
        self.request_counts: Dict[str, int] = defaultdict(int)
        self.response_times: Dict[str, list] = defaultdict(list)
        self.error_counts: Dict[str, int] = defaultdict(int)
        self.start_time = time.time()
        self._max_stored_times = 1000  # Keep last N response times
    
    def record_request(self, endpoint: str):
        """Record a request to an endpoint."""
        self.request_counts[endpoint] += 1
        self.request_counts["total"] += 1
    
    def record_response_time(self, endpoint: str, duration_ms: float):
        """Record response time for an endpoint."""
        times = self.response_times[endpoint]
        times.append(duration_ms)
        # Keep only last N entries to prevent memory growth
        if len(times) > self._max_stored_times:
            self.response_times[endpoint] = times[-self._max_stored_times:]
    
    def record_error(self, endpoint: str, error_type: str = "general"):
        """Record an error."""
        self.error_counts[f"{endpoint}:{error_type}"] += 1
        self.error_counts["total"] += 1
    
    def get_avg_response_time(self, endpoint: str = None) -> float:
        """Get average response time in ms."""
        if endpoint:
            times = self.response_times.get(endpoint, [])
        else:
            times = []
            for t in self.response_times.values():
                times.extend(t)
        
        return sum(times) / len(times) if times else 0.0
    
    def get_error_rate(self) -> float:
        """Get overall error rate as percentage."""
        total = self.request_counts.get("total", 0)
        errors = self.error_counts.get("total", 0)
        return (errors / total * 100) if total > 0 else 0.0
    
    def get_uptime_seconds(self) -> float:
        """Get service uptime in seconds."""
        return time.time() - self.start_time
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get all metrics as a summary dict."""
        return {
            "uptime_seconds": self.get_uptime_seconds(),
            "total_requests": self.request_counts.get("total", 0),
            "total_errors": self.error_counts.get("total", 0),
            "error_rate_percent": self.get_error_rate(),
            "avg_response_time_ms": self.get_avg_response_time(),
            "requests_by_endpoint": dict(self.request_counts),
            "errors_by_type": dict(self.error_counts)
        }


# Singleton metrics collector
metrics = MetricsCollector()


# ============================================================================
# Health Check Endpoint
# ============================================================================

@router.get("/health/ready")
async def readiness_check():
    """
    Kubernetes readiness probe: checks DB, Redis, Qdrant connectivity.
    Returns 200 if ready to accept traffic, 503 otherwise.
    """
    from starlette.concurrency import run_in_threadpool

    def _check_sync():
        # Database
        try:
            from services.database.base import get_db_connection
            with get_db_connection() as conn:
                conn.cursor().execute("SELECT 1")
        except Exception:
            return False
        # Redis
        try:
            from services.auth_service import redis_client
            if redis_client:
                redis_client.ping()
        except Exception:
            return False
        # Qdrant (optional - don't fail if Qdrant is down)
        try:
            from services.nlp_service import nlp_service
            nlp_service.client.get_collections()
        except Exception:
            pass  # Qdrant optional
        return True

    ok = await run_in_threadpool(_check_sync)
    if not ok:
        from fastapi.responses import JSONResponse
        return JSONResponse(
            content={"status": "not_ready"},
            status_code=503,
        )
    return {"status": "ready"}


@router.get("/health")
async def health_check():
    """
    Health check endpoint with database and Qdrant connectivity status.
    All checks run in threadpool to avoid blocking event loop.
    
    Returns:
        200 OK if all systems healthy
        503 Service Unavailable if critical systems are down
    """
    from starlette.concurrency import run_in_threadpool
    
    checks = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "version": "3.0.0",
        "checks": {}
    }
    
    overall_healthy = True
    
    # Check PostgreSQL and connection pool
    def check_db():
        from services.database.base import get_db_connection
        from services.database.pool import get_pool_stats
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
        return get_pool_stats()
            
    try:
        pool_stats = await run_in_threadpool(check_db)
        checks["checks"]["database"] = {
            "status": "healthy",
            "type": "postgresql",
            "pool": pool_stats
        }
    except Exception as e:
        overall_healthy = False
        checks["checks"]["database"] = {
            "status": "unhealthy",
            "type": "postgresql",
            "error": str(e)[:100]
        }
        logger.error(f"Health check - Database unhealthy: {e}")
    
    # Check Qdrant
    def check_qdrant():
        from services.nlp_service import nlp_service
        return nlp_service.client.get_collections()

    try:
        collections = await run_in_threadpool(check_qdrant)
        checks["checks"]["qdrant"] = {
            "status": "healthy",
            "collections": len(collections.collections)
        }
    except Exception as e:
        # Qdrant failure is not critical (can fall back to in-memory)
        checks["checks"]["qdrant"] = {
            "status": "degraded",
            "error": str(e)[:100]
        }
        logger.warning(f"Health check - Qdrant degraded: {e}")
    
    # Check Redis (if configured)
    def check_redis():
        from services.auth_service import redis_client
        if redis_client:
            redis_client.ping()
            return True
        return False

    try:
        is_configured = await run_in_threadpool(check_redis)
        if is_configured:
            checks["checks"]["redis"] = {"status": "healthy"}
        else:
            checks["checks"]["redis"] = {"status": "not_configured"}
    except Exception as e:
        checks["checks"]["redis"] = {
            "status": "unhealthy",
            "error": str(e)[:100]
        }

    # Check Redis Streams (message broker)
    def check_redis_stream():
        try:
            from services.message_broker import _get_redis
            r = _get_redis()
            if r:
                r.ping()
                return True
        except Exception:
            pass
        return False

    try:
        if await run_in_threadpool(check_redis_stream):
            checks["checks"]["redis_streams"] = {"status": "healthy"}
        else:
            checks["checks"]["redis_streams"] = {"status": "not_configured"}
    except Exception as e:
        checks["checks"]["redis_streams"] = {"status": "degraded", "error": str(e)[:50]}
    
    # Check LLM provider configuration
    try:
        from services.llm import llm_service
        checks["checks"]["llm"] = {
            "status": "configured" if llm_service.is_enabled() else "not_configured",
            "provider": llm_service.get_provider_name()
        }
    except Exception as e:
        checks["checks"]["llm"] = {"status": "error"}
    
    # Set overall status
    if not overall_healthy:
        checks["status"] = "unhealthy"
    
    return checks


# ============================================================================
# Metrics Endpoint (Prometheus-compatible)
# ============================================================================

@router.get("/metrics")
async def prometheus_metrics():
    """
    Prometheus-compatible metrics endpoint.
    
    Returns metrics in a format that can be scraped by Prometheus.
    """
    summary = metrics.get_metrics_summary()
    
    # Format as Prometheus-style metrics
    lines = [
        "# HELP vybris_uptime_seconds Time since service started",
        "# TYPE vybris_uptime_seconds gauge",
        f"vybris_uptime_seconds {summary['uptime_seconds']:.2f}",
        "",
        "# HELP vybris_requests_total Total number of requests",
        "# TYPE vybris_requests_total counter",
        f"vybris_requests_total {summary['total_requests']}",
        "",
        "# HELP vybris_errors_total Total number of errors",
        "# TYPE vybris_errors_total counter",
        f"vybris_errors_total {summary['total_errors']}",
        "",
        "# HELP vybris_error_rate_percent Error rate as percentage",
        "# TYPE vybris_error_rate_percent gauge",
        f"vybris_error_rate_percent {summary['error_rate_percent']:.2f}",
        "",
        "# HELP vybris_avg_response_time_ms Average response time in milliseconds",
        "# TYPE vybris_avg_response_time_ms gauge",
        f"vybris_avg_response_time_ms {summary['avg_response_time_ms']:.2f}",
    ]
    
    # Add per-endpoint request counts
    lines.append("")
    lines.append("# HELP vybris_endpoint_requests_total Requests per endpoint")
    lines.append("# TYPE vybris_endpoint_requests_total counter")
    for endpoint, count in summary['requests_by_endpoint'].items():
        if endpoint != "total":
            safe_endpoint = endpoint.replace("/", "_").replace("-", "_")
            lines.append(f'vybris_endpoint_requests_total{{endpoint="{endpoint}"}} {count}')
    
    return "\n".join(lines)


@router.get("/metrics/json")
async def metrics_json():
    """
    JSON format metrics endpoint for easier consumption.
    """
    return metrics.get_metrics_summary()


# ============================================================================
# RAG Performance Metrics
# ============================================================================

class RAGMetrics:
    """
    Specialized metrics for RAG pipeline performance.
    """
    
    def __init__(self):
        self.retrieval_times: list = []
        self.rerank_times: list = []
        self.llm_times: list = []
        self.avg_scores: list = []
        self._max_entries = 500
    
    def record_retrieval(self, duration_ms: float, num_results: int, avg_score: float):
        """Record a retrieval operation."""
        self.retrieval_times.append(duration_ms)
        self.avg_scores.append(avg_score)
        self._trim_lists()
    
    def record_rerank(self, duration_ms: float):
        """Record a re-ranking operation."""
        self.rerank_times.append(duration_ms)
        self._trim_lists()
    
    def record_llm(self, duration_ms: float):
        """Record LLM response generation time."""
        self.llm_times.append(duration_ms)
        self._trim_lists()
    
    def _trim_lists(self):
        """Keep lists from growing too large."""
        if len(self.retrieval_times) > self._max_entries:
            self.retrieval_times = self.retrieval_times[-self._max_entries:]
        if len(self.rerank_times) > self._max_entries:
            self.rerank_times = self.rerank_times[-self._max_entries:]
        if len(self.llm_times) > self._max_entries:
            self.llm_times = self.llm_times[-self._max_entries:]
        if len(self.avg_scores) > self._max_entries:
            self.avg_scores = self.avg_scores[-self._max_entries:]
    
    def get_summary(self) -> Dict[str, Any]:
        """Get RAG performance summary."""
        def avg(lst):
            return sum(lst) / len(lst) if lst else 0.0
        
        def p95(lst):
            if not lst:
                return 0.0
            sorted_lst = sorted(lst)
            idx = int(len(sorted_lst) * 0.95)
            return sorted_lst[min(idx, len(sorted_lst) - 1)]
        
        return {
            "retrieval": {
                "avg_ms": avg(self.retrieval_times),
                "p95_ms": p95(self.retrieval_times),
                "count": len(self.retrieval_times)
            },
            "rerank": {
                "avg_ms": avg(self.rerank_times),
                "p95_ms": p95(self.rerank_times),
                "count": len(self.rerank_times)
            },
            "llm": {
                "avg_ms": avg(self.llm_times),
                "p95_ms": p95(self.llm_times),
                "count": len(self.llm_times)
            },
            "avg_retrieval_score": avg(self.avg_scores)
        }


# Singleton RAG metrics
rag_metrics = RAGMetrics()


@router.get("/metrics/rag")
async def rag_metrics_endpoint():
    """
    RAG-specific performance metrics.
    """
    return rag_metrics.get_summary()


@router.get("/metrics/prometheus")
async def prometheus_metrics_endpoint():
    """
    Prometheus metrics endpoint.
    Returns metrics in Prometheus format.
    """
    if PROMETHEUS_AVAILABLE:
        return get_metrics()
    else:
        from fastapi import HTTPException
        raise HTTPException(
            status_code=503,
            detail="Prometheus metrics not available. Install prometheus_client package."
        )

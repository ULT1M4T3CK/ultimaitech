"""
Unit tests for URL normalization and anchor deduplication.

Tests the normalize_url() function and scraper service's handling of anchor-based URLs.
"""

import pytest
from shared.utils.url import normalize_url, is_valid_url, extract_domain


class TestNormalizeUrl:
    """Test suite for URL normalization function."""
    
    def test_anchor_deduplication(self):
        """Test that URLs with different anchors normalize to the same URL."""
        urls_with_anchors = [
            'https://example.com/page#section1',
            'https://example.com/page#section2',
            'https://example.com/page#top',
            'https://example.com/page#navigation',
            'https://example.com/page',  # No anchor
        ]
        
        normalized = [normalize_url(url) for url in urls_with_anchors]
        
        # All should normalize to the same URL
        assert len(set(normalized)) == 1, "All anchor variants should normalize to same URL"
        assert normalized[0] == 'https://example.com/page'
        assert '#' not in normalized[0], "Normalized URL should not contain fragments"
    
    def test_query_param_preservation(self):
        """Test that query params are kept but sorted."""
        url1 = 'https://example.com/page?z=1&a=2#anchor'
        url2 = 'https://example.com/page?a=2&z=1'
        
        norm1 = normalize_url(url1)
        norm2 = normalize_url(url2)
        
        assert norm1 == norm2, "Query params should be sorted consistently"
        assert 'a=2' in norm1, "Query param 'a' should be preserved"
        assert 'z=1' in norm1, "Query param 'z' should be preserved"
        assert '#' not in norm1, "Fragment should be stripped"
    
    def test_trailing_slash_normalization(self):
        """Test trailing slash handling."""
        urls = [
            'https://example.com/page/',
            'https://example.com/page',
        ]
        
        normalized = [normalize_url(url) for url in urls]
        
        # Should normalize to same URL (without trailing slash)
        assert normalized[0] == normalized[1]
        assert not normalized[0].endswith('/'), "Trailing slash should be removed"
    
    def test_case_normalization(self):
        """Test that scheme and domain are lowercased."""
        url = 'HTTPS://EXAMPLE.COM/Page'
        normalized = normalize_url(url)
        
        assert normalized.startswith('https://'), "Scheme should be lowercase"
        assert 'example.com' in normalized, "Domain should be lowercase"
        # Path should preserve case
        assert '/Page' in normalized, "Path case should be preserved"
    
    def test_default_port_removal(self):
        """Test that default ports are removed."""
        url_http = 'http://example.com:80/page'
        url_https = 'https://example.com:443/page'
        
        norm_http = normalize_url(url_http)
        norm_https = normalize_url(url_https)
        
        assert ':80' not in norm_http, "Default HTTP port should be removed"
        assert ':443' not in norm_https, "Default HTTPS port should be removed"
    
    def test_complex_url_with_all_features(self):
        """Test a complex URL with anchors, query params, trailing slash."""
        url1 = 'HTTPS://EXAMPLE.COM:443/Page/?z=3&a=1&b=2#section1'
        url2 = 'https://example.com/Page?a=1&b=2&z=3#section2'
        
        norm1 = normalize_url(url1)
        norm2 = normalize_url(url2)
        
        assert norm1 == norm2, "Complex URLs should normalize identically"
        assert '#' not in norm1, "Fragment should be removed"
        assert ':443' not in norm1, "Default port should be removed"
    
    def test_empty_and_invalid_urls(self):
        """Test edge cases with empty or invalid URLs."""
        assert normalize_url('') == '', "Empty URL should return empty string"
        assert normalize_url('   ') == '', "Whitespace-only should return empty"
        
        # Invalid URLs should return original (stripped)
        invalid = 'not-a-url'
        assert normalize_url(invalid) == invalid.strip()


class TestScraperServiceAnchorHandling:
    """Test suite for scraper service's anchor deduplication."""
    
    def test_process_link_anchor_variants(self):
        """Test that _process_link handles anchor variants correctly."""
        from services.scraper_service import scraper_service
        from urllib.parse import urlparse
        
        base_url = 'https://example.com/page'
        parsed = urlparse(base_url)
        
        # Test different anchors on same page
        links_with_anchors = [
            'https://example.com/other#section1',
            'https://example.com/other#section2',
            '/other#section3',  # Relative URL with anchor
        ]
        
        results = []
        for href in links_with_anchors:
            result = scraper_service._process_link(href, parsed, 'example.com', 'example.com', base_url)
            if result:
                results.append(result)
        
        # All should return the same normalized URL (without anchors)
        if results:
            unique_results = set(results)
            assert len(unique_results) == 1, f"All anchor variants should normalize to same URL, got: {unique_results}"
            assert '#' not in list(unique_results)[0], "Processed links should not contain fragments"
    
    def test_process_link_skips_fragment_only_links(self):
        """Test that links starting with # are skipped."""
        from services.scraper_service import scraper_service
        from urllib.parse import urlparse
        
        base_url = 'https://example.com/page'
        parsed = urlparse(base_url)
        
        # Fragment-only links should be skipped
        fragment_links = ['#section1', '#top', '#']
        
        for href in fragment_links:
            result = scraper_service._process_link(href, parsed, 'example.com', 'example.com', base_url)
            assert result is None, f"Fragment-only link '{href}' should be skipped"
    
    def test_process_link_same_page_detection(self):
        """Test that links to the current page (with anchors) are filtered out."""
        from services.scraper_service import scraper_service
        from urllib.parse import urlparse
        
        current_url = 'https://example.com/page'
        parsed = urlparse(current_url)
        
        # These all point to the current page
        same_page_links = [
            'https://example.com/page',
            'https://example.com/page#section1',
            '/page#top',
        ]
        
        for href in same_page_links:
            result = scraper_service._process_link(href, parsed, 'example.com', 'example.com', current_url)
            # Should return None because it's the same page
            assert result is None, f"Link to current page '{href}' should be filtered out"
    
    def test_process_link_preserves_query_params(self):
        """Test that query parameters are preserved in processed links."""
        from services.scraper_service import scraper_service
        from urllib.parse import urlparse
        
        base_url = 'https://example.com/page'
        parsed = urlparse(base_url)
        
        link_with_params = 'https://example.com/other?category=tech&page=2#section1'
        result = scraper_service._process_link(link_with_params, parsed, 'example.com', 'example.com', base_url)
        
        assert result is not None, "Link should be processed"
        assert 'category=tech' in result or 'category' in result, "Query params should be preserved"
        assert '#' not in result, "Fragment should be removed"


class TestUrlValidation:
    """Test suite for URL validation helpers."""
    
    def test_valid_urls(self):
        """Test that valid URLs are recognized (localhost intentionally blocked for SSRF)."""
        valid_urls = [
            'https://example.com',
            'http://example.com/page',
            'https://sub.example.com/path?query=1',
        ]
        
        for url in valid_urls:
            assert is_valid_url(url), f"'{url}' should be valid"
    
    def test_invalid_urls(self):
        """Test that invalid URLs are rejected."""
        invalid_urls = [
            '',
            'not-a-url',
            'ftp://example.com',  # Wrong scheme
            'example.com',  # No scheme
            'javascript:alert(1)',
        ]
        
        for url in invalid_urls:
            assert not is_valid_url(url), f"'{url}' should be invalid"
    
    def test_extract_domain(self):
        """Test domain extraction."""
        test_cases = [
            ('https://www.example.com/page', 'example.com'),
            ('http://sub.example.com:8080/path', 'sub.example.com'),
            ('https://example.co.uk', 'example.co.uk'),
        ]
        
        for url, expected_domain in test_cases:
            domain = extract_domain(url)
            assert domain == expected_domain, f"Expected domain '{expected_domain}' from '{url}', got '{domain}'"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

"""
Unit Tests for Shared Utilities
"""

import pytest
import sys
import os

# Add backend to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


class TestTextUtils:
    """Tests for shared.utils.text module."""
    
    def test_clean_text_removes_whitespace(self):
        """clean_text should collapse multiple spaces."""
        from shared.utils.text import clean_text
        
        result = clean_text("hello    world")
        assert result == "hello world"
    
    def test_clean_text_strips_edges(self):
        """clean_text should strip leading/trailing whitespace."""
        from shared.utils.text import clean_text
        
        result = clean_text("  hello world  ")
        assert result == "hello world"
    
    def test_clean_text_handles_empty(self):
        """clean_text should handle empty strings."""
        from shared.utils.text import clean_text
        
        assert clean_text("") == ""
        assert clean_text(None) == ""
    
    def test_clean_text_handles_newlines(self):
        """clean_text should normalize newlines."""
        from shared.utils.text import clean_text
        
        result = clean_text("hello\n\nworld")
        assert "hello" in result and "world" in result
    
    def test_truncate_text_short_text(self):
        """truncate_text should not modify short text."""
        from shared.utils.text import truncate_text
        
        result = truncate_text("hello", 100)
        assert result == "hello"
    
    def test_truncate_text_long_text(self):
        """truncate_text should truncate and add suffix."""
        from shared.utils.text import truncate_text
        
        result = truncate_text("hello world this is a test", 10)
        assert len(result) <= 10
        assert result.endswith("...")
    
    def test_count_words_basic(self):
        """count_words should count words correctly."""
        from shared.utils.text import count_words
        
        assert count_words("hello world") == 2
        assert count_words("one two three four") == 4
    
    def test_count_words_empty(self):
        """count_words should handle empty strings."""
        from shared.utils.text import count_words
        
        assert count_words("") == 0
        assert count_words(None) == 0


class TestUrlUtils:
    """Tests for shared.utils.url module."""
    
    def test_normalize_url_removes_trailing_slash(self):
        """normalize_url should remove trailing slashes (except for root)."""
        from shared.utils.url import normalize_url
        
        result = normalize_url("https://example.com/page/")
        assert not result.endswith("/")
    
    def test_normalize_url_removes_fragment(self):
        """normalize_url should remove URL fragments."""
        from shared.utils.url import normalize_url
        
        result = normalize_url("https://example.com/page#section")
        assert "#" not in result
    
    def test_normalize_url_lowercases(self):
        """normalize_url should lowercase scheme and domain."""
        from shared.utils.url import normalize_url
        
        result = normalize_url("HTTPS://EXAMPLE.COM/path")
        assert result.startswith("https://")
    
    def test_is_valid_url_valid(self):
        """is_valid_url should accept valid URLs."""
        from shared.utils.url import is_valid_url
        
        assert is_valid_url("https://example.com") is True
        assert is_valid_url("http://example.com/path") is True
        assert is_valid_url("https://sub.example.com") is True
    
    def test_is_valid_url_invalid(self):
        """is_valid_url should reject invalid URLs."""
        from shared.utils.url import is_valid_url
        
        assert is_valid_url("") is False
        assert is_valid_url("not-a-url") is False
        assert is_valid_url("ftp://example.com") is False
    
    def test_extract_domain_basic(self):
        """extract_domain should extract domain correctly."""
        from shared.utils.url import extract_domain
        
        assert extract_domain("https://example.com/path") == "example.com"
        assert extract_domain("https://www.example.com") == "example.com"
    
    def test_extract_domain_empty(self):
        """extract_domain should handle empty input."""
        from shared.utils.url import extract_domain
        
        assert extract_domain("") is None
        assert extract_domain(None) is None
    
    def test_is_same_domain(self):
        """is_same_domain should compare domains correctly."""
        from shared.utils.url import is_same_domain
        
        assert is_same_domain("https://example.com/a", "https://example.com/b") is True
        assert is_same_domain("https://example.com", "https://other.com") is False


class TestErrors:
    """Tests for shared.errors module."""
    
    def test_vybris_error_base(self):
        """VybrisError should store message and code."""
        from shared.errors import VybrisError
        
        error = VybrisError("Test error", code="TEST_ERROR", status_code=400)
        
        assert error.message == "Test error"
        assert error.code == "TEST_ERROR"
        assert error.status_code == 400
    
    def test_vybris_error_to_dict(self):
        """VybrisError.to_dict should return proper structure."""
        from shared.errors import VybrisError
        
        error = VybrisError("Test error", code="TEST")
        result = error.to_dict()
        
        assert "error" in result
        assert "message" in result
        assert result["message"] == "Test error"
    
    def test_validation_error(self):
        """ValidationError should have 400 status code."""
        from shared.errors import ValidationError
        
        error = ValidationError("Invalid input", field="email")
        
        assert error.status_code == 400
        assert "field" in error.details
    
    def test_not_found_error(self):
        """NotFoundError should have 404 status code."""
        from shared.errors import NotFoundError
        
        error = NotFoundError("User", resource_id="123")
        
        assert error.status_code == 404
        assert "123" in str(error.details) or "User" in error.message
    
    def test_authorization_error(self):
        """AuthorizationError should have 403 status code."""
        from shared.errors import AuthorizationError
        
        error = AuthorizationError("Not allowed")
        
        assert error.status_code == 403


class TestTypes:
    """Tests for shared.types module."""
    
    def test_paginated_response(self):
        """PaginatedResponse should calculate total_pages."""
        from shared.types import PaginatedResponse
        
        response = PaginatedResponse(
            items=["a", "b", "c"],
            total=25,
            page=1,
            page_size=10,
            has_more=True
        )
        
        assert response.total_pages == 3
        assert len(response.items) == 3
    
    def test_api_response_success(self):
        """APIResponse should handle success case."""
        from shared.types import APIResponse
        
        response = APIResponse(
            success=True,
            data={"id": "123"},
            message="Created successfully"
        )
        
        assert response.success is True
        assert response.error is None
    
    def test_api_response_error(self):
        """APIResponse should handle error case."""
        from shared.types import APIResponse
        
        response = APIResponse(
            success=False,
            error="Something went wrong"
        )
        
        assert response.success is False
        assert response.data is None

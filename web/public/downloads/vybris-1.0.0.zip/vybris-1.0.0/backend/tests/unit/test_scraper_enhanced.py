import pytest
import asyncio
from unittest.mock import MagicMock, patch, PropertyMock

# Handle AsyncMock version compatibility
try:
    from unittest.mock import AsyncMock
except ImportError:
    # Fallback for older python versions
    class AsyncMock(MagicMock):
        async def __call__(self, *args, **kwargs):
            return super(AsyncMock, self).__call__(*args, **kwargs)

from services.scraper_service import ScraperService


@pytest.mark.asyncio
async def test_scraper_js_capabilities():
    """Verify that JS rendering is advertised as available."""
    service = ScraperService()
    # Mock playwright availability to True for testing logic
    with patch.object(ScraperService, 'playwright_available', new_callable=PropertyMock) as mock_avail:
        mock_avail.return_value = True
        caps = service.get_capabilities()
        assert caps["javascript_rendering"] is True

@pytest.mark.asyncio
async def test_handle_popups_logic():
    """Test that handle_popups attempts to click buttons."""
    service = ScraperService()
    mock_page = MagicMock()
    mock_page.query_selector = AsyncMock()
    mock_button = MagicMock()
    mock_button.is_visible = AsyncMock(return_value=True)
    mock_button.click = AsyncMock()
    mock_page.query_selector.return_value = mock_button
    
    await service._handle_popups(mock_page)
    
    assert mock_page.query_selector.called
    assert mock_button.click.called

@pytest.mark.asyncio
async def test_auto_scroll_logic():
    """Test that auto_scroll evaluates the scroll script."""
    service = ScraperService()
    mock_page = MagicMock()
    mock_page.evaluate = AsyncMock()
    
    await service._auto_scroll(mock_page)
    
    assert mock_page.evaluate.called
    # Check if internal script contains scroll logic
    args = mock_page.evaluate.call_args[0][0]
    assert "window.scrollBy" in args

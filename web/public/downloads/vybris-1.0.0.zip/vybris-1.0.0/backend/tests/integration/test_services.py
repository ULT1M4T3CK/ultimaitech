"""
Integration Tests for Scraper API Endpoints
Tests the scraper router with mocked services.
"""

import pytest
from unittest.mock import MagicMock, patch, AsyncMock
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


class TestScraperService:
    """Tests for the ScraperService."""
    
    def test_validate_url_valid(self):
        """validate_url should accept valid URLs."""
        from services.scraper_service import ScraperService
        
        service = ScraperService()
        
        valid, result = service.validate_url("https://example.com")
        assert valid is True
        assert result.startswith("https://")
    
    def test_validate_url_adds_scheme(self):
        """validate_url should add https scheme if missing."""
        from services.scraper_service import ScraperService
        
        service = ScraperService()
        
        valid, result = service.validate_url("example.com")
        assert valid is True
        assert result == "https://example.com"
    
    def test_validate_url_invalid(self):
        """validate_url should reject invalid URLs."""
        from services.scraper_service import ScraperService
        
        service = ScraperService()
        
        valid, error = service.validate_url("")
        assert valid is False
    
    def test_normalize_url(self):
        """normalize_url should normalize URLs for deduplication."""
        from services.scraper_service import ScraperService
        
        service = ScraperService()
        
        # Test various normalizations (trailing slash on path, scheme/domain case)
        assert service.normalize_url("https://example.com/page/") == service.normalize_url("https://example.com/page")
        assert service.normalize_url("https://EXAMPLE.COM") == service.normalize_url("https://example.com")
    
    def test_clean_text(self):
        """clean_text should clean and normalize text."""
        from services.scraper_service import ScraperService
        
        service = ScraperService()
        
        result = service.clean_text("  hello   world  ")
        assert result == "hello world"
    
    def test_create_job(self):
        """create_job should create a new scrape job."""
        from services.scraper_service import ScraperService
        
        service = ScraperService()
        
        job = service.create_job(
            url="https://example.com",
            depth=2,
            max_pages=10
        )
        
        assert job.job_id.startswith("scrape_")
        assert job.url == "https://example.com"
        assert job.depth == 2
        assert job.max_pages == 10
        assert job.status.value == "pending"
    
    def test_get_job(self):
        """get_job should retrieve a job by ID."""
        from services.scraper_service import ScraperService
        
        service = ScraperService()
        
        # Create a job
        job = service.create_job(url="https://example.com")
        
        # Retrieve it
        retrieved = service.get_job(job.job_id)
        
        assert retrieved is not None
        assert retrieved.job_id == job.job_id
    
    def test_get_job_not_found(self):
        """get_job should return None for non-existent job."""
        from services.scraper_service import ScraperService
        
        service = ScraperService()
        
        result = service.get_job("non_existent_id")
        assert result is None
    
    def test_get_capabilities(self):
        """get_capabilities should return scraper capabilities."""
        from services.scraper_service import ScraperService
        
        service = ScraperService()
        
        caps = service.get_capabilities()
        
        assert "static_html" in caps
        assert caps["static_html"] is True
        assert "max_depth" in caps
        assert "max_pages" in caps
    
    def test_get_common_page_patterns(self):
        """get_common_page_patterns should return common URLs."""
        from services.scraper_service import ScraperService
        
        service = ScraperService()
        
        patterns = service.get_common_page_patterns("https://example.com")
        
        assert len(patterns) > 0
        assert all(p.startswith("https://example.com") for p in patterns)
        # Should include common pages
        assert any("/about" in p for p in patterns)
        assert any("/contact" in p for p in patterns)


class TestRAGService:
    """Tests for the RAGService."""
    
    def test_preprocess_query_basic(self):
        """preprocess_query should normalize queries."""
        from services.rag_service import RAGService
        
        service = RAGService()
        
        result = service.preprocess_query("Hello World")
        
        assert result.original == "Hello World"
        assert result.normalized == "hello world"
    
    def test_preprocess_query_empty(self):
        """preprocess_query should handle empty input."""
        from services.rag_service import RAGService
        
        service = RAGService()
        
        result = service.preprocess_query("")
        
        assert result.original == ""
        assert result.normalized == ""
    
    def test_detect_intent(self):
        """_detect_intent should identify query intent."""
        from services.rag_service import RAGService
        
        service = RAGService()
        
        assert service._detect_intent("What is the price?") == "pricing"
        assert service._detect_intent("How can I contact you?") == "contact"
        assert service._detect_intent("Tell me about your company") == "about"
        assert service._detect_intent("Random question") == "general"
    
    def test_chunk_text_short(self):
        """chunk_text should not chunk short text."""
        from services.rag_service import RAGService
        
        service = RAGService()
        
        chunks = service.chunk_text("Short text")
        
        assert len(chunks) == 1
        assert chunks[0]['text'] == "Short text"
    
    def test_chunk_text_long(self):
        """chunk_text should chunk long text."""
        from services.rag_service import RAGService
        
        service = RAGService()
        
        # Create long text
        long_text = " ".join(["word"] * 500)
        
        chunks = service.chunk_text(long_text)
        
        assert len(chunks) > 1
    
    def test_build_context(self):
        """_build_context should combine search results."""
        from services.rag_service import RAGService, SearchResult
        
        service = RAGService()
        
        results = [
            SearchResult(content="First result", score=0.9),
            SearchResult(content="Second result", score=0.8),
        ]
        
        context = service._build_context(results)
        
        assert "First result" in context
        assert "Second result" in context
    
    def test_generate_template_response(self):
        """_generate_template_response should format responses."""
        from services.rag_service import RAGService, SearchResult
        
        service = RAGService()
        
        results = [SearchResult(content="Answer to question", score=0.85)]
        
        response = service._generate_template_response("question", results)
        
        assert response is not None
        assert "Answer to question" in response

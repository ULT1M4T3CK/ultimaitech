"""
Pytest Fixtures for VYBR!S Backend Tests
"""

import pytest
import os
import sys

# Add the backend directory to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@pytest.fixture
def sample_user_data():
    """Sample user data for testing."""
    return {
        'username': 'testuser',
        'email': 'test@example.com',
        'role': 'user',
        'hashed_password': 'hashed_password_here',
        'is_active': True,
        'metadata': {'key': 'value'}
    }


@pytest.fixture
def sample_chatbot_data():
    """Sample chatbot data for testing."""
    return {
        'name': 'Test Chatbot',
        'type': 'Customer Service',
        'status': 'Active',
        'user_id': 'user_123',
        'config': {
            'welcome_message': 'Hello!',
            'language': 'en',
            'custom_styles': {
                'primaryColor': '#d148e6'
            }
        },
        'data': {
            'conversations': 0,
            'total_messages': 0
        }
    }


@pytest.fixture
def sample_knowledge_data():
    """Sample knowledge item data for testing."""
    return {
        'chatbot_id': 'bot_test123',
        'item_type': 'text',
        'title': 'Test Knowledge',
        'content': 'This is some test knowledge content.',
        'metadata': {'source': 'test'}
    }


@pytest.fixture
def sample_training_job_data():
    """Sample training job data for testing."""
    return {
        'chatbot_id': 'bot_test123',
        'chatbot_name': 'Test Bot',
        'status': 'pending',
        'chunks_total': 10
    }


@pytest.fixture
def sample_scrape_request():
    """Sample scrape request for testing."""
    return {
        'url': 'https://example.com',
        'depth': 2,
        'max_pages': 10,
        'include_subpages': True,
        'render_js': False
    }


# ==================== Mock Fixtures ====================

@pytest.fixture
def mock_db_connection(mocker):
    """Mock database connection for unit tests."""
    mock_conn = mocker.MagicMock()
    mock_cursor = mocker.MagicMock()
    mock_cursor.fetchall.return_value = []
    mock_cursor.fetchone.return_value = None
    mock_conn.cursor.return_value.__enter__.return_value = mock_cursor
    mock_conn.cursor.return_value.__exit__.return_value = None
    return mock_conn


@pytest.fixture
def mock_nlp_service(mocker):
    """Mock NLP service for unit tests."""
    mock_service = mocker.MagicMock()
    mock_service.search.return_value = []
    mock_service.train_text.return_value = True
    mock_service.train_qa.return_value = True
    return mock_service


@pytest.fixture
def mock_perplexity_service(mocker):
    """Mock Perplexity service for unit tests."""
    mock_service = mocker.MagicMock()
    mock_service.generate.return_value = "Test response"
    return mock_service


# ==================== Test Utilities ====================

class TestHelpers:
    """Helper methods for tests."""
    
    @staticmethod
    def assert_valid_uuid(value: str) -> bool:
        """Check if a string is a valid UUID format."""
        import uuid
        try:
            uuid.UUID(value)
            return True
        except ValueError:
            return False
    
    @staticmethod
    def assert_iso_datetime(value: str) -> bool:
        """Check if a string is a valid ISO datetime."""
        from datetime import datetime
        try:
            datetime.fromisoformat(value.replace('Z', '+00:00'))
            return True
        except ValueError:
            return False


@pytest.fixture
def helpers():
    """Provide test helper methods."""
    return TestHelpers()


# ==================== Auth Overrides for API Tests ====================

@pytest.fixture
def override_get_current_user():
    """Override get_current_user for authenticated API tests."""
    from main import app
    from routers.auth import get_current_user

    _overrides = {}

    def _override(user_data: dict):
        async def _fake():
            return user_data
        app.dependency_overrides[get_current_user] = _fake
        _overrides[get_current_user] = user_data

    yield _override
    app.dependency_overrides.pop(get_current_user, None)


@pytest.fixture
def override_require_admin():
    """Override require_admin for Elias/admin API tests."""
    from main import app
    from routers.auth import require_admin

    def _override(user_data: dict):
        async def _fake():
            return user_data
        app.dependency_overrides[require_admin] = _fake

    yield _override
    app.dependency_overrides.pop(require_admin, None)

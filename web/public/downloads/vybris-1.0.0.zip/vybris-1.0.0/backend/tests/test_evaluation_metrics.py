
import unittest
import asyncio
from services.evaluation_service import evaluation_service
from services.nlp_service import nlp_service


class TestEvaluationMetrics(unittest.TestCase):
    def test_cosine_similarity(self):
        v1 = [1, 0, 0]
        v2 = [1, 0, 0]
        self.assertAlmostEqual(evaluation_service.calculate_cosine_similarity(v1, v2), 1.0)
        
        v3 = [0, 1, 0]
        self.assertAlmostEqual(evaluation_service.calculate_cosine_similarity(v1, v3), 0.0)
        
        v4 = [-1, 0, 0]
        self.assertAlmostEqual(evaluation_service.calculate_cosine_similarity(v1, v4), -1.0)

    def test_relevance(self):
        """calculate_relevance is async; must be awaited."""
        query = "What is the pricing?"
        answer = "Our pricing starts at $10."
        score = asyncio.run(evaluation_service.calculate_relevance(query, answer))
        self.assertTrue(-1.0 <= score <= 1.0)

    def test_grounding(self):
        """calculate_grounding is async; must be awaited."""
        answer = "We offer 24/7 support."
        context = [
            {"text": "We offer 24/7 support for all plans."},
            {"text": "Pricing is affordable."}
        ]
        score = asyncio.run(evaluation_service.calculate_grounding(answer, context))
        self.assertTrue(-1.0 <= score <= 1.0)


if __name__ == '__main__':
    unittest.main()

"""
API Tests for Chatbots Endpoints
Tests the chatbot CRUD operations via FastAPI TestClient
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock
import json


@pytest.fixture
def client():
    """Create test client"""
    from main import app
    return TestClient(app)


@pytest.fixture
def mock_user():
    """Mock authenticated user"""
    return {
        'id': 'test_user_123',
        'username': 'testuser',
        'email': 'test@example.com',
        'role': 'admin'
    }


@pytest.fixture
def mock_chatbot():
    """Mock chatbot data (includes fields required by Chatbot model)."""
    from datetime import datetime
    now = datetime.utcnow().isoformat() + 'Z'
    return {
        'id': 'test_bot_123',
        'name': 'Test Bot',
        'type': 'General Purpose',
        'owner_id': 'test_user_123',
        'status': 'Draft',
        'users': 0,
        'accuracy': 'N/A',
        'createdAt': now,
        'updatedAt': now,
        'config': {},
        'data': {}
    }


class TestChatbotsAPI:
    """Test chatbot API endpoints"""
    
    def test_create_chatbot_requires_auth(self, client):
        """Test that creating a chatbot requires authentication"""
        response = client.post("/api/v1/chatbots", json={
            "name": "Test Bot",
            "type": "General Purpose"
        })
        assert response.status_code == 401
    
    @patch('routers.chatbots.usage_service')
    @patch('routers.chatbots.ChatbotDB')
    def test_create_chatbot_success(self, mock_db, mock_usage, client, mock_user, mock_chatbot, override_get_current_user):
        """Test successful chatbot creation"""
        override_get_current_user(mock_user)
        mock_db.create.return_value = mock_chatbot
        
        response = client.post("/api/v1/chatbots", json={
            "name": "Test Bot",
            "type": "General Purpose"
        })
        
        assert response.status_code == 200
        assert response.json()['name'] == 'Test Bot'
        mock_db.create.assert_called_once()
    
    @patch('routers.chatbots.ChatbotDB')
    def test_get_chatbots_list(self, mock_db, client, mock_user, override_get_current_user):
        """Test getting list of chatbots"""
        override_get_current_user(mock_user)
        bot_list = [{'id': 'bot1', 'name': 'Bot 1'}, {'id': 'bot2', 'name': 'Bot 2'}]
        mock_db.get_by_user.return_value = bot_list
        mock_db.get_by_owner_ids.return_value = bot_list
        mock_db.get_all.return_value = bot_list
        
        response = client.get("/api/v1/chatbots")
        
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) == 2
    
    @patch('routers.chatbots.ChatbotDB')
    def test_get_chatbot_by_id(self, mock_db, client, mock_user, mock_chatbot, override_get_current_user):
        """Test getting a chatbot by ID"""
        override_get_current_user(mock_user)
        mock_db.get_by_id.return_value = mock_chatbot
        
        response = client.get(f"/api/v1/chatbots/{mock_chatbot['id']}")
        
        assert response.status_code == 200
        assert response.json()['id'] == mock_chatbot['id']
    
    @patch('routers.chatbots.ChatbotDB')
    def test_update_chatbot(self, mock_db, client, mock_user, mock_chatbot, override_get_current_user):
        """Test updating a chatbot"""
        override_get_current_user(mock_user)
        updated_bot = {**mock_chatbot, 'name': 'Updated Bot'}
        mock_db.get_by_id.return_value = mock_chatbot
        mock_db.update.return_value = updated_bot
        
        response = client.put(f"/api/v1/chatbots/{mock_chatbot['id']}", json={
            "name": "Updated Bot"
        })
        
        assert response.status_code == 200
        assert response.json()['name'] == 'Updated Bot'
    
    @patch('routers.chatbots.usage_service')
    @patch('routers.chatbots.ChatbotDB')
    def test_delete_chatbot(self, mock_db, mock_usage, client, mock_user, mock_chatbot, override_get_current_user):
        """Test deleting a chatbot"""
        override_get_current_user(mock_user)
        mock_db.get_by_id.return_value = mock_chatbot
        mock_db.delete.return_value = True
        
        response = client.delete(f"/api/v1/chatbots/{mock_chatbot['id']}")
        
        assert response.status_code == 200
        mock_db.delete.assert_called_once_with(mock_chatbot['id'])

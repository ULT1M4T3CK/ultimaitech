"""
API Tests for NLP Endpoints
Tests the NLP processing endpoints
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock, AsyncMock


@pytest.fixture
def client():
    """Create test client"""
    from main import app
    return TestClient(app)


@pytest.fixture
def mock_user():
    """Mock authenticated user"""
    return {
        'id': 'test_user_123',
        'username': 'testuser',
        'email': 'test@example.com',
        'role': 'admin'
    }


class TestNLPAPI:
    """Test NLP API endpoints"""

    def test_process_text_validates_request(self, client):
        """Test that process endpoint validates required fields."""
        response = client.post("/api/v1/nlp/process", json={})
        assert response.status_code == 422

    @patch('application.chat.intent_router.IntentRouter')
    @patch('services.cache_service.response_cache')
    @patch('services.database.ChatbotDB')
    def test_process_text_cache_hit(self, mock_db, mock_cache, mock_router, client):
        """Test that cached responses are returned immediately."""
        from application.chat.intent_router import RouteType
        mock_route = MagicMock()
        mock_route.route = RouteType.RAG
        mock_router.return_value.route.return_value = mock_route

        cached_response = {
            "intent": "greeting",
            "confidence": 0.9,
            "response": "Hello! How can I help you?",
            "sources": [],
            "live_chat_request_id": None,
            "live_chat_status": None,
            "explanation": None,
        }
        mock_cache.get.return_value = cached_response
        mock_db.get_by_id.return_value = {"id": "test_bot", "config": {}, "name": "Test Bot"}

        response = client.post("/api/v1/nlp/process", json={
            "chatbot_id": "test_bot",
            "text": "Hello"
        })

        assert response.status_code == 200
        data = response.json()
        assert data.get('response') == cached_response['response']

    @patch('application.chat.chat_orchestrator.chat_orchestrator')
    @patch('application.chat.intent_router.IntentRouter')
    @patch('services.cache_service.response_cache')
    @patch('services.database.ChatbotDB')
    def test_process_text_no_results(
        self, mock_db, mock_cache, mock_router, mock_orch, client
    ):
        """Test processing when no RAG results found (fallback)."""
        mock_cache.get.return_value = None
        mock_db.get_by_id.return_value = {
            'id': 'test_bot',
            'config': {'fallback_message': 'I did not understand that.'},
            'name': 'Test Bot'
        }
        from application.chat.intent_router import RouteType
        mock_route = MagicMock()
        mock_route.route = RouteType.RAG
        mock_router.return_value.route.return_value = mock_route

        orch_result = MagicMock()
        orch_result.intent = 'no_results_fallback'
        orch_result.confidence = 0.0
        orch_result.response = 'I did not understand that.'
        orch_result.sources = []
        orch_result.live_chat_request_id = None
        orch_result.live_chat_status = None
        orch_result.explanation = None
        mock_orch.process = AsyncMock(return_value=orch_result)

        response = client.post("/api/v1/nlp/process", json={
            "chatbot_id": "test_bot",
            "text": "Random question with no answer"
        })

        assert response.status_code == 200
        data = response.json()
        assert 'no_results' in data.get('intent', '').lower() or 'understand' in data.get('response', '').lower()

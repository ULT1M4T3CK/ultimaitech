"""
API tests for Elias smart assistant (summaries, to-dos, dashboard, ask).
All endpoints are admin-only and user-scoped.
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock, AsyncMock


@pytest.fixture
def client():
    """Create test client."""
    from main import app
    return TestClient(app)


@pytest.fixture
def admin_user():
    """Mock admin user for Elias (require_admin)."""
    return {
        "id": 1,
        "username": "admin",
        "email": "admin@example.com",
        "role": "admin",
    }


def _apply_admin_override(override_require_admin, admin_user):
    """Apply require_admin override for Elias tests."""
    override_require_admin(admin_user)


class TestEliasAuth:
    """Elias endpoints require admin auth (no auth sent => 401)."""

    def test_dashboard_requires_auth(self, client):
        response = client.get("/api/v1/elias/dashboard")
        assert response.status_code == 401

    def test_summaries_list_requires_auth(self, client):
        response = client.get("/api/v1/elias/summaries")
        assert response.status_code == 401

    def test_todos_list_requires_auth(self, client):
        response = client.get("/api/v1/elias/todos")
        assert response.status_code == 401

    def test_ask_requires_auth(self, client):
        response = client.post("/api/v1/elias/ask", json={"message": "hello"})
        assert response.status_code == 401


class TestEliasDashboard:
    """GET /api/v1/elias/dashboard"""

    @patch("routers.elias.EliasTodosDB.get_by_user")
    @patch("routers.elias.EliasSummariesDB.get_latest")
    def test_dashboard_returns_summary_and_todos(
        self, mock_get_latest, mock_get_todos, client, admin_user, override_require_admin
    ):
        _apply_admin_override(override_require_admin, admin_user)
        mock_get_latest.return_value = {
            "id": 1,
            "user_id": 1,
            "type": "daily",
            "content": "Today's summary.",
            "period_start": None,
            "period_end": None,
            "session_id": None,
            "created_at": "2025-01-01T00:00:00",
        }
        mock_get_todos.return_value = [
            {"id": 1, "user_id": 1, "title": "Task", "status": "pending", "due_at": None, "created_from_session_id": None, "created_at": "2025-01-01T00:00:00", "updated_at": "2025-01-01T00:00:00"},
        ]
        response = client.get("/api/v1/elias/dashboard")
        assert response.status_code == 200
        data = response.json()
        assert "summary" in data
        assert data["summary"]["content"] == "Today's summary."
        assert "todos" in data
        assert len(data["todos"]) == 1
        assert "pending_count" in data
        assert data["pending_count"] == 1


class TestEliasSummaries:
    """Summaries CRUD."""

    @patch("routers.elias.EliasSummariesDB.get_by_user")
    def test_list_summaries(self, mock_get_by_user, client, admin_user, override_require_admin):
        _apply_admin_override(override_require_admin, admin_user)
        mock_get_by_user.return_value = []
        response = client.get("/api/v1/elias/summaries")
        assert response.status_code == 200
        assert response.json() == {"summaries": []}

    @patch("routers.elias.EliasSummariesDB.create")
    def test_create_summary(self, mock_create, client, admin_user, override_require_admin):
        _apply_admin_override(override_require_admin, admin_user)
        mock_create.return_value = {
            "id": 1,
            "user_id": 1,
            "type": "daily",
            "content": "New summary",
            "period_start": None,
            "period_end": None,
            "session_id": None,
            "created_at": "2025-01-01T00:00:00",
        }
        response = client.post(
            "/api/v1/elias/summaries",
            json={
                "type": "daily",
                "content": "New summary",
            },
        )
        assert response.status_code == 200
        assert response.json()["content"] == "New summary"


class TestEliasTodos:
    """To-dos CRUD."""

    @patch("routers.elias.EliasTodosDB.get_by_user")
    def test_list_todos(self, mock_get_by_user, client, admin_user, override_require_admin):
        _apply_admin_override(override_require_admin, admin_user)
        mock_get_by_user.return_value = []
        response = client.get("/api/v1/elias/todos")
        assert response.status_code == 200
        assert response.json() == {"todos": []}

    @patch("routers.elias.EliasTodosDB.create")
    def test_create_todo(self, mock_create, client, admin_user, override_require_admin):
        _apply_admin_override(override_require_admin, admin_user)
        mock_create.return_value = {
            "id": 1,
            "user_id": 1,
            "title": "New todo",
            "status": "pending",
            "due_at": None,
            "created_from_session_id": None,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
        }
        response = client.post(
            "/api/v1/elias/todos",
            json={"title": "New todo"},
        )
        assert response.status_code == 200
        assert response.json()["title"] == "New todo"

    @patch("routers.elias.EliasTodosDB.update")
    @patch("routers.elias.EliasTodosDB.get_by_id")
    def test_patch_todo_mark_done(
        self, mock_get_by_id, mock_update, client, admin_user, override_require_admin
    ):
        _apply_admin_override(override_require_admin, admin_user)
        mock_get_by_id.return_value = {
            "id": 1,
            "user_id": 1,
            "title": "Task",
            "status": "pending",
            "due_at": None,
            "created_from_session_id": None,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
        }
        mock_update.return_value = {
            "id": 1,
            "user_id": 1,
            "title": "Task",
            "status": "done",
            "due_at": None,
            "created_from_session_id": None,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
        }
        response = client.patch("/api/v1/elias/todos/1", json={"status": "done"})
        assert response.status_code == 200
        assert response.json()["status"] == "done"


class TestEliasAsk:
    """POST /api/v1/elias/ask"""

    def test_ask_503_when_gateway_not_configured(self, client, admin_user, override_require_admin):
        _apply_admin_override(override_require_admin, admin_user)
        # ELIAS_GATEWAY_URL is unset in test env, so router raises 503
        response = client.post("/api/v1/elias/ask", json={"message": "hello"})
        assert response.status_code == 503
        assert "not configured" in response.json().get("detail", "").lower() or ""

    @patch("routers.elias.try_elias_reply")
    @patch("routers.elias.ELIAS_GATEWAY_URL", "http://test-gateway")
    def test_ask_200_with_reply(self, mock_try_elias_reply, client, admin_user, override_require_admin):
        _apply_admin_override(override_require_admin, admin_user)
        mock_try_elias_reply.return_value = (True, "Elias says hi.")
        response = client.post("/api/v1/elias/ask", json={"message": "hello"})
        assert response.status_code == 200
        data = response.json()
        assert data.get("reply") == "Elias says hi."
        assert data.get("error") is None

    def test_ask_200_with_error_when_elias_fails(self, client, admin_user, override_require_admin):
        _apply_admin_override(override_require_admin, admin_user)
        with patch("routers.elias.ELIAS_GATEWAY_URL", "http://test-gateway"):
            with patch("routers.elias.try_elias_reply", new_callable=AsyncMock) as mock_try_elias:
                with patch("routers.elias.llm_service") as mock_llm:
                    mock_try_elias.return_value = (False, None)
                    mock_llm.is_enabled.return_value = False  # Disable LLM fallback
                    response = client.post("/api/v1/elias/ask", json={"message": "hello"})
        assert response.status_code == 200
        data = response.json()
        assert data.get("reply") is None
        assert data.get("error") is not None

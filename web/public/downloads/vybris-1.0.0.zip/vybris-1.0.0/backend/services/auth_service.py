from datetime import datetime, timedelta
from typing import Optional
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel
import os
import redis
import secrets
import logging
import hashlib
import uuid

logger = logging.getLogger(__name__)

# Configuration - CRITICAL: Set JWT_SECRET_KEY in production!
SECRET_KEY = os.getenv("JWT_SECRET_KEY")
ENVIRONMENT = os.getenv("ENVIRONMENT", "development").lower()

if not SECRET_KEY:
    # Only allow auto-generation in explicit development mode
    # Fail if ENVIRONMENT is anything other than development/dev/local
    if ENVIRONMENT not in ("development", "dev", "local"):
        raise ValueError(
            f"CRITICAL: JWT_SECRET_KEY environment variable is REQUIRED! "
            f"Current ENVIRONMENT={ENVIRONMENT}. Set JWT_SECRET_KEY in production."
        )
    # Auto-generate for development only
    SECRET_KEY = secrets.token_urlsafe(32)
    logger.warning("⚠️  DEVELOPMENT MODE: Using auto-generated JWT secret. Set JWT_SECRET_KEY for production!")

REFRESH_SECRET_KEY = os.getenv("JWT_REFRESH_SECRET_KEY", SECRET_KEY + "_refresh_v3")
ALGORITHM = "HS256"

# Token expiration settings (configurable via environment)
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))  # 1 hour
REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", "7"))  # Long-lived

# Feature flag for JWT mode (allows gradual rollout)
USE_JWT_TOKENS = os.getenv("USE_JWT_TOKENS", "true").lower() == "true"

# Support multiple hash schemes for backward compatibility
# argon2 is preferred, but we also support bcrypt and pbkdf2 for existing users
pwd_context = CryptContext(
    schemes=["argon2", "bcrypt", "pbkdf2_sha256", "pbkdf2_sha512"],
    deprecated="auto",
    argon2__default_rounds=12,  # Reasonable security/performance balance
)

# Redis connection for session blacklist (kept for backward compatibility)
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
try:
    # SEC-023: Added timeouts to prevent blocking indefinitely if Redis hangs
    redis_client = redis.from_url(
        REDIS_URL, 
        decode_responses=True,
        socket_timeout=2.0,        # 2 seconds read/write timeout
        socket_connect_timeout=2.0 # 2 seconds connect timeout
    )
    redis_client.ping()  # Test connection
    print(f"[Auth] Connected to Redis at {REDIS_URL}")
except Exception as e:
    print(f"[Auth] Warning: Redis not available for session blacklist: {e}")
    redis_client = None

# SEC-005: In-memory fallback for session blacklist when Redis unavailable
# Format: {user_id_or_username: expiry_datetime}
_memory_blacklist: dict = {}

# Session management - track active sessions per user
# Format: {user_id: {session_id: {token_hash, created_at, last_activity, ip, user_agent}}}
_active_sessions: dict = {}

# Refresh token rotation - track used refresh tokens to prevent reuse
# Format: {token_hash: expiry_timestamp}
_used_refresh_tokens: dict = {}

# Progressive rate limiting for auth failures
# Format: {identifier: {attempts: int, last_attempt: datetime, lockout_until: datetime}}
_auth_failure_tracking: dict = {}


class TokenData(BaseModel):
    username: Optional[str] = None
    token_type: Optional[str] = None  # "access" or "refresh"
    mfa_pending: Optional[bool] = None  # True when MFA verification is required


def verify_password(plain_password, hashed_password):
    """
    Verify a password against a hash.
    
    Supports multiple hash formats (argon2, bcrypt) for backward compatibility.
    Handles NULL/empty hashes gracefully.
    """
    if not hashed_password:
        logger.warning("Attempted to verify password against NULL/empty hash")
        return False
    
    try:
        return pwd_context.verify(plain_password, hashed_password)
    except Exception as e:
        # Log the error but don't expose hash format details
        logger.error(f"Password verification failed: {type(e).__name__}")
        # If hash format is unknown, it might be an old format - try to identify
        if "UnknownHashError" in str(type(e).__name__):
            logger.warning(f"Unknown hash format detected. User may need to reset password.")
        return False


def get_password_hash(password):
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Create a short-lived access token."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({
        "exp": expire,
        "type": "access",
        "iat": datetime.utcnow()
    })
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def create_refresh_token(data: dict, expires_delta: Optional[timedelta] = None, jti: Optional[str] = None):
    """
    Create a long-lived refresh token with optional JTI (JWT ID) for rotation tracking.
    
    Args:
        data: Token payload data
        expires_delta: Optional custom expiration
        jti: Optional JWT ID for token rotation tracking
    """
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    
    # Add JTI for token rotation tracking
    if not jti:
        jti = secrets.token_urlsafe(16)
    
    to_encode.update({
        "exp": expire,
        "type": "refresh",
        "iat": datetime.utcnow(),
        "jti": jti  # JWT ID for rotation tracking
    })
    encoded_jwt = jwt.encode(to_encode, REFRESH_SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt, jti


def decode_access_token(token: str) -> Optional[TokenData]:
    """Decode and validate an access token."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        token_type: str = payload.get("type", "access")
        mfa_pending: bool = payload.get("mfa_pending", False)
        
        if username is None:
            return None
        
        # Verify it's an access token
        if token_type != "access":
            return None
            
        return TokenData(username=username, token_type=token_type, mfa_pending=mfa_pending)
    except JWTError:
        return None


def decode_refresh_token(token: str) -> Optional[dict]:
    """
    Decode and validate a refresh token.
    Returns full payload dict (not just TokenData) to access JTI.
    """
    try:
        payload = jwt.decode(token, REFRESH_SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        token_type: str = payload.get("type")
        
        if username is None or token_type != "refresh":
            return None
        
        # Check if token has been used (rotation check)
        jti = payload.get("jti")
        if jti:
            token_hash = hashlib.sha256(token.encode()).hexdigest()
            if _is_refresh_token_used(token_hash, jti):
                logger.warning(f"Attempted reuse of refresh token JTI: {jti}")
                return None
        
        return payload
    except JWTError:
        return None


def _is_refresh_token_used(token_hash: str, jti: str) -> bool:
    """Check if a refresh token has already been used (for rotation)."""
    now = datetime.utcnow().timestamp()
    
    # Check Redis first
    if redis_client:
        try:
            from shared.redis_keys import auth_used_refresh_key
            used_key = auth_used_refresh_key(jti)
            if redis_client.exists(used_key):
                return True
        except Exception as e:
            logger.warning(f"Redis check failed for refresh token: {e}")
    
    # Check in-memory fallback
    if jti in _used_refresh_tokens:
        expiry = _used_refresh_tokens[jti]
        if now < expiry:
            return True
        else:
            # Clean up expired entry
            del _used_refresh_tokens[jti]
    
    return False


def mark_refresh_token_used(jti: str, expires_in_seconds: int = None):
    """
    Mark a refresh token as used to prevent reuse (token rotation).
    
    Args:
        jti: JWT ID of the refresh token
        expires_in_seconds: How long to remember this token was used (default: refresh token expiry)
    """
    if not jti:
        return
    
    expires_in = expires_in_seconds or (REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60)
    expiry_timestamp = datetime.utcnow().timestamp() + expires_in
    
    # Store in Redis
    if redis_client:
        try:
            from shared.redis_keys import auth_used_refresh_key
            redis_client.setex(auth_used_refresh_key(jti), expires_in, "1")
        except Exception as e:
            logger.warning(f"Failed to mark refresh token as used in Redis: {e}")
    
    # Store in-memory fallback
    _used_refresh_tokens[jti] = expiry_timestamp
    
    # Cleanup old entries periodically
    now = datetime.utcnow().timestamp()
    expired_jtis = [j for j, exp in _used_refresh_tokens.items() if now > exp]
    for j in expired_jtis:
        del _used_refresh_tokens[j]





# ============================================================================
# Session Blacklist Functions
# ============================================================================

def blacklist_user_sessions(user_id: str, username: str):
    """
    Blacklist a user's sessions by storing their ID in Redis.
    All tokens for this user will be rejected until the blacklist entry expires.
    
    SEC-005: Also stores in memory as fallback.
    """
    expiry_time = datetime.utcnow() + timedelta(hours=24)
    
    # Always update in-memory blacklist as a fallback
    _memory_blacklist[user_id] = expiry_time
    _memory_blacklist[username] = expiry_time
    
    if redis_client is None:
        logger.warning(f"[Auth] Redis unavailable - using in-memory blacklist for {username}")
        return True  # Still return True since we have in-memory fallback
    
    try:
        from shared.redis_keys import auth_blacklist_user_key, auth_blacklist_username_key
        # Store the blacklist entry for 24 hours (same as token expiry)
        redis_client.setex(auth_blacklist_user_key(user_id), timedelta(hours=24), username)
        # Also blacklist by username in case tokens use username
        redis_client.setex(auth_blacklist_username_key(username), timedelta(hours=24), user_id)
        
        logger.info(f"[Auth] Blacklisted all sessions for user {username} (ID: {user_id})")
        return True
    except Exception as e:
        logger.warning(f"[Auth] Redis blacklist failed, using in-memory fallback: {e}")
        return True  # Still return True since we have in-memory fallback


def is_user_blacklisted(user_id: str = None, username: str = None) -> bool:
    """
    Check if a user's sessions are blacklisted.
    Returns True if the user is blacklisted and should be denied access.
    
    SEC-005: Uses in-memory fallback when Redis is unavailable.
    """
    # Try Redis first
    if redis_client is not None:
        try:
            from shared.redis_keys import auth_blacklist_user_key, auth_blacklist_username_key
            if user_id:
                if redis_client.exists(auth_blacklist_user_key(user_id)):
                    return True
            
            if username:
                if redis_client.exists(auth_blacklist_username_key(username)):
                    return True
            
            return False
        except Exception as e:
            logger.warning(f"[Auth] Redis check failed, falling back to memory: {e}")
            # Fall through to in-memory check
    
    # SEC-005: In-memory fallback when Redis unavailable
    # Check if user is in our in-memory blacklist
    if user_id and user_id in _memory_blacklist:
        expiry = _memory_blacklist[user_id]
        if datetime.utcnow() < expiry:
            return True
        else:
            del _memory_blacklist[user_id]
    
    if username and username in _memory_blacklist:
        expiry = _memory_blacklist[username]
        if datetime.utcnow() < expiry:
            return True
        else:
            del _memory_blacklist[username]
    
    return False


def remove_from_blacklist(user_id: str, username: str):
    """Remove a user from the blacklist (e.g., if they're re-activated)"""
    if redis_client is None:
        return False
    
    try:
        from shared.redis_keys import auth_blacklist_user_key, auth_blacklist_username_key
        redis_client.delete(auth_blacklist_user_key(user_id))
        redis_client.delete(auth_blacklist_username_key(username))
        return True
    except Exception as e:
        print(f"[Auth] Error removing from blacklist: {e}")
        return False


# ============================================================================
# Session Management Functions
# ============================================================================

def create_session(user_id: str, token_hash: str, ip: str = None, user_agent: str = None) -> str:
    """
    Create a new active session for a user.
    
    Uses Redis with transactions for atomic updates in production.
    Falls back to in-memory only in development.
    
    Returns:
        session_id: Unique session identifier
    """
    session_id = str(uuid.uuid4())
    now = datetime.utcnow()
    
    session_data = {
        "token_hash": token_hash,
        "created_at": now.isoformat(),
        "last_activity": now.isoformat(),
        "ip": ip,
        "user_agent": user_agent
    }
    
    # In production, require Redis
    if ENVIRONMENT in ("production", "prod", "staging"):
        if not redis_client:
            from shared.errors import ConfigurationError
            raise ConfigurationError(
                "Redis is REQUIRED for session management in production. "
                "Set REDIS_URL environment variable."
            )
    
    # Store in Redis with transaction for atomicity
    if redis_client:
        try:
            import json
            from shared.redis_keys import auth_session_key, auth_user_sessions_key
            rk = auth_session_key(user_id, session_id)
            user_sessions_key = auth_user_sessions_key(user_id)
            
            # Use Redis transaction (MULTI/EXEC) for atomic updates
            pipe = redis_client.pipeline()
            pipe.setex(
                rk,
                REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60,  # Convert days to seconds
                json.dumps(session_data)
            )
            # Add session ID to user's session list
            pipe.sadd(user_sessions_key, session_id)
            pipe.expire(user_sessions_key, REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60)
            pipe.execute()
        except Exception as e:
            logger.error(f"Failed to store session in Redis: {e}")
            if ENVIRONMENT in ("production", "prod", "staging"):
                raise
    
    # Store in-memory fallback (development only)
    if ENVIRONMENT in ("development", "dev", "local"):
        if user_id not in _active_sessions:
            _active_sessions[user_id] = {}
        _active_sessions[user_id][session_id] = {
            **session_data,
            "created_at": now,  # Keep as datetime for in-memory
            "last_activity": now
        }
    
    return session_id


def update_session_activity(user_id: str, session_id: str):
    """Update last activity timestamp for a session using Redis transaction."""
    now = datetime.utcnow()
    
    # Update in Redis with transaction
    if redis_client:
        try:
            import json
            from shared.redis_keys import auth_session_key
            rk = auth_session_key(user_id, session_id)
            
            # Use Redis transaction for atomic update
            pipe = redis_client.pipeline()
            existing = pipe.get(rk)
            pipe.execute()
            
            if existing:
                session_data = json.loads(existing)
                session_data["last_activity"] = now.isoformat()
                
                # Atomic update
                pipe = redis_client.pipeline()
                pipe.setex(
                    rk,
                    REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60,
                    json.dumps(session_data)
                )
                pipe.execute()
        except Exception as e:
            logger.warning(f"Failed to update session in Redis: {e}")
            if ENVIRONMENT in ("production", "prod", "staging"):
                raise
    
    # Update in-memory (development only)
    if ENVIRONMENT in ("development", "dev", "local"):
        if user_id in _active_sessions and session_id in _active_sessions[user_id]:
            _active_sessions[user_id][session_id]["last_activity"] = now


def revoke_session(user_id: str, session_id: str) -> bool:
    """Revoke a specific session using Redis transaction."""
    # Remove from Redis with transaction
    if redis_client:
        try:
            from shared.redis_keys import auth_session_key, auth_user_sessions_key
            rk = auth_session_key(user_id, session_id)
            user_sessions_key = auth_user_sessions_key(user_id)
            
            # Use Redis transaction for atomic deletion
            pipe = redis_client.pipeline()
            pipe.delete(rk)
            pipe.srem(user_sessions_key, session_id)
            result = pipe.execute()
            return result[0] > 0  # Return True if session was deleted
        except Exception as e:
            logger.warning(f"Failed to revoke session in Redis: {e}")
            if ENVIRONMENT in ("production", "prod", "staging"):
                raise
    
    # Remove from in-memory (development only)
    if ENVIRONMENT in ("development", "dev", "local"):
        if user_id in _active_sessions and session_id in _active_sessions[user_id]:
            del _active_sessions[user_id][session_id]
            if not _active_sessions[user_id]:
                del _active_sessions[user_id]
            return True
    
    return False


def revoke_all_user_sessions(user_id: str) -> int:
    """Revoke all sessions for a user. Returns count of revoked sessions."""
    count = 0
    
    # Remove from Redis
    if redis_client:
        try:
            from shared.redis_keys import REDIS_KEY_PREFIX, auth_user_sessions_key
            pattern = f"{REDIS_KEY_PREFIX}:auth:session:{user_id}:*"
            keys = redis_client.keys(pattern)
            if keys:
                count = redis_client.delete(*keys)
            # Clear user_sessions set
            redis_client.delete(auth_user_sessions_key(user_id))
        except Exception as e:
            logger.warning(f"Failed to revoke sessions in Redis: {e}")
    
    # Remove from in-memory
    if user_id in _active_sessions:
        count = len(_active_sessions[user_id])
        del _active_sessions[user_id]
    
    return count


def get_user_sessions(user_id: str) -> list:
    """Get all active sessions for a user."""
    sessions = []
    
    # Get from Redis
    if redis_client:
        try:
            from shared.redis_keys import REDIS_KEY_PREFIX
            pattern = f"{REDIS_KEY_PREFIX}:auth:session:{user_id}:*"
            keys = redis_client.keys(pattern)
            for key in keys:
                session_data = redis_client.get(key)
                if session_data:
                    import json
                    try:
                        data = json.loads(session_data)
                        # Key format: vybris:auth:session:user_id:session_id
                        session_id = key.split(":")[-1] if ":" in key else ""
                        sessions.append({
                            "session_id": session_id,
                            **data
                        })
                    except:
                        pass
        except Exception as e:
            logger.warning(f"Failed to get sessions from Redis: {e}")
    
    # Get from in-memory
    if user_id in _active_sessions:
        for session_id, data in _active_sessions[user_id].items():
            sessions.append({
                "session_id": session_id,
                **{k: v.isoformat() if isinstance(v, datetime) else v 
                   for k, v in data.items()}
            })
    
    return sessions


# ============================================================================
# Password Strength Validation
# ============================================================================

def validate_password_strength(password: str) -> tuple[bool, str]:
    """
    Validate password strength with complexity rules.
    
    Returns:
        (is_valid, error_message)
    """
    if len(password) < 12:
        return False, "Password must be at least 12 characters long"
    
    if len(password) > 128:
        return False, "Password must be no more than 128 characters long"
    
    # Check for at least one uppercase letter
    if not any(c.isupper() for c in password):
        return False, "Password must contain at least one uppercase letter"
    
    # Check for at least one lowercase letter
    if not any(c.islower() for c in password):
        return False, "Password must contain at least one lowercase letter"
    
    # Check for at least one digit
    if not any(c.isdigit() for c in password):
        return False, "Password must contain at least one number"
    
    # Check for at least one special character
    special_chars = "!@#$%^&*()_+-=[]{}|;:,.<>?"
    if not any(c in special_chars for c in password):
        return False, "Password must contain at least one special character (!@#$%^&*()_+-=[]{}|;:,.<>?)"
    
    # Check for common weak passwords
    common_passwords = [
        "password", "123456", "12345678", "qwerty", "abc123",
        "password123", "admin123", "letmein", "welcome", "monkey"
    ]
    password_lower = password.lower()
    for weak in common_passwords:
        if weak in password_lower:
            return False, "Password is too common or easily guessable"
    
    return True, ""


# ============================================================================
# Progressive Rate Limiting for Auth Failures
# ============================================================================

def record_auth_failure(identifier: str, max_attempts: int = 5, lockout_duration_minutes: int = 15):
    """
    Record an authentication failure and check if account should be locked.
    
    Args:
        identifier: Username, email, or IP address
        max_attempts: Maximum attempts before lockout
        lockout_duration_minutes: Minutes to lockout after max attempts
    
    Returns:
        (is_locked, lockout_until_datetime, attempts_remaining)
    """
    now = datetime.utcnow()
    
    # Get or create tracking entry
    if identifier not in _auth_failure_tracking:
        _auth_failure_tracking[identifier] = {
            "attempts": 0,
            "last_attempt": now,
            "lockout_until": None
        }
    
    tracking = _auth_failure_tracking[identifier]
    
    # Check if currently locked out
    if tracking["lockout_until"] and now < tracking["lockout_until"]:
        return True, tracking["lockout_until"], 0
    
    # Reset if lockout expired
    if tracking["lockout_until"] and now >= tracking["lockout_until"]:
        tracking["attempts"] = 0
        tracking["lockout_until"] = None
    
    # Increment attempts
    tracking["attempts"] += 1
    tracking["last_attempt"] = now
    
    # Check if we've exceeded max attempts
    if tracking["attempts"] >= max_attempts:
        lockout_until = now + timedelta(minutes=lockout_duration_minutes)
        tracking["lockout_until"] = lockout_until
        logger.warning(f"Account {identifier} locked out after {tracking['attempts']} failed attempts")
        return True, lockout_until, 0
    
    attempts_remaining = max_attempts - tracking["attempts"]
    return False, None, attempts_remaining


def reset_auth_failures(identifier: str):
    """Reset authentication failure tracking for an identifier (e.g., after successful login)."""
    if identifier in _auth_failure_tracking:
        del _auth_failure_tracking[identifier]
    
    # Also reset in Redis if available
    if redis_client:
        try:
            from shared.redis_keys import auth_failures_key
            redis_client.delete(auth_failures_key(identifier))
        except Exception as e:
            logger.warning(f"Failed to reset auth failures in Redis: {e}")


def get_auth_failure_status(identifier: str) -> dict:
    """Get current authentication failure status for an identifier."""
    if identifier not in _auth_failure_tracking:
        return {"attempts": 0, "is_locked": False, "lockout_until": None}
    
    tracking = _auth_failure_tracking[identifier]
    now = datetime.utcnow()
    
    is_locked = tracking["lockout_until"] and now < tracking["lockout_until"]
    
    return {
        "attempts": tracking["attempts"],
        "is_locked": is_locked,
        "lockout_until": tracking["lockout_until"].isoformat() if tracking["lockout_until"] else None
    }


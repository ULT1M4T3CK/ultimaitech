"""
Perplexity API Service for VYBR!S Chatbot
Uses direct HTTP API calls with llama-3.1-sonar-large-128k-chat model (NO web search).
Only uses scraped website content (RAG) - completely offline.
"""

import os
import httpx
import json
import logging
from typing import Optional, List, Dict, Any
from services.circuit_breaker import perplexity_circuit, with_fallback

logger = logging.getLogger(__name__)

# Configuration
PERPLEXITY_API_KEY = os.getenv("PERPLEXITY_API_KEY")
# Use sonar-pro for best quality responses with RAG context
# Note: Previous model llama-3.1-sonar-large-128k-chat was deprecated
PERPLEXITY_MODEL = os.getenv("PERPLEXITY_MODEL", "sonar")
PERPLEXITY_BASE_URL = "https://api.perplexity.ai/chat/completions"


class PerplexityService:
    def __init__(self):
        self.enabled = False
        self.api_key = PERPLEXITY_API_KEY
        
        if self.api_key:
            self.enabled = True
            print(f"Perplexity service initialized with model: {PERPLEXITY_MODEL}")
        else:
            print("PERPLEXITY_API_KEY not set. Perplexity service disabled.")
    
    async def generate_response(
        self,
        user_query: str,
        context_chunks: List[Dict[str, Any]],
        chatbot_name: str = "Assistant",
        company_name: str = "",
        chatbot_type: str = "General Purpose",
        personality: str = "Professional",
        supported_languages: List[str] = None,
        system_prompt: Optional[str] = None,
        max_tokens: int = 512,
        temperature: float = 0.3,
        available_actions: Optional[List[Dict[str, Any]]] = None,
        action_results: Optional[List[Dict[str, Any]]] = None, # Results from executed actions
        history: List[Dict[str, str]] = None  # Conversation history
    ) -> Optional[str]:
        """
        Generate a response using Perplexity API with RAG context.
        Now supports Custom Actions via ReAct-lite pattern.
        """
        # SEC-015: Validate inputs to prevent injection
        if not user_query or not isinstance(user_query, str):
            return "I didn't receive a valid question."
            
        if not self.enabled:
            return None
        
        # Build context from retrieved chunks
        context_text = self._format_context(context_chunks)
        
        # Extract company name from chatbot name if not provided
        if not company_name:
            company_name = chatbot_name.replace("Assistant", "").strip() or "our company"
        
        # Format supported languages
        language_names = {
            'en': 'English', 'nl': 'Dutch', 'de': 'German', 'fr': 'French', 
            'es': 'Spanish', 'it': 'Italian', 'pt': 'Portuguese', 'pl': 'Polish',
            'ru': 'Russian', 'zh': 'Chinese', 'ja': 'Japanese', 'ko': 'Korean',
            'ar': 'Arabic', 'hi': 'Hindi', 'tr': 'Turkish', 'sv': 'Swedish',
            'da': 'Danish', 'no': 'Norwegian', 'fi': 'Finnish', 'cs': 'Czech'
        }
        
        language_instruction = "Respond in the same language as the user's question."
        if supported_languages and len(supported_languages) > 0:
            lang_list = [language_names.get(lang, lang) for lang in supported_languages]
            language_instruction = f"""You MUST respond ONLY in these languages: {', '.join(lang_list)}. 
If the user writes in a language NOT in your supported list, respond with:
"I'm sorry, I can only assist you in {' and '.join(lang_list)}. Please feel free to ask your question in one of these languages, and I'll be happy to help!"
If the user's language IS in your supported list, respond in that same language."""
        
        # Import descriptions for type and personality
        from shared.constants.personality_descriptions import (
            CHATBOT_TYPE_DESCRIPTIONS,
            PERSONALITY_GUIDELINES
        )
        
        type_description = CHATBOT_TYPE_DESCRIPTIONS.get(chatbot_type, CHATBOT_TYPE_DESCRIPTIONS["General Purpose"])
        personality_guideline = PERSONALITY_GUIDELINES.get(personality, PERSONALITY_GUIDELINES["Professional"])

        # === Action Instructions ===
        action_instruction = ""
        if available_actions:
            action_desc_list = []
            for act in available_actions:
                params_desc = ", ".join([f"{p['name']} ({p['type']})" for p in (act.get('parameters') or [])])
                action_desc_list.append(f"- ID: {act['id']}\n  Name: {act['name']}\n  Description: {act['description']}\n  Parameters: {params_desc}")
            
            action_descriptions = "\n".join(action_desc_list)
            
            action_instruction = f"""
## AVAILABLE ACTIONS (TOOLS)
You have access to the following external tools/actions. Use them when the user's request requires fetching live data or performing an operation.

{action_descriptions}

## HOW TO USE ACTIONS
If you need to use an action, your response must consist ONLY of the JSON action request.
Format:
ACTION: {{ "action_id": "REPLACE_WITH_ID", "params": {{ "param_name": "param_value" }} }}

Example:
User: "Is the Deluxe Boat available on 2023-10-27?"
You: ACTION: {{ "action_id": "act_123", "params": {{ "date": "2023-10-27", "boat_type": "Deluxe" }} }}

- Do NOT provide the final answer yet if you are calling an action.
- Only call ONE action at a time.
"""

        # === Action Results Injection ===
        context_extension = ""
        if action_results:
            result_texts = []
            for res in action_results:
                result_texts.append(f"Action '{res.get('action_name')}' result: {json.dumps(res.get('result'))}")
            
            context_extension = "\n\n### ACTION RESULTS (LIVE DATA)\n" + "\n".join(result_texts)
            # Add instruction to use this data
            action_instruction += "\n\n## UPDATED CONTEXT\nI have executed the actions you requested. The results are listed below in 'ACTION RESULTS'. Use this data to answer the user's question."


        # PHASE 2: Get type-specific response formatting preferences
        from shared.constants.type_configurations import get_response_formatting
        formatting_prefs = get_response_formatting(chatbot_type)
        
        # Build formatting instructions based on type
        formatting_instructions = ""
        if formatting_prefs:
            format_type = formatting_prefs.get('format_type', 'general')
            
            if format_type == 'structured' and formatting_prefs.get('prefer_structured'):
                formatting_instructions = """
## RESPONSE FORMATTING (STRUCTURED)
- Use clear, structured responses with sections when appropriate
- Include key information in a format that's easy to scan
- Use bullet points or numbered lists for multiple items
"""
                if formatting_prefs.get('include_confirmation'):
                    formatting_instructions += "- Always include confirmation details when applicable\n"
            
            elif format_type == 'persuasive' and formatting_prefs.get('prefer_bullet_points'):
                formatting_instructions = """
## RESPONSE FORMATTING (PERSUASIVE)
- Use bullet points to highlight key benefits and features
- Emphasize value propositions clearly
- Make it easy for users to understand what they'll gain
"""
                if formatting_prefs.get('include_cta'):
                    formatting_instructions += "- Include clear calls-to-action when appropriate\n"
            
            elif format_type == 'instructional' and formatting_prefs.get('prefer_numbered_steps'):
                formatting_instructions = """
## RESPONSE FORMATTING (INSTRUCTIONAL)
- Use numbered steps for procedures and troubleshooting
- Break down complex processes into clear, sequential steps
- Use code blocks (```) for technical commands, code, or configuration
"""
                if formatting_prefs.get('include_code_blocks'):
                    formatting_instructions += "- Format code, commands, and technical content in code blocks\n"
            
            elif format_type == 'product_focused' and formatting_prefs.get('prefer_product_cards'):
                formatting_instructions = """
## RESPONSE FORMATTING (PRODUCT-FOCUSED)
- Present product information in a clear, scannable format
- Use structured sections for product details (features, specs, pricing)
- Make comparisons easy to understand when multiple products are mentioned
"""
                if formatting_prefs.get('include_comparisons'):
                    formatting_instructions += "- Use tables or structured lists for product comparisons\n"
            
            elif format_type == 'informative' and formatting_prefs.get('prefer_structured'):
                formatting_instructions = """
## RESPONSE FORMATTING (INFORMATIVE)
- Use clear, structured responses with well-organized information
- Break down complex topics into digestible sections
- Use headings and bullet points for clarity
"""
                if formatting_prefs.get('include_disclaimers'):
                    formatting_instructions += "- Include appropriate disclaimers when providing sensitive information\n"
            
            elif format_type == 'educational' and formatting_prefs.get('prefer_explanations'):
                formatting_instructions = """
## RESPONSE FORMATTING (EDUCATIONAL)
- Provide clear explanations with context
- Use examples to illustrate concepts
- Structure information in a way that supports learning
"""
                if formatting_prefs.get('include_examples'):
                    formatting_instructions += "- Include relevant examples to help understanding\n"

        # Default system prompt with STRICT RAG-ONLY enforcement
        if not system_prompt:
            system_prompt = f"""You are {chatbot_name}, a helpful and knowledgeable assistant representing {company_name}.
            
## YOUR ROLE
{type_description}
Act as a partner to the user, not just a tool. Be proactive in offering relevant details.

## COMMUNICATION STYLE
{personality_guideline}
- Be concise but friendly and warm.
- If the user's question is ambiguous, ask clarifying questions.
- Avoid robotic or overly formal language.

{formatting_instructions}

## LANGUAGE REQUIREMENT
{language_instruction}

{action_instruction}

## CRITICAL: RAG-ONLY RESPONSE POLICY
**YOU MUST STRICTLY FOLLOW THESE RULES:**

1. **ONLY use information from the REFERENCE MATERIAL provided below**
2. **NEVER use external knowledge, general knowledge, or information not in the reference material**
3. **If the reference material doesn't contain the answer, you MUST say: "I don't have that information in my knowledge base. Could you rephrase your question or ask about something else?"**
4. **DO NOT make up information, speculate, or use knowledge from outside the reference material**
5. **DO NOT search the web or use any external sources**
6. **Your responses MUST be grounded ONLY in the provided reference material**

## YOUR KNOWLEDGE (RAG CONTENT ONLY)
Here is everything you know about {company_name} (from scraped website content and manually trained data):

### REFERENCE MATERIAL (Static Knowledge - RAG ONLY)
{context_text}

{context_extension}

**REMEMBER**: If the user asks about something NOT in the reference material above, you MUST say you don't have that information. Do NOT invent answers.

## RESPONSE FORMATTING RULES
1. **Use standard Markdown** for formatting (bold, italics, lists).
2. Use bullet points (`-`) for lists. Do NOT use checkmarks (`✓`) unless specifically appropriate for a checklist.
3. Keep responses clean and easy to read.
4. Use short paragraphs (2-3 sentences max).
"""
        else:
            # Custom prompt override logic - we prepend our dynamic context with RAG-ONLY enforcement
            system_prompt = f"""{system_prompt}

## CRITICAL: RAG-ONLY RESPONSE POLICY
**YOU MUST STRICTLY FOLLOW THESE RULES:**

1. **ONLY use information from the KNOWLEDGE BASE provided below**
2. **NEVER use external knowledge, general knowledge, or information not in the knowledge base**
3. **If the knowledge base doesn't contain the answer, you MUST say: "I don't have that information in my knowledge base. Could you rephrase your question or ask about something else?"**
4. **DO NOT make up information, speculate, or use knowledge from outside the knowledge base**
5. **DO NOT search the web or use any external sources**
6. **Your responses MUST be grounded ONLY in the provided knowledge base**

KNOWLEDGE BASE (RAG CONTENT ONLY):
{context_text}
{context_extension}

**REMEMBER**: If the user asks about something NOT in the knowledge base above, you MUST say you don't have that information. Do NOT invent answers.

{action_instruction}"""

        
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            # Construct messages with history
            messages = [{"role": "system", "content": system_prompt}]
            
            if history:
                # Validate history format
                valid_history = [
                    {'role': m.get('role'), 'content': m.get('content')} 
                    for m in history 
                    if m.get('role') in ['user', 'assistant'] and m.get('content')
                ]
                messages.extend(valid_history)
                
            messages.append({"role": "user", "content": user_query})
            
            payload = {
                "model": PERPLEXITY_MODEL,
                "messages": messages,
                "max_tokens": max_tokens,
                "temperature": 0.1,  # Very low for deterministic, context-focused responses
                "disable_search": True,  # CRITICAL: Disable web search to prevent hallucinations
                "return_citations": False  # Don't return citations (we're using RAG only)
            }
            
            # STRICT RAG-ONLY: Verify we have context before making API call
            if not context_chunks or len(context_chunks) == 0:
                logger.warning("Perplexity called with empty context - this should not happen in RAG-only mode")
                return None
            
            # Use shorter timeout for better reliability (10s instead of 30s)
            # This prevents hanging requests and improves user experience
            # Add retry logic for transient failures
            from services.retry_handler import retry_with_backoff
            
            @perplexity_circuit
            @with_fallback(fallback_value=None)
            async def _make_request():
                async with httpx.AsyncClient(timeout=10.0) as client:
                    response = await client.post(
                        PERPLEXITY_BASE_URL,
                        headers=headers,
                        json=payload
                    )
                    response.raise_for_status()
                    return response.json()
            
            # Retry up to 3 times with exponential backoff
            data = await retry_with_backoff(
                _make_request,
                max_attempts=3,
                initial_delay=1.0,
                max_delay=5.0,
                exceptions=(httpx.HTTPError, httpx.TimeoutException, httpx.RequestError)
            )
            
            if data.get("choices") and len(data["choices"]) > 0:
                return data["choices"][0]["message"]["content"]
            
            return None
            
        except httpx.HTTPStatusError as e:
            print(f"Perplexity API HTTP error: {e.response.status_code} - {e.response.text}")
            return None
        except Exception as e:
            print(f"Perplexity API error: {e}")
            return None
    
    def _format_context(self, context_chunks: List[Dict[str, Any]]) -> str:
        """Format retrieved chunks into a readable context string.
        
        STRICT RAG-ONLY: Only formats content from RAG results.
        Returns explicit message if no valid RAG content is available.
        """
        if not context_chunks:
            return "No information available in the knowledge base. You MUST tell the user you don't have that information."
        
        formatted_parts = []
        for i, chunk in enumerate(context_chunks, 1):
            text = chunk.get('text', '')
            payload = chunk.get('payload', {})
            title = payload.get('title', '')
            score = chunk.get('score', 0)
            
            # Only include chunks with reasonable confidence (RAG content only)
            if score >= 0.3:
                # SEC-016: Basic sanitization to reduce injection attempts in context
                # Remove common prompt injection patterns from training data
                sanitized_text = text.replace('[[', '[').replace(']]', ']')
                sanitized_text = sanitized_text.replace('{{', '{').replace('}}', '}')
                
                if title:
                    formatted_parts.append(f"### {title}\n{sanitized_text}")
                else:
                    formatted_parts.append(sanitized_text)
        
        if not formatted_parts:
            return "No relevant information found in the knowledge base. You MUST tell the user you don't have that information and ask them to rephrase or ask about something else."
        
        return "\n\n".join(formatted_parts)
    
    def is_enabled(self) -> bool:
        """Check if Perplexity service is available."""
        return self.enabled

    async def generate_simple_reply(
        self,
        user_message: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 1024,
    ) -> Optional[str]:
        """
        Single-turn reply with no RAG context. Used e.g. for Elias tab when gateway sync is unavailable.
        """
        if not self.enabled or not user_message or not isinstance(user_message, str):
            return None
        system = (system_prompt or "You are Elias, a helpful assistant for VYBR!S. Answer concisely and clearly.").strip()
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user_message.strip()[:8000]},
        ]
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": PERPLEXITY_MODEL,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": 0.2,
        }
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(PERPLEXITY_BASE_URL, headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
            if data.get("choices") and len(data["choices"]) > 0:
                return (data["choices"][0].get("message") or {}).get("content") or None
        except Exception as e:
            logger.warning("Perplexity simple reply failed: %s", e)
        return None


# Singleton instance
perplexity_service = PerplexityService()

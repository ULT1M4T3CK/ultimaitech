"""
MFA Service for VYBR!S
Implements Time-based One-Time Password (TOTP) authentication
SOC 2 Compliance: CC5.2 (Enhanced authentication)
"""

import pyotp
import qrcode
import io
import base64
from typing import Optional, Tuple
from datetime import datetime


class MFAService:
    """Multi-Factor Authentication service using TOTP"""
    
    @staticmethod
    def generate_secret() -> str:
        """
        Generate a new TOTP secret for a user.
        
        Returns:
            Base32-encoded secret string
        """
        return pyotp.random_base32()
    
    @staticmethod
    def generate_qr_code(username: str, secret: str, issuer: str = "VYBR!S") -> str:
        """
        Generate a QR code for TOTP enrollment.
        
        Args:
            username: User's username or email
            secret: TOTP secret
            issuer: Service name
            
        Returns:
            Base64-encoded PNG image of QR code
        """
        # Create provisioning URI
        totp = pyotp.TOTP(secret)
        uri = totp.provisioning_uri(
            name=username,
            issuer_name=issuer
        )
        
        # Generate QR code
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(uri)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert to base64 for frontend display
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        img_str = base64.b64encode(buffer.getvalue()).decode()
        
        return f"data:image/png;base64,{img_str}"
    
    @staticmethod
    def verify_totp(secret: str, code: str, window: int = 1) -> bool:
        """
        Verify a TOTP code.
        
        Args:
            secret: User's TOTP secret
            code: 6-digit code from authenticator app
            window: Number of time steps to check before/after current (allows for clock drift)
            
        Returns:
            True if code is valid, False otherwise
        """
        if not secret or not code:
            return False
        
        # Remove spaces and validate format
        code = code.replace(" ", "").strip()
        if not code.isdigit() or len(code) != 6:
            return False
        
        totp = pyotp.TOTP(secret)
        return totp.verify(code, valid_window=window)
    
    @staticmethod
    def generate_backup_codes(count: int = 10) -> list[str]:
        """
        Generate backup recovery codes.
        
        Args:
            count: Number of backup codes to generate
            
        Returns:
            List of 8-character alphanumeric codes
        """
        codes = []
        for _ in range(count):
            # Generate secure random code
            code = pyotp.random_base32()[:8]
            codes.append(code)
        return codes
    
    @staticmethod
    def hash_backup_code(code: str) -> str:
        """
        Hash a backup code for storage.
        
        Args:
            code: Plain backup code
            
        Returns:
            Hashed code (using bcrypt for consistency with passwords)
        """
        from services.auth_service import get_password_hash
        return get_password_hash(code)
    
    @staticmethod
    def verify_backup_code(code: str, hashed_code: str) -> bool:
        """
        Verify a backup code against its hash.
        
        Args:
            code: User-provided backup code
            hashed_code: Stored hash
            
        Returns:
            True if match, False otherwise
        """
        from services.auth_service import verify_password
        return verify_password(code, hashed_code)


# Example usage for testing
if __name__ == "__main__":
    # Generate secret
    secret = MFAService.generate_secret()
    print(f"Secret: {secret}")
    
    # Generate QR code
    qr_code = MFAService.generate_qr_code("test@example.com", secret)
    print(f"QR Code: {qr_code[:100]}...")  # Truncated for display
    
    # Generate current TOTP
    totp = pyotp.TOTP(secret)
    current_code = totp.now()
    print(f"Current TOTP: {current_code}")
    
    # Verify code
    is_valid = MFAService.verify_totp(secret, current_code)
    print(f"Verification: {is_valid}")
    
    # Generate backup codes
    backup_codes = MFAService.generate_backup_codes()
    print(f"Backup codes: {backup_codes}")

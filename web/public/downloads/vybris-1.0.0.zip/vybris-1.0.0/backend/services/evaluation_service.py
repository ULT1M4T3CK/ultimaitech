
import numpy as np
from typing import List, Dict, Any
import logging
from services.nlp_service import nlp_service

logger = logging.getLogger(__name__)

class EvaluationService:
    def __init__(self):
        """
        Initialize evaluation service. 
        Uses the globally initialized nlp_service for embedding generation to save memory.
        """
        pass

    def calculate_cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine similarity between two vectors."""
        if not vec1 or not vec2:
            return 0.0
            
        v1 = np.array(vec1)
        v2 = np.array(vec2)
        
        dot_product = np.dot(v1, v2)
        norm_v1 = np.linalg.norm(v1)
        norm_v2 = np.linalg.norm(v2)
        
        if norm_v1 == 0 or norm_v2 == 0:
            return 0.0
            
        return float(dot_product / (norm_v1 * norm_v2))

    async def calculate_relevance(self, query: str, answer: str) -> float:
        """
        Measure Answer Relevance: How well does the answer address the query?
        Calculated as Cosine Similarity(Query, Answer).
        """
        try:
            query_embedding = nlp_service.get_embedding(query)
            answer_embedding = nlp_service.get_embedding(answer)
            return self.calculate_cosine_similarity(query_embedding, answer_embedding)
        except Exception as e:
            logger.error(f"Error calculating relevance: {e}")
            return 0.0

    async def calculate_grounding(self, answer: str, context_chunks: List[Dict[str, Any]]) -> float:
        """
        Measure Grounding (Faithfulness): How much is the answer supported by the context?
        Calculated as the maximum similarity between the answer and any of the context chunks.
        """
        if not context_chunks:
            return 0.0
            
        try:
            answer_embedding = nlp_service.get_embedding(answer)
            max_similarity = 0.0
            
            for chunk in context_chunks:
                # Get context text from chunk (fields might vary based on retriever)
                context_text = chunk.get('text', '') or chunk.get('content', '')
                if not context_text:
                    continue
                    
                context_embedding = nlp_service.get_embedding(context_text)
                similarity = self.calculate_cosine_similarity(answer_embedding, context_embedding)
                max_similarity = max(max_similarity, similarity)
                
            return max_similarity
        except Exception as e:
            logger.error(f"Error calculating grounding: {e}")
            return 0.0
    
    async def calculate_type_specific_quality_score(
        self,
        chatbot_type: str,
        query: str,
        answer: str,
        context_chunks: List[Dict[str, Any]],
        confidence: float
    ) -> Dict[str, float]:
        """
        PHASE 3: Calculate type-specific quality score using weighted metrics.
        
        Args:
            chatbot_type: Type of chatbot
            query: User query
            answer: Generated answer
            context_chunks: Context chunks used
            confidence: Retrieval confidence
        
        Returns:
            Dict with individual scores and weighted overall score
        """
        from shared.constants.type_configurations import get_evaluation_weights
        
        # Get type-specific weights
        weights = get_evaluation_weights(chatbot_type)
        
        # If no type-specific weights, use default equal weights
        if not weights:
            weights = {
                "accuracy": 0.3,
                "relevance": 0.3,
                "completeness": 0.2,
                "clarity": 0.2
            }
        
        # Calculate individual metrics
        relevance = await self.calculate_relevance(query, answer)
        grounding = await self.calculate_grounding(answer, context_chunks)
        
        # Calculate completeness (how much of the query is addressed)
        completeness = min(relevance * 1.2, 1.0)  # Slightly boost relevance as completeness proxy
        
        # Calculate clarity (simplified - based on answer length and structure)
        # Shorter, well-structured answers score higher
        answer_length = len(answer.split())
        clarity = 1.0 - min(answer_length / 200, 0.5)  # Penalize very long answers
        
        # Use grounding as accuracy proxy
        accuracy = grounding
        
        # Calculate weighted overall score
        overall_score = (
            (accuracy * weights.get("accuracy", 0.3)) +
            (relevance * weights.get("relevance", 0.3)) +
            (completeness * weights.get("completeness", 0.2)) +
            (clarity * weights.get("clarity", 0.2))
        )
        
        return {
            "overall_score": overall_score,
            "accuracy": accuracy,
            "relevance": relevance,
            "completeness": completeness,
            "clarity": clarity,
            "grounding": grounding,
            "confidence": confidence
        }

# Singleton
evaluation_service = EvaluationService()

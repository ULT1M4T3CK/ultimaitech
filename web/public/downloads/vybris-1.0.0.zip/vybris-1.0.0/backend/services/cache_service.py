"""
Response Cache Service for VYBR!S Chatbots
Thread-safe in-memory cache with TTL for frequently asked questions.
Reduces response latency by 50-90% for cache hits.
"""

import hashlib
import threading
import time
import json
import gzip
import os
from typing import Optional, Dict, Any, Tuple, List
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)

# Redis connection for distributed caching
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
redis_client = None

try:
    import redis
    redis_client = redis.from_url(
        REDIS_URL,
        decode_responses=False,  # We'll handle encoding ourselves for compression
        socket_timeout=2.0,
        socket_connect_timeout=2.0
    )
    redis_client.ping()
    logger.info(f"Redis cache connected at {REDIS_URL}")
except Exception as e:
    logger.warning(f"Redis not available for distributed cache, using in-memory only: {e}")
    redis_client = None


@dataclass
class CacheEntry:
    """A single cache entry with TTL."""
    response: Dict[str, Any]
    created_at: float
    ttl_seconds: int
    hits: int = 0
    
    def is_expired(self) -> bool:
        return time.time() > (self.created_at + self.ttl_seconds)


class ResponseCache:
    """
    Thread-safe cache for chatbot responses with Redis backend support.
    
    Features:
    - Distributed caching via Redis (with in-memory fallback)
    - Per-chatbot LRU eviction
    - Configurable TTL
    - Cache compression for large responses
    - Cache statistics for monitoring
    - Automatic cleanup of expired entries
    - Cache warming support
    """
    
    DEFAULT_TTL = 3600  # 1 hour for exact matches
    MAX_ENTRIES_PER_CHATBOT = 500  # Limit memory usage
    CLEANUP_INTERVAL = 300  # Run cleanup every 5 minutes
    COMPRESSION_THRESHOLD = 1024  # Compress responses larger than 1KB
    LOW_HIT_RATE_THRESHOLD = 0.3  # Alert if hit rate drops below 30%
    
    def __init__(
        self,
        default_ttl: int = None,
        max_entries: int = None,
        use_redis: bool = True,
        compress_large: bool = True
    ):
        self._cache: Dict[str, CacheEntry] = {}
        self._lock = threading.RLock()
        self._default_ttl = default_ttl or self.DEFAULT_TTL
        self._max_entries = max_entries or self.MAX_ENTRIES_PER_CHATBOT
        self._last_cleanup = time.time()
        self._use_redis = use_redis and redis_client is not None
        self._compress_large = compress_large
        
        # Statistics
        self._hits = 0
        self._misses = 0
        self._redis_hits = 0
        self._redis_misses = 0
        
        logger.info(
            f"Response cache initialized (TTL: {self._default_ttl}s, "
            f"max entries: {self._max_entries}, Redis: {self._use_redis}, "
            f"compression: {self._compress_large})"
        )
    
    def _generate_cache_key(self, chatbot_id: str, query: str) -> str:
        """Generate a cache key from chatbot_id and normalized query."""
        # Normalize query: lowercase, strip whitespace, remove punctuation
        normalized = query.lower().strip()
        # Remove common trailing punctuation
        for char in '?!.':
            normalized = normalized.rstrip(char)
        
        # Create hash of the normalized query
        query_hash = hashlib.sha256(normalized.encode()).hexdigest()[:16]
        return f"{chatbot_id}:{query_hash}"
    
    def get(self, chatbot_id: str, query: str) -> Optional[Dict[str, Any]]:
        """
        Get a cached response if available and not expired.
        Checks Redis first (if enabled), then in-memory cache.
        
        Returns:
            The cached response dict, or None if not found/expired
        """
        key = self._generate_cache_key(chatbot_id, query)
        
        # Try Redis first (if enabled)
        if self._use_redis:
            try:
                from shared.redis_keys import redis_key
                full_key = redis_key("cache", key)
                cached_data = redis_client.get(full_key)
                
                if cached_data:
                    # Decompress if needed
                    try:
                        if cached_data.startswith(b'\x1f\x8b'):  # gzip magic number
                            cached_data = gzip.decompress(cached_data)
                        response = json.loads(cached_data.decode())
                        self._redis_hits += 1
                        self._hits += 1
                        logger.debug(f"Redis cache HIT for chatbot {chatbot_id}")
                        return response
                    except Exception as e:
                        logger.warning(f"Error deserializing Redis cache entry: {e}")
                        # Fall through to in-memory cache
                else:
                    self._redis_misses += 1
            except Exception as e:
                logger.warning(f"Redis cache read error: {e}, falling back to in-memory")
        
        # Try in-memory cache
        with self._lock:
            self._maybe_cleanup()
            
            entry = self._cache.get(key)
            if entry is None:
                self._misses += 1
                return None
            
            if entry.is_expired():
                del self._cache[key]
                self._misses += 1
                return None
            
            # Cache hit!
            entry.hits += 1
            self._hits += 1
            logger.debug(f"Memory cache HIT for chatbot {chatbot_id}, query hash: {key[-16:]}")
            
            return entry.response
    
    def set(
        self, 
        chatbot_id: str, 
        query: str, 
        response: Dict[str, Any],
        ttl_seconds: int = None
    ) -> None:
        """
        Cache a response in both Redis (if enabled) and in-memory cache.
        
        Args:
            chatbot_id: The chatbot ID
            query: The original query text
            response: The response to cache (must be JSON-serializable)
            ttl_seconds: Optional custom TTL (uses default if not specified)
        """
        key = self._generate_cache_key(chatbot_id, query)
        ttl = ttl_seconds or self._default_ttl
        
        # Serialize response
        try:
            serialized = json.dumps(response).encode()
            
            # Compress if large and compression enabled
            if self._compress_large and len(serialized) > self.COMPRESSION_THRESHOLD:
                serialized = gzip.compress(serialized)
                logger.debug(f"Compressed cache entry (saved {len(json.dumps(response).encode()) - len(serialized)} bytes)")
        except Exception as e:
            logger.error(f"Error serializing response for cache: {e}")
            return
        
        # Store in Redis (if enabled)
        if self._use_redis:
            try:
                from shared.redis_keys import redis_key
                full_key = redis_key("cache", key)
                redis_client.setex(full_key, ttl, serialized)
            except Exception as e:
                logger.warning(f"Redis cache write error: {e}")
        
        # Store in-memory (always, as fallback)
        with self._lock:
            # Check if we need to evict for this chatbot
            self._evict_if_needed(chatbot_id)
            
            self._cache[key] = CacheEntry(
                response=response.copy(),  # Store a copy
                created_at=time.time(),
                ttl_seconds=ttl
            )
            
        logger.debug(f"Cached response for chatbot {chatbot_id}, TTL: {ttl}s")
    
    def invalidate(self, chatbot_id: str, pattern: Optional[str] = None) -> int:
        """
        Invalidate cache entries for a specific chatbot.
        Supports pattern-based invalidation for smarter cache management.
        
        Args:
            chatbot_id: The chatbot ID
            pattern: Optional pattern to match (e.g., "pricing*" to invalidate pricing queries)
        
        Returns:
            Number of entries invalidated
        """
        prefix = f"{chatbot_id}:"
        removed = 0
        
        # Invalidate in Redis
        if self._use_redis:
            try:
                from shared.redis_keys import REDIS_KEY_PREFIX
                cache_prefix = f"{REDIS_KEY_PREFIX}:cache:{prefix}"
                if pattern:
                    # Pattern-based invalidation
                    redis_pattern = f"{cache_prefix}*{pattern}*"
                    keys = redis_client.keys(redis_pattern)
                    if keys:
                        removed += redis_client.delete(*keys)
                else:
                    # Invalidate all for chatbot
                    redis_pattern = f"{cache_prefix}*"
                    keys = redis_client.keys(redis_pattern)
                    if keys:
                        removed += redis_client.delete(*keys)
            except Exception as e:
                logger.warning(f"Redis cache invalidation error: {e}")
        
        # Invalidate in-memory
        with self._lock:
            if pattern:
                # Pattern-based invalidation
                keys_to_remove = [
                    k for k in self._cache
                    if k.startswith(prefix) and pattern in k
                ]
            else:
                # Invalidate all for chatbot
                keys_to_remove = [k for k in self._cache if k.startswith(prefix)]
            
            for key in keys_to_remove:
                del self._cache[key]
                removed += 1
        
        if removed > 0:
            logger.info(f"Invalidated {removed} cache entries for chatbot {chatbot_id}" + (f" (pattern: {pattern})" if pattern else ""))
        
        return removed
    
    def _evict_if_needed(self, chatbot_id: str) -> None:
        """Evict oldest entries if chatbot has too many cached entries."""
        prefix = f"{chatbot_id}:"
        chatbot_entries = [(k, v) for k, v in self._cache.items() if k.startswith(prefix)]
        
        if len(chatbot_entries) >= self._max_entries:
            # Sort by created_at and remove oldest 10%
            chatbot_entries.sort(key=lambda x: x[1].created_at)
            to_remove = max(1, len(chatbot_entries) // 10)
            
            for i in range(to_remove):
                key = chatbot_entries[i][0]
                del self._cache[key]
            
            logger.debug(f"Evicted {to_remove} old entries for chatbot {chatbot_id}")
    
    def _maybe_cleanup(self) -> None:
        """Periodically clean up expired entries."""
        now = time.time()
        if now - self._last_cleanup < self.CLEANUP_INTERVAL:
            return
        
        self._last_cleanup = now
        expired_keys = [k for k, v in self._cache.items() if v.is_expired()]
        
        for key in expired_keys:
            del self._cache[key]
        
        if expired_keys:
            logger.debug(f"Cleaned up {len(expired_keys)} expired cache entries")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics for monitoring."""
        with self._lock:
            total_entries = len(self._cache)
            chatbots = set(k.split(':')[0] for k in self._cache)
            
            total_requests = self._hits + self._misses
            hit_rate = self._hits / max(1, total_requests)
            
            stats = {
                'total_entries': total_entries,
                'chatbots_cached': len(chatbots),
                'hits': self._hits,
                'misses': self._misses,
                'hit_rate': hit_rate,
                'default_ttl_seconds': self._default_ttl,
                'redis_enabled': self._use_redis,
                'compression_enabled': self._compress_large
            }
            
            if self._use_redis:
                stats.update({
                    'redis_hits': self._redis_hits,
                    'redis_misses': self._redis_misses,
                    'redis_hit_rate': self._redis_hits / max(1, self._redis_hits + self._redis_misses)
                })
            
            # Check for low hit rate
            if hit_rate < self.LOW_HIT_RATE_THRESHOLD and total_requests > 100:
                stats['warning'] = f"Low hit rate: {hit_rate:.2%} (threshold: {self.LOW_HIT_RATE_THRESHOLD:.0%})"
            
            return stats
    
    def warm_cache(self, chatbot_id: str, common_queries: List[Tuple[str, Dict[str, Any]]], ttl: Optional[int] = None):
        """
        Pre-populate cache with common queries (cache warming).
        
        Args:
            chatbot_id: The chatbot ID
            common_queries: List of (query, response) tuples to pre-cache
            ttl: Optional TTL for warmed entries (uses default if not specified)
        """
        warmed = 0
        for query, response in common_queries:
            try:
                self.set(chatbot_id, query, response, ttl_seconds=ttl)
                warmed += 1
            except Exception as e:
                logger.warning(f"Error warming cache for query: {e}")
        
        logger.info(f"Warmed cache with {warmed} entries for chatbot {chatbot_id}")
        return warmed
    
    def clear(self) -> None:
        """Clear all cache entries."""
        with self._lock:
            self._cache.clear()
            logger.info("Cache cleared")


# Singleton instance
response_cache = ResponseCache()

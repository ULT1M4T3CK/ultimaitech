"""
Workflow Trigger Service
Evaluates workflow triggers and runs matching workflows on CRM/automation events.
"""

import asyncio
import logging
from typing import Dict, Any, List

from services.database import WorkflowDB, ChatbotDB
from services.workflow_engine import run_workflow

logger = logging.getLogger(__name__)


def get_workflows_for_trigger(chatbot_id: str, event_type: str) -> List[Dict[str, Any]]:
    """
    Get enabled workflows for a chatbot that have a matching trigger.
    Triggers format: [{"type": "stage_change", "config": {"target_stage": "..."}}, ...]
    """
    workflows = WorkflowDB.get_by_chatbot(chatbot_id, enabled_only=True)
    matching = []
    for wf in workflows:
        triggers = wf.get("triggers") or []
        for t in triggers:
            if isinstance(t, dict) and t.get("type") == event_type:
                matching.append(wf)
                break
    return matching


def _trigger_matches(trigger: Dict[str, Any], event_type: str, context: Dict[str, Any]) -> bool:
    """Check if a trigger matches the event and context."""
    t_type = trigger.get("type")
    if t_type != event_type:
        return False
    config = trigger.get("config") or {}
    if event_type == "stage_change":
        target = config.get("target_stage") or config.get("stage_id")
        if target and context.get("new_stage") != target:
            return False
    elif event_type == "score_threshold":
        threshold = config.get("threshold", 0)
        direction = config.get("direction", "above")
        score = context.get("qualification_score", 0)
        if direction == "above" and score < threshold:
            return False
        if direction == "below" and score > threshold:
            return False
    elif event_type == "lead_created":
        pass  # Always match
    elif event_type == "time_in_stage":
        days = config.get("days", 0)
        if days > 0 and context.get("days_in_stage", 0) < days:
            return False
    elif event_type == "lead_tier_change":
        target_tier = config.get("target_tier")
        if target_tier and context.get("new_tier") != target_tier:
            return False
    elif event_type == "on_user_intent":
        target_intent = config.get("intent") or config.get("target_intent")
        if target_intent and context.get("intent") != target_intent:
            return False
    elif event_type == "on_handoff":
        pass  # Always match when handoff requested
    elif event_type == "on_sentiment":
        target = config.get("sentiment", "negative")
        if context.get("sentiment") != target:
            return False
    return True


async def evaluate_triggers(
    chatbot_id: str,
    event_type: str,
    context: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """
    Evaluate workflows for a chatbot and run those whose triggers match.
    Returns list of run results.
    """
    workflows = get_workflows_for_trigger(chatbot_id, event_type)
    results = []
    for wf in workflows:
        triggers = wf.get("triggers") or []
        matched = False
        for t in triggers:
            if isinstance(t, dict) and _trigger_matches(t, event_type, context):
                matched = True
                break
        if not matched:
            continue
        try:
            result = await run_workflow(wf["id"], chatbot_id, context)
            results.append({"workflow_id": wf["id"], "workflow_name": wf.get("name"), "result": result})
            logger.info(f"Workflow {wf['id']} executed for {event_type}: {result}")
        except Exception as e:
            logger.error(f"Workflow {wf['id']} failed: {e}")
            results.append({"workflow_id": wf["id"], "result": {"success": False, "error": str(e)}})
    return results


async def evaluate_triggers_for_owner(
    owner_id: str,
    event_type: str,
    context: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """
    Evaluate workflows for all chatbots owned by owner_id.
    Used when lead's account_owner_id is known but not chatbot_id.
    """
    chatbots = ChatbotDB.get_by_owner_ids([owner_id])
    all_results = []
    for bot in chatbots:
        cid = bot.get("id")
        if cid:
            results = await evaluate_triggers(cid, event_type, context)
            all_results.extend(results)
    return all_results

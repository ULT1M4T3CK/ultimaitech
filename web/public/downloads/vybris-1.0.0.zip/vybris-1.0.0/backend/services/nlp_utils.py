"""
NLP Utility Functions
Context window management, confidence calibration, and response quality tracking.
"""

import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging
from collections import defaultdict

logger = logging.getLogger(__name__)


@dataclass
class ContextChunk:
    """Represents a chunk of context with metadata."""
    content: str
    score: float
    source: str
    metadata: Dict[str, Any]
    estimated_tokens: int = 0


class ContextWindowManager:
    """
    Manages context window size intelligently for LLM prompts.
    
    Features:
    - Token-aware truncation (not just character count)
    - Priority-based chunk selection (higher scores first)
    - Semantic chunk boundaries (avoids cutting mid-sentence)
    - Configurable token limits
    """
    
    # Rough token estimation: ~4 characters per token for English
    CHARS_PER_TOKEN = 4
    
    def __init__(self, max_tokens: int = 2000, reserve_tokens: int = 200):
        """
        Initialize context window manager.
        
        Args:
            max_tokens: Maximum tokens for context
            reserve_tokens: Tokens to reserve for system prompt, user query, etc.
        """
        self.max_tokens = max_tokens
        self.reserve_tokens = reserve_tokens
        self.available_tokens = max_tokens - reserve_tokens
    
    def estimate_tokens(self, text: str) -> int:
        """
        Estimate token count for text.
        Uses character-based estimation (rough but fast).
        For more accuracy, could use actual tokenizer.
        """
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text.strip())
        # Rough estimate: ~4 chars per token
        return len(text) // self.CHARS_PER_TOKEN
    
    def truncate_intelligently(self, text: str, max_tokens: int) -> str:
        """
        Truncate text at semantic boundaries (sentence/paragraph).
        
        Args:
            text: Text to truncate
            max_tokens: Maximum tokens allowed
        
        Returns:
            Truncated text
        """
        max_chars = max_tokens * self.CHARS_PER_TOKEN
        
        if len(text) <= max_chars:
            return text
        
        # Try to truncate at sentence boundary
        truncated = text[:max_chars]
        
        # Find last sentence boundary
        sentence_end = max(
            truncated.rfind('. '),
            truncated.rfind('.\n'),
            truncated.rfind('! '),
            truncated.rfind('? '),
            truncated.rfind('\n\n')  # Paragraph break
        )
        
        if sentence_end > max_chars * 0.7:  # Only use if we keep at least 70%
            return text[:sentence_end + 1].strip()
        
        # Fallback: truncate at word boundary
        word_end = truncated.rfind(' ')
        if word_end > max_chars * 0.8:
            return text[:word_end].strip() + "..."
        
        return truncated.strip() + "..."
    
    def build_context(
        self,
        chunks: List[ContextChunk],
        prioritize_by_score: bool = True
    ) -> Tuple[str, int]:
        """
        Build context string from chunks, respecting token limits.
        
        Args:
            chunks: List of context chunks
            prioritize_by_score: If True, include higher-scoring chunks first
        
        Returns:
            Tuple of (context_string, tokens_used)
        """
        if prioritize_by_score:
            chunks = sorted(chunks, key=lambda c: c.score, reverse=True)
        
        context_parts = []
        tokens_used = 0
        
        for chunk in chunks:
            # Estimate tokens for this chunk
            chunk_tokens = chunk.estimated_tokens or self.estimate_tokens(chunk.content)
            
            if tokens_used + chunk_tokens > self.available_tokens:
                # Truncate this chunk to fit
                remaining_tokens = self.available_tokens - tokens_used
                if remaining_tokens > 50:  # Only include if we have meaningful space
                    truncated = self.truncate_intelligently(chunk.content, remaining_tokens)
                    context_parts.append(truncated)
                    tokens_used += self.estimate_tokens(truncated)
                break
            
            context_parts.append(chunk.content)
            tokens_used += chunk_tokens
        
        context = "\n\n".join(context_parts)
        return context, tokens_used


class ConfidenceCalibrator:
    """
    Calibrates confidence scores based on historical accuracy.
    
    Tracks:
    - Predicted confidence vs actual user feedback
    - Per-chatbot calibration curves
    - Adjusts scores to better reflect true accuracy
    """
    
    def __init__(self):
        # Store: {chatbot_id: {confidence_range: (total, correct)}}
        self.history: Dict[str, Dict[str, Tuple[int, int]]] = defaultdict(lambda: defaultdict(lambda: (0, 0)))
    
    def record_prediction(
        self,
        chatbot_id: str,
        predicted_confidence: float,
        was_correct: bool
    ):
        """
        Record a prediction and its outcome for calibration.
        
        Args:
            chatbot_id: ID of the chatbot
            predicted_confidence: Original confidence score (0-1)
            was_correct: Whether the prediction was correct (based on user feedback)
        """
        # Bin confidence into ranges for tracking
        confidence_bin = self._bin_confidence(predicted_confidence)
        
        total, correct = self.history[chatbot_id][confidence_bin]
        self.history[chatbot_id][confidence_bin] = (total + 1, correct + (1 if was_correct else 0))
    
    def _bin_confidence(self, confidence: float) -> str:
        """Bin confidence into ranges."""
        if confidence >= 0.9:
            return "0.9-1.0"
        elif confidence >= 0.75:
            return "0.75-0.9"
        elif confidence >= 0.5:
            return "0.5-0.75"
        elif confidence >= 0.3:
            return "0.3-0.5"
        else:
            return "0.0-0.3"
    
    def calibrate_confidence(
        self,
        chatbot_id: str,
        raw_confidence: float
    ) -> float:
        """
        Calibrate a confidence score based on historical accuracy.
        
        Args:
            chatbot_id: ID of the chatbot
            raw_confidence: Original confidence score
        
        Returns:
            Calibrated confidence score
        """
        chatbot_history = self.history.get(chatbot_id, {})
        
        if not chatbot_history:
            # No history, return original
            return raw_confidence
        
        # Find the bin for this confidence
        confidence_bin = self._bin_confidence(raw_confidence)
        total, correct = chatbot_history.get(confidence_bin, (0, 0))
        
        if total < 10:
            # Not enough data, return original
            return raw_confidence
        
        # Calculate actual accuracy for this confidence range
        actual_accuracy = correct / total if total > 0 else 0.5
        
        # Adjust confidence towards actual accuracy (weighted average)
        # Weight actual accuracy more as we get more data
        weight = min(total / 100, 0.7)  # Max 70% weight on history
        calibrated = (1 - weight) * raw_confidence + weight * actual_accuracy
        
        return min(max(calibrated, 0.0), 1.0)  # Clamp to [0, 1]
    
    def get_calibration_stats(self, chatbot_id: str) -> Dict[str, Any]:
        """Get calibration statistics for a chatbot."""
        chatbot_history = self.history.get(chatbot_id, {})
        
        if not chatbot_history:
            return {"status": "no_data", "bins": {}}
        
        stats = {}
        for bin_range, (total, correct) in chatbot_history.items():
            stats[bin_range] = {
                "total": total,
                "correct": correct,
                "accuracy": correct / total if total > 0 else 0
            }
        
        return {"status": "calibrated", "bins": stats}


class ResponseQualityTracker:
    """
    Tracks response quality metrics for continuous improvement.
    
    Metrics:
    - User feedback (thumbs up/down)
    - Response time
    - Confidence scores
    - Source relevance
    - User engagement (follow-up questions, session length)
    """
    
    def __init__(self):
        # Store metrics: {chatbot_id: [metrics]}
        self.metrics: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    
    def record_response(
        self,
        chatbot_id: str,
        query: str,
        response: str,
        confidence: float,
        sources: List[Dict[str, Any]],
        processing_time_ms: float,
        session_id: Optional[str] = None
    ):
        """
        Record a response for quality tracking.
        
        Args:
            chatbot_id: ID of the chatbot
            query: User query
            response: Generated response
            confidence: Confidence score
            sources: List of source chunks used
            processing_time_ms: Processing time in milliseconds
            session_id: Optional session ID
        """
        metric = {
            "timestamp": datetime.utcnow().isoformat(),
            "query": query[:200],  # Truncate for storage
            "response_length": len(response),
            "confidence": confidence,
            "num_sources": len(sources),
            "avg_source_score": sum(s.get("score", 0) for s in sources) / len(sources) if sources else 0,
            "processing_time_ms": processing_time_ms,
            "session_id": session_id,
            "user_feedback": None,  # Set later via record_feedback
            "was_helpful": None
        }
        
        self.metrics[chatbot_id].append(metric)
        
        # Keep only last 1000 metrics per chatbot
        if len(self.metrics[chatbot_id]) > 1000:
            self.metrics[chatbot_id] = self.metrics[chatbot_id][-1000:]
    
    def record_feedback(
        self,
        chatbot_id: str,
        session_id: str,
        was_helpful: bool,
        feedback_text: Optional[str] = None
    ):
        """
        Record user feedback for a response.
        
        Args:
            chatbot_id: ID of the chatbot
            session_id: Session ID to match response
            was_helpful: Whether the response was helpful
            feedback_text: Optional feedback text
        """
        # Find most recent response for this session
        chatbot_metrics = self.metrics.get(chatbot_id, [])
        
        for metric in reversed(chatbot_metrics):
            if metric.get("session_id") == session_id:
                metric["user_feedback"] = feedback_text
                metric["was_helpful"] = was_helpful
                break
    
    def get_quality_stats(self, chatbot_id: str, days: int = 30) -> Dict[str, Any]:
        """
        Get quality statistics for a chatbot.
        
        Args:
            chatbot_id: ID of the chatbot
            days: Number of days to analyze
        
        Returns:
            Dictionary with quality metrics
        """
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        chatbot_metrics = self.metrics.get(chatbot_id, [])
        
        # Filter by date
        recent_metrics = [
            m for m in chatbot_metrics
            if datetime.fromisoformat(m["timestamp"]) >= cutoff_date
        ]
        
        if not recent_metrics:
            return {"status": "no_data", "period_days": days}
        
        # Calculate statistics
        total_responses = len(recent_metrics)
        feedback_count = sum(1 for m in recent_metrics if m.get("was_helpful") is not None)
        helpful_count = sum(1 for m in recent_metrics if m.get("was_helpful") is True)
        
        avg_confidence = sum(m["confidence"] for m in recent_metrics) / total_responses
        avg_processing_time = sum(m["processing_time_ms"] for m in recent_metrics) / total_responses
        avg_sources = sum(m["num_sources"] for m in recent_metrics) / total_responses
        
        return {
            "status": "active",
            "period_days": days,
            "total_responses": total_responses,
            "avg_confidence": round(avg_confidence, 3),
            "avg_processing_time_ms": round(avg_processing_time, 2),
            "avg_sources_per_response": round(avg_sources, 1),
            "feedback_count": feedback_count,
            "helpful_count": helpful_count,
            "helpful_rate": round(helpful_count / feedback_count, 3) if feedback_count > 0 else None
        }


# Singleton instances
context_window_manager = ContextWindowManager()
confidence_calibrator = ConfidenceCalibrator()
response_quality_tracker = ResponseQualityTracker()

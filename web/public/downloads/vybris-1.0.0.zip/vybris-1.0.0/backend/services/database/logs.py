"""
Log Database Operations
Handles all database operations for system logs
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from datetime import datetime
from .base import get_db_connection


def _row_to_log(row: Dict) -> Dict[str, Any]:
    """Convert database row to log dict"""
    return {
        'id': row['id'],
        'timestamp': row['timestamp'].isoformat() if hasattr(row['timestamp'], 'isoformat') else row['timestamp'],
        'level': row['level'],
        'service': row['service'],
        'user_id': row['user_id'],
        'chatbot_id': row['chatbot_id'],
        'action': row['action'],
        'message': row['message'],
        'metadata': row['metadata'] if isinstance(row['metadata'], dict) else json.loads(row['metadata'] or '{}')
    }


class LogDB:
    """Database operations for logs"""
    
    # SEC-013: Sensitive fields that should never be logged
    SENSITIVE_FIELDS = {
        'password', 'hashed_password', 'token', 'access_token', 'refresh_token',
        'api_key', 'secret', 'credit_card', 'ssn', 'authorization',
        'jwt', 'bearer', 'cookie', 'session', 'private_key'
    }
    
    @staticmethod
    def sanitize_metadata(metadata: Dict[str, Any]) -> Dict[str, Any]:
        """SEC-013: Remove sensitive fields from log metadata"""
        if not metadata:
            return {}
        
        sanitized = {}
        for key, value in metadata.items():
            # Check if key contains sensitive terms
            key_lower = key.lower()
            is_sensitive = any(sensitive in key_lower for sensitive in LogDB.SENSITIVE_FIELDS)
            
            if is_sensitive:
                sanitized[key] = "[REDACTED]"
            elif isinstance(value, dict):
                # Recursively sanitize nested dicts
                sanitized[key] = LogDB.sanitize_metadata(value)
            elif isinstance(value, str) and len(value) > 100:
                # Truncate very long strings
                sanitized[key] = value[:100] + "...[truncated]"
            else:
                sanitized[key] = value
        
        return sanitized
    
    @staticmethod
    def create(log_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new log entry"""
        log_id = log_data.get('id', f"log_{uuid.uuid4().hex[:12]}")
        
        # SEC-013: Sanitize metadata before storing
        sanitized_metadata = LogDB.sanitize_metadata(log_data.get('metadata', {}))
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO logs (id, timestamp, level, service, user_id, chatbot_id, action, message, metadata)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
            ''', (
                log_id,
                log_data.get('timestamp', datetime.utcnow()),
                log_data['level'],
                log_data['service'],
                log_data.get('user_id'),
                log_data.get('chatbot_id'),
                log_data.get('action'),
                log_data['message'],
                json.dumps(sanitized_metadata)
            ))
            conn.commit()
            row = cursor.fetchone()
            return dict(row) if row else None
    
    @staticmethod
    def get_all(limit: int = 100, offset: int = 0, level: str = None, service: str = None, chatbot_id: str = None) -> List[Dict[str, Any]]:
        """Get logs with filtering"""
        query = 'SELECT * FROM logs WHERE 1=1'
        params = []
        
        if level:
            query += ' AND level = %s'
            params.append(level)
        if service:
            query += ' AND service = %s'
            params.append(service)
        if chatbot_id:
            query += ' AND chatbot_id = %s'
            params.append(chatbot_id)
        
        query += ' ORDER BY timestamp DESC LIMIT %s OFFSET %s'
        params.extend([limit, offset])
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            return [_row_to_log(row) for row in cursor.fetchall()]
    
    @staticmethod
    def count(level: str = None, service: str = None) -> int:
        """Count logs with filtering"""
        query = 'SELECT COUNT(*) as count FROM logs WHERE 1=1'
        params = []
        
        if level:
            query += ' AND level = %s'
            params.append(level)
        if service:
            query += ' AND service = %s'
            params.append(service)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            row = cursor.fetchone()
            return row['count'] if row else 0
    
    @staticmethod
    def clear_all() -> int:
        """Clear all logs"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM logs')
            conn.commit()
            return cursor.rowcount

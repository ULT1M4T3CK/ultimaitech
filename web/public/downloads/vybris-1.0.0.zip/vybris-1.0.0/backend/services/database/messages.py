"""
Message Database Operations
Handles all database operations for chat messages
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from datetime import datetime
from .base import get_db_connection


class MessageDB:
    """Database operations for chat messages"""
    
    @staticmethod
    def create(message_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new message record"""
        msg_id = message_data.get('id') or str(uuid.uuid4())
        is_unknown = message_data.get('is_unknown', False)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO chat_messages 
                (id, session_id, chatbot_id, role, content, intent, confidence, is_unknown, metadata)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
            ''', (
                msg_id,
                message_data['session_id'],
                message_data['chatbot_id'],
                message_data['role'],
                message_data['content'],
                message_data.get('intent'),
                message_data.get('confidence'),
                is_unknown,
                json.dumps(message_data.get('metadata', {}))
            ))
            conn.commit()
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['metadata'] = result['metadata'] if isinstance(result['metadata'], dict) else json.loads(result.get('metadata') or '{}')
                return result
            return None

    @staticmethod
    def get_by_session(session_id: str, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Get all messages for a session"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM chat_messages 
                WHERE session_id = %s 
                ORDER BY created_at ASC
                LIMIT %s OFFSET %s
            ''', (session_id, limit, offset))
            rows = cursor.fetchall()
            results = []
            for row in rows:
                result = dict(row)
                result['metadata'] = result['metadata'] if isinstance(result['metadata'], dict) else json.loads(result.get('metadata') or '{}')
                results.append(result)
            return results

    @staticmethod
    def get_by_session_since(
        session_id: str,
        since: Optional[datetime] = None,
        limit: int = 200
    ) -> List[Dict[str, Any]]:
        """Get messages for a session after a timestamp"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            if since:
                cursor.execute('''
                    SELECT * FROM chat_messages
                    WHERE session_id = %s AND created_at > %s
                    ORDER BY created_at ASC
                    LIMIT %s
                ''', (session_id, since, limit))
            else:
                cursor.execute('''
                    SELECT * FROM chat_messages
                    WHERE session_id = %s
                    ORDER BY created_at ASC
                    LIMIT %s
                ''', (session_id, limit))
            rows = cursor.fetchall()
            results = []
            for row in rows:
                result = dict(row)
                result['metadata'] = result['metadata'] if isinstance(result['metadata'], dict) else json.loads(result.get('metadata') or '{}')
                results.append(result)
            return results

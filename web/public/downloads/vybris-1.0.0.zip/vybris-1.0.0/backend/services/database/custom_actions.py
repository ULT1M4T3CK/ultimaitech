"""
Custom Action Database Operations
Handles all database operations for custom actions
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


class CustomActionDB:
    """Database operations for custom actions"""
    
    @staticmethod
    def create(action_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new custom action"""
        action_id = action_data.get('id') or f"action_{uuid.uuid4().hex[:12]}"
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO custom_actions (
                    id, chatbot_id, name, description, url_template, method, 
                    headers, parameters, enabled
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
            ''', (
                action_id,
                action_data['chatbot_id'],
                action_data['name'],
                action_data.get('description'),
                action_data['url_template'],
                action_data.get('method', 'POST'),
                json.dumps(action_data.get('headers', {})),
                json.dumps(action_data.get('parameters', [])),
                action_data.get('enabled', True)
            ))
            conn.commit()
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['headers'] = result['headers'] if isinstance(result.get('headers'), dict) else json.loads(result.get('headers') or '{}')
                result['parameters'] = result['parameters'] if isinstance(result.get('parameters'), list) else json.loads(result.get('parameters') or '[]')
                return result
            return None

    @staticmethod
    def get_by_chatbot(chatbot_id: str) -> List[Dict[str, Any]]:
        """Get all custom actions for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM custom_actions 
                WHERE chatbot_id = %s 
                ORDER BY created_at DESC
            ''', (chatbot_id,))
            rows = cursor.fetchall()
            results = []
            for row in rows:
                result = dict(row)
                result['headers'] = result['headers'] if isinstance(result.get('headers'), dict) else json.loads(result.get('headers') or '{}')
                result['parameters'] = result['parameters'] if isinstance(result.get('parameters'), list) else json.loads(result.get('parameters') or '[]')
                results.append(result)
            return results

    @staticmethod
    def get_active_by_chatbot(chatbot_id: str) -> List[Dict[str, Any]]:
        """Get active custom actions for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM custom_actions 
                WHERE chatbot_id = %s AND enabled = TRUE
                ORDER BY created_at DESC
            ''', (chatbot_id,))
            rows = cursor.fetchall()
            results = []
            for row in rows:
                result = dict(row)
                result['headers'] = result['headers'] if isinstance(result.get('headers'), dict) else json.loads(result.get('headers') or '{}')
                result['parameters'] = result['parameters'] if isinstance(result.get('parameters'), list) else json.loads(result.get('parameters') or '[]')
                results.append(result)
            return results

    @staticmethod
    def get_by_id(action_id: str) -> Optional[Dict[str, Any]]:
        """Get a single custom action by ID"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM custom_actions WHERE id = %s', (action_id,))
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['headers'] = result['headers'] if isinstance(result.get('headers'), dict) else json.loads(result.get('headers') or '{}')
                result['parameters'] = result['parameters'] if isinstance(result.get('parameters'), list) else json.loads(result.get('parameters') or '[]')
                return result
            return None

    @staticmethod
    def update(action_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a custom action"""
        allowed_fields = ['name', 'description', 'url_template', 'method', 'headers', 'parameters', 'enabled']
        set_clauses = ['updated_at = NOW()']
        values = []
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                val = updates[field]
                if field in ['headers', 'parameters'] and isinstance(val, (dict, list)):
                    val = json.dumps(val)
                values.append(val)
        
        if len(set_clauses) == 1:  # Only updated_at
            return CustomActionDB.get_by_id(action_id)
        
        values.append(action_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f'''
                UPDATE custom_actions SET {", ".join(set_clauses)}
                WHERE id = %s
                RETURNING *
            ''', values)
            conn.commit()
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['headers'] = result['headers'] if isinstance(result.get('headers'), dict) else json.loads(result.get('headers') or '{}')
                result['parameters'] = result['parameters'] if isinstance(result.get('parameters'), list) else json.loads(result.get('parameters') or '[]')
                return result
            return None

    @staticmethod
    def delete(action_id: str) -> bool:
        """Delete a custom action"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM custom_actions WHERE id = %s', (action_id,))
            conn.commit()
            return cursor.rowcount > 0

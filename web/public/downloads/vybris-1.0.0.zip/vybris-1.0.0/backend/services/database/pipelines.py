"""
Pipeline Database Operations
Handles all database operations for pipeline stages
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


class PipelineDB:
    """Database operations for pipeline stages"""
    
    DEFAULT_STAGES = [
        {"stage_name": "New", "stage_key": "new", "stage_order": 1, "stage_color": "#6366f1"},
        {"stage_name": "Interested", "stage_key": "interested", "stage_order": 2, "stage_color": "#8b5cf6"},
        {"stage_name": "Qualified", "stage_key": "qualified", "stage_order": 3, "stage_color": "#a855f7"},
        {"stage_name": "Proposal", "stage_key": "proposal", "stage_order": 4, "stage_color": "#d946ef"},
        {"stage_name": "Negotiation", "stage_key": "negotiation", "stage_order": 5, "stage_color": "#ec4899"},
        {"stage_name": "Won", "stage_key": "won", "stage_order": 6, "stage_color": "#22c55e", "is_win_stage": True},
        {"stage_name": "Lost", "stage_key": "lost", "stage_order": 7, "stage_color": "#ef4444", "is_loss_stage": True},
    ]
    
    @staticmethod
    def create(chatbot_id: str, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new pipeline"""
        pipeline_id = pipeline_data.get('id') or str(uuid.uuid4())
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO pipelines (id, chatbot_id, name, stages)
                VALUES (%s, %s, %s, %s)
                RETURNING *
            ''', (
                pipeline_id,
                chatbot_id,
                pipeline_data.get('name', 'Default Pipeline'),
                json.dumps(pipeline_data.get('stages', PipelineDB.DEFAULT_STAGES))
            ))
            conn.commit()
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['stages'] = result['stages'] if isinstance(result['stages'], list) else json.loads(result.get('stages') or '[]')
                return result
            return None
    
    @staticmethod
    def get_by_chatbot(chatbot_id: str) -> Optional[Dict[str, Any]]:
        """Get pipeline for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM pipelines WHERE chatbot_id = %s ORDER BY created_at DESC LIMIT 1',
                (chatbot_id,)
            )
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['stages'] = result['stages'] if isinstance(result['stages'], list) else json.loads(result.get('stages') or '[]')
                return result
            return None
    
    @staticmethod
    def get_by_id(pipeline_id: str) -> Optional[Dict[str, Any]]:
        """Get a pipeline by ID"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM pipelines WHERE id = %s', (pipeline_id,))
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['stages'] = result['stages'] if isinstance(result['stages'], list) else json.loads(result.get('stages') or '[]')
                return result
            return None
    
    @staticmethod
    def update(pipeline_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a pipeline"""
        allowed_fields = ['name', 'stages']
        set_clauses = ['updated_at = NOW()']
        values = []
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                if field == 'stages':
                    values.append(json.dumps(updates[field]))
                else:
                    values.append(updates[field])
        
        if len(set_clauses) == 1:  # Only updated_at
            return PipelineDB.get_by_id(pipeline_id)
        
        values.append(pipeline_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f'''
                UPDATE pipelines SET {", ".join(set_clauses)}
                WHERE id = %s
                RETURNING *
            ''', values)
            conn.commit()
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['stages'] = result['stages'] if isinstance(result['stages'], list) else json.loads(result.get('stages') or '[]')
                return result
            return None
    
    @staticmethod
    def delete(pipeline_id: str) -> bool:
        """Delete a pipeline"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM pipelines WHERE id = %s', (pipeline_id,))
            conn.commit()
            return cursor.rowcount > 0

"""
Training Job Database Operations
Handles all database operations for training jobs
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


class TrainingJobDB:
    """Database operations for training jobs"""
    
    @staticmethod
    def create(job_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new training job"""
        job_id = job_data.get('id', f"job_{uuid.uuid4().hex[:12]}")
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO training_jobs (id, chatbot_id, status, started_at, metadata)
                VALUES (%s, %s, %s, NOW(), %s)
                RETURNING *
            ''', (
                job_id,
                job_data['chatbot_id'],
                job_data.get('status', 'pending'),
                json.dumps(job_data.get('metadata', {}))
            ))
            conn.commit()
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['metadata'] = result['metadata'] if isinstance(result['metadata'], dict) else json.loads(result.get('metadata') or '{}')
                return result
            return None
    
    @staticmethod
    def get_all(limit: int = 50) -> List[Dict[str, Any]]:
        """Get all training jobs"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM training_jobs ORDER BY started_at DESC LIMIT %s', (limit,))
            rows = cursor.fetchall()
            results = []
            for row in rows:
                result = dict(row)
                result['metadata'] = result['metadata'] if isinstance(result['metadata'], dict) else json.loads(result.get('metadata') or '{}')
                results.append(result)
            return results
    
    @staticmethod
    def get_by_id(job_id: str) -> Optional[Dict[str, Any]]:
        """Get a training job by ID"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM training_jobs WHERE id = %s', (job_id,))
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['metadata'] = result['metadata'] if isinstance(result['metadata'], dict) else json.loads(result.get('metadata') or '{}')
                return result
            return None

    @staticmethod
    def get_by_chatbot(chatbot_id: str) -> List[Dict[str, Any]]:
        """Get training jobs for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM training_jobs WHERE chatbot_id = %s ORDER BY started_at DESC', (chatbot_id,))
            rows = cursor.fetchall()
            results = []
            for row in rows:
                result = dict(row)
                result['metadata'] = result['metadata'] if isinstance(result['metadata'], dict) else json.loads(result.get('metadata') or '{}')
                results.append(result)
            return results
    
    @staticmethod
    def update(job_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a training job"""
        allowed_fields = ['status', 'completed_at', 'pages_processed', 'error', 'metadata']
        set_clauses = []
        values = []
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                if field == 'metadata':
                    values.append(json.dumps(updates[field]))
                else:
                    values.append(updates[field])
        
        if not set_clauses:
            return None
        
        values.append(job_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f'''
                UPDATE training_jobs SET {", ".join(set_clauses)}
                WHERE id = %s
                RETURNING *
            ''', values)
            conn.commit()
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['metadata'] = result['metadata'] if isinstance(result['metadata'], dict) else json.loads(result.get('metadata') or '{}')
                return result
            return None

"""
Conversation flows - intent overrides and flow JSON for Conversation Studio.
"""

from typing import Optional, Dict, Any
from .base import get_db_connection
import json
import logging

logger = logging.getLogger(__name__)


def get_flow(chatbot_id: str) -> Optional[Dict[str, Any]]:
    """Get conversation flow for a chatbot."""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT flow_json, version, updated_at FROM conversation_flows WHERE chatbot_id = %s",
                (chatbot_id,),
            )
            row = cursor.fetchone()
            if not row:
                return None
            flow = row.get("flow_json")
            if isinstance(flow, str):
                flow = json.loads(flow) if flow else {}
            return {
                "chatbot_id": chatbot_id,
                "flow_json": flow or {},
                "version": row.get("version", 1),
                "updated_at": row.get("updated_at"),
            }
    except Exception as e:
        logger.warning(f"get_flow failed: {e}")
        return None


def save_flow(chatbot_id: str, flow_json: Dict[str, Any]) -> Dict[str, Any]:
    """Save or update conversation flow. Returns the saved flow."""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            payload = json.dumps(flow_json) if isinstance(flow_json, dict) else "{}"
            cursor.execute(
                """
                INSERT INTO conversation_flows (chatbot_id, flow_json, version, updated_at)
                VALUES (%s, %s, 1, NOW())
                ON CONFLICT (chatbot_id) DO UPDATE SET
                    flow_json = EXCLUDED.flow_json,
                    version = conversation_flows.version + 1,
                    updated_at = NOW()
                RETURNING chatbot_id, flow_json, version, updated_at
                """,
                (chatbot_id, payload),
            )
            row = cursor.fetchone()
            flow = row.get("flow_json")
            if isinstance(flow, str):
                flow = json.loads(flow) if flow else {}
            return {
                "chatbot_id": row.get("chatbot_id"),
                "flow_json": flow or {},
                "version": row.get("version", 1),
                "updated_at": row.get("updated_at"),
            }
    except Exception as e:
        logger.warning(f"save_flow failed: {e}")
        raise


def get_intent_override(chatbot_id: str, intent: str) -> Optional[str]:
    """Get custom response for an intent from flow overrides. Returns None if no override."""
    flow = get_flow(chatbot_id)
    if not flow:
        return None
    overrides = flow.get("flow_json", {}).get("intentOverrides") or flow.get("flow_json", {}).get("overrides") or {}
    override = overrides.get(intent)
    if isinstance(override, dict):
        return override.get("response") or override.get("text")
    if isinstance(override, str):
        return override
    return None

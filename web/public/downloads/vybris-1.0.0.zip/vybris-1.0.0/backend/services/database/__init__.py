"""
Database module for VYBR!S - Modular database access layer
Provides persistent storage for all platform data

This module has been refactored from a monolithic 3,364-line file into
modular components for better maintainability and testability.

Backward compatibility: All classes are exported from this module,
so existing imports continue to work.
"""

# Export connection utilities
from .base import (
    get_db_connection,
    get_connection_pool,
    init_database,
    DB_HOST,
    DB_PORT,
    DB_NAME,
    DB_USER,
    DB_PASSWORD
)

# Initialize database tables on module import (required before any DB class is used)
import logging
_logger = logging.getLogger(__name__)
try:
    init_database()
    _logger.info("Database tables initialized on module import")
except Exception as e:
    _logger.error(f"Failed to initialize database tables: {e}")

# Export all database classes for backward compatibility
from .users import UserDB
from .chatbots import ChatbotDB
from .scraped_content import ScrapedContentDB
from .logs import LogDB
from .settings import SettingsDB
from .knowledge import KnowledgeDB
from .training_jobs import TrainingJobDB
from .sessions import SessionDB
from .messages import MessageDB
from .integrations import IntegrationDB
from .crm_companies import CRMCompanyDB
from .crm_leads import CRMLeadDB
from .qualifications import QualificationDB
from .pipelines import PipelineDB
from .automations import AutomationDB
from .email_sequences import EmailSequenceDB
from .onboarding import OnboardingDB
from .custom_actions import CustomActionDB
from .cors_origins import CORSOriginsDB
from .history_access_grants import HistoryAccessGrantsDB
from .history_storage_config import HistoryStorageConfigDB
from .live_chat import LiveChatDB
from .verification import VerificationDB
from .elias_assistant import EliasSummariesDB, EliasTodosDB
from .blueprints import BlueprintDB
from .workflows import WorkflowDB

__all__ = [
    # Connection utilities
    'get_db_connection',
    'get_connection_pool',
    'init_database',
    'DB_HOST',
    'DB_PORT',
    'DB_NAME',
    'DB_USER',
    'DB_PASSWORD',
    # Database classes
    'UserDB',
    'ChatbotDB',
    'ScrapedContentDB',
    'LogDB',
    'SettingsDB',
    'KnowledgeDB',
    'TrainingJobDB',
    'SessionDB',
    'MessageDB',
    'IntegrationDB',
    'CRMCompanyDB',
    'CRMLeadDB',
    'QualificationDB',
    'PipelineDB',
    'AutomationDB',
    'EmailSequenceDB',
    'OnboardingDB',
    'CustomActionDB',
    'CORSOriginsDB',
    'HistoryAccessGrantsDB',
    'HistoryStorageConfigDB',
    'LiveChatDB',
    'VerificationDB',
    'EliasSummariesDB',
    'EliasTodosDB',
    'BlueprintDB',
    'WorkflowDB',
]

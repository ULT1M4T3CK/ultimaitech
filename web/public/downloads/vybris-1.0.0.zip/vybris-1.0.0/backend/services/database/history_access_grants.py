"""
History Access Grants
Owner can grant chat-history access by email. Only owner or granted users can access;
super_user has no bypass. Chat history is not stored on server (client-side only).
"""

import uuid
from typing import List, Dict, Any

from .base import get_db_connection


def _normalize_email(email: str) -> str:
    return (email or "").strip().lower()


class HistoryAccessGrantsDB:
    """CRUD for history access grants (owner_id -> granted_email)."""

    @staticmethod
    def list_for_owner(owner_id: str) -> List[Dict[str, Any]]:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT id, owner_id, granted_email, created_at
                FROM history_access_grants
                WHERE owner_id = %s
                ORDER BY granted_email
                """,
                (owner_id,),
            )
            return [dict(row) for row in cursor.fetchall()]

    @staticmethod
    def add(owner_id: str, granted_email: str) -> Dict[str, Any]:
        email = _normalize_email(granted_email)
        if not email:
            raise ValueError("granted_email is required")
        grant_id = f"hag_{uuid.uuid4().hex[:16]}"
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO history_access_grants (id, owner_id, granted_email)
                VALUES (%s, %s, %s)
                ON CONFLICT (owner_id, granted_email) DO NOTHING
                RETURNING *
                """,
                (grant_id, owner_id, email),
            )
            row = cursor.fetchone()
            if row:
                return dict(row)
            # Already exists
            cursor.execute(
                """
                SELECT * FROM history_access_grants
                WHERE owner_id = %s AND granted_email = %s
                """,
                (owner_id, email),
            )
            r = cursor.fetchone()
            return dict(r) if r else {}

    @staticmethod
    def remove(owner_id: str, granted_email: str) -> bool:
        email = _normalize_email(granted_email)
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                DELETE FROM history_access_grants
                WHERE owner_id = %s AND granted_email = %s
                """,
                (owner_id, email),
            )
            conn.commit()
            return cursor.rowcount > 0

    @staticmethod
    def has_grant(owner_id: str, email: str) -> bool:
        e = _normalize_email(email)
        if not e:
            return False
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT 1 FROM history_access_grants
                WHERE owner_id = %s AND granted_email = %s
                LIMIT 1
                """,
                (owner_id, e),
            )
            return cursor.fetchone() is not None

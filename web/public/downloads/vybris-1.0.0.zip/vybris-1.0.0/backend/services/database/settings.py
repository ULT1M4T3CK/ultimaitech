"""
Settings Database Operations
Handles all database operations for platform settings
"""

from typing import List, Optional, Dict, Any
from .base import get_db_connection


class SettingsDB:
    """Database operations for settings"""
    
    @staticmethod
    def get(key: str) -> Optional[Dict[str, Any]]:
        """Get a setting by key"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM settings WHERE key = %s', (key,))
            row = cursor.fetchone()
            return dict(row) if row else None
    
    @staticmethod
    def get_by_category(category: str) -> List[Dict[str, Any]]:
        """Get all settings in a category"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM settings WHERE category = %s', (category,))
            return [dict(row) for row in cursor.fetchall()]
    
    @staticmethod
    def get_all() -> List[Dict[str, Any]]:
        """Get all settings"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM settings ORDER BY category, key')
            return [dict(row) for row in cursor.fetchall()]
    
    @staticmethod
    def set(key: str, value: str, category: str, updated_by: str = None) -> Dict[str, Any]:
        """Set a setting value"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO settings (key, value, category, updated_at, updated_by)
                VALUES (%s, %s, %s, NOW(), %s)
                ON CONFLICT (key) DO UPDATE SET
                    value = EXCLUDED.value,
                    category = EXCLUDED.category,
                    updated_at = NOW(),
                    updated_by = EXCLUDED.updated_by
                RETURNING *
            ''', (key, value, category, updated_by))
            conn.commit()
            row = cursor.fetchone()
            return dict(row) if row else None
    
    @staticmethod
    def delete(key: str) -> bool:
        """Delete a setting"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM settings WHERE key = %s', (key,))
            conn.commit()
            return cursor.rowcount > 0

"""
User Database Operations
Handles all database operations for users
"""

import json
from typing import List, Optional, Dict, Any
from datetime import datetime
from .base import get_db_connection


def _serialize_moderator_chatbot_ids(ids: Any) -> str:
    """Serialize moderator_chatbot_ids for DB (list of strings -> JSON array)."""
    if ids is None:
        return '[]'
    if isinstance(ids, list):
        return json.dumps([str(x) for x in ids])
    return '[]'


class UserDB:
    """Database operations for users"""
    
    @staticmethod
    def create(user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new user"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO users (id, username, email, hashed_password, full_name, role, status, invite_token, invite_expires_at, created_at, partner_id, is_super_user, mfa_enabled, mfa_secret, backup_codes, custom_chatbot_limit, moderator_chatbot_ids)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
            ''', (
                user_data['id'],
                user_data['username'],
                user_data['email'],
                user_data.get('hashed_password'),
                user_data.get('full_name'),
                user_data.get('role', 'viewer'),
                user_data.get('status', 'pending'),
                user_data.get('invite_token'),
                user_data.get('invite_expires_at'),
                user_data.get('created_at', datetime.utcnow()),
                user_data.get('partner_id'),
                user_data.get('is_super_user', False),
                user_data.get('mfa_enabled', False),
                user_data.get('mfa_secret'),
                json.dumps(user_data.get('backup_codes', [])),
                user_data.get('custom_chatbot_limit'),
                _serialize_moderator_chatbot_ids(user_data.get('moderator_chatbot_ids'))
            ))
            conn.commit()
            row = cursor.fetchone()
            return dict(row) if row else None
    
    @staticmethod
    def get_by_partner(partner_id: str) -> List[Dict[str, Any]]:
        """Get all users associated with a specific partner"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            # Get the partner themselves + all users they created/own
            cursor.execute('SELECT * FROM users WHERE id = %s OR partner_id = %s ORDER BY created_at DESC', (partner_id, partner_id))
            return [dict(row) for row in cursor.fetchall()]

    @staticmethod
    def get_all() -> List[Dict[str, Any]]:
        """Get all users"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users ORDER BY created_at DESC')
            return [dict(row) for row in cursor.fetchall()]

    @staticmethod
    def get_by_id(user_id: str) -> Optional[Dict[str, Any]]:
        """Get a user by ID"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE id = %s', (user_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    @staticmethod
    def get_by_username(username: str) -> Optional[Dict[str, Any]]:
        """Get a user by username"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
            row = cursor.fetchone()
            return dict(row) if row else None

    @staticmethod
    def get_by_email(email: str) -> Optional[Dict[str, Any]]:
        """Get a user by email"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE email = %s', (email,))
            row = cursor.fetchone()
            return dict(row) if row else None

    @staticmethod
    def get_by_invite_token(token: str) -> Optional[Dict[str, Any]]:
        """Get a user by invite token"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM users WHERE invite_token = %s AND invite_expires_at > NOW()', (token,))
            row = cursor.fetchone()
            return dict(row) if row else None

    @staticmethod
    def update(user_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a user"""
        if not updates:
            return None
        
        # Build update query dynamically
        set_clauses = []
        values = []
        
        allowed_fields = {
            'username', 'email', 'hashed_password', 'full_name', 'role', 'status',
            'invite_token', 'invite_expires_at', 'last_login', 'partner_id',
            'is_super_user', 'mfa_enabled', 'mfa_secret', 'backup_codes',
            'custom_chatbot_limit', 'branding_logo_url', 'branding_company_name',
            'branding_primary_color', 'branding_secondary_color', 'branding_theme',
            'branding_setup_complete', 'moderator_chatbot_ids'
        }
        
        for field, value in updates.items():
            if field in allowed_fields:
                if field == 'backup_codes':
                    set_clauses.append(f"{field} = %s")
                    values.append(json.dumps(value) if isinstance(value, list) else value)
                elif field == 'moderator_chatbot_ids':
                    set_clauses.append(f"{field} = %s")
                    values.append(_serialize_moderator_chatbot_ids(value))
                else:
                    set_clauses.append(f"{field} = %s")
                    values.append(value)
        
        if not set_clauses:
            return None
        
        values.append(user_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            # Note: updated_at column doesn't exist in the schema, so we don't include it
            query = f"UPDATE users SET {', '.join(set_clauses)} WHERE id = %s RETURNING *"
            cursor.execute(query, values)
            conn.commit()
            row = cursor.fetchone()
            return dict(row) if row else None

    @staticmethod
    def delete(user_id: str) -> bool:
        """Delete a user"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM users WHERE id = %s', (user_id,))
            conn.commit()
            return cursor.rowcount > 0

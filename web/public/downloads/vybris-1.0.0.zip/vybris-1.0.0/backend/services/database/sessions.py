"""
Session Database Operations
Handles all database operations for chat sessions
"""

import json
import logging
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
from .base import get_db_connection

logger = logging.getLogger(__name__)


class SessionDB:
    """Database operations for chat sessions"""
    
    SESSION_TIMEOUT = 30 * 60  # 30 minutes in seconds
    
    @staticmethod
    def get_or_create(session_id: str, chatbot_id: str) -> Dict[str, Any]:
        """Get existing session or create new one"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                
                # Try to get existing session
                cursor.execute('''
                    SELECT * FROM chat_sessions WHERE session_id = %s
                ''', (session_id,))
                row = cursor.fetchone()
                
                if row:
                    # Check if session has expired (30 minutes of inactivity)
                    last_activity = row.get('last_activity') or row.get('last_message_at')
                    if isinstance(last_activity, str):
                        last_activity = datetime.fromisoformat(last_activity.replace('Z', '+00:00'))
                    
                    now = datetime.now(timezone.utc)
                    if isinstance(last_activity, datetime):
                        if last_activity.tzinfo is None:
                            last_activity = last_activity.replace(tzinfo=timezone.utc)
                        time_diff = (now - last_activity).total_seconds()
                    else:
                        time_diff = SessionDB.SESSION_TIMEOUT + 1  # Force new session
                    
                    if time_diff < SessionDB.SESSION_TIMEOUT:
                        # Session is still active
                        logger.debug(f"[SessionDB] Found existing session: {session_id}, message_count={row.get('message_count', 0)}")
                        return dict(row)
                    else:
                        # Session expired, create new one
                        logger.info(f"[SessionDB] Session expired, recreating: {session_id}")
                        cursor.execute('DELETE FROM chat_sessions WHERE session_id = %s', (session_id,))
                        conn.commit()
                
                # Create new session
                logger.info(f"[SessionDB] Creating new session: {session_id} for chatbot: {chatbot_id}")
                cursor.execute('''
                    INSERT INTO chat_sessions (session_id, chatbot_id, started_at, last_activity, message_count, metadata)
                    VALUES (%s, %s, NOW(), NOW(), 0, '{}')
                    RETURNING *
                ''', (session_id, chatbot_id))
                conn.commit()
                row = cursor.fetchone()
                
                if row:
                    logger.info(f"[SessionDB] New session created successfully: {session_id}")
                    return dict(row)
                else:
                    logger.error(f"[SessionDB] Failed to create session - no row returned: {session_id}")
                    return None
        except Exception as e:
            logger.error(f"[SessionDB] Error in get_or_create for session {session_id}: {e}")
            return None
    
    @staticmethod
    def update_activity(session_id: str, increment_messages: bool = True) -> None:
        """Update session last activity and optionally increment message count"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            if increment_messages:
                cursor.execute('''
                    UPDATE chat_sessions 
                    SET last_activity = NOW(), message_count = message_count + 1
                    WHERE session_id = %s
                ''', (session_id,))
            else:
                cursor.execute('''
                    UPDATE chat_sessions 
                    SET last_activity = NOW()
                    WHERE session_id = %s
                ''', (session_id,))
            
            conn.commit()
    
    @staticmethod
    def get_active_conversations_count(chatbot_id: str) -> int:
        """Get count of active conversations (sessions with activity in last 30 min)"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT COUNT(*) as count FROM chat_sessions 
                WHERE chatbot_id = %s 
                AND last_activity > NOW() - INTERVAL '%s seconds'
            ''', (chatbot_id, SessionDB.SESSION_TIMEOUT))
            row = cursor.fetchone()
            return row['count'] if row else 0
    
    @staticmethod
    def cleanup_expired_sessions() -> int:
        """Remove sessions that have been inactive for more than 30 minutes"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                DELETE FROM chat_sessions 
                WHERE last_activity < NOW() - INTERVAL '%s seconds'
            ''', (SessionDB.SESSION_TIMEOUT,))
            conn.commit()
            return cursor.rowcount

    @staticmethod
    def get_history(session_id: str, limit: int = 10) -> List[Dict[str, str]]:
        """Get recent message history for a session from metadata"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT metadata FROM chat_sessions WHERE session_id = %s', (session_id,))
            row = cursor.fetchone()
            
            if row and row.get('metadata'):
                metadata = row['metadata'] if isinstance(row['metadata'], dict) else json.loads(row.get('metadata') or '{}')
                # Ensure history exists and is a list
                history = metadata.get('history', [])
                if isinstance(history, list):
                    return history[-limit:]
            return []

    @staticmethod
    def add_message(session_id: str, role: str, content: str) -> None:
        """Add a message to the session history in metadata"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT metadata FROM chat_sessions WHERE session_id = %s FOR UPDATE', (session_id,))
            row = cursor.fetchone()
            
            if row:
                metadata = row['metadata'] or {}
                if isinstance(metadata, str):
                    metadata = json.loads(metadata)
                
                history = metadata.get('history', [])
                if not isinstance(history, list):
                    history = []
                
                history.append({'role': role, 'content': content})
                
                # Keep last 20 messages
                if len(history) > 20:
                    history = history[-20:]
                
                metadata['history'] = history
                
                cursor.execute('UPDATE chat_sessions SET metadata = %s WHERE session_id = %s', (json.dumps(metadata), session_id))
            conn.commit()

    @staticmethod
    def mark_unknown_interaction(session_id: str) -> None:
        """Mark session as having an unknown intent interaction."""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE chat_sessions SET has_unknown_interaction = TRUE WHERE session_id = %s",
                (session_id,)
            )
            conn.commit()

    @staticmethod
    def update_category(session_id: str, category: str) -> None:
        """Update the session's category for analytics."""
        if not category or len(category) >= 50:
            return
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE chat_sessions SET category = %s WHERE session_id = %s",
                (category.strip(), session_id)
            )
            conn.commit()

    @staticmethod
    def get_monthly_stats(chatbot_id: str) -> List[Dict[str, Any]]:
        """Get conversation volume grouped by month for the last year"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT 
                    TO_CHAR(started_at, 'YYYY-MM') as month,
                    COUNT(*) as count
                FROM chat_sessions
                WHERE chatbot_id = %s
                AND started_at > NOW() - INTERVAL '1 year'
                GROUP BY month
                ORDER BY month ASC
            ''', (chatbot_id,))
            return [dict(row) for row in cursor.fetchall()]

"""
Automation Database Operations
Handles all database operations for automation rules
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


def _row_to_automation(row: Dict) -> Dict[str, Any]:
    """Convert database row to automation dict"""
    return {
        'id': row['id'],
        'chatbot_id': row['chatbot_id'],
        'name': row['name'],
        'trigger_type': row['trigger_type'],
        'trigger_conditions': row['trigger_conditions'] if isinstance(row.get('trigger_conditions'), list) else json.loads(row.get('trigger_conditions') or '[]'),
        'actions': row['actions'] if isinstance(row.get('actions'), list) else json.loads(row.get('actions') or '[]'),
        'enabled': row.get('enabled', True),
        'created_at': row['created_at'].isoformat() + 'Z' if hasattr(row['created_at'], 'isoformat') else row['created_at'],
        'updated_at': row['updated_at'].isoformat() + 'Z' if hasattr(row['updated_at'], 'isoformat') else row['updated_at']
    }


class AutomationDB:
    """Database operations for automation rules"""
    
    @staticmethod
    def create(automation_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new automation rule"""
        automation_id = automation_data.get('id') or str(uuid.uuid4())
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO automations (id, chatbot_id, name, trigger_type, trigger_conditions, actions, enabled)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                RETURNING *
            ''', (
                automation_id,
                automation_data['chatbot_id'],
                automation_data.get('name'),
                automation_data['trigger_type'],
                json.dumps(automation_data.get('trigger_conditions', [])),
                json.dumps(automation_data.get('actions', [])),
                automation_data.get('enabled', True)
            ))
            conn.commit()
            row = cursor.fetchone()
            return _row_to_automation(row) if row else None
    
    @staticmethod
    def get_by_chatbot(chatbot_id: str, enabled_only: bool = False) -> List[Dict[str, Any]]:
        """Get all automations for a chatbot"""
        query = 'SELECT * FROM automations WHERE chatbot_id = %s'
        params = [chatbot_id]
        if enabled_only:
            query += ' AND enabled = TRUE'
        query += ' ORDER BY created_at DESC'
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            return [_row_to_automation(row) for row in cursor.fetchall()]
    
    @staticmethod
    def get_by_id(automation_id: str) -> Optional[Dict[str, Any]]:
        """Get an automation by ID"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM automations WHERE id = %s', (automation_id,))
            row = cursor.fetchone()
            return _row_to_automation(row) if row else None
    
    @staticmethod
    def update(automation_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update an automation rule"""
        allowed_fields = ['name', 'trigger_type', 'trigger_conditions', 'actions', 'enabled']
        set_clauses = ['updated_at = NOW()']
        values = []
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                if field in ['trigger_conditions', 'actions']:
                    values.append(json.dumps(updates[field]))
                else:
                    values.append(updates[field])
        
        if len(set_clauses) == 1:  # Only updated_at
            return AutomationDB.get_by_id(automation_id)
        
        values.append(automation_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f'''
                UPDATE automations SET {", ".join(set_clauses)}
                WHERE id = %s
                RETURNING *
            ''', values)
            conn.commit()
            row = cursor.fetchone()
            return _row_to_automation(row) if row else None
    
    @staticmethod
    def get_by_trigger(trigger_type: str, active_only: bool = False) -> List[Dict[str, Any]]:
        """Get automations by trigger type (e.g. stage_change, lead_created)."""
        query = 'SELECT * FROM automations WHERE trigger_type = %s'
        params = [trigger_type]
        if active_only:
            query += ' AND enabled = TRUE'
        query += ' ORDER BY created_at DESC'
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            return [_row_to_automation(row) for row in cursor.fetchall()]

    @staticmethod
    def get_by_owner(owner_id: str, active_only: bool = False) -> List[Dict[str, Any]]:
        """Get automations for chatbots owned by owner_id."""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                '''SELECT a.* FROM automations a
                   JOIN chatbots c ON a.chatbot_id = c.id
                   WHERE c.owner_id = %s AND c.deleted_at IS NULL''',
                (owner_id,),
            )
            rows = cursor.fetchall()
        result = [_row_to_automation(r) for r in rows]
        if active_only:
            result = [r for r in result if r.get('enabled', True)]
        return result

    @staticmethod
    def log_execution(rule_id: str, lead_id: str, trigger_data: dict, action_result: dict, status: str, error_message: str = None) -> None:
        """Log automation execution for audit."""
        try:
            from .logs import LogDB
            meta = {'rule_id': rule_id, 'lead_id': lead_id}
            if error_message:
                meta['error'] = error_message[:500]
            LogDB.create({
                'level': 'INFO' if status == 'success' else 'ERROR',
                'service': 'automations',
                'action': 'execute',
                'message': f"Rule {rule_id} executed for lead {lead_id}: {status}",
                'metadata': meta,
            })
        except Exception:
            pass

    @staticmethod
    def increment_run_count(rule_id: str) -> None:
        """Increment run count for a rule (stub - no column exists yet)."""
        pass

    @staticmethod
    def delete(automation_id: str) -> bool:
        """Delete an automation rule"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM automations WHERE id = %s', (automation_id,))
            conn.commit()
            return cursor.rowcount > 0

"""
Shared Connection Pool Module for VYBR!S
Single source of truth for database connection pooling.

This module ensures all database operations use the same connection pool,
preventing connection exhaustion and resource leaks.
"""

import os
import threading
import logging
from typing import Optional
import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2 import pool
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    before_sleep_log
)

logger = logging.getLogger(__name__)

# Database connection settings
DB_HOST = os.getenv("POSTGRES_HOST", "localhost")
DB_PORT = os.getenv("POSTGRES_PORT", "5434")  # Docker mapped port
DB_NAME = os.getenv("POSTGRES_DB", "vybris")
DB_USER = os.getenv("POSTGRES_USER", "user")
DB_PASSWORD = os.getenv("POSTGRES_PASSWORD", "password")

# Pool configuration (tunable via environment variables)
POOL_MIN_CONN = int(os.getenv("DB_POOL_MIN_CONN", "5"))
POOL_MAX_CONN = int(os.getenv("DB_POOL_MAX_CONN", "50"))
POOL_CONNECT_TIMEOUT = int(os.getenv("DB_POOL_CONNECT_TIMEOUT", "10"))


def get_connection_string() -> str:
    """Get database connection string."""
    return f"host={DB_HOST} port={DB_PORT} dbname={DB_NAME} user={DB_USER} password={DB_PASSWORD}"


# Thread-safe singleton connection pool
_connection_pool: Optional[pool.ThreadedConnectionPool] = None
_pool_lock = threading.Lock()


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_exception_type((psycopg2.OperationalError, psycopg2.InterfaceError)),
    before_sleep=before_sleep_log(logger, logging.WARNING),
    reraise=True
)
def _create_connection_pool() -> pool.ThreadedConnectionPool:
    """
    Create a new connection pool with retry logic.
    
    Returns:
        ThreadedConnectionPool instance
    """
    return pool.ThreadedConnectionPool(
        minconn=POOL_MIN_CONN,
        maxconn=POOL_MAX_CONN,
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        cursor_factory=RealDictCursor,
        connect_timeout=POOL_CONNECT_TIMEOUT
    )


def get_connection_pool() -> Optional[pool.ThreadedConnectionPool]:
    """
    Get or create the connection pool (thread-safe singleton).
    
    This is the SINGLE SOURCE OF TRUTH for database connection pooling.
    All database operations should use this pool to prevent connection exhaustion.
    
    Returns:
        ThreadedConnectionPool instance or None if creation failed
    """
    global _connection_pool
    
    if _connection_pool is None:
        with _pool_lock:
            # Double-check pattern to prevent race conditions
            if _connection_pool is None:
                try:
                    _connection_pool = _create_connection_pool()
                    logger.info(
                        f"[Database Pool] Initialized connection pool "
                        f"(min={POOL_MIN_CONN}, max={POOL_MAX_CONN})"
                    )
                except Exception as e:
                    logger.error(f"[Database Pool] Failed to create connection pool after retries: {e}")
                    return None
    
    return _connection_pool


def get_pool_stats() -> dict:
    """
    Get connection pool statistics for monitoring.
    
    Returns:
        Dictionary with pool statistics:
        - minconn: Minimum connections
        - maxconn: Maximum connections
        - current_connections: Currently active connections (estimated)
        - available_connections: Available connections (estimated)
        - utilization: Pool utilization percentage
    """
    pool_instance = get_connection_pool()
    
    if not pool_instance:
        return {
            "status": "unavailable",
            "minconn": None,
            "maxconn": None,
            "current_connections": None,
            "available_connections": None,
            "utilization": None
        }
    
    try:
        # psycopg2 pool doesn't expose stats directly, so we estimate
        # In production, consider querying pg_stat_activity for real stats
        minconn = pool_instance.minconn
        maxconn = pool_instance.maxconn
        
        # Try to get a connection to test availability
        test_conn = None
        try:
            test_conn = pool_instance.getconn()
            # If we got a connection, pool has at least one available
            available = maxconn  # Conservative estimate
            current = 0  # We can't know exact count without pg_stat_activity
        except Exception:
            # Pool exhausted
            available = 0
            current = maxconn
        finally:
            if test_conn:
                pool_instance.putconn(test_conn)
        
        utilization = (current / maxconn * 100) if maxconn > 0 else 0
        
        return {
            "status": "healthy",
            "minconn": minconn,
            "maxconn": maxconn,
            "current_connections": current,
            "available_connections": available,
            "utilization": round(utilization, 2)
        }
    except Exception as e:
        logger.error(f"Failed to get pool stats: {e}")
        return {
            "status": "error",
            "error": str(e)
        }


def close_pool():
    """
    Close all connections in the pool.
    
    This should be called during graceful shutdown.
    """
    global _connection_pool
    
    with _pool_lock:
        if _connection_pool:
            try:
                _connection_pool.closeall()
                logger.info("[Database Pool] Closed all connections")
            except Exception as e:
                logger.error(f"[Database Pool] Error closing pool: {e}")
            finally:
                _connection_pool = None


def reconnect_pool() -> bool:
    """
    Reconnect the connection pool (useful after connection failures).
    
    Returns:
        True if successful, False otherwise
    """
    global _connection_pool
    
    try:
        # Close existing pool if it exists
        close_pool()
        
        # Create new pool
        new_pool = get_connection_pool()
        if new_pool:
            logger.info("[Database Pool] Reconnected successfully")
            return True
        else:
            logger.error("[Database Pool] Failed to reconnect")
            return False
    except Exception as e:
        logger.error(f"[Database Pool] Error reconnecting: {e}")
        return False

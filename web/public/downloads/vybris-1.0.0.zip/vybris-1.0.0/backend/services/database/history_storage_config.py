"""
History storage config: owner chooses where chat history is saved.
- local: client-side only (widget localStorage); we never store message content.
- cloud: we store messages server-side; owner (and grantees) can view in History.
- owner_device: store in cloud for collection, but owner exports to chosen folder
  on their device for quality/evaluation (primary copy on owner's machine).
"""

from typing import Literal

from .base import get_db_connection

StorageType = Literal["local", "cloud", "owner_device"]
DEFAULT_STORAGE = "local"


class HistoryStorageConfigDB:
    @staticmethod
    def get(owner_id: str) -> StorageType:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT storage_type FROM history_storage_config WHERE owner_id = %s",
                (owner_id,),
            )
            row = cursor.fetchone()
        if row and row.get("storage_type") in ("local", "cloud", "owner_device"):
            return row["storage_type"]
        return DEFAULT_STORAGE

    @staticmethod
    def set(owner_id: str, storage_type: StorageType) -> None:
        if storage_type not in ("local", "cloud", "owner_device"):
            raise ValueError("storage_type must be 'local', 'cloud', or 'owner_device'")
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO history_storage_config (owner_id, storage_type, updated_at)
                VALUES (%s, %s, NOW())
                ON CONFLICT (owner_id) DO UPDATE SET
                    storage_type = EXCLUDED.storage_type,
                    updated_at = NOW()
                """,
                (owner_id, storage_type),
            )

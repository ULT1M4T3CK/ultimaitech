"""
Database Index Optimization
Creates indexes for common query patterns to improve performance
"""

from .base import get_db_connection
import logging

logger = logging.getLogger(__name__)


def create_performance_indexes():
    """
    Create indexes for common query patterns.
    This should be called during database initialization or migration.
    """
    indexes = [
        # Chatbots indexes
        ("idx_chatbots_owner_id", "chatbots", "owner_id"),
        ("idx_chatbots_status", "chatbots", "status"),
        ("idx_chatbots_created_at", "chatbots", "created_at DESC"),
        ("idx_chatbots_deleted_at", "chatbots", "deleted_at"),
        ("idx_chatbots_owner_deleted", "chatbots", "owner_id, deleted_at"),
        
        # Sessions indexes
        ("idx_sessions_chatbot_id", "chat_sessions", "chatbot_id"),
        ("idx_sessions_last_activity", "chat_sessions", "last_activity DESC"),
        ("idx_sessions_chatbot_activity", "chat_sessions", "chatbot_id, last_activity DESC"),
        
        # Messages indexes
        ("idx_messages_session_id", "chat_messages", "session_id"),
        ("idx_messages_chatbot_id", "chat_messages", "chatbot_id"),
        ("idx_messages_created_at", "chat_messages", "created_at DESC"),
        ("idx_messages_session_created", "chat_messages", "session_id, created_at ASC"),
        
        # Integrations indexes
        ("idx_integrations_chatbot_id", "integrations", "chatbot_id"),
        ("idx_integrations_type", "integrations", "integration_type"),
        ("idx_integrations_status", "integrations", "status"),
        ("idx_integrations_chatbot_type", "integrations", "chatbot_id, integration_type"),
        
        # Knowledge items indexes
        ("idx_knowledge_chatbot_id", "knowledge_items", "chatbot_id"),
        ("idx_knowledge_source_type", "knowledge_items", "source_type"),
        ("idx_knowledge_created_at", "knowledge_items", "created_at DESC"),
        
        # CRM indexes
        ("idx_crm_leads_status", "crm_leads", "status"),
        ("idx_crm_leads_owner", "crm_leads", "account_owner_id"),
        ("idx_crm_leads_priority", "crm_leads", "priority"),
        ("idx_crm_leads_followup", "crm_leads", "next_followup_date"),
        ("idx_crm_leads_company", "crm_leads", "company_id"),
        ("idx_crm_leads_owner_status", "crm_leads", "account_owner_id, status"),
        
        # Logs indexes
        ("idx_logs_timestamp", "logs", "timestamp DESC"),
        ("idx_logs_level", "logs", "level"),
        ("idx_logs_chatbot", "logs", "chatbot_id"),
        ("idx_logs_user", "logs", "user_id"),
        ("idx_logs_chatbot_timestamp", "logs", "chatbot_id, timestamp DESC"),
        
        # Users indexes
        ("idx_users_email", "users", "email"),
        ("idx_users_role", "users", "role"),
        
    ]
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        created_count = 0
        skipped_count = 0
        
        for index_name, table_name, columns in indexes:
            try:
                # Check if index already exists
                cursor.execute("""
                    SELECT COUNT(*) as cnt
                    FROM pg_indexes 
                    WHERE indexname = %s
                """, (index_name,))
                
                row = cursor.fetchone()
                if (row['cnt'] if isinstance(row, dict) else row[0]) > 0:
                    logger.debug(f"Index {index_name} already exists, skipping")
                    skipped_count += 1
                    continue
                
                # Create index
                cursor.execute(f"""
                    CREATE INDEX IF NOT EXISTS {index_name} 
                    ON {table_name} ({columns})
                """)
                created_count += 1
                logger.info(f"Created index: {index_name} on {table_name}({columns})")
                
            except Exception as e:
                logger.warning(f"Failed to create index {index_name}: {e}")
        
        conn.commit()
        logger.info(f"Index creation complete: {created_count} created, {skipped_count} skipped")
        return created_count


def optimize_database():
    """
    Run all database optimizations including index creation.
    Call this during application startup or migration.
    """
    logger.info("Starting database optimization...")
    indexes_created = create_performance_indexes()
    logger.info(f"Database optimization complete. Created {indexes_created} indexes.")
    return indexes_created

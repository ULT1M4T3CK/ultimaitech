"""
Base database utilities for VYBR!S
Connection pooling and database initialization
"""

import os
from contextlib import contextmanager
import psycopg2
from psycopg2.extras import RealDictCursor
import logging
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    before_sleep_log
)

# Import shared connection pool (single source of truth)
from services.database.pool import (
    get_connection_pool,
    get_connection_string,
    DB_HOST,
    DB_PORT,
    DB_NAME,
    DB_USER,
    DB_PASSWORD
)

# Re-export for backward compatibility
__all__ = ['DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']

logger = logging.getLogger(__name__)


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_exception_type((psycopg2.OperationalError, psycopg2.InterfaceError)),
    before_sleep=before_sleep_log(logger, logging.WARNING),
    reraise=True
)
def _get_connection_from_pool(pool_instance):
    """Get connection from pool with retry logic."""
    return pool_instance.getconn()


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_exception_type((psycopg2.OperationalError, psycopg2.InterfaceError)),
    before_sleep=before_sleep_log(logger, logging.WARNING),
    reraise=True
)
def _create_direct_connection():
    """Create direct connection with retry logic."""
    return psycopg2.connect(
        get_connection_string(),
        cursor_factory=RealDictCursor,
        connect_timeout=10
    )


@contextmanager
def get_db_connection(autocommit: bool = True):
    """
    Context manager for database connections (uses pool if available).
    
    IMPORTANT: By default, this auto-commits on success and rolls back on error.
    Set autocommit=False if you need manual transaction control.
    
    Includes retry logic for connection failures (3 attempts with exponential backoff).
    
    Usage:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users")
            results = cursor.fetchall()
            # Auto-commits on success, rolls back on exception
    """
    pool_instance = get_connection_pool()
    
    if pool_instance:
        conn = _get_connection_from_pool(pool_instance)
        try:
            yield conn
            if autocommit:
                conn.commit()
        except Exception as e:
            if autocommit:
                conn.rollback()
            raise e
        finally:
            pool_instance.putconn(conn)
    else:
        # Fallback to direct connection with retry
        conn = _create_direct_connection()
        try:
            yield conn
            if autocommit:
                conn.commit()
        except Exception as e:
            if autocommit:
                conn.rollback()
            raise e
        finally:
            conn.close()


@contextmanager
def get_db_transaction():
    """
    Context manager for database transactions with automatic rollback on error.
    
    Usage:
        with get_db_transaction() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO users ...")
            cursor.execute("UPDATE chatbots ...")
            # Transaction commits automatically on success
            # Rolls back automatically on exception
    """
    pool = get_connection_pool()
    
    if pool:
        conn = pool.getconn()
    else:
        conn = psycopg2.connect(
            get_connection_string(),
            cursor_factory=RealDictCursor,
            connect_timeout=10
        )
    
    try:
        yield conn
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        if pool:
            pool.putconn(conn)
        else:
            conn.close()


def check_connection_health() -> dict:
    """
    Check the health of the database connection pool.
    
    Returns:
        dict with health status, pool info, and connection stats
    """
    pool = get_connection_pool()
    health = {
        "status": "healthy",
        "pool_available": pool is not None,
        "pool_size": None,
        "active_connections": None,
        "idle_connections": None,
        "errors": []
    }
    
    if not pool:
        health["status"] = "degraded"
        health["errors"].append("Connection pool not initialized")
        return health
    
    try:
        # Try to get a connection to test
        test_conn = pool.getconn()
        try:
            cursor = test_conn.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
            health["status"] = "healthy"
        except Exception as e:
            health["status"] = "unhealthy"
            health["errors"].append(f"Connection test failed: {str(e)}")
        finally:
            pool.putconn(test_conn)
        
        # Get pool statistics (if available)
        # Note: psycopg2 pool doesn't expose stats directly, so we estimate
        # In production, consider using pg_stat_activity for real stats
        
    except Exception as e:
        health["status"] = "unhealthy"
        health["errors"].append(f"Health check failed: {str(e)}")
    
    return health


def reconnect_pool():
    """
    Reconnect the connection pool (useful after connection failures).
    Returns True if successful, False otherwise.
    """
    from services.database.pool import reconnect_pool as shared_reconnect_pool
    return shared_reconnect_pool()


# ============================================================================
# Soft Delete Support
# ============================================================================

def add_soft_delete_column(table_name: str, column_name: str = "deleted_at"):
    """
    Add a deleted_at column to a table for soft delete support.
    This should be called during migrations.
    """
    with get_db_connection() as conn:
        cursor = conn.cursor()
        try:
            # Check if column already exists
            cursor.execute("""
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_name = %s AND column_name = %s
            """, (table_name, column_name))
            
            if cursor.fetchone():
                logger.debug(f"Column {column_name} already exists on {table_name}")
                return False
            
            # Add column
            cursor.execute(f"""
                ALTER TABLE {table_name} 
                ADD COLUMN {column_name} TIMESTAMP NULL
            """)
            
            # Create index for faster queries
            cursor.execute(f"""
                CREATE INDEX IF NOT EXISTS idx_{table_name}_{column_name} 
                ON {table_name}({column_name})
            """)
            
            conn.commit()
            logger.info(f"Added soft delete column {column_name} to {table_name}")
            return True
        except Exception as e:
            conn.rollback()
            logger.error(f"Failed to add soft delete column to {table_name}: {e}")
            return False


def soft_delete(table_name: str, record_id: str, id_column: str = "id", deleted_by: str = None):
    """
    Soft delete a record by setting deleted_at timestamp.
    
    Args:
        table_name: Name of the table
        record_id: ID of the record to delete
        id_column: Name of the ID column (default: "id")
        deleted_by: Optional user ID who performed the deletion
    
    Returns:
        True if successful, False otherwise
    """
    with get_db_transaction() as conn:
        cursor = conn.cursor()
        try:
            # Check if deleted_at column exists
            cursor.execute("""
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_name = %s AND column_name = 'deleted_at'
            """, (table_name,))
            
            if not cursor.fetchone():
                # Fallback to hard delete if soft delete not supported
                cursor.execute(f"DELETE FROM {table_name} WHERE {id_column} = %s", (record_id,))
                return cursor.rowcount > 0
            
            # Soft delete
            update_query = f"""
                UPDATE {table_name} 
                SET deleted_at = NOW()
                WHERE {id_column} = %s AND deleted_at IS NULL
            """
            cursor.execute(update_query, (record_id,))
            
            # If table has updated_by column, set it
            if deleted_by:
                cursor.execute("""
                    SELECT column_name 
                    FROM information_schema.columns 
                    WHERE table_name = %s AND column_name = 'deleted_by'
                """, (table_name,))
                if cursor.fetchone():
                    cursor.execute(f"""
                        UPDATE {table_name} 
                        SET deleted_by = %s
                        WHERE {id_column} = %s
                    """, (deleted_by, record_id))
            
            return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Soft delete failed for {table_name}.{record_id}: {e}")
            raise


def restore_soft_deleted(table_name: str, record_id: str, id_column: str = "id"):
    """
    Restore a soft-deleted record by clearing deleted_at.
    
    Args:
        table_name: Name of the table
        record_id: ID of the record to restore
        id_column: Name of the ID column (default: "id")
    
    Returns:
        True if successful, False otherwise
    """
    with get_db_transaction() as conn:
        cursor = conn.cursor()
        try:
            cursor.execute(f"""
                UPDATE {table_name} 
                SET deleted_at = NULL
                WHERE {id_column} = %s AND deleted_at IS NOT NULL
            """, (record_id,))
            return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Restore failed for {table_name}.{record_id}: {e}")
            raise


# ============================================================================
# Batch Operations Utilities
# ============================================================================

def batch_insert(table_name: str, records: list, columns: list, batch_size: int = 100):
    """
    Insert multiple records in batches for better performance.
    
    Args:
        table_name: Name of the table
        records: List of tuples with values matching columns order
        columns: List of column names
        batch_size: Number of records per batch
    
    Returns:
        Number of records inserted
    """
    if not records:
        return 0
    
    columns_str = ", ".join(columns)
    placeholders = ", ".join(["%s"] * len(columns))
    query = f"INSERT INTO {table_name} ({columns_str}) VALUES ({placeholders})"
    
    total_inserted = 0
    
    with get_db_transaction() as conn:
        cursor = conn.cursor()
        try:
            # Process in batches
            for i in range(0, len(records), batch_size):
                batch = records[i:i + batch_size]
                cursor.executemany(query, batch)
                total_inserted += len(batch)
            
            return total_inserted
        except Exception as e:
            logger.error(f"Batch insert failed for {table_name}: {e}")
            raise


def batch_update(table_name: str, updates: list, id_column: str = "id", batch_size: int = 100):
    """
    Update multiple records in batches.
    
    Args:
        table_name: Name of the table
        updates: List of dicts with {id: value, field1: value1, ...}
        id_column: Name of the ID column
        batch_size: Number of records per batch
    
    Returns:
        Number of records updated
    """
    if not updates:
        return 0
    
    total_updated = 0
    
    with get_db_transaction() as conn:
        cursor = conn.cursor()
        try:
            for i in range(0, len(updates), batch_size):
                batch = updates[i:i + batch_size]
                
                for record in batch:
                    record_id = record.pop(id_column)
                    set_clauses = []
                    values = []
                    
                    for field, value in record.items():
                        set_clauses.append(f"{field} = %s")
                        values.append(value)
                    
                    if set_clauses:
                        set_clauses.append("updated_at = NOW()")
                        values.append(record_id)
                        
                        query = f"""
                            UPDATE {table_name} 
                            SET {', '.join(set_clauses)}
                            WHERE {id_column} = %s AND deleted_at IS NULL
                        """
                        cursor.execute(query, values)
                        total_updated += cursor.rowcount
            
            return total_updated
        except Exception as e:
            logger.error(f"Batch update failed for {table_name}: {e}")
            raise


def init_database():
    """
    Initialize database tables and run migrations.
    This function creates all necessary tables if they don't exist
    and handles schema migrations.
    """
    from datetime import datetime
    import json
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                hashed_password TEXT,
                full_name TEXT,
                role TEXT NOT NULL DEFAULT 'viewer',
                status TEXT NOT NULL DEFAULT 'pending',
                custom_chatbot_limit INTEGER,
                invite_token TEXT,
                invite_expires_at TIMESTAMP,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                last_login TIMESTAMP,
                mfa_enabled BOOLEAN DEFAULT FALSE,
                mfa_secret TEXT,
                backup_codes JSONB DEFAULT '[]',
                partner_id TEXT REFERENCES users(id) ON DELETE SET NULL,
                branding_logo_url TEXT,
                branding_company_name TEXT,
                branding_primary_color TEXT,
                branding_secondary_color TEXT,
                branding_theme TEXT DEFAULT 'dark',
                branding_setup_complete BOOLEAN DEFAULT FALSE,
                is_super_user BOOLEAN DEFAULT FALSE
            )
        ''')
        
        # Check existing columns for migrations
        cursor.execute("""
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name = 'users'
        """)
        existing_columns = [row['column_name'] for row in cursor.fetchall()]
        
        # Migrations for users table
        migrations = {
            'custom_chatbot_limit': 'ALTER TABLE users ADD COLUMN custom_chatbot_limit INTEGER',
            'mfa_enabled': 'ALTER TABLE users ADD COLUMN mfa_enabled BOOLEAN DEFAULT FALSE',
            'mfa_secret': 'ALTER TABLE users ADD COLUMN mfa_secret TEXT',
            'backup_codes': "ALTER TABLE users ADD COLUMN backup_codes JSONB DEFAULT '[]'",
            'branding_logo_url': 'ALTER TABLE users ADD COLUMN branding_logo_url TEXT',
            'branding_company_name': 'ALTER TABLE users ADD COLUMN branding_company_name TEXT',
            'branding_primary_color': 'ALTER TABLE users ADD COLUMN branding_primary_color TEXT',
            'branding_secondary_color': 'ALTER TABLE users ADD COLUMN branding_secondary_color TEXT',
            'branding_theme': "ALTER TABLE users ADD COLUMN branding_theme TEXT DEFAULT 'dark'",
            'branding_setup_complete': 'ALTER TABLE users ADD COLUMN branding_setup_complete BOOLEAN DEFAULT FALSE',
            'partner_id': 'ALTER TABLE users ADD COLUMN partner_id TEXT REFERENCES users(id) ON DELETE SET NULL',
            'is_super_user': 'ALTER TABLE users ADD COLUMN is_super_user BOOLEAN DEFAULT FALSE',
            'moderator_chatbot_ids': "ALTER TABLE users ADD COLUMN moderator_chatbot_ids JSONB DEFAULT '[]'"
        }
        
        for column, sql in migrations.items():
            if column not in existing_columns:
                cursor.execute(sql)
                print(f"[Database Migration] Added {column} column to users table")
        
        # Create index for partner_id if it doesn't exist
        cursor.execute("""
            SELECT indexname FROM pg_indexes 
            WHERE tablename = 'users' AND indexname = 'idx_users_partner'
        """)
        if not cursor.fetchone():
            cursor.execute('CREATE INDEX idx_users_partner ON users(partner_id)')
        
        conn.commit()
        
        # Chatbots table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chatbots (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                owner_id TEXT REFERENCES users(id) ON DELETE SET NULL,
                status TEXT NOT NULL DEFAULT 'Draft',
                users INTEGER DEFAULT 0,
                accuracy TEXT DEFAULT 'N/A',
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
                config JSONB NOT NULL DEFAULT '{}',
                data JSONB NOT NULL DEFAULT '{}',
                deleted_at TIMESTAMP NULL,
                deleted_by TEXT REFERENCES users(id) ON DELETE SET NULL
             )
        ''')
        
        # Add soft delete column if it doesn't exist (migration)
        cursor.execute("""
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name = 'chatbots' AND column_name = 'deleted_at'
        """)
        if not cursor.fetchone():
            cursor.execute('ALTER TABLE chatbots ADD COLUMN deleted_at TIMESTAMP NULL')
            cursor.execute('ALTER TABLE chatbots ADD COLUMN deleted_by TEXT REFERENCES users(id) ON DELETE SET NULL')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_chatbots_deleted_at ON chatbots(deleted_at)')
        
        # Scraped content table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS scraped_content (
                chatbot_id TEXT PRIMARY KEY REFERENCES chatbots(id) ON DELETE CASCADE,
                source_url TEXT,
                scraped_at TIMESTAMP,
                pages JSONB DEFAULT '[]',
                total_words INTEGER DEFAULT 0,
                total_pages INTEGER DEFAULT 0
            )
        ''')
        
        # Logs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS logs (
                id TEXT PRIMARY KEY,
                timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
                level TEXT NOT NULL,
                service TEXT NOT NULL,
                user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
                chatbot_id TEXT REFERENCES chatbots(id) ON DELETE SET NULL,
                action TEXT,
                message TEXT NOT NULL,
                metadata JSONB DEFAULT '{}'
            )
        ''')
        
        # Error logs table for persistent error tracking
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS error_logs (
                id TEXT PRIMARY KEY,
                request_id TEXT NOT NULL,
                error_type TEXT NOT NULL,
                error_code TEXT,
                error_message TEXT NOT NULL,
                category TEXT NOT NULL,
                path TEXT,
                method TEXT,
                status_code INTEGER,
                context JSONB DEFAULT '{}',
                created_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_error_logs_request_id ON error_logs(request_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_error_logs_category ON error_logs(category)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_error_logs_created_at ON error_logs(created_at)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_error_logs_error_code ON error_logs(error_code)')
        
        # Settings table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'general',
                updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_by TEXT REFERENCES users(id) ON DELETE SET NULL
            )
        ''')
        
        # Knowledge items table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS knowledge_items (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                source_type TEXT NOT NULL,
                title TEXT,
                content TEXT NOT NULL,
                url TEXT,
                word_count INTEGER DEFAULT 0,
                vector_id TEXT,
                metadata JSONB DEFAULT '{}',
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        
        # Training jobs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS training_jobs (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                status TEXT NOT NULL DEFAULT 'pending',
                started_at TIMESTAMP,
                completed_at TIMESTAMP,
                pages_processed INTEGER DEFAULT 0,
                error TEXT,
                metadata JSONB DEFAULT '{}'
            )
        ''')
        
        # Chat sessions table for conversation tracking
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chat_sessions (
                session_id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                started_at TIMESTAMP NOT NULL DEFAULT NOW(),
                last_activity TIMESTAMP NOT NULL DEFAULT NOW(),
                message_count INTEGER DEFAULT 0,
                category TEXT DEFAULT 'General',
                has_unknown_interaction BOOLEAN DEFAULT FALSE,
                metadata JSONB DEFAULT '{}'
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_sessions_chatbot ON chat_sessions(chatbot_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_sessions_activity ON chat_sessions(last_activity)')
        
        # Chat messages table for persistent history
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chat_messages (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL REFERENCES chat_sessions(session_id) ON DELETE CASCADE,
                chatbot_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                intent TEXT,
                confidence FLOAT,
                is_unknown BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                metadata JSONB DEFAULT '{}'
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_messages_session ON chat_messages(session_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_messages_chatbot ON chat_messages(chatbot_id)')
        
        # Response feedback table (Phase 4.2: thumbs up/down)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS response_feedback (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                session_id TEXT NOT NULL,
                rating TEXT NOT NULL CHECK (rating IN ('thumbs_up', 'thumbs_down')),
                created_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_feedback_chatbot ON response_feedback(chatbot_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_feedback_created ON response_feedback(created_at)')
        
        # Integrations table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS integrations (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                integration_type TEXT NOT NULL,
                name TEXT NOT NULL,
                config JSONB NOT NULL DEFAULT '{}',
                status TEXT NOT NULL DEFAULT 'inactive',
                metadata JSONB DEFAULT '{}',
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        
        # CRM Companies table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS crm_companies (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                website TEXT,
                industry TEXT,
                size TEXT,
                description TEXT,
                metadata JSONB DEFAULT '{}',
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        
        # CRM Leads table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS crm_leads (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                company_id TEXT REFERENCES crm_companies(id) ON DELETE SET NULL,
                company_name TEXT,
                status TEXT NOT NULL DEFAULT 'new',
                priority TEXT NOT NULL DEFAULT 'medium',
                source TEXT,
                estimated_value DECIMAL(10, 2),
                account_owner_id TEXT REFERENCES users(id) ON DELETE SET NULL,
                next_followup_date TIMESTAMP,
                last_contact_date TIMESTAMP,
                notes TEXT,
                metadata JSONB DEFAULT '{}',
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        
        # Qualifications table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS qualifications (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                framework_name TEXT NOT NULL,
                framework_config JSONB NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        
        # Qualification answers table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS qualification_answers (
                id TEXT PRIMARY KEY,
                qualification_id TEXT NOT NULL REFERENCES qualifications(id) ON DELETE CASCADE,
                lead_id TEXT NOT NULL REFERENCES crm_leads(id) ON DELETE CASCADE,
                answers JSONB NOT NULL,
                score INTEGER NOT NULL DEFAULT 0,
                percentage INTEGER NOT NULL DEFAULT 0,
                tier TEXT,
                created_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        
        # Pipelines table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pipelines (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                stages JSONB NOT NULL DEFAULT '[]',
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        
        # Automations table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS automations (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                trigger_type TEXT NOT NULL,
                trigger_conditions JSONB NOT NULL DEFAULT '[]',
                actions JSONB NOT NULL DEFAULT '[]',
                enabled BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        
        # Chatbot blueprints table (Phase 4 - Marketplace MVP)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chatbot_blueprints (
                id TEXT PRIMARY KEY,
                owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                description TEXT,
                category TEXT DEFAULT 'general',
                config JSONB NOT NULL DEFAULT '{}',
                is_public BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_blueprints_owner ON chatbot_blueprints(owner_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_blueprints_public ON chatbot_blueprints(is_public)')
        
        # Workflows table (Phase 4 - Multi-step automations)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS workflows (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                steps JSONB NOT NULL DEFAULT '[]',
                enabled BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_workflows_chatbot ON workflows(chatbot_id)')
        # Migration: add triggers column for workflow trigger evaluation
        cursor.execute("""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = 'workflows' AND column_name = 'triggers'
        """)
        if not cursor.fetchone():
            cursor.execute("ALTER TABLE workflows ADD COLUMN triggers JSONB DEFAULT '[]'")
        
        # Email sequences table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS email_sequences (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                emails JSONB NOT NULL DEFAULT '[]',
                enabled BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        
        # Onboarding workflows table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS onboarding_workflows (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                steps JSONB NOT NULL DEFAULT '[]',
                enabled BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        
        # Custom actions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS custom_actions (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                description TEXT,
                url_template TEXT NOT NULL,
                method TEXT NOT NULL DEFAULT 'POST',
                headers JSONB DEFAULT '{}',
                parameters JSONB DEFAULT '[]',
                enabled BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        # Migration: add url_template if table had old "url" column (no url_template)
        cursor.execute("""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = 'custom_actions' AND column_name = 'url_template'
        """)
        if not cursor.fetchone():
            cursor.execute("""
                SELECT column_name FROM information_schema.columns
                WHERE table_name = 'custom_actions' AND column_name = 'url'
            """)
            has_url = cursor.fetchone()
            cursor.execute('ALTER TABLE custom_actions ADD COLUMN url_template TEXT')
            if has_url:
                cursor.execute("""
                    UPDATE custom_actions SET url_template = COALESCE(url, '')
                """)
                cursor.execute('ALTER TABLE custom_actions DROP COLUMN IF EXISTS url')
            cursor.execute("""
                UPDATE custom_actions SET url_template = '' WHERE url_template IS NULL
            """)
            cursor.execute('ALTER TABLE custom_actions ALTER COLUMN url_template SET NOT NULL')
        
        # History access grants: owner can grant chat-history access by email.
        # Only owner or granted users can access history; super_user has no bypass.
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS history_access_grants (
                id TEXT PRIMARY KEY,
                owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                granted_email TEXT NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                UNIQUE(owner_id, granted_email)
            )
        ''')
        cursor.execute(
            'CREATE INDEX IF NOT EXISTS idx_history_access_grants_owner ON history_access_grants(owner_id)'
        )
        cursor.execute(
            'CREATE INDEX IF NOT EXISTS idx_history_access_grants_email ON history_access_grants(owner_id, granted_email)'
        )
        
        # History storage config: owner chooses local (client-only) vs cloud (we store) vs owner_device (export to folder).
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS history_storage_config (
                owner_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
                storage_type TEXT NOT NULL DEFAULT 'local' CHECK (storage_type IN ('local', 'cloud', 'owner_device')),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        # Migration: extend check to include owner_device (for existing tables)
        try:
            cursor.execute("ALTER TABLE history_storage_config DROP CONSTRAINT IF EXISTS history_storage_config_storage_type_check")
            cursor.execute("ALTER TABLE history_storage_config ADD CONSTRAINT history_storage_config_storage_type_check CHECK (storage_type IN ('local', 'cloud', 'owner_device'))")
        except Exception:
            pass
        
        # Live chat requests: secure storage for human handoff queue
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS live_chat_requests (
                request_id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                session_id TEXT NOT NULL,
                message TEXT,
                page_url TEXT,
                status TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'active', 'closed', 'cancelled')),
                moderator_id TEXT REFERENCES users(id) ON DELETE SET NULL,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                accepted_at TIMESTAMP,
                closed_at TIMESTAMP,
                metadata JSONB DEFAULT '{}'
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_live_chat_status ON live_chat_requests(status)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_live_chat_chatbot ON live_chat_requests(chatbot_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_live_chat_created ON live_chat_requests(created_at)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_live_chat_moderator ON live_chat_requests(moderator_id)')
        # Migration: user_closed_at when user closes from widget (agent keeps chat until they end)
        cursor.execute("""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = 'live_chat_requests' AND column_name = 'user_closed_at'
        """)
        if not cursor.fetchone():
            cursor.execute('ALTER TABLE live_chat_requests ADD COLUMN user_closed_at TIMESTAMP NULL')
        
        # Elias assistant: summaries and to-dos (smart assistant tab)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS elias_summaries (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                type TEXT NOT NULL CHECK (type IN ('daily', 'session')),
                content TEXT NOT NULL,
                period_start TIMESTAMP,
                period_end TIMESTAMP,
                session_id TEXT,
                created_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_elias_summaries_user ON elias_summaries(user_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_elias_summaries_created ON elias_summaries(created_at DESC)')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS elias_todos (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                title TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'done', 'cancelled')),
                due_at TIMESTAMP,
                created_from_session_id TEXT,
                created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_elias_todos_user ON elias_todos(user_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_elias_todos_status ON elias_todos(status)')

        # LLM audit log (AI ethics, attribution)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS llm_audit_log (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                session_id TEXT,
                request_id TEXT,
                prompt_hash TEXT,
                model TEXT,
                tokens_in INTEGER DEFAULT 0,
                tokens_out INTEGER DEFAULT 0,
                latency_ms INTEGER DEFAULT 0,
                created_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_llm_audit_chatbot ON llm_audit_log(chatbot_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_llm_audit_created ON llm_audit_log(created_at DESC)')

        # Conversation audit (AI ethics - event log for user_message_received, response_generated)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversation_audit (
                id TEXT PRIMARY KEY,
                chatbot_id TEXT NOT NULL REFERENCES chatbots(id) ON DELETE CASCADE,
                session_id TEXT,
                event_type TEXT NOT NULL,
                payload_json JSONB NOT NULL DEFAULT '{}',
                created_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_conversation_audit_chatbot ON conversation_audit(chatbot_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_conversation_audit_created ON conversation_audit(created_at DESC)')

        # Conversation flows (Conversation Studio - intent overrides, flow JSON)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversation_flows (
                chatbot_id TEXT PRIMARY KEY REFERENCES chatbots(id) ON DELETE CASCADE,
                flow_json JSONB NOT NULL DEFAULT '{}',
                version INTEGER DEFAULT 1,
                updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
        ''')
        
        conn.commit()
        print("[Database] All tables initialized successfully")
        
        # Create performance indexes
        try:
            from services.database.indexes import create_performance_indexes
            indexes_created = create_performance_indexes()
            print(f"[Database] Created {indexes_created} performance indexes")
        except Exception as e:
            print(f"[Database] Warning: Failed to create indexes: {e}")

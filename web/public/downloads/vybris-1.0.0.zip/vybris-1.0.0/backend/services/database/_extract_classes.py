"""
Helper script to extract database classes from monolithic database.py
This script helps identify class boundaries for manual extraction
"""

import re

# Read the original file
with open('../database.py', 'r') as f:
    content = f.read()

# Find all class definitions with their line numbers
classes = []
for match in re.finditer(r'^class (\w+DB):', content, re.MULTILINE):
    class_name = match.group(1)
    line_num = content[:match.start()].count('\n') + 1
    classes.append((class_name, line_num, match.start()))

# Find the end of each class (next class or end of file)
for i, (class_name, line_num, start_pos) in enumerate(classes):
    if i + 1 < len(classes):
        end_pos = classes[i + 1][2]
    else:
        end_pos = len(content)
    
    class_content = content[start_pos:end_pos]
    # Find the last method/function in the class
    # Look for the next class-level definition (not indented)
    lines = class_content.split('\n')
    class_lines = []
    for line in lines:
        if line.strip() and not line.startswith(' ') and not line.startswith('\t'):
            if line.strip().startswith('class ') or line.strip().startswith('def '):
                if line.strip().startswith('class '):
                    break
        class_lines.append(line)
    
    print(f"\n{class_name} (starts at line {line_num}):")
    print(f"  Length: {len(class_content)} chars")
    print(f"  Methods found: {len(re.findall(r'    @staticmethod|    def ', class_content))}")

"""
Knowledge Database Operations
Handles all database operations for knowledge items
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


class KnowledgeDB:
    """Database operations for knowledge items"""
    
    @staticmethod
    def create(item_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new knowledge item"""
        return KnowledgeDB.create_batch([item_data])[0]

    @staticmethod
    def create_batch(items_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Create multiple knowledge items in a single transaction"""
        if not items_data:
            return []
            
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            # Prepare data values
            values_list = []
            results = []
            
            for item in items_data:
                item_id = item.get('id', f"ki_{uuid.uuid4().hex[:12]}")
                values_list.append((
                    item_id,
                    item['chatbot_id'],
                    item['source_type'],
                    item.get('title'),
                    item['content'],
                    item.get('url'),
                    item.get('word_count', len(item['content'].split())),
                    item.get('vector_id'),
                    json.dumps(item.get('metadata', {}))
                ))
            
            # Execute batch insert
            cursor.executemany('''
                INSERT INTO knowledge_items (id, chatbot_id, source_type, title, content, url, word_count, vector_id, metadata)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            ''', values_list)
            
            conn.commit()
            
            # Return created items
            return [{'id': v[0], 'status': 'created'} for v in values_list]
    
    @staticmethod
    def get_by_chatbot(chatbot_id: str) -> List[Dict[str, Any]]:
        """Get all knowledge items for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM knowledge_items WHERE chatbot_id = %s ORDER BY created_at DESC', (chatbot_id,))
            rows = cursor.fetchall()
            results = []
            for row in rows:
                result = dict(row)
                result['metadata'] = result['metadata'] if isinstance(result['metadata'], dict) else json.loads(result.get('metadata') or '{}')
                results.append(result)
            return results
    
    @staticmethod
    def get_by_id(item_id: str) -> Optional[Dict[str, Any]]:
        """Get a single knowledge item"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM knowledge_items WHERE id = %s', (item_id,))
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['metadata'] = result['metadata'] if isinstance(result['metadata'], dict) else json.loads(result.get('metadata') or '{}')
                return result
            return None
    
    @staticmethod
    def update(item_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a knowledge item"""
        allowed_fields = ['title', 'content', 'url', 'word_count', 'vector_id', 'metadata']
        set_clauses = ['updated_at = NOW()']
        values = []
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                if field == 'metadata':
                    values.append(json.dumps(updates[field]))
                else:
                    values.append(updates[field])
        
        values.append(item_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f'''
                UPDATE knowledge_items SET {", ".join(set_clauses)}
                WHERE id = %s
                RETURNING *
            ''', values)
            conn.commit()
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['metadata'] = result['metadata'] if isinstance(result['metadata'], dict) else json.loads(result.get('metadata') or '{}')
                return result
            return None
    
    @staticmethod
    def delete(item_id: str) -> bool:
        """Delete a knowledge item"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM knowledge_items WHERE id = %s', (item_id,))
            conn.commit()
            return cursor.rowcount > 0
    
    @staticmethod
    def delete_by_chatbot(chatbot_id: str) -> int:
        """Delete all knowledge items for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM knowledge_items WHERE chatbot_id = %s', (chatbot_id,))
            conn.commit()
            return cursor.rowcount

    @staticmethod
    def delete_by_chatbot_and_source(chatbot_id: str, source_type: str) -> int:
        """Delete knowledge items for a chatbot by source type"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                'DELETE FROM knowledge_items WHERE chatbot_id = %s AND source_type = %s',
                (chatbot_id, source_type)
            )
            conn.commit()
            return cursor.rowcount

"""
CORS Origins Database Operations
Manages allowed CORS origins for widget embedding
"""

from typing import List, Optional, Dict, Any
from datetime import datetime
from .base import get_db_connection, get_db_transaction
import logging

logger = logging.getLogger(__name__)


class CORSOriginsDB:
    """Database operations for CORS allowed origins"""
    
    @staticmethod
    def ensure_table():
        """Ensure the cors_origins table exists"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS cors_origins (
                    id SERIAL PRIMARY KEY,
                    origin TEXT NOT NULL UNIQUE,
                    domain TEXT NOT NULL,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    added_by_chatbot_id TEXT,
                    is_active BOOLEAN DEFAULT TRUE,
                    notes TEXT
                )
            ''')
            
            # Create index for faster lookups
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_cors_origins_domain 
                ON cors_origins(domain)
            ''')
            
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_cors_origins_active 
                ON cors_origins(is_active) WHERE is_active = TRUE
            ''')
            
            conn.commit()
            logger.debug("CORS origins table ensured")
    
    @staticmethod
    def add_origin(origin: str, domain: str, chatbot_id: Optional[str] = None, notes: Optional[str] = None) -> bool:
        """
        Add a CORS origin to the allowed list.
        
        Args:
            origin: Full origin URL (e.g., "https://example.com" or "http://example.com")
            domain: Base domain (e.g., "example.com")
            chatbot_id: Optional chatbot ID that triggered this addition
            notes: Optional notes about why this origin was added
        
        Returns:
            True if added, False if already exists
        """
        CORSOriginsDB.ensure_table()
        
        with get_db_transaction() as conn:
            cursor = conn.cursor()
            try:
                cursor.execute('''
                    INSERT INTO cors_origins (origin, domain, added_by_chatbot_id, notes)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (origin) DO UPDATE SET
                        is_active = TRUE,
                        added_at = CURRENT_TIMESTAMP
                ''', (origin, domain, chatbot_id, notes))
                
                logger.info(f"Added CORS origin: {origin} (domain: {domain})")
                return True
            except Exception as e:
                logger.error(f"Failed to add CORS origin {origin}: {e}")
                return False
    
    @staticmethod
    def add_domain_from_url(url: str, chatbot_id: Optional[str] = None) -> List[str]:
        """
        Add both HTTP and HTTPS origins for a domain extracted from a URL.
        
        Args:
            url: Source URL (e.g., "https://example.com/page")
            chatbot_id: Optional chatbot ID that triggered this addition
        
        Returns:
            List of origins that were added (e.g., ["https://example.com", "http://example.com"])
        """
        from urllib.parse import urlparse
        
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            
            # Remove port
            if ':' in domain:
                domain = domain.split(':')[0]
            
            # Remove www prefix for consistency
            base_domain = domain[4:] if domain.startswith('www.') else domain
            
            if not base_domain:
                return []
            
            added_origins = []
            
            # Add both HTTP and HTTPS versions
            for scheme in ['https', 'http']:
                origin = f"{scheme}://{base_domain}"
                if CORSOriginsDB.add_origin(
                    origin=origin,
                    domain=base_domain,
                    chatbot_id=chatbot_id,
                    notes=f"Auto-added from scraped URL: {url}"
                ):
                    added_origins.append(origin)
            
            # Also add www variant if original had www
            if domain.startswith('www.'):
                for scheme in ['https', 'http']:
                    origin = f"{scheme}://{domain}"
                    if CORSOriginsDB.add_origin(
                        origin=origin,
                        domain=base_domain,
                        chatbot_id=chatbot_id,
                        notes=f"Auto-added from scraped URL: {url}"
                    ):
                        added_origins.append(origin)
            
            return added_origins
            
        except Exception as e:
            logger.error(f"Failed to add domain from URL {url}: {e}")
            return []
    
    @staticmethod
    def get_all_active() -> List[str]:
        """Get all active CORS origins"""
        CORSOriginsDB.ensure_table()
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT origin FROM cors_origins 
                WHERE is_active = TRUE 
                ORDER BY added_at DESC
            ''')
            rows = cursor.fetchall()
            return [row['origin'] for row in rows]
    
    @staticmethod
    def get_all() -> List[Dict[str, Any]]:
        """Get all CORS origins with metadata"""
        CORSOriginsDB.ensure_table()
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, origin, domain, added_at, added_by_chatbot_id, is_active, notes
                FROM cors_origins 
                ORDER BY added_at DESC
            ''')
            rows = cursor.fetchall()
            return [
                {
                    'id': row['id'],
                    'origin': row['origin'],
                    'domain': row['domain'],
                    'added_at': row['added_at'].isoformat() if hasattr(row['added_at'], 'isoformat') else str(row['added_at']),
                    'added_by_chatbot_id': row['added_by_chatbot_id'],
                    'is_active': row['is_active'],
                    'notes': row['notes']
                }
                for row in rows
            ]
    
    @staticmethod
    def deactivate(origin: str) -> bool:
        """Deactivate a CORS origin"""
        with get_db_transaction() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE cors_origins 
                SET is_active = FALSE 
                WHERE origin = %s
            ''', (origin,))
            return cursor.rowcount > 0
    
    @staticmethod
    def delete(origin: str) -> bool:
        """Delete a CORS origin"""
        with get_db_transaction() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM cors_origins WHERE origin = %s', (origin,))
            return cursor.rowcount > 0

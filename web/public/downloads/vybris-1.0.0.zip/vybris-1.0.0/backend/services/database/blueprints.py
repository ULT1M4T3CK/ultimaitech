"""
Blueprint Database Operations (Phase 4 - Marketplace MVP)
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


class BlueprintDB:
    """Database operations for chatbot blueprints."""

    @staticmethod
    def create(data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        bid = data.get("id") or f"bp_{uuid.uuid4().hex[:12]}"
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO chatbot_blueprints (id, owner_id, name, description, category, config, is_public)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                RETURNING *
                """,
                (
                    bid,
                    data["owner_id"],
                    data.get("name", "Untitled"),
                    data.get("description"),
                    data.get("category", "general"),
                    json.dumps(data.get("config", {})),
                    data.get("is_public", False),
                ),
            )
            conn.commit()
            row = cursor.fetchone()
            return _row_to_blueprint(row) if row else None

    @staticmethod
    def get_by_id(blueprint_id: str) -> Optional[Dict[str, Any]]:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM chatbot_blueprints WHERE id = %s", (blueprint_id,))
            row = cursor.fetchone()
            return _row_to_blueprint(row) if row else None

    @staticmethod
    def get_by_owner(owner_id: str) -> List[Dict[str, Any]]:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM chatbot_blueprints WHERE owner_id = %s ORDER BY updated_at DESC", (owner_id,))
            return [_row_to_blueprint(row) for row in cursor.fetchall()]

    @staticmethod
    def list_public(category: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            if category:
                cursor.execute(
                    "SELECT * FROM chatbot_blueprints WHERE is_public = TRUE AND category = %s ORDER BY updated_at DESC LIMIT %s",
                    (category, limit),
                )
            else:
                cursor.execute(
                    "SELECT * FROM chatbot_blueprints WHERE is_public = TRUE ORDER BY updated_at DESC LIMIT %s",
                    (limit,),
                )
            return [_row_to_blueprint(row) for row in cursor.fetchall()]

    @staticmethod
    def update(blueprint_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        allowed = ["name", "description", "category", "config", "is_public"]
        set_clauses = ["updated_at = NOW()"]
        values = []
        for f in allowed:
            if f in updates:
                set_clauses.append(f"{f} = %s")
                values.append(json.dumps(updates[f]) if f == "config" else updates[f])
        if len(set_clauses) == 1:
            return BlueprintDB.get_by_id(blueprint_id)
        values.append(blueprint_id)
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                f"UPDATE chatbot_blueprints SET {', '.join(set_clauses)} WHERE id = %s RETURNING *",
                values,
            )
            conn.commit()
            row = cursor.fetchone()
            return _row_to_blueprint(row) if row else None

    @staticmethod
    def delete(blueprint_id: str) -> bool:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM chatbot_blueprints WHERE id = %s", (blueprint_id,))
            conn.commit()
            return cursor.rowcount > 0


def _row_to_blueprint(row) -> Dict[str, Any]:
    d = dict(row)
    if "config" in d and isinstance(d["config"], str):
        d["config"] = json.loads(d["config"] or "{}")
    return d

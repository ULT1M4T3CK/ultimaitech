"""
Qualification Database Operations
Handles all database operations for qualification frameworks
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


def _row_to_qualification_framework(row: Dict) -> Dict[str, Any]:
    """Convert database row to qualification framework dict"""
    return {
        'id': row['id'],
        'chatbot_id': row.get('chatbot_id'),
        'framework_name': row.get('framework_name'),
        'framework_config': row['framework_config'] if isinstance(row.get('framework_config'), dict) else json.loads(row.get('framework_config') or '{}'),
        'created_at': row['created_at'].isoformat() + 'Z' if hasattr(row.get('created_at'), 'isoformat') else row.get('created_at'),
        'updated_at': row['updated_at'].isoformat() + 'Z' if hasattr(row.get('updated_at'), 'isoformat') else row.get('updated_at')
    }


class QualificationDB:
    """Database operations for qualification frameworks"""
    
    @staticmethod
    def create(framework_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new qualification framework"""
        framework_id = framework_data.get('id') or str(uuid.uuid4())
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO qualifications (id, chatbot_id, framework_name, framework_config)
                VALUES (%s, %s, %s, %s)
                RETURNING *
            ''', (
                framework_id,
                framework_data.get('chatbot_id'),
                framework_data.get('framework_name', 'Custom Qualification'),
                json.dumps(framework_data.get('framework_config', {}))
            ))
            conn.commit()
            row = cursor.fetchone()
            return _row_to_qualification_framework(row) if row else None
    
    @staticmethod
    def get_by_chatbot(chatbot_id: str) -> Optional[Dict[str, Any]]:
        """Get the qualification framework for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM qualifications WHERE chatbot_id = %s ORDER BY created_at DESC LIMIT 1',
                (chatbot_id,)
            )
            row = cursor.fetchone()
            return _row_to_qualification_framework(row) if row else None
    
    @staticmethod
    def get_by_id(framework_id: str) -> Optional[Dict[str, Any]]:
        """Get a qualification framework by ID"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM qualifications WHERE id = %s', (framework_id,))
            row = cursor.fetchone()
            return _row_to_qualification_framework(row) if row else None
    
    @staticmethod
    def update(framework_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a qualification framework"""
        allowed_fields = ['framework_name', 'framework_config']
        set_clauses = ['updated_at = NOW()']
        values = []
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                if field == 'framework_config':
                    values.append(json.dumps(updates[field]))
                else:
                    values.append(updates[field])
        
        if len(set_clauses) == 1:  # Only updated_at
            return QualificationDB.get_by_id(framework_id)
        
        values.append(framework_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f'''
                UPDATE qualifications SET {", ".join(set_clauses)}
                WHERE id = %s
                RETURNING *
            ''', values)
            conn.commit()
            row = cursor.fetchone()
            return _row_to_qualification_framework(row) if row else None
    
    @staticmethod
    def delete(framework_id: str) -> bool:
        """Delete a qualification framework"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM qualifications WHERE id = %s', (framework_id,))
            conn.commit()
            return cursor.rowcount > 0
    
    @staticmethod
    def calculate_score(answers: List[Dict], framework: Dict) -> Dict[str, Any]:
        """Calculate qualification score from answers"""
        total_score = 0
        max_score = 0
        answer_details = []
        
        questions = framework.get('framework_config', {}).get('questions', [])
        for i, question in enumerate(questions):
            answer = answers[i] if i < len(answers) else None
            question_score = 0
            max_question_score = 0
            
            if question.get('answer_options'):
                # Multiple choice - find the selected option's score
                for option in question['answer_options']:
                    option_score = option.get('score', 0)
                    if option_score > max_question_score:
                        max_question_score = option_score
                    if answer and option.get('value') == answer.get('value'):
                        question_score = option_score
            else:
                # Free text - use default score if answered
                max_question_score = question.get('max_score', 10)
                if answer and answer.get('value'):
                    question_score = question.get('default_score', max_question_score)
            
            total_score += question_score
            max_score += max_question_score
            answer_details.append({
                'question': question.get('text'),
                'answer': answer.get('value') if answer else None,
                'score': question_score,
                'max_score': max_question_score
            })
        
        # Calculate percentage
        percentage = round((total_score / max_score * 100) if max_score > 0 else 0)
        
        # Determine tier (using default thresholds if not specified)
        config = framework.get('framework_config', {})
        hot_threshold = config.get('hot_threshold', 80)
        warm_threshold = config.get('warm_threshold', 50)
        cold_threshold = config.get('cold_threshold', 25)
        
        if percentage >= hot_threshold:
            tier = 'Hot'
        elif percentage >= warm_threshold:
            tier = 'Warm'
        elif percentage >= cold_threshold:
            tier = 'Cold'
        else:
            tier = 'Unqualified'
        
        return {
            'score': percentage,
            'tier': tier,
            'total_points': total_score,
            'max_points': max_score,
            'answers': answer_details
        }

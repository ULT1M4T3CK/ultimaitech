"""
Scraped Content Database Operations
Handles all database operations for scraped content
"""

import json
from typing import Optional, Dict, Any
from .base import get_db_connection


class ScrapedContentDB:
    """Database operations for scraped content"""
    
    @staticmethod
    def save(chatbot_id: str, content: Dict[str, Any]) -> None:
        """Save scraped content for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO scraped_content (chatbot_id, source_url, scraped_at, pages, total_words, total_pages)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (chatbot_id) DO UPDATE SET
                    source_url = EXCLUDED.source_url,
                    scraped_at = EXCLUDED.scraped_at,
                    pages = EXCLUDED.pages,
                    total_words = EXCLUDED.total_words,
                    total_pages = EXCLUDED.total_pages
            ''', (
                chatbot_id,
                content.get('source_url'),
                content.get('scraped_at'),
                json.dumps(content.get('pages', [])),
                content.get('total_words', 0),
                content.get('total_pages', 0)
            ))
            conn.commit()
    
    @staticmethod
    def get(chatbot_id: str) -> Optional[Dict[str, Any]]:
        """Get scraped content for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM scraped_content WHERE chatbot_id = %s', (chatbot_id,))
            row = cursor.fetchone()
            
            if row:
                return {
                    'chatbot_id': row['chatbot_id'],
                    'source_url': row['source_url'],
                    'scraped_at': row['scraped_at'].isoformat() if hasattr(row['scraped_at'], 'isoformat') else row['scraped_at'],
                    'pages': row['pages'] if isinstance(row['pages'], list) else json.loads(row['pages']),
                    'total_words': row['total_words'],
                    'total_pages': row['total_pages']
                }
            return None
    
    @staticmethod
    def delete(chatbot_id: str) -> bool:
        """Delete scraped content for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM scraped_content WHERE chatbot_id = %s', (chatbot_id,))
            conn.commit()
            return cursor.rowcount > 0

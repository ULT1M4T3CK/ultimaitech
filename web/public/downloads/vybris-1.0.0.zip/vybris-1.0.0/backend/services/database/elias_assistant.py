"""
Elias Assistant Database Operations
Stores summaries and to-dos for the Elias smart assistant tab.
All access is scoped by user_id for security.
"""

import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


# Maximum lengths for validation (security / UX)
SUMMARY_CONTENT_MAX_LEN = 50_000
TODO_TITLE_MAX_LEN = 500


class EliasSummariesDB:
    """Database operations for Elias summaries. User-scoped."""

    @staticmethod
    def create(
        user_id: str,
        summary_type: str,
        content: str,
        *,
        period_start: Optional[str] = None,
        period_end: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a summary. Content is truncated to SUMMARY_CONTENT_MAX_LEN."""
        if summary_type not in ("daily", "session"):
            raise ValueError("type must be 'daily' or 'session'")
        content = (content or "")[:SUMMARY_CONTENT_MAX_LEN]
        summary_id = f"es_{uuid.uuid4().hex[:16]}"
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO elias_summaries (id, user_id, type, content, period_start, period_end, session_id)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                RETURNING *
                """,
                (summary_id, user_id, summary_type, content, period_start, period_end, session_id),
            )
            conn.commit()
            row = cursor.fetchone()
            return dict(row) if row else {}

    @staticmethod
    def get_by_user(
        user_id: str,
        summary_type: Optional[str] = None,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        """List summaries for a user, newest first. Optional filter by type."""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            if summary_type:
                cursor.execute(
                    """
                    SELECT * FROM elias_summaries
                    WHERE user_id = %s AND type = %s
                    ORDER BY created_at DESC
                    LIMIT %s
                    """,
                    (user_id, summary_type, min(limit, 100)),
                )
            else:
                cursor.execute(
                    """
                    SELECT * FROM elias_summaries
                    WHERE user_id = %s
                    ORDER BY created_at DESC
                    LIMIT %s
                    """,
                    (user_id, min(limit, 100)),
                )
            return [dict(row) for row in cursor.fetchall()]

    @staticmethod
    def get_latest(user_id: str, summary_type: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Get the most recent summary for the user."""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            if summary_type:
                cursor.execute(
                    """
                    SELECT * FROM elias_summaries
                    WHERE user_id = %s AND type = %s
                    ORDER BY created_at DESC
                    LIMIT 1
                    """,
                    (user_id, summary_type),
                )
            else:
                cursor.execute(
                    """
                    SELECT * FROM elias_summaries
                    WHERE user_id = %s
                    ORDER BY created_at DESC
                    LIMIT 1
                    """,
                    (user_id,),
                )
            row = cursor.fetchone()
            return dict(row) if row else None

    @staticmethod
    def get_by_id(summary_id: str, user_id: str) -> Optional[Dict[str, Any]]:
        """Get a summary by id. Returns None if not found or wrong user."""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM elias_summaries WHERE id = %s AND user_id = %s",
                (summary_id, user_id),
            )
            row = cursor.fetchone()
            return dict(row) if row else None

    @staticmethod
    def delete(summary_id: str, user_id: str) -> bool:
        """Delete a summary. Returns True if deleted."""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "DELETE FROM elias_summaries WHERE id = %s AND user_id = %s",
                (summary_id, user_id),
            )
            conn.commit()
            return cursor.rowcount > 0


class EliasTodosDB:
    """Database operations for Elias to-dos. User-scoped."""

    @staticmethod
    def create(
        user_id: str,
        title: str,
        *,
        due_at: Optional[str] = None,
        created_from_session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a to-do. Title is truncated to TODO_TITLE_MAX_LEN."""
        title = (title or "").strip()[:TODO_TITLE_MAX_LEN]
        if not title:
            raise ValueError("title is required")
        todo_id = f"et_{uuid.uuid4().hex[:16]}"
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO elias_todos (id, user_id, title, due_at, created_from_session_id)
                VALUES (%s, %s, %s, %s, %s)
                RETURNING *
                """,
                (todo_id, user_id, title, due_at, created_from_session_id),
            )
            conn.commit()
            row = cursor.fetchone()
            return dict(row) if row else {}

    @staticmethod
    def get_by_user(
        user_id: str,
        status: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """List to-dos for a user. Optional filter by status."""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            if status:
                if status not in ("pending", "done", "cancelled"):
                    raise ValueError("status must be pending, done, or cancelled")
                cursor.execute(
                    """
                    SELECT * FROM elias_todos
                    WHERE user_id = %s AND status = %s
                    ORDER BY created_at DESC
                    LIMIT %s
                    """,
                    (user_id, status, min(limit, 200)),
                )
            else:
                cursor.execute(
                    """
                    SELECT * FROM elias_todos
                    WHERE user_id = %s
                    ORDER BY created_at DESC
                    LIMIT %s
                    """,
                    (user_id, min(limit, 200)),
                )
            return [dict(row) for row in cursor.fetchall()]

    @staticmethod
    def get_by_id(todo_id: str, user_id: str) -> Optional[Dict[str, Any]]:
        """Get a to-do by id. Returns None if not found or wrong user."""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM elias_todos WHERE id = %s AND user_id = %s",
                (todo_id, user_id),
            )
            row = cursor.fetchone()
            return dict(row) if row else None

    @staticmethod
    def update(todo_id: str, user_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a to-do. Allowed fields: title, status, due_at."""
        allowed = {"title", "status", "due_at"}
        updates = {k: v for k, v in updates.items() if k in allowed}
        if "status" in updates and updates["status"] not in ("pending", "done", "cancelled"):
            raise ValueError("status must be pending, done, or cancelled")
        if "title" in updates:
            updates["title"] = (updates["title"] or "").strip()[:TODO_TITLE_MAX_LEN]
        if not updates:
            return EliasTodosDB.get_by_id(todo_id, user_id)
        set_parts = [f"{k} = %s" for k in updates]
        set_parts.append("updated_at = NOW()")
        values = list(updates.values()) + [todo_id, user_id]
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                f"""
                UPDATE elias_todos SET {", ".join(set_parts)}
                WHERE id = %s AND user_id = %s
                RETURNING *
                """,
                values,
            )
            conn.commit()
            row = cursor.fetchone()
            return dict(row) if row else None

    @staticmethod
    def delete(todo_id: str, user_id: str) -> bool:
        """Delete a to-do. Returns True if deleted."""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "DELETE FROM elias_todos WHERE id = %s AND user_id = %s",
                (todo_id, user_id),
            )
            conn.commit()
            return cursor.rowcount > 0

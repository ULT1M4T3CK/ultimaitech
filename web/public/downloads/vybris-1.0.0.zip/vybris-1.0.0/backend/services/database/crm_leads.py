"""
CRM Lead Database Operations
Handles all database operations for CRM leads
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


def _row_to_crm_lead(row: Dict) -> Dict[str, Any]:
    """Convert database row to lead dict"""
    def format_date(val):
        if val is None:
            return None
        if hasattr(val, 'isoformat'):
            return val.isoformat()
        return val
    
    return {
        'id': row['id'],
        'name': row['name'],
        'email': row.get('email'),
        'phone': row.get('phone'),
        'company_id': row.get('company_id'),
        'company_name': row.get('company_name'),
        'status': row['status'],
        'priority': row.get('priority', 'medium'),
        'source': row.get('source'),
        'estimated_value': float(row['estimated_value']) if row.get('estimated_value') else None,
        'account_owner_id': row.get('account_owner_id'),
        'next_followup_date': format_date(row.get('next_followup_date')),
        'last_contact_date': format_date(row.get('last_contact_date')),
        'notes': row.get('notes'),
        'metadata': row['metadata'] if isinstance(row.get('metadata'), dict) else json.loads(row.get('metadata') or '{}'),
        'created_at': row['created_at'].isoformat() + 'Z' if hasattr(row['created_at'], 'isoformat') else row['created_at'],
        'updated_at': row['updated_at'].isoformat() + 'Z' if hasattr(row['updated_at'], 'isoformat') else row['updated_at']
    }


class CRMLeadDB:
    """Database operations for CRM leads"""
    
    @staticmethod
    def create(lead_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new lead"""
        lead_id = lead_data.get('id', f"lead_{uuid.uuid4().hex[:12]}")
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO crm_leads (
                    id, name, email, phone, company_id, company_name,
                    status, priority, source, estimated_value,
                    account_owner_id, next_followup_date, last_contact_date,
                    notes, metadata
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
            ''', (
                lead_id,
                lead_data['name'],
                lead_data.get('email'),
                lead_data.get('phone'),
                lead_data.get('company_id'),
                lead_data.get('company_name'),
                lead_data.get('status', 'new'),
                lead_data.get('priority', 'medium'),
                lead_data.get('source'),
                lead_data.get('estimated_value'),
                lead_data.get('account_owner_id'),
                lead_data.get('next_followup_date'),
                lead_data.get('last_contact_date'),
                lead_data.get('notes'),
                json.dumps(lead_data.get('metadata', {}))
            ))
            conn.commit()
            row = cursor.fetchone()
            return _row_to_crm_lead(row) if row else None
    
    @staticmethod
    def get_all(
        limit: int = 100,
        offset: int = 0,
        status: str = None,
        priority: str = None,
        account_owner_id: str = None,
        account_owner_ids: List[str] = None,
        include_unassigned: bool = False,
        search: str = None,
        sort_by: str = 'created_at',
        sort_order: str = 'desc'
    ) -> List[Dict[str, Any]]:
        """Get all leads with filtering and sorting"""
        query = 'SELECT * FROM crm_leads WHERE 1=1'
        params = []
        
        if status:
            query += ' AND status = %s'
            params.append(status)
        
        if priority:
            query += ' AND priority = %s'
            params.append(priority)
        
        # Support both single owner_id (backward compatibility) and list of owner_ids
        if account_owner_ids is not None:
            # Filter by list of owner IDs (for partner accounts)
            # Include leads where account_owner_id OR created_by is in the partner account, or account_owner_id is NULL
            if len(account_owner_ids) > 0:
                placeholders = ','.join(['%s'] * len(account_owner_ids))
                query += f' AND (account_owner_id IN ({placeholders}) OR created_by IN ({placeholders}) OR account_owner_id IS NULL)'
                params.extend(account_owner_ids)
                params.extend(account_owner_ids)  # Add twice for both IN clauses
            else:
                # Empty list means no leads
                query += ' AND 1=0'
        elif account_owner_id:
            if include_unassigned:
                query += ' AND (account_owner_id = %s OR account_owner_id IS NULL)'
            else:
                query += ' AND account_owner_id = %s'
            params.append(account_owner_id)
        
        if search:
            query += ' AND (LOWER(name) LIKE %s OR LOWER(email) LIKE %s OR LOWER(company_name) LIKE %s)'
            search_term = f'%{search.lower()}%'
            params.extend([search_term, search_term, search_term])
        
        # Validate sort column to prevent SQL injection
        allowed_sort_columns = ['created_at', 'updated_at', 'name', 'status', 'priority', 
                                'next_followup_date', 'estimated_value', 'last_contact_date']
        if sort_by not in allowed_sort_columns:
            sort_by = 'created_at'
        
        # SECURITY: Use psycopg2.sql for safe identifier handling
        from psycopg2 import sql
        sort_direction_str = 'DESC' if sort_order.lower() == 'desc' else 'ASC'
        sort_column = sql.Identifier(sort_by)
        sort_direction = sql.SQL(sort_direction_str)
        
        # Build final query with safe identifier
        query_base = sql.SQL(query)
        query_final = query_base + sql.SQL(' ORDER BY {sort_column} {sort_direction} NULLS LAST LIMIT %s OFFSET %s').format(
            sort_column=sort_column,
            sort_direction=sort_direction
        )
        params.extend([limit, offset])
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            # Debug: log the query and params (truncated for security)
            import logging
            logger = logging.getLogger(__name__)
            logger.debug(f"[CRM] get_all query with safe identifiers")
            cursor.execute(query_final, params)
            rows = cursor.fetchall()
            logger.debug(f"[CRM] get_all returned {len(rows)} rows")
            return [_row_to_crm_lead(row) for row in rows]
    
    @staticmethod
    def get_by_id(lead_id: str) -> Optional[Dict[str, Any]]:
        """Get a lead by ID"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM crm_leads WHERE id = %s', (lead_id,))
            row = cursor.fetchone()
            return _row_to_crm_lead(row) if row else None
    
    @staticmethod
    def get_by_status(status: str) -> List[Dict[str, Any]]:
        """Get all leads with a specific status"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM crm_leads WHERE status = %s ORDER BY priority DESC, last_contact_date DESC',
                (status,)
            )
            return [_row_to_crm_lead(row) for row in cursor.fetchall()]
    
    @staticmethod
    def get_by_owner(account_owner_id: str) -> List[Dict[str, Any]]:
        """Get all leads for a specific owner"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM crm_leads WHERE account_owner_id = %s ORDER BY priority DESC, created_at DESC',
                (account_owner_id,)
            )
            return [_row_to_crm_lead(row) for row in cursor.fetchall()]
    
    @staticmethod
    def get_followups_due(days_ahead: int = 7) -> List[Dict[str, Any]]:
        """Get leads with followups due within the specified days"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM crm_leads 
                WHERE next_followup_date <= CURRENT_DATE + INTERVAL '%s days'
                  AND status NOT IN ('won', 'lost', 'do_not_contact')
                ORDER BY next_followup_date ASC
            ''', (days_ahead,))
            return [_row_to_crm_lead(row) for row in cursor.fetchall()]
    
    @staticmethod
    def get_overdue_followups() -> List[Dict[str, Any]]:
        """Get leads with overdue followups"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM crm_leads 
                WHERE next_followup_date < CURRENT_DATE
                  AND status NOT IN ('won', 'lost', 'do_not_contact')
                ORDER BY next_followup_date ASC
            ''')
            return [_row_to_crm_lead(row) for row in cursor.fetchall()]
    
    @staticmethod
    def update(lead_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a lead"""
        allowed_fields = [
            'name', 'email', 'phone', 'company_id', 'company_name',
            'status', 'priority', 'source', 'estimated_value',
            'account_owner_id', 'next_followup_date', 'last_contact_date',
            'notes', 'metadata'
        ]
        set_clauses = ['updated_at = NOW()']
        values = []
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                if field == 'metadata':
                    values.append(json.dumps(updates[field]))
                else:
                    values.append(updates[field])
        
        values.append(lead_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f'''
                UPDATE crm_leads SET {", ".join(set_clauses)}
                WHERE id = %s
                RETURNING *
            ''', values)
            conn.commit()
            row = cursor.fetchone()
            return _row_to_crm_lead(row) if row else None
    
    @staticmethod
    def delete(lead_id: str) -> bool:
        """Delete a lead"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM crm_leads WHERE id = %s', (lead_id,))
            conn.commit()
            return cursor.rowcount > 0
    
    @staticmethod
    def count(status: str = None, account_owner_id: str = None, account_owner_ids: List[str] = None, include_unassigned: bool = False) -> int:
        """Count leads with optional filters"""
        query = 'SELECT COUNT(*) as count FROM crm_leads WHERE 1=1'
        params = []
        
        if status:
            query += ' AND status = %s'
            params.append(status)
        
        # Support both single owner_id (backward compatibility) and list of owner_ids
        if account_owner_ids is not None:
            # Filter by list of owner IDs (for partner accounts)
            # Include leads where account_owner_id OR created_by is in the partner account, or account_owner_id is NULL
            if len(account_owner_ids) > 0:
                placeholders = ','.join(['%s'] * len(account_owner_ids))
                query += f' AND (account_owner_id IN ({placeholders}) OR created_by IN ({placeholders}) OR account_owner_id IS NULL)'
                params.extend(account_owner_ids)
                params.extend(account_owner_ids)  # Add twice for both IN clauses
            else:
                # Empty list means no leads
                query += ' AND 1=0'
        elif account_owner_id:
            if include_unassigned:
                query += ' AND (account_owner_id = %s OR account_owner_id IS NULL)'
            else:
                query += ' AND account_owner_id = %s'
            params.append(account_owner_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            row = cursor.fetchone()
            return row['count'] if row else 0
    
    @staticmethod
    def get_stats(owner_id: str = None, owner_ids: List[str] = None, include_unassigned: bool = False) -> Dict[str, Any]:
        """Get CRM statistics, optionally filtered by owner(s)"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            # Build owner filter clause
            owner_filter = ""
            owner_params = ()
            if owner_ids is not None:
                # Filter by list of owner IDs (for partner accounts)
                # Include leads where account_owner_id OR created_by is in the partner account, or account_owner_id is NULL
                if len(owner_ids) > 0:
                    placeholders = ','.join(['%s'] * len(owner_ids))
                    owner_filter = f" AND (account_owner_id IN ({placeholders}) OR created_by IN ({placeholders}) OR account_owner_id IS NULL)"
                    owner_params = tuple(owner_ids + owner_ids)  # Duplicate list for both IN clauses
                else:
                    # Empty list means no leads
                    owner_filter = " AND 1=0"
            elif owner_id:
                if include_unassigned:
                    owner_filter = " AND (account_owner_id = %s OR account_owner_id IS NULL)"
                else:
                    owner_filter = " AND account_owner_id = %s"
                owner_params = (owner_id,)
            
            # Status counts
            cursor.execute(f'''
                SELECT status, COUNT(*) as count 
                FROM crm_leads 
                WHERE 1=1{owner_filter}
                GROUP BY status
            ''', owner_params)
            status_counts = {row['status']: row['count'] for row in cursor.fetchall()}
            
            # Priority counts (exclude inactive statuses)
            cursor.execute(f'''
                SELECT priority, COUNT(*) as count 
                FROM crm_leads 
                WHERE status NOT IN ('won', 'lost', 'do_not_contact'){owner_filter}
                GROUP BY priority
            ''', owner_params)
            priority_counts = {row['priority']: row['count'] for row in cursor.fetchall()}
            
            # Total pipeline value (all active pipeline stages)
            cursor.execute(f'''
                SELECT COALESCE(SUM(estimated_value), 0) as total_value
                FROM crm_leads 
                WHERE status IN ('new', 'interested', 'qualified', 'demo_booked', 'offer_sent', 'negotiation'){owner_filter}
            ''', owner_params)
            pipeline_value = cursor.fetchone()['total_value']
            
            # Won deals value
            cursor.execute(f'''
                SELECT COALESCE(SUM(estimated_value), 0) as won_value
                FROM crm_leads 
                WHERE status = 'won'{owner_filter}
            ''', owner_params)
            won_value = cursor.fetchone()['won_value']
            
            # Overdue followups count
            cursor.execute(f'''
                SELECT COUNT(*) as count 
                FROM crm_leads 
                WHERE next_followup_date < CURRENT_DATE
                  AND status NOT IN ('won', 'lost', 'do_not_contact'){owner_filter}
            ''', owner_params)
            overdue_count = cursor.fetchone()['count']
            
            return {
                'status_counts': status_counts,
                'priority_counts': priority_counts,
                'pipeline_value': float(pipeline_value) if pipeline_value else 0,
                'won_value': float(won_value) if won_value else 0,
                'overdue_followups': overdue_count,
                'total_leads': sum(status_counts.values())
            }

"""
Cached Database Queries
High-level cached access to frequently queried data
"""

from typing import Optional, Dict, Any
from .chatbots import ChatbotDB
from .users import UserDB
from .integrations import IntegrationDB
from services.cache_decorator import cache_result, invalidate_chatbot_cache


class CachedQueries:
    """Cached database queries for frequently accessed data"""
    
    @staticmethod
    @cache_result(ttl=300)  # Cache for 5 minutes
    def get_chatbot_config(chatbot_id: str) -> Optional[Dict[str, Any]]:
        """Get chatbot configuration (cached)"""
        bot = ChatbotDB.get_by_id(chatbot_id)
        return bot.get('config', {}) if bot else None
    
    @staticmethod
    @cache_result(ttl=600)  # Cache for 10 minutes
    def get_user_by_id(user_id: str) -> Optional[Dict[str, Any]]:
        """Get user by ID (cached)"""
        return UserDB.get_by_id(user_id)
    
    @staticmethod
    @cache_result(ttl=300)  # Cache for 5 minutes
    def get_integrations_by_chatbot(chatbot_id: str) -> list:
        """Get all integrations for a chatbot (cached)"""
        return IntegrationDB.get_by_chatbot(chatbot_id)
    
    @staticmethod
    def invalidate_chatbot(chatbot_id: str):
        """Invalidate all cache entries for a chatbot"""
        invalidate_chatbot_cache(chatbot_id)

"""
Email Sequence Database Operations
Handles all database operations for email sequences
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


def _row_to_email_sequence(row: Dict) -> Dict[str, Any]:
    """Convert database row to email sequence dict"""
    return {
        'id': row['id'],
        'chatbot_id': row['chatbot_id'],
        'name': row['name'],
        'emails': row['emails'] if isinstance(row.get('emails'), list) else json.loads(row.get('emails') or '[]'),
        'enabled': row.get('enabled', True),
        'created_at': row['created_at'].isoformat() + 'Z' if hasattr(row['created_at'], 'isoformat') else row['created_at'],
        'updated_at': row['updated_at'].isoformat() + 'Z' if hasattr(row['updated_at'], 'isoformat') else row['updated_at']
    }


class EmailSequenceDB:
    """Database operations for email sequences"""
    
    @staticmethod
    def create(seq_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new email sequence"""
        seq_id = seq_data.get('id') or str(uuid.uuid4())
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO email_sequences (id, chatbot_id, name, emails, enabled)
                VALUES (%s, %s, %s, %s, %s)
                RETURNING *
            ''', (
                seq_id,
                seq_data['chatbot_id'],
                seq_data.get('name'),
                json.dumps(seq_data.get('emails', [])),
                seq_data.get('enabled', True)
            ))
            conn.commit()
            row = cursor.fetchone()
            return _row_to_email_sequence(row) if row else None
    
    @staticmethod
    def get_by_chatbot(chatbot_id: str, enabled_only: bool = False) -> List[Dict[str, Any]]:
        """Get all email sequences for a chatbot"""
        query = 'SELECT * FROM email_sequences WHERE chatbot_id = %s'
        params = [chatbot_id]
        if enabled_only:
            query += ' AND enabled = TRUE'
        query += ' ORDER BY created_at DESC'
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            return [_row_to_email_sequence(row) for row in cursor.fetchall()]
    
    @staticmethod
    def get_by_id(seq_id: str) -> Optional[Dict[str, Any]]:
        """Get email sequence by ID"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM email_sequences WHERE id = %s', (seq_id,))
            row = cursor.fetchone()
            return _row_to_email_sequence(row) if row else None
    
    @staticmethod
    def update(seq_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update an email sequence"""
        allowed_fields = ['name', 'emails', 'enabled']
        set_clauses = ['updated_at = NOW()']
        values = []
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                if field == 'emails':
                    values.append(json.dumps(updates[field]))
                else:
                    values.append(updates[field])
        
        if len(set_clauses) == 1:  # Only updated_at
            return EmailSequenceDB.get_by_id(seq_id)
        
        values.append(seq_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f'''
                UPDATE email_sequences SET {", ".join(set_clauses)}
                WHERE id = %s
                RETURNING *
            ''', values)
            conn.commit()
            row = cursor.fetchone()
            return _row_to_email_sequence(row) if row else None
    
    @staticmethod
    def delete(seq_id: str) -> bool:
        """Delete an email sequence"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM email_sequences WHERE id = %s', (seq_id,))
            conn.commit()
            return cursor.rowcount > 0

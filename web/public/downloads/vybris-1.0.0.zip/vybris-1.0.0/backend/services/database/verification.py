"""
Verification Token Database Operations
Handles OTP verification for secure action access
"""

import uuid
import secrets
import hashlib
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from .base import get_db_connection


class VerificationDB:
    """Database operations for OTP verification tokens"""
    
    # OTP expires in 5 minutes
    OTP_EXPIRY_MINUTES = 5
    # Verification token expires in 30 minutes
    TOKEN_EXPIRY_MINUTES = 30
    # Max OTP attempts before lockout
    MAX_ATTEMPTS = 5
    # Lockout duration in minutes
    LOCKOUT_MINUTES = 15
    
    @staticmethod
    def _hash_identifier(identifier: str) -> str:
        """Hash email/phone for privacy"""
        return hashlib.sha256(identifier.lower().strip().encode()).hexdigest()[:32]
    
    @staticmethod
    def _generate_otp() -> str:
        """Generate a 6-digit OTP"""
        return str(secrets.randbelow(900000) + 100000)
    
    @staticmethod
    def _generate_token() -> str:
        """Generate a secure verification token"""
        return f"vt_{secrets.token_urlsafe(32)}"
    
    @staticmethod
    def _mask_email(email: str) -> str:
        """Mask email for display: john@example.com -> j***@example.com"""
        if '@' not in email:
            return email[:1] + '***'
        local, domain = email.split('@', 1)
        if len(local) <= 2:
            masked_local = local[0] + '***'
        else:
            masked_local = local[0] + '***' + local[-1]
        return f"{masked_local}@{domain}"
    
    @staticmethod
    def _mask_phone(phone: str) -> str:
        """Mask phone for display: +31612345678 -> +316****5678"""
        digits = ''.join(c for c in phone if c.isdigit() or c == '+')
        if len(digits) < 6:
            return '****' + digits[-2:]
        return digits[:4] + '****' + digits[-4:]
    
    @staticmethod
    def ensure_table():
        """Create verification table if not exists"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS verification_tokens (
                    id VARCHAR(64) PRIMARY KEY,
                    chatbot_id VARCHAR(64) NOT NULL,
                    session_id VARCHAR(128),
                    identifier_hash VARCHAR(64) NOT NULL,
                    identifier_type VARCHAR(16) NOT NULL,
                    identifier_masked VARCHAR(128),
                    otp_hash VARCHAR(128),
                    verification_token VARCHAR(128),
                    status VARCHAR(16) DEFAULT 'pending',
                    attempts INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP,
                    verified_at TIMESTAMP,
                    token_expires_at TIMESTAMP,
                    CONSTRAINT valid_status CHECK (status IN ('pending', 'verified', 'expired', 'locked'))
                )
            ''')
            # Index for lookups
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_verification_lookup 
                ON verification_tokens(chatbot_id, identifier_hash, status)
            ''')
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_verification_token 
                ON verification_tokens(verification_token)
            ''')
            conn.commit()
    
    @staticmethod
    def create_otp_request(
        chatbot_id: str,
        identifier: str,
        identifier_type: str = 'email',
        session_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new OTP verification request.
        
        Returns:
            Dict with otp (for sending), masked identifier, and request_id
        """
        VerificationDB.ensure_table()
        
        identifier_hash = VerificationDB._hash_identifier(identifier)
        
        # Check for lockout
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            # Check if locked out
            lockout_threshold = datetime.utcnow() - timedelta(minutes=VerificationDB.LOCKOUT_MINUTES)
            cursor.execute('''
                SELECT COUNT(*) as failed_count FROM verification_tokens
                WHERE chatbot_id = %s 
                AND identifier_hash = %s 
                AND status = 'locked'
                AND created_at > %s
            ''', (chatbot_id, identifier_hash, lockout_threshold))
            
            row = cursor.fetchone()
            if row and row['failed_count'] > 0:
                return {
                    'success': False,
                    'error': 'Too many failed attempts. Please try again later.',
                    'locked_until': (datetime.utcnow() + timedelta(minutes=VerificationDB.LOCKOUT_MINUTES)).isoformat()
                }
            
            # Invalidate any existing pending OTPs for this identifier
            cursor.execute('''
                UPDATE verification_tokens 
                SET status = 'expired'
                WHERE chatbot_id = %s 
                AND identifier_hash = %s 
                AND status = 'pending'
            ''', (chatbot_id, identifier_hash))
            
            # Generate new OTP
            request_id = f"vr_{uuid.uuid4().hex[:16]}"
            otp = VerificationDB._generate_otp()
            otp_hash = hashlib.sha256(otp.encode()).hexdigest()
            expires_at = datetime.utcnow() + timedelta(minutes=VerificationDB.OTP_EXPIRY_MINUTES)
            
            # Mask identifier for display
            if identifier_type == 'email':
                masked = VerificationDB._mask_email(identifier)
            else:
                masked = VerificationDB._mask_phone(identifier)
            
            cursor.execute('''
                INSERT INTO verification_tokens (
                    id, chatbot_id, session_id, identifier_hash, identifier_type,
                    identifier_masked, otp_hash, status, expires_at
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, 'pending', %s)
            ''', (
                request_id, chatbot_id, session_id, identifier_hash,
                identifier_type, masked, otp_hash, expires_at
            ))
            conn.commit()
            
            return {
                'success': True,
                'request_id': request_id,
                'otp': otp,  # This should be sent via email/SMS, not returned to user!
                'masked_identifier': masked,
                'identifier_type': identifier_type,
                'expires_in_seconds': VerificationDB.OTP_EXPIRY_MINUTES * 60
            }
    
    @staticmethod
    def verify_otp(
        chatbot_id: str,
        identifier: str,
        code: str,
        session_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Verify an OTP code and return a verification token if valid.
        
        Returns:
            Dict with success, verification_token (if valid), or error
        """
        VerificationDB.ensure_table()
        
        identifier_hash = VerificationDB._hash_identifier(identifier)
        code_hash = hashlib.sha256(code.strip().encode()).hexdigest()
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            # Find pending OTP request
            cursor.execute('''
                SELECT * FROM verification_tokens
                WHERE chatbot_id = %s 
                AND identifier_hash = %s 
                AND status = 'pending'
                AND expires_at > %s
                ORDER BY created_at DESC
                LIMIT 1
            ''', (chatbot_id, identifier_hash, datetime.utcnow()))
            
            row = cursor.fetchone()
            
            if not row:
                return {
                    'success': False,
                    'error': 'No pending verification found or code expired. Please request a new code.'
                }
            
            request = dict(row)
            
            # Check attempts
            if request['attempts'] >= VerificationDB.MAX_ATTEMPTS:
                cursor.execute('''
                    UPDATE verification_tokens SET status = 'locked'
                    WHERE id = %s
                ''', (request['id'],))
                conn.commit()
                return {
                    'success': False,
                    'error': 'Too many failed attempts. Please request a new code.'
                }
            
            # Verify OTP
            if request['otp_hash'] != code_hash:
                # Increment attempts
                cursor.execute('''
                    UPDATE verification_tokens 
                    SET attempts = attempts + 1
                    WHERE id = %s
                ''', (request['id'],))
                conn.commit()
                
                remaining = VerificationDB.MAX_ATTEMPTS - request['attempts'] - 1
                return {
                    'success': False,
                    'error': f'Invalid code. {remaining} attempts remaining.'
                }
            
            # OTP is valid - generate verification token
            verification_token = VerificationDB._generate_token()
            token_expires_at = datetime.utcnow() + timedelta(minutes=VerificationDB.TOKEN_EXPIRY_MINUTES)
            
            cursor.execute('''
                UPDATE verification_tokens 
                SET status = 'verified',
                    verification_token = %s,
                    verified_at = %s,
                    token_expires_at = %s
                WHERE id = %s
            ''', (verification_token, datetime.utcnow(), token_expires_at, request['id']))
            conn.commit()
            
            return {
                'success': True,
                'verified': True,
                'verification_token': verification_token,
                'expires_at': token_expires_at.isoformat(),
                'expires_in_seconds': VerificationDB.TOKEN_EXPIRY_MINUTES * 60
            }
    
    @staticmethod
    def validate_token(
        chatbot_id: str,
        verification_token: str
    ) -> Dict[str, Any]:
        """
        Validate a verification token for use with sensitive actions.
        
        Returns:
            Dict with valid status and identifier info if valid
        """
        VerificationDB.ensure_table()
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM verification_tokens
                WHERE chatbot_id = %s 
                AND verification_token = %s 
                AND status = 'verified'
                AND token_expires_at > %s
            ''', (chatbot_id, verification_token, datetime.utcnow()))
            
            row = cursor.fetchone()
            
            if not row:
                return {
                    'valid': False,
                    'error': 'Invalid or expired verification token'
                }
            
            request = dict(row)
            
            return {
                'valid': True,
                'identifier_type': request['identifier_type'],
                'identifier_masked': request['identifier_masked'],
                'verified_at': request['verified_at'].isoformat() if request['verified_at'] else None,
                'expires_at': request['token_expires_at'].isoformat() if request['token_expires_at'] else None
            }
    
    @staticmethod
    def invalidate_token(verification_token: str) -> bool:
        """Invalidate a verification token (logout)"""
        VerificationDB.ensure_table()
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE verification_tokens 
                SET status = 'expired'
                WHERE verification_token = %s
            ''', (verification_token,))
            conn.commit()
            return cursor.rowcount > 0
    
    @staticmethod
    def cleanup_expired():
        """Clean up expired verification records (run periodically)"""
        VerificationDB.ensure_table()
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            # Delete records older than 24 hours
            cutoff = datetime.utcnow() - timedelta(hours=24)
            cursor.execute('''
                DELETE FROM verification_tokens
                WHERE created_at < %s
            ''', (cutoff,))
            conn.commit()
            return cursor.rowcount

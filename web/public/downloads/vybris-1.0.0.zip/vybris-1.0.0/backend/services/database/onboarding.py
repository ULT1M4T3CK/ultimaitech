"""
Onboarding Database Operations
Handles all database operations for client onboarding workflows
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


class OnboardingDB:
    """Database operations for client onboarding workflows"""
    
    DEFAULT_STAGES = [
        {"name": "Welcome", "key": "welcome", "order": 1},
        {"name": "Setup", "key": "setup", "order": 2},
        {"name": "Training", "key": "training", "order": 3},
        {"name": "Launch", "key": "launch", "order": 4},
        {"name": "Complete", "key": "complete", "order": 5}
    ]
    
    @staticmethod
    def create(workflow_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new onboarding workflow"""
        workflow_id = workflow_data.get('id') or str(uuid.uuid4())
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO onboarding_workflows (id, chatbot_id, name, steps, enabled)
                VALUES (%s, %s, %s, %s, %s)
                RETURNING *
            ''', (
                workflow_id,
                workflow_data['chatbot_id'],
                workflow_data.get('name', 'Default Onboarding'),
                json.dumps(workflow_data.get('steps', OnboardingDB.DEFAULT_STAGES)),
                workflow_data.get('enabled', True)
            ))
            conn.commit()
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['steps'] = result['steps'] if isinstance(result['steps'], list) else json.loads(result.get('steps') or '[]')
                return result
            return None
    
    @staticmethod
    def get_by_chatbot(chatbot_id: str) -> Optional[Dict[str, Any]]:
        """Get onboarding workflow for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM onboarding_workflows WHERE chatbot_id = %s ORDER BY created_at DESC LIMIT 1', (chatbot_id,))
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['steps'] = result['steps'] if isinstance(result['steps'], list) else json.loads(result.get('steps') or '[]')
                return result
            return None
    
    @staticmethod
    def get_by_id(workflow_id: str) -> Optional[Dict[str, Any]]:
        """Get onboarding workflow by ID"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM onboarding_workflows WHERE id = %s', (workflow_id,))
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['steps'] = result['steps'] if isinstance(result['steps'], list) else json.loads(result.get('steps') or '[]')
                return result
            return None
    
    @staticmethod
    def update(workflow_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update an onboarding workflow"""
        allowed_fields = ['name', 'steps', 'enabled']
        set_clauses = ['updated_at = NOW()']
        values = []
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                if field == 'steps':
                    values.append(json.dumps(updates[field]))
                else:
                    values.append(updates[field])
        
        if len(set_clauses) == 1:  # Only updated_at
            return OnboardingDB.get_by_id(workflow_id)
        
        values.append(workflow_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f'''
                UPDATE onboarding_workflows SET {", ".join(set_clauses)}
                WHERE id = %s
                RETURNING *
            ''', values)
            conn.commit()
            row = cursor.fetchone()
            if row:
                result = dict(row)
                result['steps'] = result['steps'] if isinstance(result['steps'], list) else json.loads(result.get('steps') or '[]')
                return result
            return None
    
    @staticmethod
    def delete(workflow_id: str) -> bool:
        """Delete an onboarding workflow"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM onboarding_workflows WHERE id = %s', (workflow_id,))
            conn.commit()
            return cursor.rowcount > 0

"""
Integration Database Operations
Handles all database operations for third-party integrations
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


def _row_to_integration(row: Dict) -> Dict[str, Any]:
    """Convert database row to integration dict"""
    # Handle config parsing safely
    config = row.get('config', {})
    if isinstance(config, str):
        try:
            config = json.loads(config)
        except (json.JSONDecodeError, TypeError):
            config = {}
    elif not isinstance(config, dict):
        config = {}
    
    # Handle metadata parsing safely
    metadata = row.get('metadata', {})
    if isinstance(metadata, str):
        try:
            metadata = json.loads(metadata) if metadata else {}
        except (json.JSONDecodeError, TypeError):
            metadata = {}
    elif not isinstance(metadata, dict):
        metadata = {}
    
    # Handle date formatting safely
    created_at = row.get('created_at')
    if created_at and hasattr(created_at, 'isoformat'):
        created_at = created_at.isoformat() + 'Z'
    
    updated_at = row.get('updated_at')
    if updated_at and hasattr(updated_at, 'isoformat'):
        updated_at = updated_at.isoformat() + 'Z'
    
    last_sync = row.get('last_sync')
    if last_sync and hasattr(last_sync, 'isoformat'):
        last_sync = last_sync.isoformat() + 'Z'
    
    return {
        'id': row.get('id'),
        'chatbot_id': row.get('chatbot_id'),
        'integration_type': row.get('integration_type'),
        'name': row.get('name'),
        'config': config,
        'status': row.get('status', 'active'),
        'created_at': created_at,
        'updated_at': updated_at,
        'last_sync': last_sync,
        'metadata': metadata
    }


class IntegrationDB:
    """Database operations for third-party integrations"""
    
    @staticmethod
    def create(integration_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new integration"""
        import logging
        logger = logging.getLogger(__name__)
        
        integration_id = integration_data.get('id', f"int_{uuid.uuid4().hex[:12]}")
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO integrations (id, chatbot_id, integration_type, name, config, status, metadata)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    RETURNING *
                ''', (
                    integration_id,
                    integration_data['chatbot_id'],
                    integration_data['integration_type'],
                    integration_data['name'],
                    json.dumps(integration_data.get('config', {})),
                    integration_data.get('status', 'active'),
                    json.dumps(integration_data.get('metadata', {}))
                ))
                conn.commit()
                row = cursor.fetchone()
                if not row:
                    logger.error(f"Integration creation failed: INSERT returned no row for integration_id={integration_id}")
                    return None
                return _row_to_integration(row)
        except Exception as e:
            logger.error(f"Error creating integration: {e}", exc_info=True)
            raise
    
    @staticmethod
    def get_by_chatbot(chatbot_id: str) -> List[Dict[str, Any]]:
        """Get all integrations for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM integrations WHERE chatbot_id = %s ORDER BY created_at DESC', (chatbot_id,))
            return [_row_to_integration(row) for row in cursor.fetchall()]
    
    @staticmethod
    def get_by_id(integration_id: str) -> Optional[Dict[str, Any]]:
        """Get a single integration by ID"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM integrations WHERE id = %s', (integration_id,))
            row = cursor.fetchone()
            return _row_to_integration(row) if row else None
    
    @staticmethod
    def get_by_type(chatbot_id: str, integration_type: str) -> List[Dict[str, Any]]:
        """Get all integrations of a specific type for a chatbot"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM integrations WHERE chatbot_id = %s AND integration_type = %s ORDER BY created_at DESC', 
                (chatbot_id, integration_type)
            )
            return [_row_to_integration(row) for row in cursor.fetchall()]
    
    @staticmethod
    def update(integration_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update an integration"""
        allowed_fields = ['name', 'config', 'status', 'last_sync', 'metadata']
        set_clauses = ['updated_at = NOW()']
        values = []
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                if field in ['config', 'metadata']:
                    values.append(json.dumps(updates[field]))
                elif field == 'status':
                    # Normalize status to lowercase
                    values.append(str(updates[field]).lower())
                else:
                    values.append(updates[field])
        
        if len(set_clauses) == 1:  # Only updated_at clause
            # No fields to update, just return current state
            return IntegrationDB.get_by_id(integration_id)
        
        values.append(integration_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f'''
                UPDATE integrations SET {", ".join(set_clauses)}
                WHERE id = %s
                RETURNING *
            ''', values)
            conn.commit()
            row = cursor.fetchone()
            return _row_to_integration(row) if row else None
    
    @staticmethod
    def delete(integration_id: str) -> bool:
        """Delete an integration"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM integrations WHERE id = %s', (integration_id,))
            conn.commit()
            return cursor.rowcount > 0
    
    @staticmethod
    def update_sync_time(integration_id: str) -> None:
        """Update the last sync timestamp"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE integrations SET last_sync = NOW()
                WHERE id = %s
            ''', (integration_id,))
            conn.commit()

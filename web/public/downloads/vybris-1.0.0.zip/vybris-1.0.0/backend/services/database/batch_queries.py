"""
Batch Database Queries
Optimizes N+1 query patterns by batching database operations
"""

from typing import List, Dict, Any
from .base import get_db_connection


class BatchQueries:
    """Batch database queries to avoid N+1 patterns"""
    
    @staticmethod
    def get_chatbot_stats_batch(chatbot_ids: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Get monthly stats for multiple chatbots in a single query.
        Avoids N+1 pattern when fetching stats for chatbot lists.
        
        Args:
            chatbot_ids: List of chatbot IDs
        
        Returns:
            Dict mapping chatbot_id to stats dict
        """
        if not chatbot_ids:
            return {}
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            # Use IN clause to fetch all stats in one query
            placeholders = ','.join(['%s'] * len(chatbot_ids))
            query = f'''
                SELECT 
                    chatbot_id,
                    TO_CHAR(started_at, 'YYYY-MM') as month,
                    COUNT(*) as count
                FROM chat_sessions
                WHERE chatbot_id IN ({placeholders})
                AND started_at > NOW() - INTERVAL '1 year'
                GROUP BY chatbot_id, month
                ORDER BY chatbot_id, month ASC
            '''
            
            cursor.execute(query, chatbot_ids)
            rows = cursor.fetchall()
            
            # Group by chatbot_id
            stats_by_chatbot = {}
            for chatbot_id in chatbot_ids:
                stats_by_chatbot[chatbot_id] = []
            
            for row in rows:
                chatbot_id = row['chatbot_id']
                if chatbot_id not in stats_by_chatbot:
                    stats_by_chatbot[chatbot_id] = []
                stats_by_chatbot[chatbot_id].append({
                    'month': row['month'],
                    'count': row['count']
                })
            
            return stats_by_chatbot
    
    @staticmethod
    def get_integrations_batch(chatbot_ids: List[str]) -> Dict[str, List[Dict[str, Any]]]:
        """
        Get integrations for multiple chatbots in a single query.
        
        Args:
            chatbot_ids: List of chatbot IDs
        
        Returns:
            Dict mapping chatbot_id to list of integrations
        """
        if not chatbot_ids:
            return {}
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            placeholders = ','.join(['%s'] * len(chatbot_ids))
            query = f'''
                SELECT * FROM integrations
                WHERE chatbot_id IN ({placeholders})
                ORDER BY chatbot_id, created_at DESC
            '''
            
            cursor.execute(query, chatbot_ids)
            rows = cursor.fetchall()
            
            # Group by chatbot_id
            integrations_by_chatbot = {}
            for chatbot_id in chatbot_ids:
                integrations_by_chatbot[chatbot_id] = []
            
            for row in rows:
                chatbot_id = row['chatbot_id']
                if chatbot_id not in integrations_by_chatbot:
                    integrations_by_chatbot[chatbot_id] = []
                integrations_by_chatbot[chatbot_id].append(dict(row))
            
            return integrations_by_chatbot

"""
Chatbot Database Operations
Handles all database operations for chatbots
"""

import json
from typing import List, Optional, Dict, Any
from datetime import datetime
from .base import get_db_connection, get_db_transaction


def _row_to_chatbot(row: Dict) -> Dict[str, Any]:
    """Convert database row to chatbot dict"""
    return {
        'id': row['id'],
        'name': row['name'],
        'type': row['type'],
        'owner_id': row.get('owner_id'),
        'status': row['status'],
        'users': row['users'],
        'accuracy': row['accuracy'],
        'createdAt': row['created_at'].isoformat() + 'Z' if hasattr(row['created_at'], 'isoformat') else row['created_at'],
        'updatedAt': row['updated_at'].isoformat() + 'Z' if hasattr(row['updated_at'], 'isoformat') else row['updated_at'],
        'config': row['config'] if isinstance(row['config'], dict) else json.loads(row['config']),
        'data': row['data'] if isinstance(row['data'], dict) else json.loads(row['data'])
    }


class ChatbotDB:
    """Database operations for chatbots"""
    
    @staticmethod
    def _has_deleted_at_column(conn) -> bool:
        """Check if deleted_at column exists in chatbots table"""
        cursor = conn.cursor()
        cursor.execute("""
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name='chatbots' AND column_name='deleted_at'
        """)
        return cursor.fetchone() is not None
    
    @staticmethod
    def create(chatbot_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new chatbot using transaction"""
        with get_db_transaction() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO chatbots (id, name, type, owner_id, status, users, accuracy, created_at, updated_at, config, data)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
            ''', (
                chatbot_data['id'],
                chatbot_data['name'],
                chatbot_data['type'],
                chatbot_data.get('owner_id'),
                chatbot_data.get('status', 'Draft'),
                chatbot_data.get('users', 0),
                chatbot_data.get('accuracy', 'N/A'),
                chatbot_data.get('createdAt', datetime.utcnow().isoformat() + 'Z'),
                chatbot_data.get('updatedAt', datetime.utcnow().isoformat() + 'Z'),
                json.dumps(chatbot_data.get('config', {})),
                json.dumps(chatbot_data.get('data', {}))
            ))
            row = cursor.fetchone()
            if row:
                return _row_to_chatbot(row)
            return chatbot_data
    
    @staticmethod
    def get_all(limit: int = 100, offset: int = 0, include_deleted: bool = False) -> List[Dict[str, Any]]:
        """
        Get all chatbots with pagination.
        
        Args:
            limit: Maximum number of records to return
            offset: Number of records to skip
            include_deleted: If True, include soft-deleted chatbots
        
        Returns:
            List of chatbot dicts
        """
        with get_db_connection() as conn:
            cursor = conn.cursor()
            has_deleted_at = ChatbotDB._has_deleted_at_column(conn)
            
            if include_deleted or not has_deleted_at:
                cursor.execute(
                    'SELECT * FROM chatbots ORDER BY created_at DESC LIMIT %s OFFSET %s',
                    (limit, offset)
                )
            else:
                cursor.execute(
                    'SELECT * FROM chatbots WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT %s OFFSET %s',
                    (limit, offset)
                )
            return [_row_to_chatbot(row) for row in cursor.fetchall()]
    
    @staticmethod
    def get_by_owner_ids(
        owner_ids: List[str],
        limit: int = 100,
        offset: int = 0,
        include_deleted: bool = False,
    ) -> List[Dict[str, Any]]:
        """
        Get chatbots owned by any of the given user IDs.
        Used for partner account scope - partners see chatbots from their account only.
        """
        if not owner_ids:
            return []
        with get_db_connection() as conn:
            cursor = conn.cursor()
            has_deleted_at = ChatbotDB._has_deleted_at_column(conn)
            placeholders = ",".join(["%s"] * len(owner_ids))
            params: List[Any] = list(owner_ids)
            where_owner = f"WHERE owner_id IN ({placeholders})"
            if not include_deleted and has_deleted_at:
                where_owner += " AND deleted_at IS NULL"
            cursor.execute(
                f"SELECT * FROM chatbots {where_owner} ORDER BY created_at DESC LIMIT %s OFFSET %s",
                (*params, limit, offset),
            )
            return [_row_to_chatbot(row) for row in cursor.fetchall()]

    @staticmethod
    def get_by_user(user_id: str, limit: int = 100, offset: int = 0, include_deleted: bool = False) -> List[Dict[str, Any]]:
        """
        Get all chatbots owned by a user with pagination.
        
        Args:
            user_id: ID of the user
            limit: Maximum number of records to return
            offset: Number of records to skip
            include_deleted: If True, include soft-deleted chatbots
        
        Returns:
            List of chatbot dicts
        """
        with get_db_connection() as conn:
            cursor = conn.cursor()
            has_deleted_at = ChatbotDB._has_deleted_at_column(conn)
            
            if include_deleted or not has_deleted_at:
                cursor.execute(
                    'SELECT * FROM chatbots WHERE owner_id = %s ORDER BY created_at DESC LIMIT %s OFFSET %s',
                    (user_id, limit, offset)
                )
            else:
                cursor.execute(
                    'SELECT * FROM chatbots WHERE owner_id = %s AND deleted_at IS NULL ORDER BY created_at DESC LIMIT %s OFFSET %s',
                    (user_id, limit, offset)
                )
            return [_row_to_chatbot(row) for row in cursor.fetchall()]

    @staticmethod
    def get_by_id(chatbot_id: str, include_deleted: bool = False) -> Optional[Dict[str, Any]]:
        """
        Get a single chatbot by ID.
        
        Args:
            chatbot_id: ID of the chatbot
            include_deleted: If True, include soft-deleted chatbots
        
        Returns:
            Chatbot dict or None if not found
        """
        with get_db_connection() as conn:
            cursor = conn.cursor()
            has_deleted_at = ChatbotDB._has_deleted_at_column(conn)
            
            if include_deleted or not has_deleted_at:
                cursor.execute('SELECT * FROM chatbots WHERE id = %s', (chatbot_id,))
            else:
                cursor.execute('SELECT * FROM chatbots WHERE id = %s AND deleted_at IS NULL', (chatbot_id,))
            row = cursor.fetchone()
            return _row_to_chatbot(row) if row else None
    
    @staticmethod
    def update(chatbot_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Update a chatbot - only updates specified fields (optimized).
        Uses JSONB merge for config and data fields to preserve existing values.
        """
        if not updates:
            return ChatbotDB.get_by_id(chatbot_id)
        
        # Build dynamic UPDATE query with only changed fields
        set_clauses = []
        values = []
        
        # Handle simple fields
        simple_fields = ['name', 'type', 'status', 'users', 'accuracy']
        for field in simple_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                values.append(updates[field])
        
        # Handle config field (JSONB merge to preserve existing values)
        if 'config' in updates:
            if isinstance(updates['config'], dict):
                # Use JSONB merge operator to update only specified keys
                set_clauses.append("config = config || %s")
                values.append(json.dumps(updates['config']))
            else:
                set_clauses.append("config = %s")
                values.append(json.dumps(updates['config']) if isinstance(updates['config'], dict) else updates['config'])
        
        # Handle data field (JSONB merge to preserve existing values)
        if 'data' in updates:
            if isinstance(updates['data'], dict):
                # Use JSONB merge operator to update only specified keys
                set_clauses.append("data = data || %s")
                values.append(json.dumps(updates['data']))
            else:
                set_clauses.append("data = %s")
                values.append(json.dumps(updates['data']) if isinstance(updates['data'], dict) else updates['data'])
        
        # Always update updated_at
        set_clauses.append("updated_at = NOW()")
        values.append(chatbot_id)
        
        if not set_clauses:
            return ChatbotDB.get_by_id(chatbot_id)
        
        with get_db_transaction() as conn:
            cursor = conn.cursor()
            has_deleted_at = ChatbotDB._has_deleted_at_column(conn)
            
            where_clause = "WHERE id = %s"
            if has_deleted_at:
                where_clause = "WHERE id = %s AND deleted_at IS NULL"
            
            query = f"""
                UPDATE chatbots 
                SET {', '.join(set_clauses)}
                {where_clause}
                RETURNING *
            """
            cursor.execute(query, values)
            row = cursor.fetchone()
            
            if row:
                return _row_to_chatbot(row)
            return None
    
    @staticmethod
    def delete(chatbot_id: str, soft_delete: bool = True) -> bool:
        """
        Delete a chatbot.
        
        Args:
            chatbot_id: ID of the chatbot to delete
            soft_delete: If True, use soft delete (sets deleted_at). If False, hard delete.
        
        Returns:
            True if successful, False otherwise
        """
        if soft_delete:
            # Use soft delete from base utilities
            from .base import soft_delete
            return soft_delete("chatbots", chatbot_id)
        else:
            # Hard delete
            with get_db_transaction() as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM chatbots WHERE id = %s', (chatbot_id,))
                return cursor.rowcount > 0
    
    @staticmethod
    def restore(chatbot_id: str) -> bool:
        """Restore a soft-deleted chatbot"""
        from .base import restore_soft_deleted
        return restore_soft_deleted("chatbots", chatbot_id)

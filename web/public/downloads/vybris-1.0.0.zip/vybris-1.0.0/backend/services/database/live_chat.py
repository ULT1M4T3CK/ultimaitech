"""
Live Chat Database Operations
Handles all database operations for live chat requests and agent chats
"""

import json
import logging
import time
import os
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
from .base import get_db_connection

logger = logging.getLogger(__name__)

def _safe_debug_log(data):
    """Write debug log only when VYBRIS_DEBUG_LOG=1 or DEBUG_LOG_PATH is set (avoid file I/O in production)."""
    if not os.getenv('VYBRIS_DEBUG_LOG') and not os.getenv('DEBUG_LOG_PATH'):
        return
    try:
        log_path = os.getenv('DEBUG_LOG_PATH', '/tmp/vybris_debug.log')
        with open(log_path, 'a') as f:
            f.write(json.dumps(data) + '\n')
    except Exception:
        pass  # Silently fail - don't crash the app


class LiveChatDB:
    """Database operations for live chat requests"""
    
    @staticmethod
    def create_request(
        request_id: str,
        chatbot_id: str,
        session_id: str,
        message: Optional[str] = None,
        page_url: Optional[str] = None
    ) -> Dict[str, Any]:
        """Create a new live chat request"""
        # #region agent log
        _safe_debug_log({
            'sessionId': 'debug-session',
            'runId': 'run1',
            'hypothesisId': 'C',
            'location': 'live_chat.py:19',
            'message': 'LiveChatDB.create_request: Entry',
            'data': {
                'request_id': request_id,
                'chatbot_id': chatbot_id,
                'session_id': session_id
            },
            'timestamp': int(time.time() * 1000)
        })
        # #endregion
        
        try:
            # Avoid duplicate open requests for the same session + bot
            existing = LiveChatDB.get_open_request(chatbot_id, session_id)
            if existing:
                if page_url and page_url != existing.get("page_url"):
                    updated = LiveChatDB.update_page_url(existing.get("request_id"), page_url)
                    if updated:
                        return updated
                logger.info(
                    "Live chat request already open for session: %s (request_id=%s)",
                    session_id,
                    existing.get("request_id"),
                )
                return existing
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO live_chat_requests 
                    (request_id, chatbot_id, session_id, message, page_url, status, created_at)
                    VALUES (%s, %s, %s, %s, %s, 'queued', NOW())
                    RETURNING *
                ''', (request_id, chatbot_id, session_id, message, page_url))
                conn.commit()
                row = cursor.fetchone()
                
                # #region agent log
                _safe_debug_log({
                    'sessionId': 'debug-session',
                    'runId': 'run1',
                    'hypothesisId': 'C',
                    'location': 'live_chat.py:37',
                    'message': 'LiveChatDB.create_request: After insert',
                    'data': {
                        'request_id': request_id,
                        'row_fetched': row is not None,
                        'row_status': dict(row).get('status') if row else None
                    },
                    'timestamp': int(time.time() * 1000)
                })
                # #endregion
                
                if row:
                    logger.info(f"Live chat request created: {request_id}")
                    return dict(row)
                return None
        except Exception as e:
            # #region agent log
            _safe_debug_log({
                'sessionId': 'debug-session',
                'runId': 'run1',
                'hypothesisId': 'C',
                'location': 'live_chat.py:44',
                'message': 'LiveChatDB.create_request: Exception',
                'data': {
                    'error': str(e),
                    'error_type': type(e).__name__
                },
                'timestamp': int(time.time() * 1000)
            })
            # #endregion
            logger.error(f"Error creating live chat request: {e}")
            raise

    @staticmethod
    def get_open_request(chatbot_id: str, session_id: str) -> Optional[Dict[str, Any]]:
        """Get the most recent queued/active request for a session."""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM live_chat_requests
                    WHERE chatbot_id = %s
                      AND session_id = %s
                      AND (status IN ('queued', 'active') OR status IS NULL)
                    ORDER BY created_at DESC
                    LIMIT 1
                ''', (chatbot_id, session_id))
                row = cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error fetching open request: {e}")
            return None

    @staticmethod
    def update_page_url(request_id: Optional[str], page_url: str) -> Optional[Dict[str, Any]]:
        """Update page URL for a request and return the row."""
        if not request_id:
            return None
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE live_chat_requests
                    SET page_url = %s
                    WHERE request_id = %s
                    RETURNING *
                ''', (page_url, request_id))
                conn.commit()
                row = cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error updating page_url: {e}")
            return None
    
    @staticmethod
    def get_queue_items(moderator_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get queue for an agent: only waiting (queued) or their own active chat."""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                if moderator_id:
                    cursor.execute('''
                        SELECT * FROM live_chat_requests
                        WHERE user_closed_at IS NULL
                          AND (
                            status = 'queued' OR status IS NULL
                            OR (status = 'active' AND moderator_id = %s)
                          )
                        ORDER BY
                            CASE WHEN status = 'queued' OR status IS NULL THEN 0 ELSE 1 END,
                            created_at ASC
                    ''', (moderator_id,))
                else:
                    cursor.execute('''
                        SELECT * FROM live_chat_requests
                        WHERE (status = 'queued' OR status IS NULL)
                          AND user_closed_at IS NULL
                        ORDER BY created_at ASC
                    ''')
                rows = cursor.fetchall()
                return [dict(row) for row in rows] if rows else []
        except Exception as e:
            logger.error(f"Error fetching queue items: {e}", exc_info=True)
            return []

    @staticmethod
    def get_queued_requests() -> List[Dict[str, Any]]:
        """Get all queued (not accepted) live chat requests"""
        # #region agent log
        _safe_debug_log({
            'sessionId': 'debug-session',
            'runId': 'run1',
            'hypothesisId': 'D',
            'location': 'live_chat.py:47',
            'message': 'LiveChatDB.get_queued_requests: Entry',
            'data': {},
            'timestamp': int(time.time() * 1000)
        })
        # #endregion
        
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                # Use explicit status check and handle NULL status
                cursor.execute('''
                    SELECT * FROM live_chat_requests
                    WHERE status = 'queued' OR status IS NULL
                    ORDER BY created_at ASC
                ''')
                rows = cursor.fetchall()
                
                # #region agent log
                _safe_debug_log({
                    'sessionId': 'debug-session',
                    'runId': 'run1',
                    'hypothesisId': 'D',
                    'location': 'live_chat.py:58',
                    'message': 'LiveChatDB.get_queued_requests: Query result',
                    'data': {
                        'rows_count': len(rows),
                        'request_ids': [dict(row).get('request_id') for row in rows[:5]] if rows else [],
                        'statuses': [dict(row).get('status') for row in rows[:5]] if rows else []
                    },
                    'timestamp': int(time.time() * 1000)
                })
                # #endregion
                
                result = [dict(row) for row in rows] if rows else []
                logger.info(f"Retrieved {len(result)} queued live chat requests")
                return result
        except Exception as e:
            # #region agent log
            _safe_debug_log({
                'sessionId': 'debug-session',
                'runId': 'run1',
                'hypothesisId': 'D',
                'location': 'live_chat.py:60',
                'message': 'LiveChatDB.get_queued_requests: Exception',
                'data': {
                    'error': str(e),
                    'error_type': type(e).__name__
                },
                'timestamp': int(time.time() * 1000)
            })
            # #endregion
            logger.error(f"Error fetching queued requests: {e}", exc_info=True)
            return []
    
    @staticmethod
    def accept_request(request_id: str, moderator_id: str) -> Optional[Dict[str, Any]]:
        """Accept a live chat request"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE live_chat_requests
                    SET status = 'active',
                        moderator_id = %s,
                        accepted_at = NOW()
                    WHERE request_id = %s AND (status = 'queued' OR status IS NULL)
                    RETURNING *
                ''', (moderator_id, request_id))
                conn.commit()
                row = cursor.fetchone()
                if row:
                    logger.info(f"Live chat request accepted: {request_id} by moderator {moderator_id}")
                    return dict(row)
                return None
        except Exception as e:
            logger.error(f"Error accepting live chat request: {e}")
            return None
    
    @staticmethod
    def mark_user_closed(request_id: str) -> bool:
        """Mark that the user closed from widget. Chat stays active for agent until they end it."""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE live_chat_requests
                    SET user_closed_at = NOW()
                    WHERE request_id = %s AND status = 'active'
                ''', (request_id,))
                conn.commit()
                success = cursor.rowcount > 0
                if success:
                    logger.info(f"Live chat user closed (agent notified): {request_id}")
                return success
        except Exception as e:
            logger.error(f"Error marking user closed: {e}")
            return False

    @staticmethod
    def close_request(request_id: str, moderator_id: Optional[str] = None) -> bool:
        """Close a live chat request (by agent)"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                if moderator_id:
                    cursor.execute('''
                        UPDATE live_chat_requests
                        SET status = 'closed',
                            closed_at = NOW()
                        WHERE request_id = %s AND moderator_id = %s
                    ''', (request_id, moderator_id))
                else:
                    cursor.execute('''
                        UPDATE live_chat_requests
                        SET status = 'closed',
                            closed_at = NOW()
                        WHERE request_id = %s
                    ''', (request_id,))
                conn.commit()
                success = cursor.rowcount > 0
                if success:
                    logger.info(f"Live chat request closed: {request_id}")
                return success
        except Exception as e:
            logger.error(f"Error closing live chat request: {e}")
            return False
    
    @staticmethod
    def get_by_id(request_id: str) -> Optional[Dict[str, Any]]:
        """Get a live chat request by ID"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM live_chat_requests
                    WHERE request_id = %s
                ''', (request_id,))
                row = cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error fetching live chat request: {e}")
            return None
    
    @staticmethod
    def get_by_moderator(moderator_id: str, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get all live chat requests handled by a moderator"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                if status:
                    cursor.execute('''
                        SELECT * FROM live_chat_requests
                        WHERE moderator_id = %s AND status = %s
                        ORDER BY created_at DESC
                    ''', (moderator_id, status))
                else:
                    cursor.execute('''
                        SELECT * FROM live_chat_requests
                        WHERE moderator_id = %s
                        ORDER BY created_at DESC
                    ''', (moderator_id,))
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error fetching moderator requests: {e}")
            return []
    
    @staticmethod
    def get_all_agent_chats(
        limit: int = 50,
        offset: int = 0,
        chatbot_id: Optional[str] = None,
        moderator_id: Optional[str] = None,
        status: Optional[str] = None
    ) -> tuple[List[Dict[str, Any]], int]:
        """Get all agent chats with pagination and filters"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                
                # Build WHERE clause
                conditions = []
                params = []
                
                if chatbot_id:
                    conditions.append("chatbot_id = %s")
                    params.append(chatbot_id)
                
                if moderator_id:
                    conditions.append("moderator_id = %s")
                    params.append(moderator_id)
                
                if status:
                    conditions.append("status = %s")
                    params.append(status)
                
                where_clause = " AND ".join(conditions) if conditions else "1=1"
                
                # Get total count
                cursor.execute(f'''
                    SELECT COUNT(*) as total FROM live_chat_requests
                    WHERE {where_clause}
                ''', tuple(params))
                total = cursor.fetchone()['total']
                
                # Get paginated results
                params.extend([limit, offset])
                cursor.execute(f'''
                    SELECT * FROM live_chat_requests
                    WHERE {where_clause}
                    ORDER BY created_at DESC
                    LIMIT %s OFFSET %s
                ''', tuple(params))
                rows = cursor.fetchall()
                
                return [dict(row) for row in rows], total
        except Exception as e:
            logger.error(f"Error fetching agent chats: {e}")
            return [], 0

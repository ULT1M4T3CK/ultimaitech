"""
Workflow Database Operations (Phase 4 - Multi-step automations)
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from .base import get_db_connection


def _row_to_workflow(row) -> Dict[str, Any]:
    d = dict(row)
    for k in ("steps", "triggers"):
        if k in d and isinstance(d.get(k), str):
            d[k] = json.loads(d[k] or "[]")
        elif k not in d or d.get(k) is None:
            d[k] = []
    return d


class WorkflowDB:
    """Database operations for workflows (multi-step automations)."""

    @staticmethod
    def create(data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        wid = data.get("id") or f"wf_{uuid.uuid4().hex[:12]}"
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO workflows (id, chatbot_id, name, steps, enabled, triggers)
                VALUES (%s, %s, %s, %s, %s, %s)
                RETURNING *
                """,
                (
                    wid,
                    data["chatbot_id"],
                    data.get("name", "Untitled"),
                    json.dumps(data.get("steps", [])),
                    data.get("enabled", True),
                    json.dumps(data.get("triggers", [])),
                ),
            )
            row = cursor.fetchone()
            return _row_to_workflow(row) if row else None

    @staticmethod
    def get_by_id(workflow_id: str) -> Optional[Dict[str, Any]]:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM workflows WHERE id = %s", (workflow_id,))
            row = cursor.fetchone()
            return _row_to_workflow(row) if row else None

    @staticmethod
    def get_by_chatbot(chatbot_id: str, enabled_only: bool = False) -> List[Dict[str, Any]]:
        q = "SELECT * FROM workflows WHERE chatbot_id = %s"
        if enabled_only:
            q += " AND enabled = TRUE"
        q += " ORDER BY created_at DESC"
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(q, (chatbot_id,))
            return [_row_to_workflow(row) for row in cursor.fetchall()]

    @staticmethod
    def update(workflow_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        allowed = ["name", "steps", "enabled", "triggers"]
        set_clauses = ["updated_at = NOW()"]
        values = []
        for f in allowed:
            if f in updates:
                set_clauses.append(f"{f} = %s")
                values.append(json.dumps(updates[f]) if f in ("steps", "triggers") else updates[f])
        if len(set_clauses) == 1:
            return WorkflowDB.get_by_id(workflow_id)
        values.append(workflow_id)
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                f"UPDATE workflows SET {', '.join(set_clauses)} WHERE id = %s RETURNING *",
                values,
            )
            conn.commit()
            row = cursor.fetchone()
            return _row_to_workflow(row) if row else None

    @staticmethod
    def delete(workflow_id: str) -> bool:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM workflows WHERE id = %s", (workflow_id,))
            conn.commit()
            return cursor.rowcount > 0

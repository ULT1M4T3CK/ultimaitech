"""
CRM Company Database Operations
Handles all database operations for CRM companies
"""

import uuid
import json
from typing import List, Optional, Dict, Any
from .base import get_db_connection


def _row_to_crm_company(row: Dict) -> Dict[str, Any]:
    """Convert database row to company dict"""
    return {
        'id': row['id'],
        'name': row['name'],
        'website': row.get('website'),
        'industry': row.get('industry'),
        'size': row.get('size'),
        'location': row.get('location'),
        'notes': row.get('notes'),
        'created_at': row['created_at'].isoformat() + 'Z' if hasattr(row['created_at'], 'isoformat') else row['created_at'],
        'updated_at': row['updated_at'].isoformat() + 'Z' if hasattr(row['updated_at'], 'isoformat') else row['updated_at'],
        'created_by': row.get('created_by'),
        'metadata': row['metadata'] if isinstance(row.get('metadata'), dict) else json.loads(row.get('metadata') or '{}')
    }


class CRMCompanyDB:
    """Database operations for CRM companies"""
    
    @staticmethod
    def create(company_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new company"""
        company_id = company_data.get('id', f"comp_{uuid.uuid4().hex[:12]}")
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO crm_companies (id, name, website, industry, size, description, metadata)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                RETURNING *
            ''', (
                company_id,
                company_data['name'],
                company_data.get('website'),
                company_data.get('industry'),
                company_data.get('size'),
                company_data.get('description'),
                json.dumps(company_data.get('metadata', {}))
            ))
            conn.commit()
            row = cursor.fetchone()
            return _row_to_crm_company(row) if row else None
    
    @staticmethod
    def get_all(limit: int = 100, offset: int = 0, search: str = None) -> List[Dict[str, Any]]:
        """Get all companies with optional search"""
        query = 'SELECT * FROM crm_companies WHERE 1=1'
        params = []
        
        if search:
            query += ' AND (LOWER(name) LIKE %s OR LOWER(website) LIKE %s)'
            search_term = f'%{search.lower()}%'
            params.extend([search_term, search_term])
        
        query += ' ORDER BY name ASC LIMIT %s OFFSET %s'
        params.extend([limit, offset])
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            return [_row_to_crm_company(row) for row in cursor.fetchall()]
    
    @staticmethod
    def get_by_id(company_id: str) -> Optional[Dict[str, Any]]:
        """Get a company by ID"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM crm_companies WHERE id = %s', (company_id,))
            row = cursor.fetchone()
            return _row_to_crm_company(row) if row else None
    
    @staticmethod
    def update(company_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update a company"""
        allowed_fields = ['name', 'website', 'industry', 'size', 'description', 'metadata']
        set_clauses = ['updated_at = NOW()']
        values = []
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = %s")
                if field == 'metadata':
                    values.append(json.dumps(updates[field]))
                else:
                    values.append(updates[field])
        
        values.append(company_id)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f'''
                UPDATE crm_companies SET {", ".join(set_clauses)}
                WHERE id = %s
                RETURNING *
            ''', values)
            conn.commit()
            row = cursor.fetchone()
            return _row_to_crm_company(row) if row else None
    
    @staticmethod
    def delete(company_id: str) -> bool:
        """Delete a company"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM crm_companies WHERE id = %s', (company_id,))
            conn.commit()
            return cursor.rowcount > 0
    
    @staticmethod
    def count() -> int:
        """Count all companies"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) as count FROM crm_companies')
            row = cursor.fetchone()
            return row['count'] if row else 0

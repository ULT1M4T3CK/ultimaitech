"""
Content Enhancer for Scraped Content
Improves content understanding by enriching scraped pages with structure, context, and metadata
"""

from typing import Dict, List, Any, Optional, Tuple
from bs4 import BeautifulSoup, Tag
import re
from urllib.parse import urlparse
import logging

logger = logging.getLogger(__name__)

# Import semantic chunking (with fallback)
try:
    from nlp.chunking import SemanticChunker
    SEMANTIC_CHUNKING_AVAILABLE = True
except ImportError:
    SEMANTIC_CHUNKING_AVAILABLE = False
    logger.warning("SemanticChunker not available, will use simple chunking")


class ContentEnhancer:
    """
    Enhances scraped content to improve chatbot understanding.
    
    Features:
    - Preserves heading hierarchy
    - Extracts structured data (tables, lists, FAQs)
    - Adds semantic context
    - Prioritizes important content
    - Enriches metadata
    """
    
    def __init__(self):
        """Initialize the content enhancer."""
        pass
    
    def enhance_page_content(
        self,
        html: str = '',
        url: str = '',
        title: str = '',
        description: str = '',
        headings: List[str] = None,
        raw_content: str = ''
    ) -> Dict[str, Any]:
        """
        Enhance a scraped page with better structure and context.
        
        Args:
            html: Original HTML content (optional)
            url: Page URL
            title: Page title
            description: Meta description
            headings: List of headings (optional)
            raw_content: Extracted text content
        
        Returns:
            Enhanced content dictionary
        """
        if headings is None:
            headings = []
        
        soup = BeautifulSoup(html, 'lxml') if html else None
        
        # Extract structured content
        structured_data = self._extract_structured_content(soup) if soup else {}
        
        # Build content sections with heading hierarchy
        # Always build sections, even without HTML (uses headings and raw_content)
        content_sections = self._build_content_sections(soup, raw_content, headings)
        
        # Determine page type and importance
        page_type = self._determine_page_type(url, title, description, headings)
        importance_score = self._calculate_importance(url, title, headings, len(raw_content))
        
        # Extract key phrases and topics
        key_topics = self._extract_key_topics(headings, raw_content)
        
        # Build enriched content
        enriched_content = self._build_enriched_content(
            title=title,
            description=description,
            headings=headings,
            content_sections=content_sections,
            structured_data=structured_data,
            page_type=page_type,
            importance_score=importance_score,
            key_topics=key_topics,
            url=url
        )
        
        return enriched_content
    
    def _extract_structured_content(self, soup: Optional[BeautifulSoup]) -> Dict[str, Any]:
        """Extract structured content like tables, lists, FAQs."""
        structured = {
            'tables': [],
            'lists': [],
            'faqs': [],
            'definitions': []
        }
        
        if not soup:
            return structured
        
        # Extract tables
        for table in soup.find_all('table'):
            rows = []
            for tr in table.find_all('tr'):
                cells = [td.get_text(strip=True) for td in tr.find_all(['td', 'th'])]
                if cells:
                    rows.append(cells)
            if rows:
                structured['tables'].append({
                    'rows': rows[:10],  # Limit to 10 rows
                    'type': 'data_table'
                })
        
        # Extract ordered and unordered lists
        for ul in soup.find_all(['ul', 'ol']):
            items = [li.get_text(strip=True) for li in ul.find_all('li', recursive=False)]
            if items and len(items) >= 2:  # Only meaningful lists
                structured['lists'].append({
                    'items': items[:20],  # Limit to 20 items
                    'type': 'unordered' if ul.name == 'ul' else 'ordered'
                })
        
        # Extract FAQ patterns (Q: ... A: ... or dt/dd pairs)
        faqs = []
        for dl in soup.find_all('dl'):
            terms = dl.find_all('dt')
            definitions = dl.find_all('dd')
            for term, definition in zip(terms, definitions):
                q = term.get_text(strip=True)
                a = definition.get_text(strip=True)
                if q and a and len(q) < 200 and len(a) < 1000:
                    faqs.append({'question': q, 'answer': a})
        
        # Also look for Q: ... A: ... patterns in text
        # This will be done separately when raw_content is available
        # (handled in _build_enriched_content or prepare_for_training)
        
        structured['faqs'] = faqs[:50]  # Limit to 50 FAQs
        
        return structured
    
    def _build_content_sections(
        self,
        soup: Optional[BeautifulSoup],
        raw_content: str,
        headings: List[str]
    ) -> List[Dict[str, Any]]:
        """
        Build content sections preserving heading hierarchy.
        
        Returns sections with their associated headings and content.
        """
        sections = []
        
        if not soup:
            # Fallback: create sections from headings if available
            if headings and raw_content:
                # Try to match headings with content sections
                # Simple approach: split content and try to associate with headings
                content_paragraphs = [p.strip() for p in raw_content.split('\n\n') if p.strip()]
                
                # Create sections based on headings
                current_section = None
                for heading in headings:
                    # Find content that might belong to this heading
                    # Look for paragraphs that mention the heading or come after it
                    section_content = []
                    for para in content_paragraphs:
                        # Simple heuristic: if paragraph is near heading text or starts with it
                        if heading.lower()[:20] in para.lower()[:100] or not section_content:
                            section_content.append(para)
                    
                    if section_content:
                        sections.append({
                            'heading': heading,
                            'level': 1,  # Default level
                            'content': '\n\n'.join(section_content),
                            'subsections': []
                        })
                
                # If we have remaining content without headings, add it
                if sections:
                    # Add any remaining content to the last section
                    remaining = [p for p in content_paragraphs if not any(p in s['content'] for s in sections)]
                    if remaining:
                        sections[-1]['content'] += '\n\n' + '\n\n'.join(remaining)
                else:
                    # No headings matched, create single section
                    sections.append({
                        'heading': headings[0] if headings else None,
                        'level': 1,
                        'content': raw_content,
                        'subsections': []
                    })
            elif raw_content:
                # No headings but have content
                sections.append({
                    'heading': None,
                    'level': 0,
                    'content': raw_content,
                    'subsections': []
                })
            else:
                # No content at all
                sections.append({
                    'heading': headings[0] if headings else None,
                    'level': 1 if headings else 0,
                    'content': '',
                    'subsections': []
                })
            return sections
        
        # Find all headings with their content
        current_section = None
        current_content = []
        
        # Process body content while preserving heading structure
        body = soup.find('body')
        if not body:
            return sections
        
        for element in body.descendants:
            if isinstance(element, Tag):
                tag_name = element.name
                
                # Found a heading
                if tag_name in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
                    # Save previous section
                    if current_section and current_content:
                        current_section['content'] = ' '.join(current_content).strip()
                        sections.append(current_section)
                    
                    # Start new section
                    level = int(tag_name[1])
                    heading_text = element.get_text(strip=True)
                    current_section = {
                        'heading': heading_text,
                        'level': level,
                        'content': '',
                        'subsections': []
                    }
                    current_content = []
                
                # Add text content to current section
                elif tag_name in ['p', 'div', 'span', 'li'] and current_section:
                    text = element.get_text(strip=True)
                    if text and len(text) > 10:
                        current_content.append(text)
        
        # Don't forget the last section
        if current_section and current_content:
            current_section['content'] = ' '.join(current_content).strip()
            sections.append(current_section)
        
        # If no sections found, create one from raw content
        if not sections:
            sections.append({
                'heading': headings[0] if headings else None,
                'level': 1,
                'content': raw_content,
                'subsections': []
            })
        
        return sections
    
    def _determine_page_type(
        self,
        url: str,
        title: str,
        description: str,
        headings: List[str]
    ) -> str:
        """Determine the type of page (homepage, product, article, FAQ, etc.)."""
        url_lower = url.lower()
        title_lower = title.lower()
        desc_lower = description.lower() if description else ''
        headings_text = ' '.join(headings).lower()
        
        combined = f"{url_lower} {title_lower} {desc_lower} {headings_text}"
        
        # Homepage indicators
        if any(indicator in combined for indicator in ['home', 'index', 'welcome', 'main']):
            if url.count('/') <= 2:  # Root or one level deep
                return 'homepage'
        
        # FAQ page
        if any(indicator in combined for indicator in ['faq', 'frequently asked', 'questions', 'help']):
            return 'faq'
        
        # Product/Service page
        if any(indicator in combined for indicator in ['product', 'service', 'pricing', 'plan', 'feature']):
            return 'product'
        
        # Article/Blog
        if any(indicator in combined for indicator in ['blog', 'article', 'post', 'news']):
            return 'article'
        
        # Contact page
        if any(indicator in combined for indicator in ['contact', 'reach', 'get in touch']):
            return 'contact'
        
        # About page
        if any(indicator in combined for indicator in ['about', 'who we are', 'our story']):
            return 'about'
        
        return 'general'
    
    def _calculate_importance(
        self,
        url: str,
        title: str,
        headings: List[str],
        content_length: int
    ) -> float:
        """
        Calculate importance score (0.0 to 1.0) for prioritizing content.
        
        Higher score = more important content.
        """
        score = 0.5  # Base score
        
        # Homepage gets high priority
        url_depth = url.count('/')
        if url_depth <= 2:
            score += 0.3
        
        # Pages with H1 headings are more important
        if headings and any('h1' in str(h).lower() for h in headings[:1]):
            score += 0.1
        
        # Longer content suggests more important pages
        if content_length > 1000:
            score += 0.1
        
        # Pages with multiple headings suggest structured content
        if len(headings) >= 3:
            score += 0.1
        
        return min(score, 1.0)
    
    def _extract_key_topics(self, headings: List[str], content: str) -> List[str]:
        """Extract key topics from headings and content."""
        topics = []
        
        # Add headings as topics
        for heading in headings[:10]:  # Top 10 headings
            if heading and len(heading) < 100:
                topics.append(heading.strip())
        
        # Extract common phrases (simple approach)
        # Could be enhanced with NLP/keyword extraction
        words = content.lower().split()
        common_phrases = {}
        
        # Simple bigram extraction
        for i in range(len(words) - 1):
            phrase = f"{words[i]} {words[i+1]}"
            if len(phrase) > 5 and len(phrase) < 30:
                common_phrases[phrase] = common_phrases.get(phrase, 0) + 1
        
        # Get top phrases
        sorted_phrases = sorted(common_phrases.items(), key=lambda x: x[1], reverse=True)
        for phrase, count in sorted_phrases[:5]:
            if count >= 3:  # Appears at least 3 times
                topics.append(phrase.title())
        
        return topics[:15]  # Limit to 15 topics
    
    def _build_enriched_content(
        self,
        title: str,
        description: str,
        headings: List[str],
        content_sections: List[Dict[str, Any]],
        structured_data: Dict[str, Any],
        page_type: str,
        importance_score: float,
        key_topics: List[str],
        url: str
    ) -> Dict[str, Any]:
        """Build the final enriched content structure."""
        
        # Build main content with heading context
        enriched_text_parts = []
        
        # Add title and description as context
        if title:
            enriched_text_parts.append(f"Page Title: {title}")
        if description:
            enriched_text_parts.append(f"Description: {description}")
        
        # Add content sections with headings
        if content_sections:
            for section in content_sections:
                section_text = ""
                if section.get('heading'):
                    section_text += f"{section['heading']}\n"
                if section.get('content'):
                    section_text += section['content']
                if section_text:
                    enriched_text_parts.append(section_text)
        else:
            # Fallback: use raw content if no sections
            # This shouldn't happen, but handle gracefully
            pass
        
        # Add structured data
        if structured_data.get('faqs'):
            enriched_text_parts.append("\nFrequently Asked Questions:")
            for faq in structured_data['faqs'][:10]:  # Top 10 FAQs
                enriched_text_parts.append(f"Q: {faq['question']}\nA: {faq['answer']}")
        
        if structured_data.get('lists'):
            for lst in structured_data['lists'][:5]:  # Top 5 lists
                enriched_text_parts.append("\n" + "\n".join(f"- {item}" for item in lst['items'][:10]))
        
        # Combine all parts
        enriched_content = "\n\n".join(enriched_text_parts)
        
        # If no enriched content was built, use a fallback
        if not enriched_content.strip():
            enriched_content = f"{title}\n\n{description or ''}" if title else ""
        
        return {
            'title': title,
            'description': description,
            'headings': headings,
            'enriched_content': enriched_content,
            'content_sections': content_sections,
            'structured_data': structured_data,
            'page_type': page_type,
            'importance_score': importance_score,
            'key_topics': key_topics,
            'url': url,
            'metadata': {
                'has_faqs': len(structured_data.get('faqs', [])) > 0,
                'has_tables': len(structured_data.get('tables', [])) > 0,
                'has_lists': len(structured_data.get('lists', [])) > 0,
                'section_count': len(content_sections),
                'heading_count': len(headings)
            }
        }
    
    def prepare_for_training(
        self,
        enhanced_content: Dict[str, Any],
        use_semantic_chunking: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Prepare enhanced content for training with optimal chunking.
        
        Returns list of training chunks with enriched metadata.
        """
        from nlp.chunking import SemanticChunker
        
        training_chunks = []
        
        # Ensure we have content to chunk
        content_to_chunk = enhanced_content.get('enriched_content', '')
        if not content_to_chunk or not content_to_chunk.strip():
            # Fallback: use raw content sections or title/description
            fallback_parts = []
            if enhanced_content.get('title'):
                fallback_parts.append(enhanced_content['title'])
            if enhanced_content.get('description'):
                fallback_parts.append(enhanced_content['description'])
            if enhanced_content.get('content_sections'):
                for section in enhanced_content['content_sections']:
                    if section.get('content'):
                        fallback_parts.append(section['content'])
            content_to_chunk = '\n\n'.join(fallback_parts) if fallback_parts else ''
        
        if not content_to_chunk or not content_to_chunk.strip():
            logger.warning(f"No content to chunk for {enhanced_content.get('url', 'unknown')}")
            return []
        
        # Use semantic chunking if available and requested
        chunk_results = []
        if use_semantic_chunking and SEMANTIC_CHUNKING_AVAILABLE:
            try:
                chunker = SemanticChunker(max_chunk_size=500, overlap=50, min_chunk_size=100)
                chunk_results = chunker.chunk_text(
                    content_to_chunk,
                    metadata={
                        'url': enhanced_content.get('url', ''),
                        'title': enhanced_content.get('title', ''),
                        'page_type': enhanced_content.get('page_type', 'general'),
                        'importance_score': enhanced_content.get('importance_score', 0.5)
                    }
                )
            except Exception as e:
                logger.warning(f"Semantic chunking failed, falling back to simple: {e}")
                use_semantic_chunking = False
        else:
            use_semantic_chunking = False

        if use_semantic_chunking:
            for i, chunk_result in enumerate(chunk_results):
                # Enrich chunk with additional context
                chunk_text = chunk_result.text
                
                if not chunk_text or not chunk_text.strip():
                    continue  # Skip empty chunks
                
                # Add page context prefix for better understanding
                context_prefix = f"[{enhanced_content.get('page_type', 'GENERAL').upper()}] "
                if enhanced_content.get('title'):
                    context_prefix += f"{enhanced_content['title']} - "
                
                enriched_chunk = context_prefix + chunk_text
                
                training_chunks.append({
                    'text': enriched_chunk,
                    'metadata': {
                        **chunk_result.metadata,
                        'url': enhanced_content['url'],
                        'title': enhanced_content['title'],
                        'description': enhanced_content.get('description', ''),
                        'page_type': enhanced_content['page_type'],
                        'importance_score': enhanced_content['importance_score'],
                        'key_topics': enhanced_content.get('key_topics', [])[:5],  # Top 5 topics
                        'chunk_index': i,
                        'chunk_type': chunk_result.chunk_type,
                        'has_headings': len(enhanced_content.get('headings', [])) > 0,
                        'has_faqs': enhanced_content['metadata'].get('has_faqs', False)
                    }
                })
        if not use_semantic_chunking:
            # Fallback to simple chunking with enrichment
            try:
                from routers.nlp.training import simple_chunk_text
            except ImportError:
                # Fallback if import fails
                def simple_chunk_text(text: str, chunk_size: int = 250, overlap: int = 50) -> List[str]:
                    words = text.split()
                    chunks = []
                    i = 0
                    while i < len(words):
                        chunk_words = words[i:i + chunk_size]
                        chunks.append(' '.join(chunk_words))
                        i += chunk_size - overlap
                    return chunks
            
            chunks = simple_chunk_text(enhanced_content['enriched_content'])
            
            for i, chunk in enumerate(chunks):
                context_prefix = f"[{enhanced_content['page_type'].upper()}] "
                if enhanced_content.get('title'):
                    context_prefix += f"{enhanced_content['title']} - "
                
                training_chunks.append({
                    'text': context_prefix + chunk,
                    'metadata': {
                        'url': enhanced_content['url'],
                        'title': enhanced_content['title'],
                        'description': enhanced_content.get('description', ''),
                        'page_type': enhanced_content['page_type'],
                        'importance_score': enhanced_content['importance_score'],
                        'chunk_index': i
                    }
                })
        
        # Also create dedicated chunks for FAQs (high-value content)
        structured_data = enhanced_content.get('structured_data', {})
        if structured_data.get('faqs'):
            for faq in structured_data['faqs']:
                question = faq.get('question', '').strip()
                answer = faq.get('answer', '').strip()
                if question and answer:
                    faq_text = f"Question: {question}\nAnswer: {answer}"
                    training_chunks.append({
                        'text': faq_text,
                        'metadata': {
                            'url': enhanced_content.get('url', ''),
                            'title': enhanced_content.get('title', ''),
                            'page_type': enhanced_content.get('page_type', 'general'),
                            'importance_score': min(enhanced_content.get('importance_score', 0.5) + 0.2, 1.0),  # Boost FAQ importance
                            'type': 'faq',
                            'question': question,
                            'answer': answer
                        }
                    })
        
        return training_chunks


# Singleton instance
content_enhancer = ContentEnhancer()

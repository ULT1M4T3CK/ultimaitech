"""
Response Validation Service
Validates chatbot responses to ensure quality and prevent hallucinations.
"""

from typing import List, Dict, Any, Optional
import logging
from services.nlp_service import nlp_service

logger = logging.getLogger(__name__)


class ResponseValidator:
    """
    Validates chatbot responses for quality, accuracy, and grounding.
    """
    
    MIN_GROUNDING_THRESHOLD = 0.6  # Minimum similarity to context chunks
    MIN_RELEVANCE_THRESHOLD = 0.5  # Minimum relevance to query
    
    def __init__(self):
        self.min_grounding = self.MIN_GROUNDING_THRESHOLD
        self.min_relevance = self.MIN_RELEVANCE_THRESHOLD
    
    def validate_response(
        self,
        response: str,
        query: str,
        context_chunks: List[Dict[str, Any]],
        confidence: float
    ) -> Dict[str, Any]:
        """
        Validate a response against query and context.
        
        Returns:
            Dict with validation results:
            {
                'valid': bool,
                'grounding_score': float,
                'relevance_score': float,
                'warnings': List[str],
                'should_use_fallback': bool
            }
        """
        validation_result = {
            'valid': True,
            'grounding_score': 0.0,
            'relevance_score': 0.0,
            'warnings': [],
            'should_use_fallback': False
        }
        
        # Check 1: Response not empty
        if not response or len(response.strip()) < 10:
            validation_result['valid'] = False
            validation_result['warnings'].append('Response too short or empty')
            validation_result['should_use_fallback'] = True
            return validation_result
        
        # Check 2: Response not too long (potential hallucination)
        if len(response) > 2000:
            validation_result['warnings'].append('Response unusually long, may contain hallucinations')
        
        # Check 3: Grounding validation (if context available)
        if context_chunks:
            try:
                response_embedding = nlp_service.get_embedding(response)
                max_grounding = 0.0
                
                for chunk in context_chunks[:3]:  # Check top 3 chunks
                    chunk_text = chunk.get('text', '') or chunk.get('content', '')
                    if not chunk_text:
                        continue
                    
                    chunk_embedding = nlp_service.get_embedding(chunk_text)
                    similarity = self._cosine_similarity(response_embedding, chunk_embedding)
                    max_grounding = max(max_grounding, similarity)
                
                validation_result['grounding_score'] = max_grounding
                
                if max_grounding < self.min_grounding:
                    validation_result['warnings'].append(
                        f'Response may not be grounded in context (grounding: {max_grounding:.2f})'
                    )
                    # Don't fail, but warn
                    if max_grounding < 0.4:  # Very low grounding
                        validation_result['should_use_fallback'] = True
            except Exception as e:
                logger.error(f"Error validating grounding: {e}")
        
        # Check 4: Relevance validation
        try:
            query_embedding = nlp_service.get_embedding(query)
            response_embedding = nlp_service.get_embedding(response)
            relevance = self._cosine_similarity(query_embedding, response_embedding)
            
            validation_result['relevance_score'] = relevance
            
            if relevance < self.min_relevance:
                validation_result['warnings'].append(
                    f'Response may not be relevant to query (relevance: {relevance:.2f})'
                )
        except Exception as e:
            logger.error(f"Error validating relevance: {e}")
        
        # Check 5: Confidence check
        if confidence < 0.3:
            validation_result['warnings'].append('Low confidence score')
            validation_result['should_use_fallback'] = True
        
        # Final validation decision
        if validation_result['should_use_fallback']:
            validation_result['valid'] = False
        
        return validation_result
    
    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine similarity between two vectors."""
        import numpy as np
        
        if not vec1 or not vec2 or len(vec1) != len(vec2):
            return 0.0
        
        v1 = np.array(vec1)
        v2 = np.array(vec2)
        
        dot_product = np.dot(v1, v2)
        norm_v1 = np.linalg.norm(v1)
        norm_v2 = np.linalg.norm(v2)
        
        if norm_v1 == 0 or norm_v2 == 0:
            return 0.0
        
        return float(dot_product / (norm_v1 * norm_v2))
    
    def check_hallucination_indicators(self, response: str, context_chunks: List[Dict[str, Any]]) -> List[str]:
        """
        Check for common hallucination indicators.
        
        Returns:
            List of warning messages
        """
        warnings = []
        
        # Check for phrases that suggest made-up information
        hallucination_phrases = [
            'i believe',
            'i think',
            'generally speaking',
            'typically',
            'usually',
            'in general',
            'most likely',
            'probably'
        ]
        
        response_lower = response.lower()
        for phrase in hallucination_phrases:
            if phrase in response_lower:
                warnings.append(f'Response contains uncertain language: "{phrase}"')
        
        # Check if response mentions things not in context
        # (This is a simple heuristic - could be improved with NER)
        if not context_chunks:
            warnings.append('No context available for validation')
        
        return warnings


# Singleton instance
response_validator = ResponseValidator()

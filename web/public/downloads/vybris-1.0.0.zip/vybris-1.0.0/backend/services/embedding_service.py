"""
Embedding Service Abstraction (Phase 3).

Central facade for text embeddings. Supports:
- In-process: delegates to NLPService (sentence-transformers)
- Remote: HTTP embedding API (when EMBEDDING_SERVICE_URL is set)
"""

import os
import logging
from abc import ABC, abstractmethod
from typing import List

logger = logging.getLogger(__name__)

EMBEDDING_SERVICE_URL = os.getenv("EMBEDDING_SERVICE_URL", "").strip()


class EmbeddingServiceBase(ABC):
    """Abstract embedding provider."""

    @abstractmethod
    def get_embedding(self, text: str) -> List[float]:
        """Embed a single text."""
        ...

    @abstractmethod
    def get_embeddings(
        self,
        texts: List[str],
        batch_size: int = 32,
        use_cache: bool = True,
    ) -> List[List[float]]:
        """Embed multiple texts in batch."""
        ...


class InProcessEmbeddingService(EmbeddingServiceBase):
    """Uses in-process NLPService (sentence-transformers)."""

    def __init__(self):
        self._nlp = None

    def _get_nlp(self):
        if self._nlp is None:
            from services.nlp_service import nlp_service
            self._nlp = nlp_service
        return self._nlp

    def get_embedding(self, text: str) -> List[float]:
        return self._get_nlp().get_embedding(text)

    def get_embeddings(
        self,
        texts: List[str],
        batch_size: int = 32,
        use_cache: bool = True,
    ) -> List[List[float]]:
        return self._get_nlp().get_embeddings(texts, batch_size, use_cache)


class RemoteEmbeddingService(EmbeddingServiceBase):
    """Calls a remote HTTP embedding API. For future dedicated embedding service."""

    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")
        self._client = None

    def _get_client(self):
        if self._client is None:
            import httpx
            self._client = httpx.Client(timeout=60.0)
        return self._client

    def get_embedding(self, text: str) -> List[float]:
        return self.get_embeddings([text])[0]

    def get_embeddings(
        self,
        texts: List[str],
        batch_size: int = 32,
        use_cache: bool = True,
    ) -> List[List[float]]:
        # Simple HTTP API: POST /embed { "texts": [...] } -> { "embeddings": [[...], ...] }
        client = self._get_client()
        url = f"{self.base_url}/embed"
        resp = client.post(url, json={"texts": texts})
        resp.raise_for_status()
        data = resp.json()
        return data.get("embeddings", [])


def _create_embedding_service() -> EmbeddingServiceBase:
    if EMBEDDING_SERVICE_URL:
        logger.info(f"Using remote embedding service at {EMBEDDING_SERVICE_URL}")
        return RemoteEmbeddingService(EMBEDDING_SERVICE_URL)
    return InProcessEmbeddingService()


embedding_service: EmbeddingServiceBase = _create_embedding_service()

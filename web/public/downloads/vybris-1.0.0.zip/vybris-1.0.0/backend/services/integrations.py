"""
Integration Service for VYBR!S
Handles third-party integrations with messaging platforms, CRM systems, ticketing systems, etc.
"""

import os
import json
import logging
import requests
from typing import Dict, Any, Optional, List
from datetime import datetime
import hashlib
import hmac

logger = logging.getLogger(__name__)


class IntegrationError(Exception):
    """Custom exception for integration errors"""
    pass


# ============================================================================
# WhatsApp Integration (via WhatsApp Business API / Twilio)
# ============================================================================

class WhatsAppIntegration:
    """WhatsApp Business API integration"""
    
    def __init__(self, config: Dict[str, Any]):
        self.access_token = config.get('access_token')
        self.phone_number_id = config.get('phone_number_id')
        self.verify_token = config.get('verify_token')
        self.api_version = config.get('api_version', 'v18.0')
        self.base_url = f"https://graph.facebook.com/{self.api_version}"
    
    def send_message(self, to: str, message: str, message_type: str = 'text') -> Dict[str, Any]:
        """Send a WhatsApp message"""
        try:
            url = f"{self.base_url}/{self.phone_number_id}/messages"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            payload = {
                'messaging_product': 'whatsapp',
                'recipient_type': 'individual',
                'to': to,
                'type': message_type,
                'text': {'body': message}
            }
            
            response = requests.post(url, headers=headers, json=payload)
            response.raise_for_status()
            
            return {
                'success': True,
                'message_id': response.json().get('messages', [{}])[0].get('id'),
                'data': response.json()
            }
        except Exception as e:
            logger.error(f"WhatsApp send error: {e}")
            raise IntegrationError(f"Failed to send WhatsApp message: {str(e)}")
    
    def verify_webhook(self, mode: str, token: str, challenge: str) -> Optional[str]:
        """Verify WhatsApp webhook"""
        if mode == 'subscribe' and token == self.verify_token:
            return challenge
        return None
    
    def process_incoming_message(self, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Process incoming WhatsApp message"""
        try:
            entry = payload.get('entry', [{}])[0]
            changes = entry.get('changes', [{}])[0]
            value = changes.get('value', {})
            messages = value.get('messages', [])
            
            if not messages:
                return None
            
            message = messages[0]
            return {
                'from': message.get('from'),
                'message_id': message.get('id'),
                'timestamp': message.get('timestamp'),
                'text': message.get('text', {}).get('body'),
                'type': message.get('type'),
                'platform': 'whatsapp'
            }
        except Exception as e:
            logger.error(f"WhatsApp message processing error: {e}")
            return None


class TwilioWhatsAppIntegration:
    """Twilio WhatsApp integration (alternative to WhatsApp Business API)"""
    
    def __init__(self, config: Dict[str, Any]):
        self.account_sid = config.get('account_sid')
        self.auth_token = config.get('auth_token')
        self.from_number = config.get('from_number')  # Format: whatsapp:+14155238886
        self.base_url = f"https://api.twilio.com/2010-04-01/Accounts/{self.account_sid}/Messages.json"
    
    def send_message(self, to: str, message: str) -> Dict[str, Any]:
        """Send WhatsApp message via Twilio"""
        try:
            # Ensure number has whatsapp: prefix
            if not to.startswith('whatsapp:'):
                to = f'whatsapp:{to}'
            
            payload = {
                'From': self.from_number,
                'To': to,
                'Body': message
            }
            
            response = requests.post(
                self.base_url,
                auth=(self.account_sid, self.auth_token),
                data=payload
            )
            response.raise_for_status()
            
            data = response.json()
            return {
                'success': True,
                'message_id': data.get('sid'),
                'status': data.get('status')
            }
        except Exception as e:
            logger.error(f"Twilio WhatsApp error: {e}")
            raise IntegrationError(f"Failed to send Twilio WhatsApp message: {str(e)}")


# ============================================================================
# CRM Integrations (Salesforce, HubSpot, etc.)
# ============================================================================

class SalesforceIntegration:
    """Salesforce CRM integration"""
    
    def __init__(self, config: Dict[str, Any]):
        self.instance_url = config.get('instance_url')
        self.access_token = config.get('access_token')
        self.api_version = config.get('api_version', 'v58.0')
    
    def create_lead(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a lead in Salesforce"""
        try:
            url = f"{self.instance_url}/services/data/{self.api_version}/sobjects/Lead"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            
            return {
                'success': True,
                'id': response.json().get('id'),
                'data': response.json()
            }
        except Exception as e:
            logger.error(f"Salesforce create lead error: {e}")
            raise IntegrationError(f"Failed to create Salesforce lead: {str(e)}")
    
    def create_case(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a support case in Salesforce"""
        try:
            url = f"{self.instance_url}/services/data/{self.api_version}/sobjects/Case"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            
            return {
                'success': True,
                'id': response.json().get('id'),
                'data': response.json()
            }
        except Exception as e:
            logger.error(f"Salesforce create case error: {e}")
            raise IntegrationError(f"Failed to create Salesforce case: {str(e)}")
    
    def get_contact(self, contact_id: str) -> Dict[str, Any]:
        """Get contact details from Salesforce"""
        try:
            url = f"{self.instance_url}/services/data/{self.api_version}/sobjects/Contact/{contact_id}"
            headers = {'Authorization': f'Bearer {self.access_token}'}
            
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            
            return response.json()
        except Exception as e:
            logger.error(f"Salesforce get contact error: {e}")
            raise IntegrationError(f"Failed to get Salesforce contact: {str(e)}")


class HubSpotIntegration:
    """HubSpot CRM integration"""
    
    def __init__(self, config: Dict[str, Any]):
        self.access_token = config.get('access_token')
        self.base_url = "https://api.hubapi.com"
    
    def create_contact(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a contact in HubSpot"""
        try:
            url = f"{self.base_url}/crm/v3/objects/contacts"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            payload = {'properties': data}
            response = requests.post(url, headers=headers, json=payload)
            response.raise_for_status()
            
            return {
                'success': True,
                'id': response.json().get('id'),
                'data': response.json()
            }
        except Exception as e:
            logger.error(f"HubSpot create contact error: {e}")
            raise IntegrationError(f"Failed to create HubSpot contact: {str(e)}")
    
    def create_deal(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a deal in HubSpot"""
        try:
            url = f"{self.base_url}/crm/v3/objects/deals"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            payload = {'properties': data}
            response = requests.post(url, headers=headers, json=payload)
            response.raise_for_status()
            
            return {
                'success': True,
                'id': response.json().get('id'),
                'data': response.json()
            }
        except Exception as e:
            logger.error(f"HubSpot create deal error: {e}")
            raise IntegrationError(f"Failed to create HubSpot deal: {str(e)}")
    
    def create_ticket(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a support ticket in HubSpot"""
        try:
            url = f"{self.base_url}/crm/v3/objects/tickets"
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            payload = {'properties': data}
            response = requests.post(url, headers=headers, json=payload)
            response.raise_for_status()
            
            return {
                'success': True,
                'id': response.json().get('id'),
                'data': response.json()
            }
        except Exception as e:
            logger.error(f"HubSpot create ticket error: {e}")
            raise IntegrationError(f"Failed to create HubSpot ticket: {str(e)}")


# ============================================================================
# Ticketing System Integrations (Zendesk, Freshdesk, etc.)
# ============================================================================

class ZendeskIntegration:
    """Zendesk ticketing system integration"""
    
    def __init__(self, config: Dict[str, Any]):
        self.subdomain = config.get('subdomain')
        self.email = config.get('email')
        self.api_token = config.get('api_token')
        self.base_url = f"https://{self.subdomain}.zendesk.com/api/v2"
    
    def create_ticket(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a ticket in Zendesk"""
        try:
            url = f"{self.base_url}/tickets.json"
            auth = (f"{self.email}/token", self.api_token)
            headers = {'Content-Type': 'application/json'}
            
            payload = {
                'ticket': {
                    'subject': data.get('subject'),
                    'comment': {'body': data.get('description')},
                    'priority': data.get('priority', 'normal'),
                    'tags': data.get('tags', []),
                    'requester': {'name': data.get('requester_name'), 'email': data.get('requester_email')}
                }
            }
            
            response = requests.post(url, auth=auth, headers=headers, json=payload)
            response.raise_for_status()
            
            return {
                'success': True,
                'id': response.json().get('ticket', {}).get('id'),
                'data': response.json()
            }
        except Exception as e:
            logger.error(f"Zendesk create ticket error: {e}")
            raise IntegrationError(f"Failed to create Zendesk ticket: {str(e)}")
    
    def add_comment(self, ticket_id: str, comment: str, public: bool = True) -> Dict[str, Any]:
        """Add a comment to a Zendesk ticket"""
        try:
            url = f"{self.base_url}/tickets/{ticket_id}.json"
            auth = (f"{self.email}/token", self.api_token)
            headers = {'Content-Type': 'application/json'}
            
            payload = {
                'ticket': {
                    'comment': {'body': comment, 'public': public}
                }
            }
            
            response = requests.put(url, auth=auth, headers=headers, json=payload)
            response.raise_for_status()
            
            return {'success': True, 'data': response.json()}
        except Exception as e:
            logger.error(f"Zendesk add comment error: {e}")
            raise IntegrationError(f"Failed to add Zendesk comment: {str(e)}")


class FreshdeskIntegration:
    """Freshdesk ticketing system integration"""
    
    def __init__(self, config: Dict[str, Any]):
        self.domain = config.get('domain')
        self.api_key = config.get('api_key')
        self.base_url = f"https://{self.domain}.freshdesk.com/api/v2"
    
    def create_ticket(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a ticket in Freshdesk"""
        try:
            url = f"{self.base_url}/tickets"
            auth = (self.api_key, 'X')
            headers = {'Content-Type': 'application/json'}
            
            payload = {
                'subject': data.get('subject'),
                'description': data.get('description'),
                'email': data.get('email'),
                'priority': data.get('priority', 1),
                'status': data.get('status', 2),
                'tags': data.get('tags', [])
            }
            
            response = requests.post(url, auth=auth, headers=headers, json=payload)
            response.raise_for_status()
            
            return {
                'success': True,
                'id': response.json().get('id'),
                'data': response.json()
            }
        except Exception as e:
            logger.error(f"Freshdesk create ticket error: {e}")
            raise IntegrationError(f"Failed to create Freshdesk ticket: {str(e)}")


# ============================================================================
# Messaging Platform Integrations (Slack, Telegram, etc.)
# ============================================================================

class SlackIntegration:
    """Slack messaging integration"""
    
    def __init__(self, config: Dict[str, Any]):
        self.bot_token = config.get('bot_token')
        self.signing_secret = config.get('signing_secret')
        self.base_url = "https://slack.com/api"
    
    def send_message(self, channel: str, text: str, blocks: Optional[List] = None) -> Dict[str, Any]:
        """Send a message to Slack channel"""
        try:
            url = f"{self.base_url}/chat.postMessage"
            headers = {
                'Authorization': f'Bearer {self.bot_token}',
                'Content-Type': 'application/json'
            }
            
            payload = {
                'channel': channel,
                'text': text
            }
            
            if blocks:
                payload['blocks'] = blocks
            
            response = requests.post(url, headers=headers, json=payload)
            response.raise_for_status()
            
            data = response.json()
            if not data.get('ok'):
                raise IntegrationError(f"Slack API error: {data.get('error')}")
            
            return {
                'success': True,
                'ts': data.get('ts'),
                'channel': data.get('channel')
            }
        except Exception as e:
            logger.error(f"Slack send message error: {e}")
            raise IntegrationError(f"Failed to send Slack message: {str(e)}")
    
    def verify_request(self, timestamp: str, signature: str, body: str) -> bool:
        """Verify Slack request signature"""
        try:
            sig_basestring = f"v0:{timestamp}:{body}"
            my_signature = 'v0=' + hmac.new(
                self.signing_secret.encode(),
                sig_basestring.encode(),
                hashlib.sha256
            ).hexdigest()
            
            return hmac.compare_digest(my_signature, signature)
        except Exception as e:
            logger.error(f"Slack signature verification error: {e}")
            return False


class TelegramIntegration:
    """Telegram Bot integration"""
    
    def __init__(self, config: Dict[str, Any]):
        self.bot_token = config.get('bot_token')
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}"
    
    def send_message(self, chat_id: str, text: str, parse_mode: str = 'HTML') -> Dict[str, Any]:
        """Send a message via Telegram"""
        try:
            url = f"{self.base_url}/sendMessage"
            payload = {
                'chat_id': chat_id,
                'text': text,
                'parse_mode': parse_mode
            }
            
            response = requests.post(url, json=payload)
            response.raise_for_status()
            
            data = response.json()
            if not data.get('ok'):
                raise IntegrationError(f"Telegram API error: {data.get('description')}")
            
            return {
                'success': True,
                'message_id': data.get('result', {}).get('message_id')
            }
        except Exception as e:
            logger.error(f"Telegram send message error: {e}")
            raise IntegrationError(f"Failed to send Telegram message: {str(e)}")
    
    def set_webhook(self, webhook_url: str) -> Dict[str, Any]:
        """Set Telegram webhook URL"""
        try:
            url = f"{self.base_url}/setWebhook"
            payload = {'url': webhook_url}
            
            response = requests.post(url, json=payload)
            response.raise_for_status()
            
            data = response.json()
            return {'success': data.get('ok'), 'description': data.get('description')}
        except Exception as e:
            logger.error(f"Telegram set webhook error: {e}")
            raise IntegrationError(f"Failed to set Telegram webhook: {str(e)}")


# ============================================================================
# Email Integration
# ============================================================================

class EmailIntegration:
    """Email integration using SMTP or SendGrid"""
    
    def __init__(self, config: Dict[str, Any]):
        self.provider = config.get('provider', 'smtp')
        self.config = config
    
    def send_email(self, to: str, subject: str, body: str, html: bool = False) -> Dict[str, Any]:
        """Send email via configured provider"""
        if self.provider == 'sendgrid':
            return self._send_via_sendgrid(to, subject, body, html)
        else:
            return self._send_via_smtp(to, subject, body, html)
    
    def _send_via_sendgrid(self, to: str, subject: str, body: str, html: bool) -> Dict[str, Any]:
        """Send email via SendGrid"""
        try:
            import sendgrid
            from sendgrid.helpers.mail import Mail, Email, To, Content
            
            sg = sendgrid.SendGridAPIClient(api_key=self.config.get('api_key'))
            from_email = Email(self.config.get('from_email'))
            to_email = To(to)
            content_type = "text/html" if html else "text/plain"
            content = Content(content_type, body)
            mail = Mail(from_email, to_email, subject, content)
            
            response = sg.client.mail.send.post(request_body=mail.get())
            
            return {
                'success': response.status_code in [200, 201, 202],
                'status_code': response.status_code
            }
        except Exception as e:
            logger.error(f"SendGrid email error: {e}")
            raise IntegrationError(f"Failed to send email via SendGrid: {str(e)}")
    
    def _send_via_smtp(self, to: str, subject: str, body: str, html: bool) -> Dict[str, Any]:
        """Send email via SMTP"""
        try:
            import smtplib
            from email.mime.text import MIMEText
            from email.mime.multipart import MIMEMultipart
            
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = self.config.get('from_email')
            msg['To'] = to
            
            content_type = 'html' if html else 'plain'
            msg.attach(MIMEText(body, content_type))
            
            with smtplib.SMTP(self.config.get('smtp_host'), self.config.get('smtp_port', 587)) as server:
                server.starttls()
                server.login(self.config.get('smtp_user'), self.config.get('smtp_password'))
                server.send_message(msg)
            
            return {'success': True}
        except Exception as e:
            logger.error(f"SMTP email error: {e}")
            raise IntegrationError(f"Failed to send email via SMTP: {str(e)}")


# ============================================================================
# Integration Manager - Factory Pattern
# ============================================================================

class IntegrationManager:
    """Manages all integrations for a chatbot"""
    
    INTEGRATION_CLASSES = {
        'whatsapp': WhatsAppIntegration,
        'twilio_whatsapp': TwilioWhatsAppIntegration,
        'salesforce': SalesforceIntegration,
        'hubspot': HubSpotIntegration,
        'zendesk': ZendeskIntegration,
        'freshdesk': FreshdeskIntegration,
        'slack': SlackIntegration,
        'telegram': TelegramIntegration,
        'email': EmailIntegration,
    }
    
    @staticmethod
    def get_integration(integration_type: str, config: Dict[str, Any]):
        """Factory method to get integration instance"""
        integration_class = IntegrationManager.INTEGRATION_CLASSES.get(integration_type)
        if not integration_class:
            raise IntegrationError(f"Unknown integration type: {integration_type}")
        
        return integration_class(config)
    
    @staticmethod
    def validate_config(integration_type: str, config: Dict[str, Any]) -> bool:
        """Validate integration configuration"""
        required_fields = {
            'whatsapp': ['access_token', 'phone_number_id', 'verify_token'],
            'twilio_whatsapp': ['account_sid', 'auth_token', 'from_number'],
            'salesforce': ['instance_url', 'access_token'],
            'hubspot': ['access_token'],
            'zendesk': ['subdomain', 'email', 'api_token'],
            'freshdesk': ['domain', 'api_key'],
            'slack': ['bot_token', 'signing_secret'],
            'telegram': ['bot_token'],
            'email': ['from_email'],
            'universal_inventory': ['inventory_api_key'],
            'universal_booking': ['booking_api_key'],
        }
        
        fields = required_fields.get(integration_type, [])
        return all(field in config and config[field] for field in fields)


# ============================================================================
# Universal Inventory Integration
# ============================================================================

class UniversalInventoryIntegration:
    """
    Universal connector for Inventory systems (product/boat listing, stock).
    Adapted for: http://51.20.126.15/admin/booking-handler.php
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.inventory_api_key = config.get('inventory_api_key')
        self.base_url = config.get('api_base_url', 'http://51.20.126.15/admin/booking-handler.php')
        self.inventory_api_url = config.get('inventory_api_url', self.base_url)

    def fetch_inventory_items(self) -> List[Dict[str, Any]]:
        """
        Fetch inventory as structured items for indexing.
        Returns a normalized list of item dicts.
        """
        data = self._fetch_inventory_json()
        return self._normalize_inventory_items(data)

    def format_inventory_item_text(self, item: Dict[str, Any]) -> str:
        """Format a single inventory item into searchable text."""
        if not item:
            return ""

        name = (
            item.get('name') or item.get('title') or item.get('boatName') or
            item.get('model') or item.get('type') or item.get('sku') or item.get('id')
        )
        description = item.get('description') or item.get('details') or item.get('summary')
        category = item.get('category') or item.get('type') or item.get('class')
        price = (
            item.get('price') or item.get('pricePerDay') or item.get('rate') or
            item.get('cost') or item.get('dailyRate')
        )
        availability = (
            item.get('availability') or item.get('availableCount') or item.get('stock') or
            item.get('quantity') or item.get('available')
        )
        features = item.get('features') or item.get('amenities') or item.get('highlights')

        used_keys = {
            'name', 'title', 'boatName', 'model', 'type', 'sku', 'id',
            'description', 'details', 'summary', 'category', 'class',
            'price', 'pricePerDay', 'rate', 'cost', 'dailyRate',
            'availability', 'availableCount', 'stock', 'quantity', 'available',
            'features', 'amenities', 'highlights'
        }

        lines = []
        if name:
            lines.append(f"Item: {name}")
        if category:
            lines.append(f"Category: {category}")
        if description:
            lines.append(f"Description: {description}")
        if price is not None:
            lines.append(f"Price: {price}")
        if availability is not None:
            lines.append(f"Availability: {availability}")
        if features:
            if isinstance(features, list):
                features_text = ", ".join(str(f) for f in features[:10])
            else:
                features_text = str(features)
            lines.append(f"Features: {features_text}")

        additional = self._collect_additional_attributes(item, used_keys)
        if additional:
            lines.append(f"Attributes: {additional}")

        return "\n".join(lines) if lines else json.dumps(item, ensure_ascii=True)
    
    def process_text(self, text: str) -> Optional[str]:
        """
        Handle inventory-only intents: return inventory data for lookup requests.
        """
        text_lower = text.lower()
        inventory_keywords = ['available', 'inventory', 'stock', 'how many', 'left', 'boats', 'products', 'items']
        if not any(k in text_lower for k in inventory_keywords):
            return None
        return self._check_inventory()

    def _check_inventory(self) -> str:
        try:
            data = self._fetch_inventory_json()
            return f"Inventory Data: {json.dumps(data)}"
        except Exception as e:
            logger.error(f"Inventory API error: {e}")
            return "Error checking inventory."

    def _fetch_inventory_json(self) -> Any:
        """Fetch raw inventory JSON from the configured API."""
        if not self.inventory_api_key:
            raise IntegrationError("Missing inventory_api_key for inventory sync.")

        payload = {
            'action': 'chatbot_getInventory',
            'apiKey': self.inventory_api_key
        }

        response = requests.post(
            self.inventory_api_url,
            json=payload,  # Use JSON, not form-urlencoded
            headers={'Content-Type': 'application/json'},
            timeout=15
        )

        if response.status_code != 200:
            raise IntegrationError(f"Inventory API returned status {response.status_code}")

        try:
            return response.json()
        except json.JSONDecodeError:
            return {"raw_text": response.text[:2000]}

    def _normalize_inventory_items(self, data: Any) -> List[Dict[str, Any]]:
        """Normalize inventory API responses into a list of item dicts."""
        if data is None:
            return []

        items: List[Any]
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            list_keys = ["inventory", "items", "products", "boats", "data", "results"]
            items = None
            for key in list_keys:
                if isinstance(data.get(key), list):
                    items = data.get(key)
                    break
            if items is None:
                items = [data]
        else:
            items = [data]

        normalized = []
        for item in items:
            if isinstance(item, dict):
                normalized.append(item)
            else:
                normalized.append({"value": item})
        return normalized

    def _collect_additional_attributes(self, item: Dict[str, Any], used_keys: set) -> str:
        """Collect additional simple attributes for indexing."""
        extras = []
        for key, value in item.items():
            if key in used_keys:
                continue
            if value is None:
                continue
            if isinstance(value, (str, int, float, bool)):
                extras.append(f"{key}: {value}")
            elif isinstance(value, list) and value and all(isinstance(v, (str, int, float, bool)) for v in value):
                extras.append(f"{key}: {', '.join(str(v) for v in value[:8])}")
            if len(extras) >= 8:
                break
        return "; ".join(extras)


# ============================================================================
# Universal Booking Integration
# ============================================================================

class UniversalBookingIntegration:
    """
    Universal connector for Booking systems (availability check, reservations, checkout links).
    Uses booking API for availability and checkout URL for reservation completion.
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.booking_api_key = config.get('booking_api_key')
        self.base_url = config.get('api_base_url', 'http://51.20.126.15/admin/booking-handler.php')
        self.booking_api_url = config.get('booking_api_url', self.base_url)
        self.checkout_url = config.get('checkout_url')

    def process_text(self, text: str) -> Optional[str]:
        """
        Handle booking intents: checkout link, availability check, booking instructions.
        """
        if text.strip().upper().startswith("GENERATE_LINK:"):
            return self._generate_checkout_link(text)
        if text.strip().upper().startswith("BOOK:"):
            return self._generate_checkout_link(text.replace("BOOK:", "GENERATE_LINK:"))
        if text.strip().upper().startswith("CHECK_AVAILABILITY:"):
            try:
                payload_str = text.split(":", 1)[1].strip()
                parts = [p.strip() for p in payload_str.split(',')]
                date = parts[0] if parts else None
                boat_type = parts[1] if len(parts) > 1 else None
                if date:
                    return self._check_availability(date, boat_type)
            except Exception as e:
                logger.error(f"CHECK_AVAILABILITY parse error: {e}")
            return None
        intent = self._detect_intent(text)
        if intent == 'booking':
            return self._get_booking_instructions()
        return None

    def _detect_intent(self, text: str) -> Optional[str]:
        text_lower = text.lower()
        booking_keywords = ['book', 'reserve', 'reservation', 'schedule', 'checkout']
        if any(k in text_lower for k in booking_keywords):
            return 'booking'
        return None

    def _check_availability(self, date: str, boat_type: str = None) -> str:
        try:
            if not boat_type:
                return (
                    f"[SYSTEM] To check availability for {date}, please specify which boat or product type "
                    "you're interested in. You can use the inventory list to see available options."
                )
            payload = {
                'action': 'chatbot_checkAvailability',
                'apiKey': self.booking_api_key,
                'date': date,
                'boatType': boat_type
            }
            response = requests.post(
                self.booking_api_url,
                json=payload,
                headers={'Content-Type': 'application/json'},
                timeout=10
            )
            if response.status_code != 200:
                return f"[SYSTEM] Availability API returned status {response.status_code}"
            try:
                data = response.json()
                if data.get('success'):
                    available = data.get('available', False)
                    count = data.get('availableCount', 0)
                    boat_name = data.get('boatName', boat_type)
                    price = data.get('pricePerDay', 0)
                    if available:
                        return (
                            f"[SYSTEM] Availability Check Result:\n"
                            f"✅ '{boat_name}' is AVAILABLE on {date}\n"
                            f"Available units: {count}\n"
                            f"Price per day: €{price}\n"
                            f"Ready for booking."
                        )
                    return (
                        f"[SYSTEM] Availability Check Result:\n"
                        f"❌ '{boat_name}' is NOT AVAILABLE on {date}\n"
                        f"Please suggest an alternative date or boat type."
                    )
                return f"[SYSTEM] Availability check failed: {data.get('message', 'Unknown error')}"
            except json.JSONDecodeError:
                return f"[SYSTEM] Error parsing availability response."
        except Exception as e:
            logger.error(f"Availability check error: {e}")
            return "[SYSTEM] Error checking availability."

    def _get_booking_instructions(self) -> str:
        return (
            "[SYSTEM] Booking System is ONLINE. "
            "Follow this STREAMLINED process:\n"
            "1. Check Availability: logic is already handled, if available, PROCEED.\n"
            "2. Ask for Booking: If user wants to book, collect: Name, Email. (Phone is optional but good).\n"
            "3. IMPORTANT: Do NOT ask for information the user has already provided.\n"
            "4. Confirmation: Summarize details (Date, Name, Email) and ask 'Shall I proceed to checkout?'.\n"
            "5. Execute: If 'Yes', output command: 'GENERATE_LINK: <Date>, <Name>, <Email>'\n"
            "   (Date format: YYYY-MM-DD)."
        )

    def _generate_checkout_link(self, text: str) -> str:
        try:
            payload_str = text.split(":", 1)[1].strip()
            parts = [p.strip() for p in payload_str.split(',')]
            if len(parts) < 3:
                return "[SYSTEM] Error: Invalid format for link generation. Required: Date, Name, Email."
            date, name, email = parts[0], parts[1], parts[2]
            if not self.checkout_url:
                return f"[SYSTEM] Configuration Error: No Checkout URL configured. Please contact support to book manually for {date}."
            import urllib.parse
            params = {'date': date, 'name': name, 'email': email, 'source': 'chatbot'}
            query_string = urllib.parse.urlencode(params)
            full_url = f"{self.checkout_url}?{query_string}"
            return (
                f"Date is available! Please complete your reservation by following this link:\n\n"
                f"👉 **[Click Here to Complete Booking]({full_url})**\n\n"
                f"(Link expires in 15 minutes)"
            )
        except Exception as e:
            logger.error(f"Link generation error: {e}")
            return f"[SYSTEM] Internal Error during link generation: {str(e)}"


# Update IntegrationManager
IntegrationManager.INTEGRATION_CLASSES['universal_inventory'] = UniversalInventoryIntegration
IntegrationManager.INTEGRATION_CLASSES['universal_booking'] = UniversalBookingIntegration




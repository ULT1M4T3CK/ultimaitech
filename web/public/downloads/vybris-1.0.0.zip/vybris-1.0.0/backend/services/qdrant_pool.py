"""
Qdrant Connection Pool
Manages reusable Qdrant client connections for better performance
"""

import os
import threading
import warnings
from qdrant_client import QdrantClient
from typing import Optional

# Suppress Qdrant "Api key is used with an insecure connection" when using HTTP (e.g. internal Docker network)
warnings.filterwarnings("ignore", message=".*[Aa]pi key is used with an insecure connection.*", category=UserWarning)

# Qdrant connection settings
QDRANT_HOST = os.getenv("QDRANT_HOST", "localhost")
QDRANT_PORT = int(os.getenv("QDRANT_PORT", "6333"))
QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")
VECTOR_DB_URL = os.getenv("VECTOR_DB_URL")

# Thread-safe singleton client
_qdrant_client: Optional[QdrantClient] = None
_client_lock = threading.Lock()


def get_qdrant_client() -> QdrantClient:
    """
    Get or create a Qdrant client (singleton pattern with thread safety).
    Reuses the same client instance across requests for better performance.
    """
    global _qdrant_client
    
    if _qdrant_client is None:
        with _client_lock:
            if _qdrant_client is None:
                try:
                    if VECTOR_DB_URL:
                        _qdrant_client = QdrantClient(
                            url=VECTOR_DB_URL,
                            api_key=QDRANT_API_KEY,
                            timeout=10
                        )
                    else:
                        _qdrant_client = QdrantClient(
                            host=QDRANT_HOST,
                            port=QDRANT_PORT,
                            api_key=QDRANT_API_KEY,
                            https=False,
                            prefer_grpc=False,
                            timeout=10  # 10 second timeout
                        )
                    # Test connection
                    _qdrant_client.get_collections()
                    print(f"[Qdrant] Connected to {QDRANT_HOST}:{QDRANT_PORT}")
                except Exception as e:
                    print(f"[Qdrant] Failed to connect, using in-memory mode: {e}")
                    _qdrant_client = QdrantClient(":memory:")
    
    return _qdrant_client


def reset_qdrant_client():
    """Reset the Qdrant client (useful for testing or reconnection)"""
    global _qdrant_client
    with _client_lock:
        if _qdrant_client:
            try:
                _qdrant_client.close()
            except:
                pass
        _qdrant_client = None

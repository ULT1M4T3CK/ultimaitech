"""
CORS Service
Manages allowed CORS origins with caching for performance
"""

import time
import logging
from typing import List, Set
from services.database.cors_origins import CORSOriginsDB

logger = logging.getLogger(__name__)


class CORSService:
    """
    Service for managing CORS allowed origins with caching.
    
    Features:
    - Caches origins in memory for fast access
    - Auto-refreshes cache periodically
    - Automatically adds domains from scraped URLs
    """
    
    def __init__(self):
        self._cached_origins: Set[str] = set()
        self._cache_timestamp: float = 0
        self._cache_ttl: float = 300  # 5 minutes cache TTL
        self._lock = False  # Simple lock flag (could use threading.Lock in production)
    
    def _refresh_cache(self, force: bool = False) -> None:
        """Refresh the cached origins from database"""
        current_time = time.time()
        
        # Check if cache is still valid
        if not force and (current_time - self._cache_timestamp) < self._cache_ttl:
            return
        
        # Prevent concurrent refreshes
        if self._lock:
            return
        
        try:
            self._lock = True
            origins = CORSOriginsDB.get_all_active()
            self._cached_origins = set(origins)
            self._cache_timestamp = current_time
            logger.debug(f"Refreshed CORS origins cache: {len(origins)} origins")
        except Exception as e:
            logger.error(f"Failed to refresh CORS origins cache: {e}")
        finally:
            self._lock = False
    
    def get_allowed_origins(self, include_static: bool = True) -> List[str]:
        """
        Get all allowed CORS origins.
        
        Args:
            include_static: Whether to include static origins from config
        
        Returns:
            List of allowed origin URLs
        """
        # Refresh cache if needed
        self._refresh_cache()
        
        # Start with cached database origins
        origins = list(self._cached_origins)
        
        # Add static origins from environment/config if requested
        if include_static:
            import os
            static_origins_env = os.getenv("ALLOWED_ORIGINS", "")
            if static_origins_env:
                static_origins = [origin.strip() for origin in static_origins_env.split(",") if origin.strip()]
                origins.extend(static_origins)
            else:
                # Default static origins
                default_origins = [
                    "http://localhost:3000",
                    "http://localhost:80",
                    "http://localhost",
                    "http://localhost:8888",
                    "https://ultimaitech.com",
                    "https://www.ultimaitech.com",
                    "http://ultimaitech.com",
                    "http://www.ultimaitech.com",
                ]
                origins.extend(default_origins)
        
        # Remove duplicates and return
        return list(set(origins))
    
    def add_domain_from_url(self, url: str, chatbot_id: str = None) -> List[str]:
        """
        Add a domain to allowed CORS origins from a scraped URL.
        
        Args:
            url: Source URL that was scraped
            chatbot_id: Optional chatbot ID that triggered this
        
        Returns:
            List of origins that were added
        """
        try:
            added_origins = CORSOriginsDB.add_domain_from_url(url, chatbot_id)
            
            if added_origins:
                # Invalidate cache to force refresh on next access
                self._cache_timestamp = 0
                logger.info(f"Added {len(added_origins)} CORS origins from URL {url}: {added_origins}")
            
            return added_origins
        except Exception as e:
            logger.error(f"Failed to add CORS domain from URL {url}: {e}")
            return []
    
    def invalidate_cache(self) -> None:
        """Force cache refresh on next access"""
        self._cache_timestamp = 0


# Singleton instance
cors_service = CORSService()

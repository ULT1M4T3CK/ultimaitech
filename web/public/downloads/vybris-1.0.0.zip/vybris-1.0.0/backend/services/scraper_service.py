"""
Scraper Service
Business logic for web scraping operations, separated from HTTP routing.
"""

from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import uuid
import asyncio
import aiohttp
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, urlunparse
import re
import hashlib
import logging
import time
from collections import defaultdict

from shared.utils.url import normalize_url, is_valid_url
from shared.utils.text import clean_text as clean_text_util
from services.retry_handler import retry_with_backoff

logger = logging.getLogger(__name__)


class ScrapeStatus(str, Enum):
    """Scrape job status enumeration."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class ScrapedPage:
    """Represents a single scraped page."""
    url: str
    title: str
    description: Optional[str]
    content: str
    headings: List[str]
    word_count: int
    scraped_at: str
    metadata: Optional[Dict[str, Any]] = None  # Additional metadata for content enhancement


@dataclass
class ScrapeJob:
    """Represents a scraping job with its state."""
    job_id: str
    status: ScrapeStatus
    url: str
    depth: int
    max_pages: int
    pages_scraped: int = 0
    total_content_length: int = 0
    pages: List[ScrapedPage] = field(default_factory=list)
    started_at: str = ""
    completed_at: Optional[str] = None
    error: Optional[str] = None
    progress: float = 0
    current_url: Optional[str] = None
    chatbot_id: Optional[str] = None
    render_js: bool = False


class ScraperService:
    """
    Service for web scraping operations.
    
    Handles:
    - URL fetching (static and JavaScript-rendered)
    - Content extraction from HTML
    - Link discovery and crawling
    - Sitemap parsing
    - Job management
    
    Performance optimizations:
    - Concurrent static page fetching (5-10 pages at once)
    - Browser pool for Playwright (reuses single browser)
    - Configurable delays (default 0.1s)
    - Early duplicate detection
    """
    
    # In-memory job storage (could be moved to Redis in production)
    _jobs: Dict[str, ScrapeJob] = {}
    
    # Playwright availability flag and browser pool
    _playwright_available: bool = False
    _browser = None
    _browser_context = None
    _playwright_instance = None
    _browser_lock: asyncio.Lock = asyncio.Lock()
    _browser_refcount: int = 0
    
    # Concurrency settings
    DEFAULT_CONCURRENCY = 5  # Pages fetched in parallel for static
    DEFAULT_DELAY = 0.1  # Seconds between requests (per concurrent worker)
    
    # Retry settings
    DEFAULT_MAX_RETRIES = 3
    DEFAULT_RETRY_DELAY = 1.0
    DEFAULT_MAX_RETRY_DELAY = 10.0
    
    # Rate limiting per domain
    _domain_rate_limits: Dict[str, List[float]] = defaultdict(list)  # {domain: [timestamps]}
    DEFAULT_RATE_LIMIT_PER_DOMAIN = 10  # Requests per minute per domain
    
    # robots.txt cache
    _robots_cache: Dict[str, tuple] = {}  # {cache_key: (rules, expiry_time)}
    ROBOTS_CACHE_TTL = 3600  # 1 hour
    ROBOTS_CACHE_VERSION = "v2"
    
    # Content validation thresholds
    MIN_WORD_COUNT = 20
    MIN_CONTENT_LENGTH = 100
    MAX_CONTENT_LENGTH = 50000
    
    # User agent for requests
    # User agent for requests (Modern Chrome on Windows)
    USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    
    def __init__(self):
        """Initialize the scraper service."""
        self._check_playwright()
    
    def _check_playwright(self) -> None:
        """Check if Playwright is available for JS rendering."""
        try:
            from playwright.async_api import async_playwright
            self._playwright_available = True
        except ImportError:
            print("[ScraperService] Playwright not installed. JavaScript rendering disabled.")
            self._playwright_available = False
    
    @property
    def playwright_available(self) -> bool:
        """Check if Playwright is available."""
        return self._playwright_available
    
    def normalize_url(self, url: str) -> str:
        """Normalize URL for deduplication. Delegates to shared utils."""
        return normalize_url(url)

    def get_capabilities(self) -> Dict[str, Any]:
        """Get scraper capabilities."""
        return {
            "static_html": True,
            "javascript_rendering": self._playwright_available,
            "sitemap_discovery": True,
            "max_depth": 10,
            "max_pages": 10000,
            "note": "Enable render_js=true for React/Vue/Angular SPAs" if self._playwright_available 
                    else "Install Playwright for SPA support"
        }
    
    # ==================== Job Management ====================
    
    def create_job(
        self,
        url: str,
        depth: int = 3,
        max_pages: int = 50,
        chatbot_id: Optional[str] = None,
        render_js: bool = False
    ) -> ScrapeJob:
        """Create a new scraping job."""
        job_id = f"scrape_{uuid.uuid4().hex[:12]}"
        now = datetime.utcnow().isoformat() + 'Z'
        
        job = ScrapeJob(
            job_id=job_id,
            status=ScrapeStatus.PENDING,
            url=url,
            depth=depth,
            max_pages=max_pages,
            started_at=now,
            chatbot_id=chatbot_id,
            render_js=render_js
        )
        
        self._jobs[job_id] = job
        return job
    
    def get_job(self, job_id: str) -> Optional[ScrapeJob]:
        """Get a job by ID."""
        return self._jobs.get(job_id)
    
    def get_job_status(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Get job status as dictionary."""
        job = self.get_job(job_id)
        if not job:
            return None
        
        return {
            "job_id": job.job_id,
            "status": job.status.value,
            "progress": job.progress,
            "pages_scraped": job.pages_scraped,
            "current_url": job.current_url,
            "error": job.error
        }
    
    def get_job_result(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Get full job result."""
        job = self.get_job(job_id)
        if not job:
            return None
        
        return {
            "job_id": job.job_id,
            "status": job.status.value,
            "url": job.url,
            "pages_scraped": job.pages_scraped,
            "total_content_length": job.total_content_length,
            "pages": [self._page_to_dict(p) for p in job.pages],
            "started_at": job.started_at,
            "completed_at": job.completed_at,
            "error": job.error
        }
    
    def save_job_state(self, job_id: str) -> bool:
        """
        Save job state for resume capability.
        In production, this would save to database/Redis.
        Currently saves to job metadata.
        """
        job = self.get_job(job_id)
        if not job:
            return False
        
        # Store state in job metadata (in production, use persistent storage)
        if not hasattr(job, 'metadata'):
            job.metadata = {}
        
        job.metadata['state_saved_at'] = datetime.utcnow().isoformat()
        job.metadata['pages_scraped'] = job.pages_scraped
        job.metadata['status'] = job.status.value
        
        return True
    
    def resume_job(self, job_id: str) -> bool:
        """
        Resume an interrupted scraping job.
        In production, would load state from database/Redis.
        """
        job = self.get_job(job_id)
        if not job or job.status != ScrapeStatus.FAILED:
            return False
        
        # In a full implementation, would:
        # 1. Load saved state (visited URLs, content hashes, etc.)
        # 2. Restart crawling from saved checkpoint
        # 3. Skip already processed URLs
        
        logger.info(f"Resume capability for job {job_id} - would load state from persistent storage")
        return True
    
    def get_job_preview(self, job_id: str) -> Optional[List[Dict[str, Any]]]:
        """Get preview of scraped pages."""
        job = self.get_job(job_id)
        if not job or job.status != ScrapeStatus.COMPLETED:
            return None
        
        return [
            {
                "url": page.url,
                "title": page.title,
                "preview": page.content[:200] + '...' if len(page.content) > 200 else page.content,
                "word_count": page.word_count
            }
            for page in job.pages
        ]
    
    def _page_to_dict(self, page: ScrapedPage) -> Dict[str, Any]:
        """Convert ScrapedPage to dictionary."""
        return {
            "url": page.url,
            "title": page.title,
            "description": page.description,
            "content": page.content,
            "headings": page.headings,
            "word_count": page.word_count,
            "scraped_at": page.scraped_at
        }
    
    # ==================== URL Utilities ====================
    

    
    def validate_url(self, url: str) -> tuple[bool, str]:
        """Validate and normalize a URL."""
        if not url:
            return False, "URL is required"
        
        # Add scheme if missing
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        if not is_valid_url(url):
            return False, "Invalid URL format"
        
        return True, url
    
    async def check_robots_txt(self, session: aiohttp.ClientSession, url: str) -> Dict[str, Any]:
        """
        Check robots.txt for a domain and cache the result.
        
        Returns:
            Dict with 'allowed' (bool) and 'crawl_delay' (float) keys
        """
        parsed = urlparse(url)
        domain = f"{parsed.scheme}://{parsed.netloc}"
        robots_url = f"{domain}/robots.txt"
        cache_key = f"{domain}|{self.USER_AGENT.lower()}|{self.ROBOTS_CACHE_VERSION}"
        
        # Check cache
        if cache_key in self._robots_cache:
            rules, expiry = self._robots_cache[cache_key]
            if datetime.utcnow().timestamp() < expiry:
                return rules
        
        # Default: allow crawling with no delay
        rules = {
            'allowed': True,
            'crawl_delay': 0.0,
            'disallowed_paths': []
        }
        
        try:
            headers = {
                'User-Agent': self.USER_AGENT,
                'Accept': 'text/plain,text/html,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
            }
            async with session.get(robots_url, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as response:
                if response.status == 200:
                    robots_content = await response.text()
                    rules = self._parse_robots_txt(robots_content, url, user_agent=self.USER_AGENT)
        except Exception as e:
            logger.debug(f"Could not fetch robots.txt for {domain}: {e}")
            # Default to allowing if robots.txt is unavailable
        
        # Cache the result
        expiry = datetime.utcnow().timestamp() + self.ROBOTS_CACHE_TTL
        self._robots_cache[cache_key] = (rules, expiry)
        
        return rules
    
    def _parse_robots_txt(self, content: str, url: str, user_agent: Optional[str] = None) -> Dict[str, Any]:
        """
        Parse robots.txt content.
        
        Returns:
            Dict with 'allowed', 'crawl_delay', and 'disallowed_paths'
        """
        parsed = urlparse(url)
        path = parsed.path or '/'
        ua = (user_agent or self.USER_AGENT or '').lower()
        
        # Parse robots.txt into user-agent groups
        groups = []
        current_group = None
        has_rules = False
        
        for line in content.split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            if ':' not in line:
                continue
            
            key, value = line.split(':', 1)
            key = key.strip().lower()
            value = value.strip()
            
            if key == 'user-agent':
                if current_group is None or has_rules:
                    if current_group is not None:
                        groups.append(current_group)
                    current_group = {'user_agents': [], 'rules': [], 'crawl_delay': 0.0}
                    has_rules = False
                current_group['user_agents'].append(value.lower())
                continue
            
            if current_group is None:
                continue
            
            if key in ('allow', 'disallow'):
                has_rules = True
                current_group['rules'].append((key, value))
            elif key == 'crawl-delay':
                has_rules = True
                try:
                    current_group['crawl_delay'] = max(current_group.get('crawl_delay', 0.0), float(value))
                except ValueError:
                    pass
        
        if current_group is not None:
            groups.append(current_group)
        
        # Find the most specific matching user-agent group
        # When multiple groups have the same specificity, use the LAST one (most recent rules override)
        best_group = None
        best_len = -1
        for group in groups:
            group_best_len = -1
            for token in group['user_agents']:
                if token == '*':
                    match_len = 1
                elif token and token in ua:
                    match_len = len(token)
                else:
                    continue
                if match_len > group_best_len:
                    group_best_len = match_len
            if group_best_len == -1:
                continue
            if group_best_len > best_len:
                best_group = group
                best_len = group_best_len
            elif group_best_len == best_len:
                # Same specificity: use the later group (most recent rules)
                best_group = group
        
        if not best_group:
            return {
                'allowed': True,
                'crawl_delay': 0.0,
                'disallowed_paths': []
            }
        
        # Use rules from only the most specific matching group
        combined_rules = best_group.get('rules', [])
        crawl_delay = best_group.get('crawl_delay', 0.0)
        
        # Evaluate path against rules using longest-match precedence
        # Default to allowed if no rules match
        allowed = True
        best_match_len = -1
        
        # Process rules: longer matches take precedence, and Allow overrides Disallow for same-length matches
        # Sort rules by length (longest first), then by type (Allow after Disallow for same length)
        sorted_rules = sorted(combined_rules, key=lambda x: (-len(x[1]) if x[1] else 0, x[0] == 'disallow'))
        
        for rule_type, rule_path in sorted_rules:
            if not rule_path:
                # Empty disallow means allow all; empty allow has no effect
                if rule_type == 'disallow':
                    allowed = True  # Empty disallow = allow all
                continue
            if path.startswith(rule_path):
                match_len = len(rule_path)
                # Longer matches always win
                if match_len > best_match_len:
                    best_match_len = match_len
                    allowed = (rule_type == 'allow')
                elif match_len == best_match_len:
                    # Same length: Allow overrides Disallow (Allow processed after Disallow due to sorting)
                    allowed = (rule_type == 'allow')
        
        return {
            'allowed': allowed,
            'crawl_delay': crawl_delay,
            'disallowed_paths': [p for t, p in combined_rules if t == 'disallow' and p]
        }
    
    async def _check_rate_limit(self, domain: str) -> float:
        """
        Check and enforce rate limit for a domain.
        
        Returns:
            Delay in seconds to wait before next request
        """
        now = time.time()
        cutoff = now - 60  # Last minute
        
        # Clean old timestamps
        self._domain_rate_limits[domain] = [
            ts for ts in self._domain_rate_limits[domain] if ts > cutoff
        ]
        
        # Check if we're at the limit
        if len(self._domain_rate_limits[domain]) >= self.DEFAULT_RATE_LIMIT_PER_DOMAIN:
            # Calculate wait time
            oldest_request = min(self._domain_rate_limits[domain])
            wait_time = 60 - (now - oldest_request) + 1  # Add 1s buffer
            return max(0, wait_time)
        
        # Record this request
        self._domain_rate_limits[domain].append(now)
        return 0.0
    
    # ==================== Content Extraction ====================
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize extracted text."""
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'[^\w\s.,!?;:\'\"()-]', '', text)
        return text.strip()
    
    def validate_content_quality(self, content: Dict[str, Any]) -> tuple[bool, str]:
        """
        Validate scraped content quality before storing.
        
        Returns:
            (is_valid, reason_if_invalid)
        """
        # Check word count
        if content.get('word_count', 0) < self.MIN_WORD_COUNT:
            return False, f"Content too short: {content.get('word_count', 0)} words (minimum: {self.MIN_WORD_COUNT})"
        
        # Check content length
        content_text = content.get('content', '')
        if len(content_text) < self.MIN_CONTENT_LENGTH:
            return False, f"Content too short: {len(content_text)} chars (minimum: {self.MIN_CONTENT_LENGTH})"
        
        if len(content_text) > self.MAX_CONTENT_LENGTH:
            return False, f"Content too long: {len(content_text)} chars (maximum: {self.MAX_CONTENT_LENGTH})"
        
        # Check for meaningful content (not just navigation/boilerplate)
        # Ratio of unique words to total words
        words = content_text.split()
        unique_words = len(set(words))
        if len(words) > 0:
            uniqueness_ratio = unique_words / len(words)
            if uniqueness_ratio < 0.3:  # Too repetitive
                return False, f"Content too repetitive (uniqueness: {uniqueness_ratio:.2f})"
        
        # Check for common low-quality indicators
        low_quality_patterns = [
            r'404\s+not\s+found',
            r'page\s+not\s+found',
            r'access\s+denied',
            r'forbidden',
            r'error\s+\d{3}'
        ]
        
        content_lower = content_text.lower()
        for pattern in low_quality_patterns:
            if re.search(pattern, content_lower):
                return False, f"Content contains error message: {pattern}"
        
        return True, ""
    
    def extract_content(self, html: str, url: str, spa_aware: bool = False) -> Dict[str, Any]:
        """Extract meaningful content from HTML."""
        soup = BeautifulSoup(html, 'lxml')
        
        # Extract links BEFORE removing navigation elements
        links = set()
        base_url_parsed = urlparse(url)
        base_netloc = base_url_parsed.netloc
        base_hostname = base_url_parsed.hostname or base_netloc
        
        # Priority containers for link discovery
        priority_containers = [
            'nav', 'header', 'footer', '.nav', '.navigation', '.menu',
            '.footer', '#footer', '.site-footer', '#nav', '#navigation',
            '.header', '#header', '.site-header', '.main-nav', '.top-nav',
            '.bottom-nav', '.footer-nav', '.footer-links', '.footer-menu'
        ]
        
        # Collect links from priority areas
        for selector in priority_containers:
            containers = soup.select(selector) if selector.startswith(('.', '#')) else soup.find_all(selector)
            for container in containers:
                for a in container.find_all('a', href=True):
                    processed = self._process_link(a['href'], base_url_parsed, base_netloc, base_hostname, url, spa_aware=spa_aware)
                    if processed:
                        links.add(processed)
        
        # Get all other links
        for a in soup.find_all('a', href=True):
            href = a['href']
            processed = self._process_link(href, base_url_parsed, base_netloc, base_hostname, url, spa_aware=spa_aware)
            if processed:
                links.add(processed)
            # Debug: log filtered links
            elif href and not href.startswith(('#', 'javascript:', 'mailto:', 'tel:')):
                # Only log if it's a potentially valid link that was filtered
                pass  # Commented out to reduce noise, but can enable for debugging
        
        # Extract metadata
        title = ''
        title_tag = soup.find('title')
        if title_tag:
            title = title_tag.get_text(strip=True)
        
        description = ''
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        if meta_desc:
            description = meta_desc.get('content', '')
        
        # Remove unwanted elements for content extraction
        for element in soup(['script', 'style', 'nav', 'footer', 'header', 'aside',
                            'iframe', 'noscript', 'meta', 'link', 'form', 'button',
                            'svg', 'img', 'video', 'audio', 'canvas']):
            element.decompose()
        
        # Extract main content areas
        content_areas = []
        main_selectors = [
            'main', 'article', '[role="main"]', '.content', '.main-content',
            '#content', '#main', '.post-content', '.article-content', '.entry-content',
            '.page-content', '.site-content', '.wrapper', '.container',
            '.post', '.entry', '.markdown-body', '.app-container', '#app', '#root'
        ]
        
        for selector in main_selectors:
            elements = soup.select(selector)
            for el in elements:
                text = el.get_text(separator=' ', strip=True)
                if len(text) > 100:
                    content_areas.append(self.clean_text(text))
        
        # Fallback to body
        if not content_areas:
            body = soup.find('body')
            if body:
                text = body.get_text(separator=' ', strip=True)
                content_areas.append(self.clean_text(text))
        
        combined_content = ' '.join(content_areas)
        
        # Extract headings
        headings = []
        for h in soup.find_all(['h1', 'h2', 'h3']):
            heading_text = h.get_text(strip=True)
            if heading_text and len(heading_text) < 200:
                headings.append(heading_text)
        
        # Extract additional metadata for better understanding
        page_metadata = self._extract_page_metadata(soup, url)
        
        return {
            'title': title or 'Untitled Page',
            'description': description,
            'content': combined_content[:50000],
            'headings': headings[:20],
            'word_count': len(combined_content.split()),
            'links': list(links)[:500],
            'metadata': page_metadata  # Additional metadata for enhancement
        }
    
    def _canonicalize_for_crawling(self, url: str, *, spa_aware: bool) -> str:
        """
        Canonicalize URL for crawling *deduplication* (visited-set key).

        - Always uses shared.utils.url.normalize_url for standard normalization.
        - When spa_aware is True, preserves SPA routing fragments by converting common
          hash-router routes into path routes (so /#/pricing and /pricing dedupe).
        """
        if not url:
            return ""

        if not spa_aware:
            return normalize_url(url)

        try:
            parsed = urlparse(url)
            fragment = (parsed.fragment or "").strip()
            if not fragment:
                return normalize_url(url)

            # Hash-router routes: "#/pricing" or "#/docs/intro"
            if fragment.startswith("/"):
                route_path = fragment
                return normalize_url(urlunparse((parsed.scheme, parsed.netloc, route_path, "", parsed.query, "")))

            # Hash-router routes without leading slash but containing subpaths, e.g. "#docs/intro"
            # Treat anchors like "#section-2" as in-page anchors (discard).
            if "/" in fragment:
                route, sep, frag_query = fragment.partition("?")
                query = frag_query or parsed.query
                return normalize_url(urlunparse((parsed.scheme, parsed.netloc, "/" + route, "", query, "")))

            # Otherwise: likely an in-page anchor; discard fragment
            return normalize_url(urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", parsed.query, "")))
        except Exception:
            return normalize_url(url)

    def _normalize_fetch_url(self, url: str, *, spa_aware: bool) -> str:
        """
        Normalize a URL for fetching/crawling.

        For static sites, this is equivalent to normalize_url().
        For SPA hash routers, we preserve routing fragments (e.g. /#/pricing) because
        converting them to path routes can break navigation on hash-only SPAs.
        """
        if not url:
            return ""

        if not spa_aware:
            return normalize_url(url)

        try:
            parsed = urlparse(url.strip())
            fragment = parsed.fragment or ""

            # Normalize base URL (without fragment) using normalize_url
            base = urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", parsed.query, ""))
            normalized_base = normalize_url(base)

            # Preserve fragment for SPA route fragments; anchor fragments will be dropped by _process_link.
            if fragment:
                return f"{normalized_base}#{fragment}"
            return normalized_base
        except Exception:
            return url.strip()

    def _extract_page_metadata(self, soup: BeautifulSoup, url: str) -> Dict[str, Any]:
        """Extract additional metadata to improve content understanding."""
        metadata = {
            'has_navigation': len(soup.find_all('nav')) > 0,
            'has_forms': len(soup.find_all('form')) > 0,
            'has_tables': len(soup.find_all('table')) > 0,
            'has_lists': len(soup.find_all(['ul', 'ol'])) > 0,
            'language': soup.find('html', {}).get('lang', 'en') if soup.find('html') else 'en'
        }
        
        # Extract Open Graph and Twitter Card metadata
        og_title = soup.find('meta', property='og:title')
        if og_title:
            metadata['og_title'] = og_title.get('content', '')
        
        og_description = soup.find('meta', property='og:description')
        if og_description:
            metadata['og_description'] = og_description.get('content', '')
        
        # Extract schema.org structured data
        schema_data = soup.find_all('script', type='application/ld+json')
        if schema_data:
            metadata['has_schema'] = True
        
        return metadata
    
    def _process_link(
        self,
        href: str,
        base_url_parsed,
        base_netloc: str,
        base_hostname: str,
        current_url: str,
        spa_aware: bool = False
    ) -> Optional[str]:
        """Process a link and return clean URL if valid."""
        # Skip non-content links
        if href.startswith(('#', 'javascript:', 'mailto:', 'tel:')):
            return None
        
        # Fix: Build full URL using urljoin for proper relative URL handling
        if href.startswith('/'):
            full_url = f"{base_url_parsed.scheme}://{base_netloc}{href}"
        elif href.startswith(('http://', 'https://')):
            full_url = href
        else:
            full_url = urljoin(current_url, href)
        
        parsed = urlparse(full_url)
        
        # Only same-domain links (treat www and non-www as same)
        if parsed.scheme not in ('http', 'https'):
            return None
        link_hostname = parsed.hostname
        if not link_hostname:
            return None
        def normalize_domain(hostname: str) -> str:
            return hostname.lower().lstrip('www.')
        if normalize_domain(link_hostname) != normalize_domain(base_hostname):
            return None
        
        # Skip non-content patterns
        skip_patterns = [
            '/login', '/register', '/signin', '/signup', '/cart',
            '/checkout', '/account', '/wp-admin', '/admin', '/wp-login',
            '.pdf', '.jpg', '.jpeg', '.png', '.gif', '.zip', '.exe',
            '.doc', '.docx', '.xls', '.xlsx', '.mp3', '.mp4', '.webp',
            '/feed', '/rss', '/cdn-cgi/', '/wp-json/'
        ]
        
        # Fix: Check patterns directly on full_url instead of intermediate clean_url
        full_url_lower = full_url.lower()
        if any(pattern in full_url_lower for pattern in skip_patterns):
            return None

        # In SPA-aware mode, also apply skip patterns to route fragments (e.g. "#/login")
        if spa_aware and parsed.fragment:
            frag_lower = parsed.fragment.lower()
            if any(pattern.strip("/").lower() in frag_lower for pattern in skip_patterns if pattern.startswith("/")):
                return None
        
        # SPA-aware handling: preserve route fragments for fetch, drop pure anchors
        fetch_url = full_url
        if spa_aware and parsed.fragment:
            frag = parsed.fragment.strip()
            is_route_fragment = frag.startswith("/") or ("/" in frag)
            if not is_route_fragment:
                # Treat as in-page anchor -> drop fragment for fetching/deduping
                fetch_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", parsed.query, ""))

        fetch_url = self._normalize_fetch_url(fetch_url, spa_aware=spa_aware)
        normalized = self._canonicalize_for_crawling(fetch_url, spa_aware=spa_aware)
        
        # Don't add current page (compare normalized versions)
        if self._canonicalize_for_crawling(current_url, spa_aware=spa_aware) == normalized:
            return None
        
        # Return fetchable URL; dedupe should use _canonicalize_for_crawling()
        return fetch_url if fetch_url else None
    
    # ==================== Fetching ====================
    
    async def fetch_page(self, session: aiohttp.ClientSession, url: str, timeout: int = 45, max_retries: int = None) -> Optional[str]:
        """
        Fetch a single page with timeout and retry logic (static HTML only).
        
        Args:
            session: aiohttp session
            url: URL to fetch
            timeout: Request timeout in seconds
            max_retries: Maximum retry attempts (default: DEFAULT_MAX_RETRIES)
        
        Returns:
            HTML content or None if failed
        """
        max_retries = max_retries or self.DEFAULT_MAX_RETRIES
        
        async def _fetch():
            headers = {
                'User-Agent': self.USER_AGENT,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
            }
            async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=timeout)) as response:
                if response.status == 200:
                    content_type = response.headers.get('content-type', '')
                    if 'text/html' in content_type or 'application/xml' in content_type or 'text/xml' in content_type:
                        return await response.text()
                    else:
                        logger.debug(f"Unexpected content-type for {url}: {content_type}")
                        return None
                elif response.status == 429:  # Rate limited
                    retry_after = int(response.headers.get('Retry-After', 60))
                    logger.warning(f"Rate limited for {url}, waiting {retry_after}s")
                    await asyncio.sleep(retry_after)
                    raise aiohttp.ClientResponseError(
                        request_info=response.request_info,
                        history=response.history,
                        status=429
                    )
                else:
                    logger.debug(f"HTTP {response.status} for {url}")
                    return None
        
        try:
            return await retry_with_backoff(
                _fetch,
                max_attempts=max_retries,
                initial_delay=self.DEFAULT_RETRY_DELAY,
                max_delay=self.DEFAULT_MAX_RETRY_DELAY,
                exceptions=(
                    aiohttp.ClientError,
                    asyncio.TimeoutError,
                    aiohttp.ClientResponseError
                )
            )
        except Exception as e:
            logger.warning(f"Error fetching {url} after {max_retries} retries: {e}")
            return None
    
    async def fetch_pages_batch(
        self,
        session: aiohttp.ClientSession,
        urls: List[str],
        max_concurrent: int = 5,
        delay: float = 0.1,
        timeout: int = 45,
        respect_robots: bool = True,
        respect_rate_limit: bool = True
    ) -> List[tuple]:
        """
        Fetch multiple pages concurrently with rate limiting and robots.txt checking.
        
        Args:
            session: aiohttp session
            urls: List of URLs to fetch
            max_concurrent: Maximum concurrent requests
            delay: Base delay between requests
            timeout: Request timeout
            respect_robots: Whether to check robots.txt
            respect_rate_limit: Whether to enforce rate limits
        
        Returns list of (url, html) tuples. Failed fetches return (url, None).
        """
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def fetch_with_limit(url: str) -> tuple:
            async with semaphore:
                # Check robots.txt if enabled
                if respect_robots:
                    robots_rules = await self.check_robots_txt(session, url)
                    if not robots_rules['allowed']:
                        logger.debug(f"robots.txt disallows: {url}")
                        return (url, None)
                    
                    # Apply crawl delay from robots.txt
                    if robots_rules['crawl_delay'] > 0:
                        await asyncio.sleep(robots_rules['crawl_delay'])
                
                # Check and enforce rate limit
                if respect_rate_limit:
                    domain = urlparse(url).netloc
                    wait_time = await self._check_rate_limit(domain)
                    if wait_time > 0:
                        logger.debug(f"Rate limit wait for {domain}: {wait_time:.2f}s")
                        await asyncio.sleep(wait_time)
                
                # Base delay
                await asyncio.sleep(delay)
                
                # Fetch with retry
                html = await self.fetch_page(session, url, timeout=timeout)
                return (url, html)
        
        tasks = [fetch_with_limit(url) for url in urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Handle any exceptions
        clean_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.warning(f"Batch fetch error for {urls[i]}: {result}")
                clean_results.append((urls[i], None))
            else:
                clean_results.append(result)
        
        return clean_results
    
    async def fetch_page_with_playwright(
        self,
        url: str,
        timeout: int = 120,
        wait_for_selector: Optional[str] = None,
        wait_for_stability: bool = True
    ) -> Optional[str]:
        """Fetch a page using Playwright with JavaScript rendering (uses browser pool).

        Note: For best results (coverage + quality), JS crawling should prefer DOM-based
        extraction via `_render_and_extract_dom()` which returns structured content + links.
        This method is kept for backward compatibility and returns HTML only.
        """
        if not self._playwright_available:
            return None

        # Manage pool here because this method can be called standalone.
        await self._acquire_browser_pool(timeout=timeout)
        try:
            html, _ = await self._render_and_extract_dom(
                url=url,
                timeout=timeout,
                wait_for_selector=wait_for_selector,
                wait_for_stability=wait_for_stability,
                return_html=True
            )
            return html
        finally:
            await self._release_browser_pool()

    async def _auto_scroll(self, page):
        """Scroll through the page to trigger lazy loading (bounded, incremental).
        Uses more rounds and longer stable check so dynamic/long pages (e.g. boat rental sites)
        get fully expanded before we snapshot."""
        try:
            await page.evaluate("""
                async () => {
                    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
                    let lastHeight = 0;
                    let stableRounds = 0;
                    const maxRounds = 50;
                    const maxStableRounds = 6;

                    for (let i = 0; i < maxRounds; i++) {
                        window.scrollBy(0, 800);
                        await sleep(400);
                        const h = document.body.scrollHeight || 0;
                        if (h === lastHeight) {
                            stableRounds += 1;
                        } else {
                            stableRounds = 0;
                            lastHeight = h;
                        }
                        if (stableRounds >= maxStableRounds) break;
                    }
                    window.scrollTo(0, 0);
                }
            """)
            await asyncio.sleep(0.5)
        except Exception as e:
            print(f"[ScraperService] Auto-scroll error: {e}")
    
    async def _wait_for_content_stability(
        self, 
        page, 
        max_wait_ms: int = 22000, 
        stability_threshold_ms: int = 2500
    ) -> bool:
        """
        Wait for page content to stabilize (no DOM changes for stability_threshold_ms).
        This is crucial for SPAs that load content dynamically via JavaScript.
        Uses longer defaults so multi-wave / lazy-loaded content (e.g. nijenhuis-botenverhuur.com)
        has time to appear before we snapshot.
        
        Returns True if stabilized, False if timed out.
        """
        try:
            return await page.evaluate(f"""
                async () => {{
                    const maxWait = {max_wait_ms};
                    const stabilityThreshold = {stability_threshold_ms};
                    const startTime = Date.now();
                    let lastContentLength = (document.body && document.body.innerText ? document.body.innerText.length : 0);
                    let lastChangeTime = startTime;
                    
                    while (Date.now() - startTime < maxWait) {{
                        await new Promise(r => setTimeout(r, 200));
                        const currentLength = (document.body && document.body.innerText ? document.body.innerText.length : 0);
                        
                        if (currentLength !== lastContentLength) {{
                            lastContentLength = currentLength;
                            lastChangeTime = Date.now();
                        }}
                        
                        // Content stable for threshold duration
                        if (Date.now() - lastChangeTime >= stabilityThreshold) {{
                            return true;
                        }}
                    }}
                    return false; // Timed out
                }}
            """)
        except Exception as e:
            print(f"[ScraperService] Content stability check error: {e}")
            return False

    async def _wait_for_meaningful_text(self, page, timeout_ms: int = 15000, min_chars: int = 400) -> bool:
        """Wait until the page has non-trivial visible text (helps SPAs/hydration)."""
        try:
            await page.wait_for_function(
                """() => {
                    const pick = () =>
                      document.querySelector('main, article, [role="main"]') ||
                      document.querySelector('#root, #app') ||
                      document.body;
                    const el = pick();
                    const t = (el && el.innerText) ? el.innerText.trim() : '';
                    return t.length >= %d;
                }""" % int(min_chars),
                timeout=timeout_ms
            )
            return True
        except Exception:
            return False

    async def _extract_dom_snapshot(self, page) -> Dict[str, Any]:
        """Extract links + text from the rendered DOM. Uses body text when main is small
        so dynamic content outside standard main/article (e.g. nijenhuis-botenverhuur.com) is captured."""
        return await page.evaluate("""
            () => {
                const pickMain = () =>
                    document.querySelector('main, article, [role="main"]') ||
                    document.querySelector('.content, .main-content, #content, #main') ||
                    document.querySelector('#root main, #app main') ||
                    document.querySelector('#root, #app') ||
                    document.body;

                const mainEl = pickMain();
                const mainText = (mainEl && mainEl.innerText) ? mainEl.innerText : '';
                const bodyText = (document.body && document.body.innerText) ? document.body.innerText : '';
                // Use the longer of main vs body so we capture full dynamic content when
                // theme puts content outside main or loads it in waves
                const text = (bodyText.length > mainText.length * 1.2) ? bodyText : (mainText || bodyText);

                const title = document.title || '';
                const metaDesc = document.querySelector('meta[name="description"]');
                const description = metaDesc ? (metaDesc.getAttribute('content') || '') : '';

                const headings = Array.from(document.querySelectorAll('h1, h2, h3'))
                    .map(h => (h && h.innerText ? h.innerText.trim() : ''))
                    .filter(Boolean)
                    .slice(0, 50);

                const urls = new Set();
                for (const a of Array.from(document.querySelectorAll('a[href]'))) {
                    try {
                        const href = a.getAttribute('href') || '';
                        if (!href) continue;
                        urls.add(a.href);
                    } catch (e) {}
                }
                for (const el of Array.from(document.querySelectorAll('[data-href],[role="link"][data-href]'))) {
                    try {
                        const href = el.getAttribute('data-href') || '';
                        if (!href) continue;
                        urls.add(new URL(href, window.location.href).toString());
                    } catch (e) {}
                }

                return {
                    title,
                    description,
                    headings,
                    text: text || '',
                    links: Array.from(urls).slice(0, 2000),
                    lang: (document.documentElement && document.documentElement.lang) ? document.documentElement.lang : 'en'
                };
            }
        """)

    async def _render_and_extract_dom(
        self,
        url: str,
        timeout: int = 120,
        wait_for_selector: Optional[str] = None,
        wait_for_stability: bool = True,
        return_html: bool = False
    ) -> tuple[Optional[str], Optional[Dict[str, Any]]]:
        """
        Render with Playwright and extract DOM-based content + links.
        Returns (html_or_none, content_dict_or_none)
        """
        page = await self._get_browser_page(timeout)
        if not page:
            return (None, None)

        try:
            # Per-page timeouts
            try:
                page.set_default_timeout(timeout * 1000)
                page.set_default_navigation_timeout(timeout * 1000)
            except Exception:
                pass

            # Retry navigation (some SPAs flake on first load)
            last_err = None
            for attempt in range(3):
                try:
                    await page.goto(url, wait_until='domcontentloaded', timeout=timeout * 1000)
                    break
                except Exception as e:
                    last_err = e
                    await asyncio.sleep(min(1.0 * (attempt + 1), 3.0))
            else:
                raise last_err  # type: ignore[misc]

            # Brief delay so first paint / hydration can start before we handle popups
            await asyncio.sleep(0.8)
            await self._handle_popups(page)

            # Optional selector wait (if user knows SPA root/content container)
            if wait_for_selector:
                try:
                    await page.wait_for_selector(wait_for_selector, timeout=20000, state='visible')
                except Exception:
                    print(f"[ScraperService] Selector '{wait_for_selector}' not found on {url}")

            # Prefer text-based readiness over networkidle (polling/websockets can prevent idle)
            await self._wait_for_meaningful_text(page, timeout_ms=20000, min_chars=300)

            # Best-effort network idle (many SPAs never reach this; don't block on it)
            try:
                await page.wait_for_load_state('networkidle', timeout=10000)
            except Exception:
                pass

            await self._auto_scroll(page)

            # Wait for dynamic content to finish loading (longer so multi-wave/lazy content is captured)
            if wait_for_stability:
                await self._wait_for_content_stability(page, max_wait_ms=22000, stability_threshold_ms=2500)

            snapshot = await self._extract_dom_snapshot(page)
            final_url = getattr(page, "url", None) or url

            # Extract content from modals/dialogs (details, pricing, etc.) and merge into page text
            modal_content = await self._extract_modals_content(page)
            main_text = (snapshot.get("text", "") or "").strip()
            if modal_content.strip():
                main_text = main_text + "\n\n--- Modal / dialog content ---\n\n" + modal_content.strip()
            text = clean_text_util(main_text)

            # Build content dict compatible with validate_content_quality + downstream storage
            base_url_parsed = urlparse(final_url)
            base_netloc = base_url_parsed.netloc
            base_hostname = base_url_parsed.hostname or base_netloc

            processed_links: List[str] = []
            for raw in snapshot.get("links", []) or []:
                processed = self._process_link(
                    raw,
                    base_url_parsed,
                    base_netloc,
                    base_hostname,
                    final_url,
                    spa_aware=True
                )
                if processed:
                    processed_links.append(processed)

            content_dict = {
                "title": (snapshot.get("title") or "").strip() or "Untitled Page",
                "description": (snapshot.get("description") or "").strip() or "",
                "content": text[:50000],
                "headings": [h for h in (snapshot.get("headings") or []) if h][:20],
                "word_count": len(text.split()),
                "links": list(dict.fromkeys(processed_links))[:500],
                "metadata": {
                    "language": snapshot.get("lang") or "en",
                    "rendered": True
                }
            }

            html_content = await page.content() if return_html else None
            return (html_content, content_dict)
        except Exception as e:
            print(f"[ScraperService] Playwright render/extract error for {url}: {e}")
            return (None, None)
        finally:
            try:
                await page.close()
            except Exception:
                pass

    # Modal extraction: max triggers per page and timeout per modal
    MODAL_MAX_TRIGGERS = 30
    MODAL_WAIT_MS = 5000
    MODAL_CLOSE_DELAY = 0.4
    MODAL_CONTENT_WAIT_MS = 800  # Wait for AJAX content inside modal (e.g. pricing)

    async def _extract_modals_content(self, page) -> str:
        """
        Find and open modals/dialogs (e.g. details, pricing), extract their text, then close.
        Tuned for sites like nijenhuis-botenverhuur.com (Dutch boat rental: details, prijzen).
        Returns combined modal text to be merged into page content.
        """
        modal_texts: List[str] = []
        seen_text_hashes: set = set()
        try:
            # Common selectors for elements that open modals
            trigger_selectors = [
                '[data-toggle="modal"]',
                '[data-bs-toggle="modal"]',
                '[aria-haspopup="dialog"]',
                '[data-target*="modal"]',
                '[data-bs-target*="modal"]',
                '.modal-trigger',
                '[data-open]',
                '[data-dialog]',
                '[data-popup]',
                '[data-modal]',
                '[class*="modal-trigger"]',
                '[class*="open-modal"]',
                '[class*="openModal"]',
                '[onclick*="modal"]',
                '[onclick*="open"]',
                'a[href="#"]',
                'button[class*="detail"]',
                'a[class*="detail"]',
                '.card a',
                '[class*="boat"] a',
                '[class*="boot"] a',
            ]
            # Text patterns that often open detail/pricing modals (case-insensitive)
            # Dutch boat-rental (nijenhuis-botenverhuur etc.): bekijk boot, prijzen, reserveren, tarieven
            trigger_text_patterns = (
                "view details", "view more", "see details", "see more", "more info",
                "details", "pricing", "price", "more information", "learn more",
                "bekijk", "meer info", "prijzen", "informatie",  # Dutch
                "bekijk boot", "bekijk prijzen", "reserveren", "boeken", "tarieven",
                "vanaf", "prijs", "huur", "boot huren", "details bekijken",  # Dutch boat
                "mehr erfahren", "preis", "details anzeigen",  # German
            )
            triggers: List[Any] = []
            for sel in trigger_selectors:
                try:
                    els = await page.query_selector_all(sel)
                    for el in els:
                        if el and el not in triggers:
                            try:
                                if await el.is_visible():
                                    triggers.append(el)
                            except Exception:
                                pass
                except Exception:
                    continue

            # Also find buttons/links by visible text (likely modal triggers)
            try:
                for pattern in trigger_text_patterns:
                    try:
                        loc = page.get_by_role("button", name=re.compile(pattern, re.I))
                        count = await loc.count()
                        for i in range(min(count, 5)):
                            el = await loc.nth(i).element_handle()
                            if el and await el.is_visible() and el not in triggers:
                                triggers.append(el)
                    except Exception:
                        pass
                    try:
                        loc = page.locator(f"a:has-text('{pattern}')")
                        count = await loc.count()
                        for i in range(min(count, 8)):
                            el = await loc.nth(i).element_handle()
                            if el and await el.is_visible() and el not in triggers:
                                triggers.append(el)
                    except Exception:
                        pass
            except Exception:
                pass

            # Cap number of triggers
            triggers = triggers[: self.MODAL_MAX_TRIGGERS]

            # Selectors for when a modal/dialog is visible (incl. popups, overlays, drawers)
            dialog_selectors = [
                '[role="dialog"]',
                '.modal.show',
                '.modal.in',
                '.modal.open',
                '[class*="modal"][class*="show"]',
                '[class*="Modal"][class*="open"]',
                '[data-state="open"]',
                '.ReactModal__Content',
                '[aria-modal="true"]',
                '.popup.show',
                '.popup.open',
                '[class*="popup"][class*="open"]',
                '[class*="popup"][class*="show"]',
                '.overlay.show',
                '.overlay.open',
                '[class*="overlay"][class*="visible"]',
                '.drawer.open',
                '.panel.open',
                '[class*="lightbox"]',
            ]
            close_selectors = [
                '[data-dismiss="modal"]',
                '[data-bs-dismiss="modal"]',
                '.modal .close',
                '.modal-header button',
                '[aria-label="Close"]',
                '[aria-label="Sluiten"]',
                '.modal-backdrop',
                '.popup .close',
                '.popup-close',
                '[class*="close"]',
                '.overlay .close',
                'button[aria-label*="luiten"]',
                'button[aria-label*="lose"]',
            ]

            for trigger in triggers:
                try:
                    await trigger.evaluate("el => el.scrollIntoView({ block: 'center' })")
                    await asyncio.sleep(0.2)
                    await trigger.click(timeout=3000)
                except Exception:
                    continue

                dialog_el = None
                for sel in dialog_selectors:
                    try:
                        dialog_el = await page.wait_for_selector(
                            sel, state="visible", timeout=self.MODAL_WAIT_MS
                        )
                        if dialog_el:
                            break
                    except Exception:
                        continue
                if not dialog_el:
                    try:
                        await page.keyboard.press("Escape")
                        await asyncio.sleep(self.MODAL_CLOSE_DELAY)
                    except Exception:
                        pass
                    continue

                # Wait for content inside modal (e.g. pricing loaded via AJAX on nijenhuis-botenverhuur)
                await asyncio.sleep(self.MODAL_CONTENT_WAIT_MS / 1000.0)

                try:
                    modal_text = await dialog_el.evaluate(
                        "(el) => (el && el.innerText) ? el.innerText.trim() : ''"
                    )
                    if modal_text and len(modal_text) > 15:
                        h = hashlib.md5(modal_text.encode("utf-8")).hexdigest()
                        if h not in seen_text_hashes:
                            seen_text_hashes.add(h)
                            modal_texts.append(modal_text)
                except Exception:
                    pass

                for close_sel in close_selectors:
                    try:
                        close_btn = await page.query_selector(close_sel)
                        if close_btn and await close_btn.is_visible():
                            await close_btn.click(timeout=1500)
                            break
                    except Exception:
                        continue
                else:
                    try:
                        await page.keyboard.press("Escape")
                    except Exception:
                        pass
                await asyncio.sleep(self.MODAL_CLOSE_DELAY)
            return "\n\n".join(modal_texts) if modal_texts else ""
        except Exception as e:
            logger.debug("Modal extraction error: %s", e)
            return ""

    async def _handle_popups(self, page):
        """Attempt to close common cookie banners and popups (English + Dutch + German)."""
        try:
            # Common patterns for cookie/consent buttons (incl. Dutch e.g. nijenhuis-botenverhuur.com)
            selectors = [
                "button:has-text('Accept')", "button:has-text('OK')",
                "button:has-text('Agree')", "button:has-text('Got it')",
                "button:has-text('Allow all')", "button:has-text('Accepteren')",
                "button:has-text('Alles accepteren')", "button:has-text('Akkoord')",
                "button:has-text('Toestaan')", "button:has-text('Staat toe')",
                "button:has-text('Alle cookies')", "a:has-text('Accepteren')",
                "a:has-text('Alles accepteren')", "[id*='cookie'] button",
                "[class*='cookie'] button", "[class*='consent'] button",
                ".accept-cookies", "#accept-cookies", "[data-testid*='accept']"
            ]
            for selector in selectors:
                try:
                    btn = await page.query_selector(selector)
                    if btn and await btn.is_visible():
                        await btn.click(timeout=2000)
                        await asyncio.sleep(0.5)
                except Exception:
                    continue
        except Exception:
            pass
    
    async def _install_request_blocking(self):
        """Block heavy resources (images/media/fonts/analytics) to speed up JS rendering."""
        if not self._browser_context:
            return

        blocked_resource_types = {"image", "media", "font"}
        blocked_url_substrings = (
            "googletagmanager.com",
            "google-analytics.com",
            "doubleclick.net",
            "facebook.net",
            "hotjar.com",
            "segment.com",
            "clarity.ms",
        )

        async def handler(route, request):
            try:
                rtype = getattr(request, "resource_type", "") or ""
                rurl = (request.url or "").lower()
                if rtype in blocked_resource_types:
                    await route.abort()
                    return
                if any(s in rurl for s in blocked_url_substrings):
                    await route.abort()
                    return
                await route.continue_()
            except Exception:
                try:
                    await route.continue_()
                except Exception:
                    pass

        try:
            # Apply once to the shared context
            await self._browser_context.route("**/*", handler)
        except Exception:
            pass

    async def _ensure_browser_pool(self, timeout: int = 120) -> None:
        """Ensure Playwright browser + context are initialized (thread-safe)."""
        async with self._browser_lock:
            if self._browser is not None and self._browser_context is not None and self._playwright_instance is not None:
                return
            try:
                from playwright.async_api import async_playwright
                print("[ScraperService] Initializing Playwright browser pool...")
                self._playwright_instance = await async_playwright().start()
                self._browser = await self._playwright_instance.chromium.launch(
                    headless=True,
                    args=[
                        "--no-sandbox",
                        "--disable-setuid-sandbox",
                        "--disable-dev-shm-usage",
                        "--disable-gpu",
                    ],
                )
                self._browser_context = await self._browser.new_context(
                    user_agent=self.USER_AGENT,
                    viewport={"width": 1920, "height": 1080},
                    java_script_enabled=True,
                )
                try:
                    self._browser_context.set_default_timeout(timeout * 1000)
                    self._browser_context.set_default_navigation_timeout(timeout * 1000)
                except Exception:
                    pass
                await self._install_request_blocking()
                print("[ScraperService] Browser pool initialized successfully")
            except Exception as e:
                print(f"[ScraperService] Failed to initialize Playwright browser pool: {e}")
                self._browser_context = None
                self._browser = None
                try:
                    if self._playwright_instance:
                        await self._playwright_instance.stop()
                except Exception:
                    pass
                self._playwright_instance = None

    async def _acquire_browser_pool(self, timeout: int = 120) -> None:
        """Increment pool refcount and ensure pool exists."""
        await self._ensure_browser_pool(timeout=timeout)
        async with self._browser_lock:
            self._browser_refcount += 1

    async def _release_browser_pool(self) -> None:
        """Decrement pool refcount and close pool when no longer used."""
        async with self._browser_lock:
            if self._browser_refcount > 0:
                self._browser_refcount -= 1
            should_close = self._browser_refcount == 0

        if should_close:
            await self._close_browser_pool()

    async def _get_browser_page(self, timeout: int = 120):
        """Get a new Playwright page (tab) from the shared context."""
        await self._ensure_browser_pool(timeout=timeout)
        if not self._browser_context:
            return None
        try:
            return await self._browser_context.new_page()
        except Exception as e:
            print(f"[ScraperService] Failed to create browser page: {e}")
            return None

    async def _close_browser_pool(self):
        """Close the browser pool and cleanup resources (called when refcount hits 0)."""
        async with self._browser_lock:
            try:
                if self._browser_context:
                    await self._browser_context.close()
                    self._browser_context = None
                if self._browser:
                    await self._browser.close()
                    self._browser = None
                if self._playwright_instance:
                    await self._playwright_instance.stop()
                    self._playwright_instance = None
                print("[ScraperService] Browser pool closed")
            except Exception as e:
                print(f"[ScraperService] Error closing browser pool: {e}")
    
    async def smart_fetch(
        self,
        session: aiohttp.ClientSession,
        url: str,
        render_js: bool = False,
        wait_for_selector: Optional[str] = None,
        timeout: Optional[int] = None
    ) -> Optional[str]:
        """Smart page fetcher that chooses the best method."""
        # Use default timeouts if not specified
        if timeout is None:
            timeout = 120 if render_js else 45
        
        if render_js and self._playwright_available:
            return await self.fetch_page_with_playwright(url, timeout=timeout, wait_for_selector=wait_for_selector)
        else:
            return await self.fetch_page(session, url, timeout=timeout)
    
    # ==================== Sitemap ====================
    
    async def fetch_sitemap(self, session: aiohttp.ClientSession, base_url: str) -> List[str]:
        """Fetch and parse sitemap.xml to discover pages."""
        discovered_urls = []
        parsed = urlparse(base_url)
        base_domain = f"{parsed.scheme}://{parsed.netloc}"
        
        sitemap_urls = [
            f"{base_domain}/sitemap.xml",
            f"{base_domain}/sitemap_index.xml",
            f"{base_domain}/sitemap-index.xml",
            f"{base_domain}/wp-sitemap.xml",
            f"{base_domain}/sitemap/sitemap.xml"
        ]
        
        headers = {
            'User-Agent': self.USER_AGENT,
            'Accept': 'application/xml,text/xml,text/plain;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
        }
        
        for sitemap_url in sitemap_urls:
            try:
                xml_content = None
                async with session.get(sitemap_url, headers=headers, timeout=aiohttp.ClientTimeout(total=30)) as response:
                    if response.status == 200:
                        xml_content = await response.text()
                
                if xml_content:
                    soup = BeautifulSoup(xml_content, 'lxml-xml')
                    
                    # Check for sitemap index
                    sitemaps = soup.find_all('sitemap')
                    if sitemaps:
                        for sitemap in sitemaps[:20]:  # Increased from 5 to handle larger sites
                            loc = sitemap.find('loc')
                            if loc:
                                sub_xml = None
                                sub_url = loc.text.strip()
                                async with session.get(sub_url, headers=headers, timeout=aiohttp.ClientTimeout(total=30)) as sub_response:
                                    if sub_response.status == 200:
                                        sub_xml = await sub_response.text()
                                if sub_xml:
                                    sub_soup = BeautifulSoup(sub_xml, 'lxml-xml')
                                    for url_tag in sub_soup.find_all('url'):
                                        loc_tag = url_tag.find('loc')
                                        if loc_tag:
                                            discovered_urls.append(loc_tag.text.strip())
                    
                    # Direct URL entries
                    for url_tag in soup.find_all('url'):
                        loc = url_tag.find('loc')
                        if loc:
                            discovered_urls.append(loc.text.strip())
                    
                    if discovered_urls:
                        print(f"[ScraperService] Discovered {len(discovered_urls)} URLs from sitemap")
                        break
            except Exception as e:
                print(f"[ScraperService] Error parsing sitemap {sitemap_url}: {e}")
        
        return discovered_urls
    
    def get_common_page_patterns(self, base_url: str) -> List[str]:
        """Generate common page URLs that websites typically have (reduced set)."""
        parsed = urlparse(base_url)
        base_domain = f"{parsed.scheme}://{parsed.netloc}"
        
        # Only try the most common pages to avoid excessive 404s
        common_pages = [
            '/about', '/services', '/pricing', '/contact',
            '/blog', '/privacy', '/terms', '/faq'
        ]
        
        return [f"{base_domain}{page}" for page in common_pages]
    
    # ==================== Crawling ====================
    
    async def crawl_website(
        self,
        job_id: str,
        url: str,
        depth: int,
        max_pages: int,
        include_subpages: bool,
        use_sitemap: bool = True,
        render_js: bool = False,
        wait_for_selector: Optional[str] = None,
        page_timeout: Optional[int] = None,
        concurrency: Optional[int] = None,
        delay: Optional[float] = None
    ) -> None:
        """
        Crawl a website asynchronously with optimized concurrent fetching.
        
        For static pages: Uses batch fetching with configurable concurrency (default 5).
        For JS-rendered: Uses browser pool with sequential fetching.
        """
        job = self._jobs.get(job_id)
        if not job:
            return
        
        job.status = ScrapeStatus.IN_PROGRESS
        job.render_js = render_js
        
        # Use default concurrency/delay if not specified
        concurrent_pages = concurrency or self.DEFAULT_CONCURRENCY
        fetch_delay = delay if delay is not None else self.DEFAULT_DELAY
        
        visited = set()  # Track visited URLs
        content_hashes = set()  # Track unique content by hash
        content_signatures = set()  # Enhanced deduplication
        added_canonical_urls = set()  # Canonical URLs already added to pages (one entry per URL)
        to_visit = [(url, 0)]
        pages = []
        
        # Job state for resume capability
        job_state = {
            'visited': visited,
            'content_hashes': content_hashes,
            'content_signatures': content_signatures,
            'to_visit': to_visit,
            'pages': pages
        }
        
        # Track consecutive failures to intelligently stop
        consecutive_failures = 0
        max_consecutive_failures = 15  # Increased for batch processing
        
        normalized_start_url = self._canonicalize_for_crawling(url, spa_aware=render_js)
        visited.add(normalized_start_url)
        
        js_mode = "with JavaScript rendering" if render_js else "static HTML only"
        batch_info = f" (concurrent: {concurrent_pages}, delay: {fetch_delay}s)" if not render_js else ""
        print(f"[ScraperService] Starting crawl of {url} ({js_mode}){batch_info}")
        print(f"[ScraperService] Initial URL normalized to: {normalized_start_url}")
        
        try:
            async with aiohttp.ClientSession() as session:
                # Discover from sitemap
                if use_sitemap:
                    print(f"[ScraperService] Discovering URLs from sitemap...")
                    sitemap_urls = await self.fetch_sitemap(session, url)
                    print(f"[ScraperService] Found {len(sitemap_urls)} URLs in sitemap")
                    sitemap_urls_added = 0
                    for sitemap_url in sitemap_urls[:max_pages]:
                        normalized = self._canonicalize_for_crawling(sitemap_url, spa_aware=render_js)
                        if normalized and normalized not in visited:
                            to_visit.append((sitemap_url, 0))
                            visited.add(normalized)
                            sitemap_urls_added += 1
                        elif normalized in visited:
                            print(f"[ScraperService]   Sitemap URL already in visited (skipped): {sitemap_url} -> {normalized}")
                    if sitemap_urls_added > 0:
                        print(f"[ScraperService] ✓ Added {sitemap_urls_added} URLs from sitemap to queue (total queue size: {len(to_visit)})")
                    else:
                        print(f"[ScraperService] ℹ No new URLs discovered from sitemap (found {len(sitemap_urls)} total, but all were duplicates or invalid)")
                
                # Add common page patterns (only if we haven't found many pages from sitemap)
                if len(to_visit) < 15:
                    common_patterns_added = 0
                    for common_url in self.get_common_page_patterns(url):
                        normalized = self._canonicalize_for_crawling(common_url, spa_aware=render_js)
                        if normalized and normalized not in visited:
                            to_visit.append((common_url, 0))
                            visited.add(normalized)
                            common_patterns_added += 1
                    if common_patterns_added > 0:
                        print(f"[ScraperService] Added {common_patterns_added} common page patterns to queue")
                
                # Log initial queue status
                print(f"[ScraperService] Initial queue: {len(to_visit)} URLs to process (max: {max_pages} pages)")
                if len(to_visit) == 0:
                    print(f"[ScraperService] ⚠ WARNING: No URLs in queue! Sitemap and common patterns didn't discover any pages.")
                    print(f"[ScraperService]   The initial URL may have been blocked or normalized incorrectly.")
                
                # Move hashlib import outside loop
                import hashlib
                
                # Crawl pages - different strategies for static vs JS
                if render_js:
                    # JS mode: DOM-based extraction with Playwright (optionally limited concurrency)
                    js_concurrency = max(1, min((concurrency or 1), 3))
                    await self._acquire_browser_pool(timeout=page_timeout or 120)
                    try:
                        await self._crawl_sequential(
                            session, job, to_visit, visited, content_hashes, content_signatures,
                            added_canonical_urls, pages,
                            max_pages, depth, include_subpages, wait_for_selector,
                            page_timeout, fetch_delay, hashlib,
                            js_concurrency=js_concurrency
                        )
                    finally:
                        await self._release_browser_pool()
                else:
                    # Static mode: Batch concurrent fetching
                    await self._crawl_batch(
                        session, job, to_visit, visited, content_hashes, content_signatures,
                        added_canonical_urls, pages,
                        max_pages, depth, include_subpages, concurrent_pages,
                        fetch_delay, page_timeout, hashlib
                    )
            
            # Complete job
            total_content = ' '.join([p.content for p in pages])
            if len(pages) == 0:
                job.status = ScrapeStatus.FAILED
                job.error = "No pages scraped. Possible causes: robots.txt block, fetch failures, or low-quality content."
            else:
                job.status = ScrapeStatus.COMPLETED
            job.completed_at = datetime.utcnow().isoformat() + 'Z'
            job.pages = pages
            job.total_content_length = len(total_content)
            job.progress = 100
            job.current_url = None
            
            print(f"[ScraperService] Completed crawl: {len(pages)} pages found")
            
        except Exception as e:
            job.status = ScrapeStatus.FAILED
            job.error = str(e)
            job.completed_at = datetime.utcnow().isoformat() + 'Z'
            # Pool is released via crawl_website finally blocks in JS mode
    
    async def _crawl_batch(
        self, session, job, to_visit, visited, content_hashes, content_signatures,
        added_canonical_urls, pages,
        max_pages, depth, include_subpages, concurrent_pages, delay, timeout, hashlib
    ):
        """Batch crawl for static pages - fetches multiple pages in parallel."""
        consecutive_failures = 0
        max_consecutive_failures = 15
        
        while to_visit and len(pages) < max_pages:
            if consecutive_failures >= max_consecutive_failures:
                print(f"[ScraperService] Stopping: {consecutive_failures} consecutive failures")
                break
            
            # Take a batch of URLs
            batch_size = min(concurrent_pages, len(to_visit), max_pages - len(pages))
            batch = [to_visit.pop(0) for _ in range(batch_size)]
            batch_urls = [url for url, _ in batch]
            batch_depths = {url: depth_val for url, depth_val in batch}
            
            job.current_url = f"Batch of {len(batch_urls)} pages"
            job.progress = min((len(pages) / max_pages) * 100, 99)
            
            print(f"[ScraperService] Fetching batch of {len(batch_urls)} pages ({len(pages)}/{max_pages})...")
            print(f"[ScraperService]   URLs in batch: {batch_urls[:5]}{'...' if len(batch_urls) > 5 else ''}")
            print(f"[ScraperService]   Remaining in queue: {len(to_visit)} URLs")
            
            # Fetch all pages in batch concurrently (with robots.txt and rate limiting)
            results = await self.fetch_pages_batch(
                session, batch_urls,
                max_concurrent=concurrent_pages,
                delay=delay,
                timeout=timeout or 45,
                respect_robots=True,
                respect_rate_limit=True
            )
            
            # Process results
            batch_success = 0
            batch_fetch_failures = 0
            batch_validation_failures = 0
            batch_duplicate_failures = 0
            links_discovered = 0
            
            for url, html in results:
                if html:
                    content = self.extract_content(html, url)
                    
                    # IMPORTANT: Extract links BEFORE validation so we can discover pages
                    # even from low-quality or invalid pages
                    if include_subpages:
                        current_depth = batch_depths.get(url, 0)
                        if current_depth < depth:
                            extracted_links = content.get('links', [])
                            print(f"[ScraperService] Extracted {len(extracted_links)} links from {url}")
                            for link in extracted_links:
                                if not link:
                                    continue
                                link_key = self._canonicalize_for_crawling(link, spa_aware=False)
                                if link_key and link_key not in visited:
                                    to_visit.append((link, current_depth + 1))
                                    visited.add(link_key)
                                    links_discovered += 1
                                elif link_key in visited:
                                    print(f"[ScraperService]   Link already visited (skipped): {link}")
                            if links_discovered > 0:
                                print(f"[ScraperService]   Added {links_discovered} new links to queue (total queue size: {len(to_visit)})")
                    
                    # Validate content quality
                    is_valid, reason = self.validate_content_quality(content)
                    if not is_valid:
                        logger.debug(f"Skipping low-quality content from {url}: {reason}")
                        batch_validation_failures += 1
                        print(f"[ScraperService] ⚠ Validation failed for {url}: {reason}")
                        print(f"[ScraperService]   Content stats: {content.get('word_count', 0)} words, {len(content.get('content', ''))} chars, title: '{content.get('title', '')[:50]}'")
                        # Still continue to next page, but don't save this one
                        continue
                    
                    # Enhanced deduplication
                    content_signature = f"{content['title']}:{content['content'][:500]}"
                    content_hash = hashlib.md5(content_signature.encode()).hexdigest()
                    
                    # Also check normalized content signature for near-duplicates
                    normalized_content = re.sub(r'\s+', ' ', content['content'][:500].lower())
                    normalized_hash = hashlib.md5(normalized_content.encode()).hexdigest()
                    
                    if content_hash in content_hashes or normalized_hash in content_signatures:
                        logger.debug(f"Skipping duplicate content from {url}")
                        batch_duplicate_failures += 1
                        continue
                    
                    content_hashes.add(content_hash)
                    content_signatures.add(normalized_hash)
                    
                    # One entry per canonical URL: skip if we already added this page
                    canonical_url = self._canonicalize_for_crawling(url, spa_aware=False)
                    if canonical_url in added_canonical_urls:
                        logger.debug(f"Skipping duplicate URL (already in results): {url}")
                        continue
                    added_canonical_urls.add(canonical_url)
                    
                    page = ScrapedPage(
                        url=url,
                        title=content['title'],
                        description=content['description'],
                        content=content['content'],
                        headings=content['headings'],
                        word_count=content['word_count'],
                        scraped_at=datetime.utcnow().isoformat() + 'Z'
                    )
                    pages.append(page)
                    job.pages_scraped = len(pages)
                    batch_success += 1
                    print(f"[ScraperService] ✓ Scraped: {url} ({content['word_count']} words, title: {content['title'][:50]})")
                else:
                    batch_fetch_failures += 1
                    print(f"[ScraperService] ✗ Failed to fetch: {url} (check robots.txt, rate limits, or network)")
            
            # Report batch results with detailed diagnostics
            if batch_success > 0:
                consecutive_failures = 0
                status_msg = f"✓ Batch: {batch_success} pages scraped"
                if links_discovered > 0:
                    status_msg += f", {links_discovered} links discovered"
                if batch_validation_failures > 0 or batch_duplicate_failures > 0 or batch_fetch_failures > 0:
                    status_msg += f" ({batch_fetch_failures} fetch failures, {batch_validation_failures} validation failures, {batch_duplicate_failures} duplicates)"
                print(f"[ScraperService] {status_msg}")
            else:
                consecutive_failures += 1
                failure_details = []
                if batch_fetch_failures > 0:
                    failure_details.append(f"{batch_fetch_failures} fetch failures")
                if batch_validation_failures > 0:
                    failure_details.append(f"{batch_validation_failures} validation failures")
                if batch_duplicate_failures > 0:
                    failure_details.append(f"{batch_duplicate_failures} duplicates")
                details = ", ".join(failure_details) if failure_details else "no valid content"
                print(f"[ScraperService] ✗ Batch failed (#{consecutive_failures}): {details}")
                if links_discovered > 0:
                    print(f"[ScraperService]   → But discovered {links_discovered} new links to try")
    
    async def _crawl_sequential(
        self, session, job, to_visit, visited, content_hashes, content_signatures,
        added_canonical_urls, pages,
        max_pages, depth, include_subpages, wait_for_selector, timeout, delay, hashlib,
        js_concurrency: int = 1
    ):
        """JS crawl with Playwright DOM extraction (optionally limited concurrency)."""
        consecutive_failures = 0
        max_consecutive_failures = 10
        
        while to_visit and len(pages) < max_pages:
            if consecutive_failures >= max_consecutive_failures:
                print(f"[ScraperService] Stopping: {consecutive_failures} consecutive failures")
                break
            
            batch_size = min(js_concurrency, len(to_visit), max_pages - len(pages))
            batch = [to_visit.pop(0) for _ in range(batch_size)]

            job.current_url = f"JS batch of {len(batch)} pages"
            job.progress = min((len(pages) / max_pages) * 100, 99)

            async def process_one(item: tuple) -> tuple[str, int, Optional[Dict[str, Any]]]:
                current_url, current_depth = item

                # Respect robots + crawl-delay in JS mode as well
                try:
                    robots_rules = await self.check_robots_txt(session, current_url)
                    if not robots_rules.get("allowed", True):
                        return (current_url, current_depth, None)
                    crawl_delay = float(robots_rules.get("crawl_delay", 0.0) or 0.0)
                    if crawl_delay > 0:
                        await asyncio.sleep(crawl_delay)
                except Exception:
                    pass

                try:
                    domain = urlparse(current_url).netloc
                    wait_time = await self._check_rate_limit(domain)
                    if wait_time > 0:
                        await asyncio.sleep(wait_time)
                except Exception:
                    pass

                # Base delay
                await asyncio.sleep(delay)

                # Render + DOM-extract (preferred)
                _, content = await self._render_and_extract_dom(
                    url=current_url,
                    timeout=timeout or 120,
                    wait_for_selector=wait_for_selector,
                    wait_for_stability=True,
                    return_html=False
                )

                if content:
                    return (current_url, current_depth, content)

                # Fallback to static HTML if Playwright fails
                html = await self.fetch_page(session, current_url, timeout=timeout or 45)
                if not html:
                    return (current_url, current_depth, None)
                return (current_url, current_depth, self.extract_content(html, current_url, spa_aware=True))

            results = await asyncio.gather(*[process_one(item) for item in batch], return_exceptions=True)

            batch_success = 0
            for idx, result in enumerate(results):
                if isinstance(result, Exception):
                    consecutive_failures += 1
                    continue

                current_url, current_depth, content = result
                if not content:
                    consecutive_failures += 1
                    print(f"[ScraperService] ✗ Failed to fetch {current_url} - failure #{consecutive_failures} (check robots.txt, rate limits, or network)")
                    continue

                # IMPORTANT: Extract links BEFORE validation so we can discover pages
                links_discovered = 0
                if include_subpages and current_depth < depth:
                    for link in content.get("links", []) or []:
                        if not link:
                            continue
                        link_key = self._canonicalize_for_crawling(link, spa_aware=True)
                        if link_key and link_key not in visited:
                            to_visit.append((link, current_depth + 1))
                            visited.add(link_key)
                            links_discovered += 1

                # Validate content quality
                is_valid, reason = self.validate_content_quality(content)
                if not is_valid:
                    logger.debug(f"Skipping low-quality content from {current_url}: {reason}")
                    consecutive_failures += 1
                    print(f"[ScraperService] ⚠ Validation failed for {current_url}: {reason}")
                    if links_discovered > 0:
                        print(f"[ScraperService]   → But discovered {links_discovered} new links to try")
                    continue

                # Enhanced deduplication
                content_signature = f"{content.get('title','')}:{(content.get('content','') or '')[:500]}"
                content_hash = hashlib.md5(content_signature.encode()).hexdigest()
                normalized_content = re.sub(r'\s+', ' ', (content.get('content','') or '')[:500].lower())
                normalized_hash = hashlib.md5(normalized_content.encode()).hexdigest()

                if content_hash in content_hashes or normalized_hash in content_signatures:
                    logger.debug(f"Skipping duplicate content from {current_url}")
                    print(f"[ScraperService] ⚠ Duplicate content from {current_url}")
                    if links_discovered > 0:
                        print(f"[ScraperService]   → But discovered {links_discovered} new links to try")
                    continue

                content_hashes.add(content_hash)
                content_signatures.add(normalized_hash)

                # One entry per canonical URL: skip if we already added this page (keeps distinct SPA routes as separate entries)
                canonical_url = self._canonicalize_for_crawling(current_url, spa_aware=True)
                if canonical_url in added_canonical_urls:
                    logger.debug(f"Skipping duplicate URL (already in results): {current_url}")
                    if links_discovered > 0:
                        print(f"[ScraperService] ⚠ Skipped duplicate page {current_url} (already scraped), {links_discovered} links discovered")
                    continue
                added_canonical_urls.add(canonical_url)

                page = ScrapedPage(
                    url=current_url,
                    title=content.get("title", "Untitled Page"),
                    description=content.get("description"),
                    content=content.get("content", ""),
                    headings=content.get("headings", []),
                    word_count=content.get("word_count", 0),
                    scraped_at=datetime.utcnow().isoformat() + "Z",
                    metadata=content.get("metadata"),
                )
                pages.append(page)
                job.pages_scraped = len(pages)

                status_msg = f"✓ Scraped: {current_url} ({content.get('word_count', 0)} words, title: {(content.get('title','') or '')[:50]})"
                if links_discovered > 0:
                    status_msg += f", {links_discovered} links discovered"
                print(f"[ScraperService] {status_msg}")
                batch_success += 1

            if batch_success > 0:
                consecutive_failures = 0




# Singleton instance
scraper_service = ScraperService()

import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from typing import List, Optional
from services.circuit_breaker import email_circuit, with_fallback

class EmailService:
    
    SMTP_HOST = os.getenv("SMTP_HOST", "localhost")
    SMTP_PORT = int(os.getenv("SMTP_PORT", "1025")) # Default to Mailhog/Dev
    SMTP_USER = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
    FROM_EMAIL = os.getenv("FROM_EMAIL", "info@ultimaitech.com")

    @staticmethod
    @email_circuit
    @with_fallback(fallback_value=False)
    def send_email(to_email: str, subject: str, body: str, attachment_path: Optional[str] = None):
        """Send email with optional attachment"""
        
        msg = MIMEMultipart()
        msg['From'] = EmailService.FROM_EMAIL
        msg['To'] = to_email
        msg['Subject'] = subject

        msg.attach(MIMEText(body, 'html'))

        if attachment_path:
            try:
                # Resolve partial path if needed
                if attachment_path.startswith("/static/"):
                     # Assuming running from backend root
                     real_path = os.path.join(os.path.dirname(__file__), "..", attachment_path.lstrip("/"))
                else:
                    real_path = attachment_path

                with open(real_path, "rb") as f:
                    part = MIMEApplication(f.read(), Name=os.path.basename(real_path))
                
                part['Content-Disposition'] = f'attachment; filename="{os.path.basename(real_path)}"'
                msg.attach(part)
            except Exception as e:
                print(f"[EmailService] Error attaching file: {e}")

        try:
            # If using standard SMTP
            if EmailService.SMTP_HOST == "localhost":
                 with smtplib.SMTP(EmailService.SMTP_HOST, EmailService.SMTP_PORT) as server:
                    server.send_message(msg)
            else:
                # secure connection
                with smtplib.SMTP_SSL(EmailService.SMTP_HOST, EmailService.SMTP_PORT) as server:
                    server.login(EmailService.SMTP_USER, EmailService.SMTP_PASSWORD)
                    server.send_message(msg)
                    
            print(f"[EmailService] Email sent to {to_email}")
            return True
        except Exception as e:
            print(f"[EmailService] Failed to send email: {e}")
            return False

    def send_invite(self, to_email: str, full_name: str, invite_token: str, invited_by: str) -> bool:
        """
        Send invitation email to new user
        """
        subject = f"You've been invited to VYBR!S by {invited_by}"
        platform_url = os.getenv("PLATFORM_URL", "https://ultimaitech.com/vybris")
        invite_link = f"{platform_url}/accept-invite?token={invite_token}"
        
        body = f"""
        <html>
        <body>
            <h2>Hello {full_name},</h2>
            <p>You have been invited to join the VYBR!S platform by {invited_by}.</p>
            <p>Please click the link below to set up your account:</p>
            <p><a href="{invite_link}">{invite_link}</a></p>
            <p>This link will expire in 36 hours.</p>
            <br>
            <p>Best regards,</p>
            <p>The VYBR!S Team</p>
        </body>
        </html>
        """
        
        # Use simple text/html email for invites (no attachment)
        return self.send_email(to_email, subject, body)

# Add export for compatibility with routers/users.py
email_service = EmailService()

"""
Analytics services - conversation metrics and aggregations.
"""

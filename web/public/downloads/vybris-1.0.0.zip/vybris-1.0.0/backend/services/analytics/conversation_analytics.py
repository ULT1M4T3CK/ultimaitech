"""
Conversation analytics - intent distribution, resolution rate, escalation rate.
Computes on demand from chat_messages, chat_sessions, live_chat_requests.
"""

import json
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta

from services.database import MessageDB, SessionDB
from services.database.base import get_db_connection

logger = logging.getLogger(__name__)

UNKNOWN_INTENTS = {
    "unknown",
    "low_confidence_fallback",
    "no_results_fallback",
    "validation_failed_fallback",
    "llm_failed_fallback",
    "llm_error_fallback",
    "no_valid_rag_results",
}


def _is_unknown_intent(intent: Optional[str]) -> bool:
    if not intent:
        return True
    if intent in UNKNOWN_INTENTS:
        return True
    return str(intent).endswith("_fallback")


def get_intent_distribution(
    chatbot_id: str,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
) -> List[Dict[str, Any]]:
    """
    Aggregate intent counts from assistant messages.
    Returns list of {intent, count, percentage}.
    """
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            params = [chatbot_id]
            where_clauses = ["chatbot_id = %s", "role = 'assistant'", "intent IS NOT NULL"]
            if from_date:
                where_clauses.append("created_at >= %s")
                params.append(from_date)
            if to_date:
                where_clauses.append("created_at <= %s")
                params.append(to_date)

            cursor.execute(
                f"""
                SELECT intent, COUNT(*) as cnt
                FROM chat_messages
                WHERE {" AND ".join(where_clauses)}
                GROUP BY intent
                ORDER BY cnt DESC
                LIMIT 20
                """,
                tuple(params),
            )
            rows = cursor.fetchall()
            total = sum(r.get("cnt", 0) or 0 for r in rows)
            if total == 0:
                return []
            return [
                {
                    "intent": str(r.get("intent") or "unknown"),
                    "count": r.get("cnt", 0),
                    "percentage": round(100.0 * (r.get("cnt", 0) or 0) / total, 1),
                }
                for r in rows
            ]
    except Exception as e:
        logger.warning(f"get_intent_distribution failed: {e}")
        return []


def get_resolution_rate(
    chatbot_id: str,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
) -> float:
    """
    Percentage of sessions where the last assistant message intent is not unknown/fallback.
    """
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            params = [chatbot_id]
            where_clauses = ["chatbot_id = %s", "role = 'assistant'"]
            if from_date:
                where_clauses.append("created_at >= %s")
                params.append(from_date)
            if to_date:
                where_clauses.append("created_at <= %s")
                params.append(to_date)

            # Subquery: last message per session; then count resolved vs total
            cursor.execute(
                f"""
                WITH last_msg AS (
                    SELECT DISTINCT ON (session_id) session_id, intent
                    FROM chat_messages
                    WHERE {" AND ".join(where_clauses)}
                    ORDER BY session_id, created_at DESC
                )
                SELECT
                    COUNT(*) FILTER (WHERE intent IS NOT NULL AND intent != '' 
                        AND intent NOT IN %s 
                        AND intent NOT LIKE %s) as resolved,
                    COUNT(*) as total
                FROM last_msg
                """,
                tuple(params) + (tuple(UNKNOWN_INTENTS), "%%_fallback"),
            )
            row = cursor.fetchone()
            if not row or not row.get("total") or row["total"] == 0:
                return 0.0
            resolved = row.get("resolved") or 0
            return round(100.0 * resolved / row["total"], 1)
    except Exception as e:
        logger.warning(f"get_resolution_rate failed: {e}")
        return 0.0


def get_handoff_rate(
    chatbot_id: str,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
) -> float:
    """
    Percentage of sessions where the last assistant intent starts with live_chat_.
    """
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            params = [chatbot_id]
            where_clauses = ["chatbot_id = %s", "role = 'assistant'"]
            if from_date:
                where_clauses.append("created_at >= %s")
                params.append(from_date)
            if to_date:
                where_clauses.append("created_at <= %s")
                params.append(to_date)

            cursor.execute(
                f"""
                WITH last_msg AS (
                    SELECT DISTINCT ON (session_id) session_id, intent
                    FROM chat_messages
                    WHERE {" AND ".join(where_clauses)}
                    ORDER BY session_id, created_at DESC
                )
                SELECT
                    COUNT(*) FILTER (WHERE intent LIKE 'live_chat_%%') as handoff_sessions,
                    COUNT(*) as total
                FROM last_msg
                """,
                tuple(params),
            )
            row = cursor.fetchone()
            handoff_sessions = (row or {}).get("handoff_sessions", 0) or 0
            total = (row or {}).get("total", 0) or 0
            if total == 0:
                return 0.0
            return round(100.0 * handoff_sessions / total, 1)
    except Exception as e:
        logger.warning(f"get_handoff_rate failed: {e}")
        return 0.0


def get_escalation_rate(
    chatbot_id: str,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
) -> float:
    """
    Percentage of sessions that requested live chat (have an entry in live_chat_requests).
    """
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()

            # Total sessions in window
            params_total = [chatbot_id]
            where_total = ["chatbot_id = %s"]
            if from_date:
                where_total.append("started_at >= %s")
                params_total.append(from_date)
            if to_date:
                where_total.append("last_activity <= %s")
                params_total.append(to_date)

            cursor.execute(
                f"SELECT COUNT(*) as cnt FROM chat_sessions WHERE {" AND ".join(where_total)}",
                tuple(params_total),
            )
            total_row = cursor.fetchone()
            total = (total_row or {}).get("cnt", 0) or 0
            if total == 0:
                return 0.0

            # Sessions with live chat request
            params_esc = [chatbot_id]
            where_esc = ["chatbot_id = %s"]
            if from_date:
                where_esc.append("created_at >= %s")
                params_esc.append(from_date)
            if to_date:
                where_esc.append("created_at <= %s")
                params_esc.append(to_date)

            cursor.execute(
                f"""
                SELECT COUNT(DISTINCT session_id) as cnt
                FROM live_chat_requests
                WHERE {" AND ".join(where_esc)}
                """,
                tuple(params_esc),
            )
            esc_row = cursor.fetchone()
            escalated = (esc_row or {}).get("cnt", 0) or 0
            return round(100.0 * escalated / total, 1)
    except Exception as e:
        logger.warning(f"get_escalation_rate failed: {e}")
        return 0.0


def get_attribution(
    chatbot_id: str,
    session_id: str,
) -> List[Dict[str, Any]]:
    """
    Return attribution for each response in a session: chunk_ids, action_ids, llm_model.
    Data comes from chat_messages metadata when available.
    """
    try:
        from services.database import MessageDB

        messages = MessageDB.get_by_session(session_id, limit=500)
        result = []
        for msg in messages:
            if msg.get("role") != "assistant":
                continue
            meta = msg.get("metadata") or {}
            result.append({
                "message_id": msg.get("id"),
                "intent": msg.get("intent"),
                "chunk_ids": meta.get("chunk_ids") or [],
                "action_ids": meta.get("action_ids") or [],
                "llm_model": meta.get("llm_model"),
                "created_at": msg.get("created_at").isoformat() if msg.get("created_at") else None,
            })
        return result
    except Exception as e:
        logger.warning(f"get_attribution failed: {e}")
        return []


def get_recent_events(
    chatbot_id: Optional[str] = None,
    limit: int = 50,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
) -> List[Dict[str, Any]]:
    """
    Get recent conversation events from chat_messages for real-time dashboard.
    Returns assistant messages with intent, confidence, timestamps.
    """
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            where_clauses = ["role = 'assistant'"]
            params: list = []
            if chatbot_id:
                where_clauses.append("chatbot_id = %s")
                params.append(chatbot_id)
            if from_date:
                where_clauses.append("created_at >= %s")
                params.append(from_date)
            if to_date:
                where_clauses.append("created_at <= %s")
                params.append(to_date)
            params.append(limit)

            cursor.execute(
                f"""
                SELECT id, chatbot_id, session_id, content, intent, confidence, created_at, metadata
                FROM chat_messages
                WHERE {" AND ".join(where_clauses)}
                ORDER BY created_at DESC
                LIMIT %s
                """,
                tuple(params),
            )
            rows = cursor.fetchall()
            return [
                {
                    "id": r.get("id"),
                    "chatbot_id": r.get("chatbot_id"),
                    "session_id": r.get("session_id"),
                    "intent": r.get("intent"),
                    "confidence": r.get("confidence"),
                    "content_preview": (r.get("content") or "")[:100],
                    "response_time_ms": (r.get("metadata") or {}).get("response_time"),
                    "created_at": r.get("created_at").isoformat() if r.get("created_at") else None,
                }
                for r in rows
            ]
    except Exception as e:
        logger.warning(f"get_recent_events failed: {e}")
        return []


def get_conversation_audit(
    chatbot_id: Optional[str] = None,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """Get conversation audit log for compliance."""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            where_clauses = ["1=1"]
            params: list = []
            if chatbot_id:
                where_clauses.append("chatbot_id = %s")
                params.append(chatbot_id)
            if from_date:
                where_clauses.append("created_at >= %s")
                params.append(from_date)
            if to_date:
                where_clauses.append("created_at <= %s")
                params.append(to_date)
            params.append(limit)

            cursor.execute(
                f"""
                SELECT id, chatbot_id, session_id, event_type, payload_json, created_at
                FROM conversation_audit
                WHERE {" AND ".join(where_clauses)}
                ORDER BY created_at DESC
                LIMIT %s
                """,
                tuple(params),
            )
            rows = cursor.fetchall()
            return [
                {
                    "id": r.get("id"),
                    "chatbot_id": r.get("chatbot_id"),
                    "session_id": r.get("session_id"),
                    "event_type": r.get("event_type"),
                    "payload": r.get("payload_json") if isinstance(r.get("payload_json"), dict) else (json.loads(r.get("payload_json") or "{}") if isinstance(r.get("payload_json"), str) else {}),
                    "created_at": r.get("created_at").isoformat() if r.get("created_at") else None,
                }
                for r in rows
            ]
    except Exception as e:
        logger.warning(f"get_conversation_audit failed: {e}")
        return []


def prune_audit_retention(retention_days: int = 90) -> int:
    """Delete audit rows older than retention_days. Returns count deleted."""
    try:
        from datetime import timedelta

        cutoff = datetime.utcnow() - timedelta(days=retention_days)
        deleted = 0
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM conversation_audit WHERE created_at < %s", (cutoff,))
            deleted += cursor.rowcount or 0
            cursor.execute("DELETE FROM llm_audit_log WHERE created_at < %s", (cutoff,))
            deleted += cursor.rowcount or 0
        return deleted
    except Exception as e:
        logger.warning(f"prune_audit_retention failed: {e}")
        return 0


def get_session_stats(
    chatbot_id: str,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
) -> Dict[str, Any]:
    """
    Avg messages per session, new vs returning (approximation).
    """
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            params = [chatbot_id]
            where = ["chatbot_id = %s"]
            if from_date:
                where.append("started_at >= %s")
                params.append(from_date)
            if to_date:
                where.append("last_activity <= %s")
                params.append(to_date)

            cursor.execute(
                f"""
                SELECT
                    COUNT(*) as session_count,
                    COALESCE(AVG(message_count), 0) as avg_messages
                FROM chat_sessions
                WHERE {" AND ".join(where)}
                """,
                tuple(params),
            )
            row = cursor.fetchone()
            return {
                "avg_session_length": round(float((row or {}).get("avg_messages", 0) or 0), 1),
                "session_count": (row or {}).get("session_count", 0) or 0,
            }
    except Exception as e:
        logger.warning(f"get_session_stats failed: {e}")
        return {"avg_session_length": 0.0, "session_count": 0}


def get_conversation_analytics(
    chatbot_id: str,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
) -> Dict[str, Any]:
    """
    Combined conversation analytics for a chatbot.
    """
    if not to_date:
        to_date = datetime.utcnow()
    if not from_date:
        from_date = to_date - timedelta(days=30)

    intent_dist = get_intent_distribution(chatbot_id, from_date, to_date)
    resolution = get_resolution_rate(chatbot_id, from_date, to_date)
    escalation = get_escalation_rate(chatbot_id, from_date, to_date)
    session_stats = get_session_stats(chatbot_id, from_date, to_date)

    return {
        "intent_distribution": intent_dist,
        "resolution_rate": resolution,
        "escalation_rate": escalation,
        "avg_session_length": session_stats.get("avg_session_length", 0),
        "session_count": session_stats.get("session_count", 0),
        "top_intents": [d["intent"] for d in intent_dist[:5]],
        "from_date": from_date.isoformat() if from_date else None,
        "to_date": to_date.isoformat() if to_date else None,
    }

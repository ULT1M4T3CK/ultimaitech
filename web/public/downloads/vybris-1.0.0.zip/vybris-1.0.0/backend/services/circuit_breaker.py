"""
Circuit Breaker Pattern Implementation
Provides circuit breakers for external service calls to prevent cascading failures.
"""

import logging
import time
from typing import Callable, Any, Optional
from functools import wraps
from enum import Enum
from circuitbreaker import circuit

logger = logging.getLogger(__name__)


class CircuitState(Enum):
    """Circuit breaker states."""
    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing if service recovered


# Circuit breaker configurations per service
CIRCUIT_CONFIGS = {
    "perplexity": {
        "failure_threshold": 5,  # Open after 5 failures
        "recovery_timeout": 60,  # Wait 60s before trying again
        "expected_exception": Exception
    },
    "email": {
        "failure_threshold": 3,  # Open after 3 failures
        "recovery_timeout": 30,  # Wait 30s before trying again
        "expected_exception": Exception
    },
    "qdrant": {
        "failure_threshold": 5,  # Open after 5 failures
        "recovery_timeout": 60,  # Wait 60s before trying again
        "expected_exception": Exception
    }
}


def get_circuit_breaker(service_name: str):
    """
    Get a circuit breaker decorator for a specific service.
    
    Args:
        service_name: Name of the service (perplexity, email, qdrant)
    
    Returns:
        Circuit breaker decorator
    """
    config = CIRCUIT_CONFIGS.get(service_name, CIRCUIT_CONFIGS["perplexity"])
    
    return circuit(
        failure_threshold=config["failure_threshold"],
        recovery_timeout=config["recovery_timeout"],
        expected_exception=config["expected_exception"],
        name=service_name
    )


# Pre-configured circuit breakers for common services
perplexity_circuit = get_circuit_breaker("perplexity")
email_circuit = get_circuit_breaker("email")
qdrant_circuit = get_circuit_breaker("qdrant")


def with_fallback(fallback_value: Any = None, fallback_func: Optional[Callable] = None):
    """
    Decorator to add fallback behavior when circuit breaker is open.
    
    Args:
        fallback_value: Static value to return when circuit is open
        fallback_func: Function to call when circuit is open (receives same args)
    
    Usage:
        @perplexity_circuit
        @with_fallback(fallback_value=None)
        async def call_perplexity():
            ...
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                # Check if circuit breaker is open
                if "circuit breaker is OPEN" in str(e) or "CircuitBreakerError" in type(e).__name__:
                    logger.warning(f"Circuit breaker open for {func.__name__}, using fallback")
                    if fallback_func:
                        return await fallback_func(*args, **kwargs)
                    return fallback_value
                raise
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                # Check if circuit breaker is open
                if "circuit breaker is OPEN" in str(e) or "CircuitBreakerError" in type(e).__name__:
                    logger.warning(f"Circuit breaker open for {func.__name__}, using fallback")
                    if fallback_func:
                        return fallback_func(*args, **kwargs)
                    return fallback_value
                raise
        
        import asyncio
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator

"""
Vision Service - image description for multimodal chat (Phase 4.1)
Uses OpenAI Vision API when OPENAI_API_KEY is set.
"""

import base64
import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)


def describe_image(image_base64: str, mime_type: Optional[str] = None) -> Optional[str]:
    """
    Get a text description of an image using OpenAI Vision (or similar).
    Returns None if vision is not configured or fails.
    """
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        logger.debug("OPENAI_API_KEY not set, skipping vision")
        return None

    mime_type = mime_type or "image/png"
    data_url = f"data:{mime_type};base64,{image_base64}"

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": "Describe this image briefly in 1-2 sentences for a chatbot context.",
                        },
                        {
                            "type": "image_url",
                            "image_url": {"url": data_url},
                        },
                    ],
                }
            ],
            max_tokens=150,
        )
        text = response.choices[0].message.content
        return text.strip() if text else None
    except ImportError:
        logger.warning("openai package not installed, cannot use vision")
        return None
    except Exception as e:
        logger.warning("Vision API error: %s", e)
        return None

"""
Elias AI proxy client.
- When ELIAS_GATEWAY_TOKEN is set: call gateway /v1/chat/completions for a synchronous reply in the chat.
- Otherwise: POST to Elias hook (async 202); reply may appear in webchat/voice panel.
"""

import json
import logging
import os
from typing import Optional, Tuple

import httpx

logger = logging.getLogger(__name__)

ELIAS_HOOK_TOKEN = os.getenv("ELIAS_HOOK_TOKEN", "")
ELIAS_GATEWAY_TOKEN = os.getenv("ELIAS_GATEWAY_TOKEN", "").strip()  # For sync /v1/chat/completions
ELIAS_TIMEOUT = float(os.getenv("ELIAS_TIMEOUT", "25.0"))
# Sync can take 60–90s for the agent to reply; use longer timeout so we get the actual response
ELIAS_SYNC_TIMEOUT = float(os.getenv("ELIAS_SYNC_TIMEOUT", "90.0"))


async def _try_elias_sync_completion(
    base: str, message: str, chatbot_id: str, tenant_id: Optional[str]
) -> Tuple[bool, Optional[str]]:
    """Call OpenClaw gateway POST /v1/chat/completions for a synchronous reply. Uses ELIAS_GATEWAY_TOKEN."""
    if not ELIAS_GATEWAY_TOKEN:
        return False, None
    url = f"{base}/v1/chat/completions"
    payload = {
        "model": "openclaw",
        "stream": False,
        "messages": [{"role": "user", "content": message}],
    }
    headers = {
        "Authorization": f"Bearer {ELIAS_GATEWAY_TOKEN}",
        "Content-Type": "application/json",
    }
    try:
        async with httpx.AsyncClient(timeout=ELIAS_SYNC_TIMEOUT) as client:
            response = await client.post(url, json=payload, headers=headers)
    except (httpx.ConnectError, httpx.TimeoutException) as e:
        logger.warning("Elias sync completion unreachable or timeout: %s (chatbot_id=%s)", e, chatbot_id)
        return False, None
    except Exception as e:
        logger.warning("Elias sync completion failed: %s (chatbot_id=%s)", e, chatbot_id)
        return False, None
    if response.status_code != 200:
        logger.warning("Elias sync completion non-200: status=%s chatbot_id=%s", response.status_code, chatbot_id)
        return False, None
    try:
        data = response.json()
    except Exception:
        return False, None
    choices = data.get("choices")
    if not isinstance(choices, list) or len(choices) == 0:
        return False, None
    msg = choices[0]
    if not isinstance(msg, dict):
        return False, None
    content = msg.get("message", {}) if isinstance(msg.get("message"), dict) else {}
    text = content.get("content") if isinstance(content, dict) else None
    if isinstance(text, str) and text.strip():
        logger.info("Elias sync reply used for chatbot_id=%s tenant_id=%s", chatbot_id, tenant_id)
        return True, text.strip()
    return False, None


async def try_elias_reply(
    *,
    message: str,
    chatbot_id: str,
    tenant_id: Optional[str],
    session_id: Optional[str],
    elias_url: str,
    elias_bot_name: str = "Elias",
) -> Tuple[bool, Optional[str]]:
    """
    Try sync /v1/chat/completions first (actual reply in chat); if that fails, fall back to hook (202).
    Returns (success, response_text).
    """
    base = (elias_url or "").strip().rstrip("/")
    if not base or not base.startswith(("http://", "https://")):
        return False, None

    # Prefer sync so the user gets the actual reply in the chat (longer timeout for agent to respond)
    success, reply = await _try_elias_sync_completion(base, message, chatbot_id, tenant_id)
    if success and reply:
        return True, reply

    # Fallback: hook (202) so at least "reply will appear shortly" when gateway is up
    if ELIAS_HOOK_TOKEN:
        hook_success, hook_reply = await _try_elias_hook(base, message, chatbot_id, tenant_id, session_id, elias_bot_name)
        if hook_success and hook_reply:
            return True, hook_reply

    return False, None


async def _try_elias_hook(
    base: str,
    message: str,
    chatbot_id: str,
    tenant_id: Optional[str],
    session_id: Optional[str],
    elias_bot_name: str,
) -> Tuple[bool, Optional[str]]:
    """POST to hooks/elias/agent; returns (True, reply_text) on 202 or 200 with body."""
    url = f"{base}/hooks/elias/agent"
    payload_dict = {
        "message": message,
        "name": elias_bot_name,
        "sessionKey": f"vybris:{tenant_id or 'unknown'}:{chatbot_id}:{session_id or 'unknown'}",
        "wakeMode": "now",
        "deliver": True,
        "channel": "last",
    }
    payload_json = json.dumps(payload_dict)
    headers = {
        "Authorization": f"Bearer {ELIAS_HOOK_TOKEN}",
        "Content-Type": "application/json",
    }
    try:
        async with httpx.AsyncClient(timeout=ELIAS_TIMEOUT) as client:
            response = await client.post(url, data=payload_json, headers=headers)
    except httpx.ConnectError as e:
        logger.warning(
            "Elias gateway unreachable (check ELIAS_GATEWAY_URL): %s (chatbot_id=%s)",
            e, chatbot_id,
        )
        return False, None
    except httpx.TimeoutException as e:
        logger.warning("Elias gateway timeout: %s (chatbot_id=%s)", e, chatbot_id)
        return False, None
    except Exception as e:
        logger.warning("Elias proxy request failed: %s (chatbot_id=%s, tenant_id=%s)", e, chatbot_id, tenant_id)
        return False, None

    if response.status_code == 202:
        logger.info("Elias accepted (202) chatbot_id=%s tenant_id=%s", chatbot_id, tenant_id)
        return True, (
            "Message received. Elias is replying—his answer will appear in the conversation or voice panel shortly."
        )

    if response.status_code != 200:
        logger.warning("Elias proxy non-200: status=%s chatbot_id=%s tenant_id=%s", response.status_code, chatbot_id, tenant_id)
        return False, None

    try:
        data = response.json()
    except Exception:
        return False, None

    text = data.get("response") or data.get("reply") or data.get("text")
    if isinstance(text, str) and text.strip():
        logger.info("Elias reply used for chatbot_id=%s tenant_id=%s", chatbot_id, tenant_id)
        return True, text.strip()
    return False, None

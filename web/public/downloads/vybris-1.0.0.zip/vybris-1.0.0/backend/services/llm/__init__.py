"""
LLM Abstraction Layer for VYBR!S
Provider-agnostic interface for LLM integrations.
Supports Perplexity, OpenAI, and future providers.
"""

from services.llm.registry import llm_service

__all__ = ["llm_service"]

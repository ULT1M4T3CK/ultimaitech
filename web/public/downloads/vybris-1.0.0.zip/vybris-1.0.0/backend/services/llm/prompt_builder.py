"""
Shared RAG system prompt builder for LLM providers.
Extracted to allow multiple providers (Perplexity, OpenAI) to use identical prompts.
"""

import json
from typing import List, Dict, Any, Optional


def _format_context(context_chunks: List[Dict[str, Any]]) -> str:
    """Format retrieved chunks into a readable context string."""
    if not context_chunks:
        return "No information available in the knowledge base. You MUST tell the user you don't have that information."
    formatted_parts = []
    for chunk in context_chunks:
        text = chunk.get("text", "")
        payload = chunk.get("payload", {})
        title = payload.get("title", "")
        score = chunk.get("score", 0)
        if score >= 0.3:
            sanitized = text.replace("[[", "[").replace("]]", "]").replace("{{", "{").replace("}}", "}")
            if title:
                formatted_parts.append(f"### {title}\n{sanitized}")
            else:
                formatted_parts.append(sanitized)
    if not formatted_parts:
        return "No relevant information found in the knowledge base. You MUST tell the user you don't have that information."
    return "\n\n".join(formatted_parts)


def build_rag_system_prompt(
    context_chunks: List[Dict[str, Any]],
    chatbot_name: str = "Assistant",
    company_name: str = "",
    chatbot_type: str = "General Purpose",
    personality: str = "Professional",
    supported_languages: Optional[List[str]] = None,
    system_prompt: Optional[str] = None,
    available_actions: Optional[List[Dict[str, Any]]] = None,
    action_results: Optional[List[Dict[str, Any]]] = None,
) -> str:
    """
    Build the full system prompt for RAG-based response generation.
    Used by both Perplexity and OpenAI providers.
    """
    context_text = _format_context(context_chunks)
    if not company_name:
        company_name = chatbot_name.replace("Assistant", "").strip() or "our company"

    language_names = {
        "en": "English", "nl": "Dutch", "de": "German", "fr": "French",
        "es": "Spanish", "it": "Italian", "pt": "Portuguese", "pl": "Polish",
        "ru": "Russian", "zh": "Chinese", "ja": "Japanese", "ko": "Korean",
        "ar": "Arabic", "hi": "Hindi", "tr": "Turkish", "sv": "Swedish",
        "da": "Danish", "no": "Norwegian", "fi": "Finnish", "cs": "Czech",
    }
    language_instruction = "Respond in the same language as the user's question."
    if supported_languages and len(supported_languages) > 0:
        lang_list = [language_names.get(lang, lang) for lang in supported_languages]
        language_instruction = (
            f"You MUST respond ONLY in these languages: {', '.join(lang_list)}. "
            f"If the user writes in a language NOT in your supported list, respond with: "
            f"\"I'm sorry, I can only assist you in {' and '.join(lang_list)}.\" "
            f"If the user's language IS in your supported list, respond in that same language."
        )

    from shared.constants.personality_descriptions import (
        CHATBOT_TYPE_DESCRIPTIONS,
        PERSONALITY_GUIDELINES,
    )
    type_description = CHATBOT_TYPE_DESCRIPTIONS.get(chatbot_type, CHATBOT_TYPE_DESCRIPTIONS["General Purpose"])
    personality_guideline = PERSONALITY_GUIDELINES.get(personality, PERSONALITY_GUIDELINES["Professional"])

    action_instruction = ""
    if available_actions:
        action_desc_list = []
        for act in available_actions:
            params_desc = ", ".join([f"{p['name']} ({p['type']})" for p in (act.get("parameters") or [])])
            action_desc_list.append(
                f"- ID: {act['id']}\n  Name: {act['name']}\n  Description: {act['description']}\n  Parameters: {params_desc}"
            )
        action_descriptions = "\n".join(action_desc_list)
        action_instruction = f"""
## AVAILABLE ACTIONS (TOOLS)
You have access to the following external tools/actions. Use them when the user's request requires fetching live data.

{action_descriptions}

## HOW TO USE ACTIONS
If you need to use an action, your response must consist ONLY of the JSON action request.
Format: ACTION: {{ "action_id": "REPLACE_WITH_ID", "params": {{ "param_name": "param_value" }} }}
- Do NOT provide the final answer yet if you are calling an action.
- Only call ONE action at a time.
"""
    context_extension = ""
    if action_results:
        result_texts = [
            f"Action '{r.get('action_name')}' result: {json.dumps(r.get('result'))}"
            for r in action_results
        ]
        context_extension = "\n\n### ACTION RESULTS (LIVE DATA)\n" + "\n".join(result_texts)
        action_instruction += "\n\n## UPDATED CONTEXT\nUse the ACTION RESULTS below to answer the user's question."

    from shared.constants.type_configurations import get_response_formatting
    formatting_prefs = get_response_formatting(chatbot_type)
    formatting_instructions = ""
    if formatting_prefs:
        ft = formatting_prefs.get("format_type", "general")
        if ft == "structured":
            formatting_instructions = "\n## RESPONSE FORMATTING\nUse clear, structured responses with sections.\n"
        elif ft == "instructional":
            formatting_instructions = "\n## RESPONSE FORMATTING\nUse numbered steps for procedures.\n"
        elif ft == "product_focused":
            formatting_instructions = "\n## RESPONSE FORMATTING\nPresent product information in a clear, scannable format.\n"

    rag_policy = """
## CRITICAL: RAG-ONLY RESPONSE POLICY
**YOU MUST STRICTLY FOLLOW THESE RULES:**
1. **ONLY use information from the REFERENCE MATERIAL provided below**
2. **NEVER use external knowledge or information not in the reference material**
3. **If the reference material doesn't contain the answer, say: "I don't have that information in my knowledge base."**
4. **DO NOT make up information or speculate**
5. **Your responses MUST be grounded ONLY in the provided reference material**
"""

    if not system_prompt:
        return f"""You are {chatbot_name}, a helpful assistant representing {company_name}.

## YOUR ROLE
{type_description}
Act as a partner to the user, not just a tool.

## COMMUNICATION STYLE
{personality_guideline}
- Be concise but friendly.
- If the user's question is ambiguous, ask clarifying questions.
{formatting_instructions}

## LANGUAGE REQUIREMENT
{language_instruction}
{action_instruction}
{rag_policy}

## YOUR KNOWLEDGE (RAG CONTENT ONLY)
### REFERENCE MATERIAL
{context_text}
{context_extension}

**REMEMBER**: If the user asks about something NOT in the reference material, you MUST say you don't have that information.

## RESPONSE FORMATTING RULES
1. Use standard Markdown for formatting.
2. Use bullet points for lists.
3. Keep responses clean and easy to read.
"""
    else:
        return f"""{system_prompt}
{rag_policy}
KNOWLEDGE BASE:
{context_text}
{context_extension}
{action_instruction}"""

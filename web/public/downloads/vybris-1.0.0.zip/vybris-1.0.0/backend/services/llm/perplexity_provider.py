"""
Perplexity LLM Provider
Wraps the existing PerplexityService as an LLM provider.
"""

from typing import Optional, List, Dict, Any

from services.llm.base import BaseLLMProvider
from services.perplexity_service import PerplexityService


class PerplexityProvider(BaseLLMProvider):
    """Perplexity API as LLM provider."""

    def __init__(self):
        self._service = PerplexityService()

    async def generate_response(
        self,
        user_query: str,
        context_chunks: List[Dict[str, Any]],
        chatbot_name: str = "Assistant",
        company_name: str = "",
        chatbot_type: str = "General Purpose",
        personality: str = "Professional",
        supported_languages: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
        max_tokens: int = 512,
        temperature: float = 0.3,
        available_actions: Optional[List[Dict[str, Any]]] = None,
        action_results: Optional[List[Dict[str, Any]]] = None,
        history: Optional[List[Dict[str, str]]] = None,
    ) -> Optional[str]:
        return await self._service.generate_response(
            user_query=user_query,
            context_chunks=context_chunks,
            chatbot_name=chatbot_name,
            company_name=company_name,
            chatbot_type=chatbot_type,
            personality=personality,
            supported_languages=supported_languages,
            system_prompt=system_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            available_actions=available_actions,
            action_results=action_results,
            history=history,
        )

    async def generate_simple_reply(
        self,
        user_message: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 1024,
    ) -> Optional[str]:
        return await self._service.generate_simple_reply(
            user_message=user_message,
            system_prompt=system_prompt,
            max_tokens=max_tokens,
        )

    def is_enabled(self) -> bool:
        return self._service.is_enabled()

    def get_provider_name(self) -> str:
        return "perplexity"

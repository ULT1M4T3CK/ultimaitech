"""
LLM Provider Abstract Base
Defines the interface all LLM providers must implement.
"""

from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any


class BaseLLMProvider(ABC):
    """Abstract base class for LLM providers."""

    @abstractmethod
    async def generate_response(
        self,
        user_query: str,
        context_chunks: List[Dict[str, Any]],
        chatbot_name: str = "Assistant",
        company_name: str = "",
        chatbot_type: str = "General Purpose",
        personality: str = "Professional",
        supported_languages: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
        max_tokens: int = 512,
        temperature: float = 0.3,
        available_actions: Optional[List[Dict[str, Any]]] = None,
        action_results: Optional[List[Dict[str, Any]]] = None,
        history: Optional[List[Dict[str, str]]] = None,
    ) -> Optional[str]:
        """
        Generate a response using RAG context and optional conversation history.
        Returns None if generation fails or provider is disabled.
        """
        pass

    @abstractmethod
    async def generate_simple_reply(
        self,
        user_message: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 1024,
    ) -> Optional[str]:
        """
        Single-turn reply with no RAG context.
        Used e.g. for Elias tab fallback.
        """
        pass

    @abstractmethod
    def is_enabled(self) -> bool:
        """Check if this provider is configured and available."""
        pass

    def get_provider_name(self) -> str:
        """Return the provider identifier for logging and health checks."""
        return "base"

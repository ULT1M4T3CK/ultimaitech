"""
OpenAI LLM Provider
Uses OpenAI Chat Completions API for RAG-based response generation.
"""

import os
import logging
from typing import Optional, List, Dict, Any

from services.llm.base import BaseLLMProvider
from services.llm.prompt_builder import build_rag_system_prompt

logger = logging.getLogger(__name__)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL")  # Optional: for Azure or proxy


class OpenAIProvider(BaseLLMProvider):
    """OpenAI API as LLM provider."""

    def __init__(self):
        self._client = None
        self._enabled = bool(OPENAI_API_KEY)
        if self._enabled:
            try:
                from openai import AsyncOpenAI
                kwargs = {"api_key": OPENAI_API_KEY}
                if OPENAI_BASE_URL:
                    kwargs["base_url"] = OPENAI_BASE_URL
                self._client = AsyncOpenAI(**kwargs)
                logger.info(f"OpenAI provider initialized with model {OPENAI_MODEL}")
            except ImportError:
                logger.warning("openai package not installed. Run: pip install openai")
                self._enabled = False
            except Exception as e:
                logger.warning(f"OpenAI provider init failed: {e}")
                self._enabled = False

    async def generate_response(
        self,
        user_query: str,
        context_chunks: List[Dict[str, Any]],
        chatbot_name: str = "Assistant",
        company_name: str = "",
        chatbot_type: str = "General Purpose",
        personality: str = "Professional",
        supported_languages: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
        max_tokens: int = 512,
        temperature: float = 0.3,
        available_actions: Optional[List[Dict[str, Any]]] = None,
        action_results: Optional[List[Dict[str, Any]]] = None,
        history: Optional[List[Dict[str, str]]] = None,
    ) -> Optional[str]:
        if not self._enabled or not self._client:
            return None
        if not user_query or not isinstance(user_query, str):
            return "I didn't receive a valid question."
        if not context_chunks:
            logger.warning("OpenAI called with empty context - RAG-only mode requires context")
            return None

        try:
            system_content = build_rag_system_prompt(
                context_chunks=context_chunks,
                chatbot_name=chatbot_name,
                company_name=company_name,
                chatbot_type=chatbot_type,
                personality=personality,
                supported_languages=supported_languages,
                system_prompt=system_prompt,
                available_actions=available_actions,
                action_results=action_results,
            )
            messages = [{"role": "system", "content": system_content}]
            if history:
                valid = [
                    {"role": m.get("role"), "content": m.get("content")}
                    for m in history
                    if m.get("role") in ("user", "assistant") and m.get("content")
                ]
                messages.extend(valid)
            messages.append({"role": "user", "content": user_query})

            response = await self._client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=messages,
                max_tokens=max_tokens,
                temperature=0.1,
            )
            if response.choices and len(response.choices) > 0:
                return response.choices[0].message.content
            return None
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            return None

    async def generate_simple_reply(
        self,
        user_message: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 1024,
    ) -> Optional[str]:
        if not self._enabled or not self._client:
            return None
        if not user_message or not isinstance(user_message, str):
            return None
        system = (system_prompt or "You are Elias, a helpful assistant for VYBR!S. Answer concisely.").strip()
        try:
            response = await self._client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user_message.strip()[:8000]},
                ],
                max_tokens=max_tokens,
                temperature=0.2,
            )
            if response.choices and len(response.choices) > 0:
                return response.choices[0].message.content
        except Exception as e:
            logger.warning(f"OpenAI simple reply failed: {e}")
        return None

    def is_enabled(self) -> bool:
        return self._enabled

    def get_provider_name(self) -> str:
        return "openai"

"""
LLM Provider Registry
Selects and exposes the active LLM provider based on configuration.
"""

import os
import logging
from typing import Optional

from services.llm.base import BaseLLMProvider
from services.llm.perplexity_provider import PerplexityProvider
from services.llm.openai_provider import OpenAIProvider

logger = logging.getLogger(__name__)

LLM_PROVIDER = os.getenv("LLM_PROVIDER", "perplexity").lower()


def _create_provider() -> Optional[BaseLLMProvider]:
    """Create the configured LLM provider instance."""
    if LLM_PROVIDER == "openai":
        provider = OpenAIProvider()
        if provider.is_enabled():
            return provider
        logger.warning("OPENAI_API_KEY not set or OpenAI provider failed. Falling back to Perplexity.")
    provider = PerplexityProvider()
    if provider.is_enabled():
        return provider
    logger.warning("No LLM provider configured. Set PERPLEXITY_API_KEY or OPENAI_API_KEY.")
    return provider


def get_active_provider_name() -> str:
    """Return the name of the currently configured provider."""
    return LLM_PROVIDER


class LLMService:
    """
    Facade for the active LLM provider.
    Routes all calls to the configured provider (Perplexity or OpenAI).
    """

    def __init__(self):
        self._provider = _create_provider()

    @property
    def provider(self) -> Optional[BaseLLMProvider]:
        return self._provider

    async def generate_response(
        self,
        user_query: str,
        context_chunks,
        chatbot_name: str = "Assistant",
        company_name: str = "",
        chatbot_type: str = "General Purpose",
        personality: str = "Professional",
        supported_languages=None,
        system_prompt=None,
        max_tokens: int = 512,
        temperature: float = 0.3,
        available_actions=None,
        action_results=None,
        history=None,
    ):
        if not self._provider:
            return None
        return await self._provider.generate_response(
            user_query=user_query,
            context_chunks=context_chunks,
            chatbot_name=chatbot_name,
            company_name=company_name,
            chatbot_type=chatbot_type,
            personality=personality,
            supported_languages=supported_languages,
            system_prompt=system_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            available_actions=available_actions,
            action_results=action_results,
            history=history,
        )

    async def generate_simple_reply(
        self,
        user_message: str,
        system_prompt=None,
        max_tokens: int = 1024,
    ):
        if not self._provider:
            return None
        return await self._provider.generate_simple_reply(
            user_message=user_message,
            system_prompt=system_prompt,
            max_tokens=max_tokens,
        )

    def is_enabled(self) -> bool:
        return self._provider is not None and self._provider.is_enabled()

    def get_provider_name(self) -> str:
        if self._provider:
            return self._provider.get_provider_name()
        return "none"


llm_service = LLMService()

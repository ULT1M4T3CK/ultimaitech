"""
Action Service
Handles the execution of custom actions (API integrations) for chatbots.
Includes verification token validation for sensitive actions.
"""

import logging
import requests
import json
import time
import socket
import ipaddress
from urllib.parse import urlparse
from typing import Dict, Any, Optional, List
from services.database import CustomActionDB, ChatbotDB, VerificationDB

logger = logging.getLogger(__name__)

# Actions that require verification token
VERIFICATION_REQUIRED_ACTIONS = {
    'get_customer_profile',
    'get_order_details',
    'get_rewards_balance',
    'get_invoice',
    'check_payment_status',
    'modify_booking',
    'cancel_booking',
    'request_refund',
}

class ActionExecutionError(Exception):
    """Custom exception for action execution errors"""
    pass


class VerificationRequiredError(Exception):
    """Exception when action requires verification but token is missing/invalid"""
    pass


def validate_action_url(url: str) -> bool:
    """
    Validate URL is safe for action execution (no SSRF).
    Blocks private IPs, localhost, and metadata services.
    """
    try:
        parsed = urlparse(url)
        
        # Only allow http and https schemes
        if parsed.scheme not in ('http', 'https'):
            return False
        
        hostname = parsed.hostname
        if not hostname:
            return False
        
        # Block common localhost variants
        blocked_hostnames = [
            'localhost',
            '127.0.0.1',
            '0.0.0.0',
            '::1',
            '[::1]',
            'metadata.google.internal',
            '169.254.169.254',  # AWS metadata service
        ]
        
        hostname_lower = hostname.lower()
        if any(blocked in hostname_lower for blocked in blocked_hostnames):
            return False
        
        # Resolve hostname and check for private IPs
        try:
            ip = socket.gethostbyname(hostname)
            ip_obj = ipaddress.ip_address(ip)
            
            # Block private, loopback, link-local, and reserved IPs
            if (ip_obj.is_private or 
                ip_obj.is_loopback or 
                ip_obj.is_link_local or 
                ip_obj.is_reserved):
                return False
            
            # Explicitly block AWS metadata service IP
            if ip == '169.254.169.254':
                return False
                
        except (socket.gaierror, ValueError) as e:
            # If we can't resolve it, be cautious
            logger.warning(f"Could not resolve hostname {hostname}: {e}")
            return False
        
        return True
    except Exception as e:
        logger.error(f"Error validating URL {url}: {e}")
        return False


class ActionService:
    def __init__(self):
        pass

    def get_available_actions(self, chatbot_id: str) -> List[Dict[str, Any]]:
        """
        Get list of active actions for a chatbot.
        Formats them for inclusion in LLM system prompt.
        """
        actions = CustomActionDB.get_active_by_chatbot(chatbot_id)
        return actions
    
    def requires_verification(self, action_name: str) -> bool:
        """Check if an action requires verification token"""
        return action_name.lower() in VERIFICATION_REQUIRED_ACTIONS
    
    def validate_verification_token(
        self,
        chatbot_id: str,
        verification_token: Optional[str]
    ) -> Dict[str, Any]:
        """
        Validate a verification token for sensitive actions.
        
        Returns:
            Dict with 'valid' boolean and error message if invalid
        """
        if not verification_token:
            return {
                'valid': False,
                'error': 'Verification token required for this action. Please verify your identity first.'
            }
        
        result = VerificationDB.validate_token(chatbot_id, verification_token)
        return result

    def execute_action(
        self, 
        action_id: str, 
        params: Dict[str, Any],
        chatbot_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Execute a specific custom action with provided parameters.
        
        Args:
            action_id: ID of the action to execute
            params: Dictionary of parameters to substitute into URL/body
            
        Returns:
            Dict containing success status, status_code, and data/error
        """
        action = CustomActionDB.get_by_id(action_id)
        if not action:
            raise ActionExecutionError(f"Action {action_id} not found")
            
        if not action.get('enabled', True):
            raise ActionExecutionError(f"Action {action['name']} is disabled")
        
        # Check if action requires verification
        action_name = action.get('name', '').lower()
        if self.requires_verification(action_name):
            verification_token = params.get('verification_token')
            bot_id = chatbot_id or action.get('chatbot_id')
            
            if not verification_token:
                return {
                    "success": False,
                    "error": "This action requires identity verification. Please verify your identity first by providing your email, then enter the verification code sent to you.",
                    "requires_verification": True,
                    "status_code": 401
                }
            
            validation = self.validate_verification_token(bot_id, verification_token)
            if not validation.get('valid'):
                return {
                    "success": False,
                    "error": validation.get('error', 'Invalid or expired verification token. Please verify your identity again.'),
                    "requires_verification": True,
                    "status_code": 401
                }
            
            logger.info(f"Verified action {action_name} for {validation.get('identifier_masked')}")
        
        method = action['method'].upper()
        url = action.get('url_template') or action.get('url', '')
        headers = action.get('headers', {})
        if isinstance(headers, str):
            headers = json.loads(headers)
            
        # Parameter substitution in URL
        # For example: https://api.booking.com/v1/availability?date={date}
        # params: {"date": "2023-10-27"}
        
        # 1. Substitute URL parameters
        try:
            # We use a simple replace for now, but could be more robust
            for key, value in params.items():
                placeholder = f"{{{key}}}"
                if placeholder in url:
                    url = url.replace(placeholder, str(value))
        except Exception as e:
            logger.error(f"Error substituting URL parameters: {e}")
            raise ActionExecutionError("Invalid URL parameter substitution")
        
        # SECURITY: Validate URL after substitution to prevent SSRF
        if not validate_action_url(url):
            logger.warning(f"Blocked potentially unsafe URL: {url}")
            raise ActionExecutionError("Invalid or unsafe URL - SSRF protection blocked this request")
            
        # 2. Prepare Query Params / Body
        # If method is GET, remaining params go to query string
        # If method is POST/PUT, remaining params go to JSON body
        
        request_kwargs = {
            "headers": headers,
            "timeout": 10
        }
        
        try:
            start_time = time.time()
            
            if method == 'GET':
                # For GET, we append params that weren't in the URL template
                # But typically we assume the URL template handles specific path params
                # and everything else is query params
                response = requests.get(url, params=params, **request_kwargs)
            
            elif method in ['POST', 'PUT', 'PATCH', 'DELETE']:
                # For non-GET, send params as JSON body
                response = requests.request(method, url, json=params, **request_kwargs)
                
            else:
                raise ActionExecutionError(f"Unsupported HTTP method: {method}")
            
            execution_time = (time.time() - start_time) * 1000
            
            # Try to parse JSON response
            try:
                response_data = response.json()
            except ValueError:
                response_data = response.text
                
            result = {
                "success": response.ok,
                "status_code": response.status_code,
                "data": response_data,
                "execution_time_ms": execution_time
            }
            
            if not response.ok:
                logger.warning(f"Action {action['name']} failed: {response.status_code} - {response.text}")
                
            return result
            
        except requests.exceptions.Timeout:
            return {
                "success": False,
                "error": "Request timed out",
                "status_code": 408
            }
        except requests.exceptions.RequestException as e:
            logger.error(f"Action execution request failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "status_code": 500
            }
        except Exception as e:
            logger.error(f"Unexpected error executing action: {e}")
            return {
                "success": False,
                "error": str(e),
                "status_code": 500
            }

action_service = ActionService()

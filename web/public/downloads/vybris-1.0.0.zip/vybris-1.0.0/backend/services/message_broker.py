"""
Message Broker - Redis Streams for async chat processing.
Provides publish/consume for chat messages with optional async path.
"""

import os
import json
import uuid
import logging
from typing import Dict, Any, Optional, List, Tuple

logger = logging.getLogger(__name__)

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379")
STREAM_NAME = "vybris:chat:messages"
WORKFLOW_EVENTS_STREAM = "vybris:workflow:events"
WORKFLOW_CONSUMER_GROUP = "vybris-workflow-workers"
RESULT_PREFIX = "vybris:chat:results:"
RESULT_TTL = 60
CONSUMER_GROUP = "vybris-workers"

_redis_client = None


def _get_redis():
    """Lazy Redis connection."""
    global _redis_client
    if _redis_client is None:
        try:
            import redis
            _redis_client = redis.from_url(REDIS_URL, decode_responses=True)
        except Exception as e:
            logger.warning(f"Redis connection failed for message broker: {e}")
    return _redis_client


def publish_message(
    chatbot_id: str,
    session_id: str,
    text: str,
    metadata: Optional[Dict[str, Any]] = None,
    job_id: Optional[str] = None,
) -> str:
    """
    Publish a chat message to the stream.
    Returns message_id (stream entry id) or job_id if provided.
    If job_id is provided, worker will write result to vybris:chat:results:{job_id}.
    """
    r = _get_redis()
    if not r:
        return ""
    jid = job_id or f"job_{uuid.uuid4().hex[:16]}"
    try:
        payload = {
            "job_id": jid,
            "chatbot_id": chatbot_id,
            "session_id": session_id,
            "text": text,
            "metadata": json.dumps(metadata or {}),
        }
        fields = {k: str(v) for k, v in payload.items()}
        msg_id = r.xadd(STREAM_NAME, fields, maxlen=10000)
        logger.debug(f"Published message to {STREAM_NAME}: {msg_id} job_id={jid}")
        return jid
    except Exception as e:
        logger.error(f"Publish failed: {e}")
        return ""


def consume_messages(
    group: str = CONSUMER_GROUP,
    consumer: Optional[str] = None,
    block_ms: int = 5000,
    count: int = 10,
) -> List[Tuple[str, Dict[str, Any]]]:
    """
    Consume messages from the stream via consumer group.
    Returns list of (msg_id, parsed_data).
    """
    r = _get_redis()
    if not r:
        return []
    consumer_id = consumer or f"consumer-{uuid.uuid4().hex[:8]}"
    try:
        try:
            r.xgroup_create(STREAM_NAME, group, id="0", mkstream=True)
        except Exception as e:
            if "BUSYGROUP" not in str(e):
                logger.warning(f"Consumer group create: {e}")
        reply = r.xreadgroup(group, consumer_id, {STREAM_NAME: ">"}, count=count, block=block_ms)
        if not reply:
            return []
        result = []
        for stream_name, entries in reply:
            for msg_id, data in entries:
                parsed = dict(data)
                if isinstance(parsed.get("metadata"), str):
                    try:
                        parsed["metadata"] = json.loads(parsed["metadata"] or "{}")
                    except Exception:
                        parsed["metadata"] = {}
                result.append((msg_id, parsed))
        return result
    except Exception as e:
        logger.error(f"Consume failed: {e}")
        return []


def acknowledge_message(group: str, msg_id: str) -> bool:
    """Acknowledge message processing."""
    r = _get_redis()
    if not r:
        return False
    try:
        r.xack(STREAM_NAME, group, msg_id)
        return True
    except Exception as e:
        logger.warning(f"Ack failed: {e}")
        return False


def set_result(job_id: str, result: Dict[str, Any]) -> bool:
    """Store async result for polling."""
    r = _get_redis()
    if not r:
        return False
    try:
        key = RESULT_PREFIX + job_id
        r.setex(key, RESULT_TTL, json.dumps(result))
        return True
    except Exception as e:
        logger.error(f"Set result failed: {e}")
        return False


def get_result(job_id: str) -> Optional[Dict[str, Any]]:
    """Retrieve async result."""
    r = _get_redis()
    if not r:
        return None
    try:
        key = RESULT_PREFIX + job_id
        data = r.get(key)
        if data:
            return json.loads(data)
    except Exception as e:
        logger.warning(f"Get result failed: {e}")
    return None


# =============================================================================
# Workflow Events (Phase 1.2 - Wire workflow triggers to message broker)
# =============================================================================


def publish_workflow_event(
    event_type: str,
    context: Dict[str, Any],
    owner_id: Optional[str] = None,
    chatbot_id: Optional[str] = None,
) -> bool:
    """
    Publish a workflow event to the stream for async processing.
    Events: stage_change, score_threshold, time_in_stage, on_user_intent, on_handoff, on_sentiment.
    """
    r = _get_redis()
    if not r:
        return False
    try:
        payload = {
            "event_type": event_type,
            "context": json.dumps(context),
            "owner_id": owner_id or "",
            "chatbot_id": chatbot_id or "",
        }
        fields = {k: str(v) for k, v in payload.items()}
        r.xadd(WORKFLOW_EVENTS_STREAM, fields, maxlen=10000)
        logger.debug(f"Published workflow event {event_type} to {WORKFLOW_EVENTS_STREAM}")
        return True
    except Exception as e:
        logger.error(f"Workflow event publish failed: {e}")
        return False


def consume_workflow_events(
    group: str = WORKFLOW_CONSUMER_GROUP,
    consumer: Optional[str] = None,
    block_ms: int = 5000,
    count: int = 10,
) -> List[Tuple[str, Dict[str, Any]]]:
    """Consume workflow events from the stream."""
    r = _get_redis()
    if not r:
        return []
    consumer_id = consumer or f"wf-consumer-{uuid.uuid4().hex[:8]}"
    try:
        try:
            r.xgroup_create(WORKFLOW_EVENTS_STREAM, group, id="0", mkstream=True)
        except Exception as e:
            if "BUSYGROUP" not in str(e):
                logger.warning(f"Workflow consumer group create: {e}")
        reply = r.xreadgroup(
            group, consumer_id, {WORKFLOW_EVENTS_STREAM: ">"}, count=count, block=block_ms
        )
        if not reply:
            return []
        result = []
        for stream_name, entries in reply:
            for msg_id, data in entries:
                parsed = dict(data)
                if isinstance(parsed.get("context"), str):
                    try:
                        parsed["context"] = json.loads(parsed.get("context") or "{}")
                    except Exception:
                        parsed["context"] = {}
                result.append((msg_id, parsed))
        return result
    except Exception as e:
        logger.error(f"Consume workflow events failed: {e}")
        return []


def acknowledge_workflow_event(group: str, msg_id: str) -> bool:
    """Acknowledge workflow event processing."""
    r = _get_redis()
    if not r:
        return False
    try:
        r.xack(WORKFLOW_EVENTS_STREAM, group, msg_id)
        return True
    except Exception as e:
        logger.warning(f"Workflow ack failed: {e}")
        return False

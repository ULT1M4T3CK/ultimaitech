
"""
Usage Service
Handles usage tracking for users.
"""
from typing import Dict, Any, Optional, Tuple
import json
from services.database import get_db_connection, UserDB

class UsageService:
    
    @staticmethod
    def get_user_usage(user_id: str) -> Dict[str, Any]:
        """Get user's current usage stats"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM user_usage WHERE user_id = %s', (user_id,))
            usage = cursor.fetchone()
            
            if not usage:
                # Initialize if not exists
                UsageService.init_usage(user_id)
                cursor.execute('SELECT * FROM user_usage WHERE user_id = %s', (user_id,))
                usage = cursor.fetchone()
                
            return dict(usage) if usage else {'chatbots_created': 0, 'pages_crawled': 0}

    @staticmethod
    def init_usage(user_id: str):
        """Initialize usage record for a user"""
        # Count existing chatbots owned by user
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM chatbots WHERE owner_id = %s", (user_id,))
            result = cursor.fetchone()
            count = result['count'] if result else 0
            
            cursor.execute('''
                INSERT INTO user_usage (user_id, chatbots_created)
                VALUES (%s, %s)
                ON CONFLICT (user_id) DO NOTHING
            ''', (user_id, count))
            conn.commit()

    @staticmethod
    def increment_chatbot_count(user_id: str):
        """Increment chatbot count for user"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO user_usage (user_id, chatbots_created)
                VALUES (%s, 1)
                ON CONFLICT (user_id) DO UPDATE SET 
                    chatbots_created = user_usage.chatbots_created + 1,
                    updated_at = NOW()
            ''', (user_id,))
            conn.commit()
            
    @staticmethod
    def decrement_chatbot_count(user_id: str):
        """Decrement chatbot count for user"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE user_usage SET 
                    chatbots_created = GREATEST(0, chatbots_created - 1),
                    updated_at = NOW()
                WHERE user_id = %s
            ''', (user_id,))
            conn.commit()

    @staticmethod
    def increment_page_count(user_id: str, count: int):
        """Increment pages crawled count"""
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO user_usage (user_id, pages_crawled)
                VALUES (%s, %s)
                ON CONFLICT (user_id) DO UPDATE SET 
                    pages_crawled = user_usage.pages_crawled + %s,
                    updated_at = NOW()
            ''', (user_id, count, count))
            conn.commit()

usage_service = UsageService()

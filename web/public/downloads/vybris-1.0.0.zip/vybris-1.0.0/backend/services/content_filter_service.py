"""
Content Filter Service (Phase 4 - Ethics)
PII redaction, harmful content detection (optional OpenAI Moderation).
"""

import re
import logging
import os
from typing import List, Tuple, Optional

logger = logging.getLogger(__name__)

USE_MODERATION = os.getenv("USE_CONTENT_MODERATION", "false").lower() == "true"
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# PII patterns (redact with placeholder)
PII_PATTERNS = [
    (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", "[EMAIL]"),
    (r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b", "[PHONE]"),
    (r"\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b", "[CARD]"),
]


def redact_pii(text: str) -> Tuple[str, List[str]]:
    """
    Redact PII from text. Returns (redacted_text, list of redacted types).
    """
    redacted_types = []
    out = text
    for pattern, placeholder in PII_PATTERNS:
        matches = re.findall(pattern, out)
        if matches:
            kind = placeholder.strip("[]")
            if kind not in redacted_types:
                redacted_types.append(kind)
            out = re.sub(pattern, placeholder, out)
    return out, redacted_types


def check_moderation(text: str) -> Tuple[bool, Optional[dict]]:
    """
    Check text for harmful content via OpenAI Moderation API.
    Returns (is_safe, details_dict or None).
    """
    if not USE_MODERATION or not OPENAI_API_KEY:
        return True, None
    try:
        import httpx
        with httpx.Client(timeout=10.0) as client:
            resp = client.post(
                "https://api.openai.com/v1/moderations",
                json={"input": text},
                headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
            )
            resp.raise_for_status()
            data = resp.json()
            results = data.get("results", [{}])
            r = results[0] if results else {}
            flagged = r.get("flagged", False)
            return not flagged, r
    except Exception as e:
        logger.warning(f"Moderation check failed: {e}")
        return True, None

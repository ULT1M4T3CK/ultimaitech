"""
Orchestrator Service (Phase 2.1)
Central service for intent routing, fallback chains, and configurable thresholds.
Reads config from chatbot config JSON (populated by UI); delegates to chat orchestrator.
"""

import logging
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from fastapi import Request

from application.chat.chat_orchestrator import chat_orchestrator
from application.chat.models import OrchestratorResponse
from shared.constants.orchestrator_config import get_orchestrator_config
from shared.constants.type_configurations import get_confidence_thresholds

logger = logging.getLogger(__name__)


@dataclass
class OrchestratorServiceConfig:
    """Orchestrator config loaded from chatbot config (UI-populated)."""
    fallback_chain: List[str]
    rag_confidence_threshold: float
    llm_confidence_threshold: float
    handoff_confidence_threshold: float
    routing_model: str
    generation_model: str
    max_llm_calls_per_turn: int


def get_orchestrator_service_config(bot_config: dict, chatbot_type: str = "General Purpose") -> OrchestratorServiceConfig:
    """
    Build orchestrator config from chatbot config (from DB, populated by UI).
    Uses type-specific thresholds when not overridden in config.
    """
    orch = bot_config.get("orchestrator") or {}
    thresholds = get_confidence_thresholds(chatbot_type)

    return OrchestratorServiceConfig(
        fallback_chain=orch.get("fallback_chain") or ["rag", "action", "llm", "handoff"],
        rag_confidence_threshold=float(orch.get("rag_confidence_threshold", thresholds.get("min_confidence", 0.5))),
        llm_confidence_threshold=float(orch.get("llm_confidence_threshold", thresholds.get("llm_threshold", 0.5))),
        handoff_confidence_threshold=float(orch.get("handoff_confidence_threshold", thresholds.get("fallback_threshold", 0.4))),
        routing_model=orch.get("routing_model", "rule"),
        generation_model=orch.get("generation_model", "perplexity"),
        max_llm_calls_per_turn=int(orch.get("max_llm_calls_per_turn", 2)),
    )


async def orchestrate(
    *,
    text: str,
    chatbot_id: str,
    session_id: Optional[str],
    context: Optional[Dict[str, Any]],
    auto_request_live_chat: bool,
    bot: Dict[str, Any],
    req: Request,
) -> OrchestratorResponse:
    """
    Main entry point for orchestration. Delegates to chat_orchestrator.
    Config is read from bot.config.orchestrator (populated by Config UI).
    """
    return await chat_orchestrator.process(
        text=text,
        chatbot_id=chatbot_id,
        session_id=session_id,
        context=context,
        auto_request_live_chat=auto_request_live_chat,
        bot=bot,
        req=req,
    )


orchestrator_service = type("OrchestratorService", (), {
    "orchestrate": staticmethod(orchestrate),
    "get_config": staticmethod(get_orchestrator_service_config),
})()

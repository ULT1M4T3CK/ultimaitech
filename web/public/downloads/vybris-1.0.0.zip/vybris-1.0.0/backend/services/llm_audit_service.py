"""
LLM Audit Service - logs every LLM call for AI ethics and attribution.
"""

import hashlib
import logging
import uuid
from typing import Optional, List, Dict, Any
from datetime import datetime

logger = logging.getLogger(__name__)


def log_llm_call(
    chatbot_id: str,
    session_id: Optional[str],
    request_id: Optional[str],
    prompt_text: str,
    model: str,
    tokens_in: int,
    tokens_out: int,
    latency_ms: int,
) -> None:
    """Log an LLM call to the audit table."""
    try:
        from services.database.base import get_db_connection
        prompt_hash = hashlib.sha256(prompt_text.encode()[:1000]).hexdigest()[:32]
        log_id = f"llm_{uuid.uuid4().hex[:16]}"
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO llm_audit_log 
                (id, chatbot_id, session_id, request_id, prompt_hash, model, tokens_in, tokens_out, latency_ms)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (log_id, chatbot_id, session_id or "", request_id or "", prompt_hash, model, tokens_in, tokens_out, latency_ms),
            )
    except Exception as e:
        logger.warning(f"LLM audit log failed: {e}")


def get_llm_audit_log(
    chatbot_id: Optional[str] = None,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """Fetch LLM audit log entries for admin/compliance."""
    try:
        from services.database.base import get_db_connection

        with get_db_connection() as conn:
            cursor = conn.cursor()
            where_clauses = ["1=1"]
            params: list = []
            if chatbot_id:
                where_clauses.append("chatbot_id = %s")
                params.append(chatbot_id)
            if from_date:
                where_clauses.append("created_at >= %s")
                params.append(from_date)
            if to_date:
                where_clauses.append("created_at <= %s")
                params.append(to_date)
            params.append(limit)

            cursor.execute(
                f"""
                SELECT id, chatbot_id, session_id, request_id, prompt_hash, model,
                       tokens_in, tokens_out, latency_ms, created_at
                FROM llm_audit_log
                WHERE {" AND ".join(where_clauses)}
                ORDER BY created_at DESC
                LIMIT %s
                """,
                tuple(params),
            )
            rows = cursor.fetchall()
            return [
                {
                    "id": r.get("id"),
                    "chatbot_id": r.get("chatbot_id"),
                    "session_id": r.get("session_id"),
                    "request_id": r.get("request_id"),
                    "prompt_hash": r.get("prompt_hash"),
                    "model": r.get("model"),
                    "tokens_in": r.get("tokens_in"),
                    "tokens_out": r.get("tokens_out"),
                    "latency_ms": r.get("latency_ms"),
                    "created_at": r.get("created_at").isoformat() if r.get("created_at") else None,
                }
                for r in rows
            ]
    except Exception as e:
        logger.warning(f"get_llm_audit_log failed: {e}")
        return []

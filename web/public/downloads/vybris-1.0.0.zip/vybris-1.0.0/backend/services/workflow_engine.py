"""
Workflow Engine (Phase 4 - Multi-step automations)
Executes workflows with sequential steps (action, condition, delay).
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)


async def run_workflow(
    workflow_id: str,
    chatbot_id: str,
    trigger_context: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Execute a workflow. Steps can be:
    - action: { type: "move_stage"|"assign_owner"|..., config: {...} }
    - condition: { field: "...", op: "eq"|"gte"|..., value: ... } -> skip if false
    - delay: { seconds: N } -> wait N seconds
    """
    from services.database import WorkflowDB, CRMLeadDB, PipelineDB

    workflow = WorkflowDB.get_by_id(workflow_id)
    if not workflow or not workflow.get("enabled"):
        return {"success": False, "error": "Workflow not found or disabled"}

    steps = workflow.get("steps", [])
    if not steps:
        return {"success": True, "steps_executed": 0}

    lead_id = trigger_context.get("lead_id")
    if not lead_id:
        return {"success": False, "error": "lead_id required in trigger_context"}

    executed = 0
    for i, step in enumerate(steps):
        step_type = step.get("type", "action")
        config = step.get("config", {})

        if step_type == "condition":
            # Evaluate condition; skip rest if false
            field = config.get("field")
            op = config.get("op", "eq")
            value = config.get("value")
            lead = CRMLeadDB.get_by_id(lead_id)
            if not lead:
                logger.warning(f"Workflow {workflow_id}: lead {lead_id} not found")
                break
            actual = lead.get(field)
            match = False
            if op == "eq":
                match = actual == value
            elif op == "gte":
                match = (actual or 0) >= (value or 0)
            elif op == "lte":
                match = (actual or 0) <= (value or 0)
            elif op == "contains":
                match = value in (actual or [])
            if not match:
                logger.info(f"Workflow {workflow_id} step {i}: condition not met, stopping")
                break
        elif step_type == "delay":
            secs = config.get("seconds", 0)
            if secs > 0 and secs <= 300:  # Cap at 5 min
                await asyncio.sleep(secs)
                executed += 1
        elif step_type == "action":
            action_type = config.get("action_type")
            action_config = config.get("action_config", {})
            try:
                if action_type == "move_stage":
                    stage_id = action_config.get("stage_id")
                    if stage_id:
                        CRMLeadDB.update(lead_id, {"pipeline_stage_id": stage_id})
                        executed += 1
                elif action_type == "assign_owner":
                    owner_id = action_config.get("owner_id")
                    if owner_id:
                        CRMLeadDB.update(lead_id, {"owner_id": owner_id})
                        executed += 1
                elif action_type == "add_tag":
                    tag = action_config.get("tag")
                    if tag:
                        lead = CRMLeadDB.get_by_id(lead_id)
                        tags = lead.get("tags") or []
                        if tag not in tags:
                            tags.append(tag)
                            CRMLeadDB.update(lead_id, {"tags": tags})
                        executed += 1
                else:
                    logger.warning(f"Workflow action type {action_type} not implemented")
            except Exception as e:
                logger.error(f"Workflow step {i} failed: {e}")
                return {"success": False, "error": str(e), "steps_executed": executed}

    return {"success": True, "steps_executed": executed}

"""
Plugin Registry - Phase 4.3
Scans plugins/ directory, loads plugin modules, extends integrations.
"""

import json
import logging
import os
from pathlib import Path
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

PLUGINS_DIR = Path(__file__).resolve().parent.parent / "plugins"


class PluginRegistry:
    """
    Registry for plugin-provided integrations, agents, handlers.
    Plugins call register(registry) and use registry.register_integration(type, class).
    """

    def __init__(self):
        self._integrations: Dict[str, type] = {}
        self._loaded: List[str] = []

    def register_integration(self, integration_type: str, cls: type) -> None:
        """Register an integration class for a type."""
        self._integrations[integration_type] = cls
        logger.info("Plugin registered integration: %s", integration_type)

    def get_integrations(self) -> Dict[str, type]:
        return dict(self._integrations)

    def get_loaded_plugins(self) -> List[str]:
        return list(self._loaded)


_registry: Optional[PluginRegistry] = None


def get_registry() -> PluginRegistry:
    global _registry
    if _registry is None:
        _registry = PluginRegistry()
        _load_plugins(_registry)
    return _registry


def _load_plugins(registry: PluginRegistry) -> None:
    """Scan plugins/ and load each plugin's register function."""
    if not PLUGINS_DIR.exists():
        return
    for path in sorted(PLUGINS_DIR.iterdir()):
        if not path.is_dir():
            continue
        plugin_json = path / "plugin.json"
        if not plugin_json.exists():
            continue
        try:
            with open(plugin_json) as f:
                meta = json.load(f)
            entry = meta.get("entry_point") or meta.get("entry_point_module", "handler")
            if "." in entry:
                mod_name = entry
            else:
                mod_name = f"plugins.{path.name}.{entry}"
            module = __import__(mod_name, fromlist=["register"])
            if hasattr(module, "register"):
                module.register(registry)
                registry._loaded.append(meta.get("id", path.name))
        except Exception as e:
            logger.warning("Failed to load plugin %s: %s", path.name, e)


def apply_plugin_integrations() -> None:
    """Apply plugin-registered integrations to IntegrationManager."""
    from services.integrations import IntegrationManager

    registry = get_registry()
    for itype, cls in registry.get_integrations().items():
        IntegrationManager.INTEGRATION_CLASSES[itype] = cls
        logger.info("Applied plugin integration: %s", itype)

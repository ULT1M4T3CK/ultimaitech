"""
Conversation Event Emission
Standardized event emission for user messages - supports analytics, audit, and replay.
Phase 3.4: Subscriber writes to conversation_audit for AI ethics compliance.
"""

import json
import logging
import uuid
from typing import Optional, Dict, Any, List, Callable
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class ConversationEventType(str, Enum):
    """Types of conversation events."""
    USER_MESSAGE_RECEIVED = "user_message_received"
    RESPONSE_GENERATED = "response_generated"
    INTENT_DETECTED = "intent_detected"
    SESSION_CREATED = "session_created"
    LIVE_CHAT_REQUESTED = "live_chat_requested"


@dataclass
class ConversationEvent:
    """Standardized conversation event payload."""
    event_type: str
    chatbot_id: str
    session_id: Optional[str] = None
    user_message: Optional[str] = None
    response: Optional[str] = None
    intent: Optional[str] = None
    confidence: float = 0.0
    sources_count: int = 0
    processing_time_ms: float = 0.0
    request_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat() + "Z")

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# In-process subscribers (extensible for future Redis/pub-sub, webhooks, etc.)
_subscribers: List[Callable[[ConversationEvent], None]] = []


def subscribe(handler: Callable[[ConversationEvent], None]) -> None:
    """Register a handler to receive conversation events."""
    if handler not in _subscribers:
        _subscribers.append(handler)


def unsubscribe(handler: Callable[[ConversationEvent], None]) -> None:
    """Unregister an event handler."""
    if handler in _subscribers:
        _subscribers.remove(handler)


def emit(event: ConversationEvent) -> None:
    """
    Emit a conversation event.
    Logs the event and notifies all subscribers.
    """
    try:
        logger.debug(
            "Conversation event: %s chatbot=%s session=%s intent=%s",
            event.event_type,
            event.chatbot_id,
            event.session_id,
            event.intent,
        )
        for handler in _subscribers:
            try:
                handler(event)
            except Exception as e:
                logger.warning("Conversation event handler error: %s", e)
    except Exception as e:
        logger.warning("Conversation event emission error: %s", e)


def emit_response_generated(
    chatbot_id: str,
    session_id: Optional[str],
    user_message: str,
    response: str,
    intent: str,
    confidence: float,
    sources_count: int = 0,
    processing_time_ms: float = 0.0,
    request_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """Convenience: emit a response_generated event."""
    emit(ConversationEvent(
        event_type=ConversationEventType.RESPONSE_GENERATED.value,
        chatbot_id=chatbot_id,
        session_id=session_id,
        user_message=user_message,
        response=response,
        intent=intent,
        confidence=confidence,
        sources_count=sources_count,
        processing_time_ms=processing_time_ms,
        request_id=request_id,
        metadata=metadata or {},
    ))


def emit_user_message_received(
    chatbot_id: str,
    session_id: Optional[str],
    user_message: str,
    request_id: Optional[str] = None,
) -> None:
    """Convenience: emit a user_message_received event."""
    emit(ConversationEvent(
        event_type=ConversationEventType.USER_MESSAGE_RECEIVED.value,
        chatbot_id=chatbot_id,
        session_id=session_id,
        user_message=user_message,
        request_id=request_id,
    ))


def emit_live_chat_requested(
    chatbot_id: str,
    session_id: Optional[str],
    user_message: str,
    page_url: Optional[str] = None,
) -> None:
    """Convenience: emit a live_chat_requested event."""
    emit(ConversationEvent(
        event_type=ConversationEventType.LIVE_CHAT_REQUESTED.value,
        chatbot_id=chatbot_id,
        session_id=session_id,
        user_message=user_message,
        metadata={"page_url": page_url} if page_url else {},
    ))


def _audit_subscriber(event: ConversationEvent) -> None:
    """Write conversation events to conversation_audit table for compliance."""
    try:
        from services.database.base import get_db_connection

        payload = event.to_dict()
        payload.pop("event_type", None)
        payload.pop("chatbot_id", None)
        payload.pop("session_id", None)
        payload.pop("timestamp", None)
        audit_id = f"audit_{uuid.uuid4().hex[:16]}"
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO conversation_audit (id, chatbot_id, session_id, event_type, payload_json)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (audit_id, event.chatbot_id, event.session_id or "", event.event_type, json.dumps(payload)),
            )
    except Exception as e:
        logger.warning("conversation_audit write failed: %s", e)


# Register audit subscriber on module load
subscribe(_audit_subscriber)

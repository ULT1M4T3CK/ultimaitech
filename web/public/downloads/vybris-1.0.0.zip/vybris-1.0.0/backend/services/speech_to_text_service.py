"""
Speech-to-Text Service (Phase 4 - Multimodal)
Transcribes audio to text using OpenAI Whisper API.
"""

import os
import base64
import logging
from typing import Optional

logger = logging.getLogger(__name__)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
USE_WHISPER = os.getenv("USE_SPEECH_TO_TEXT", "false").lower() == "true"


def transcribe_audio(audio_base64: str, mime_type: str = "audio/webm") -> Optional[str]:
    """
    Transcribe audio (base64) to text using OpenAI Whisper.
    Returns None if Whisper is unavailable or transcription fails.
    """
    if not USE_WHISPER or not OPENAI_API_KEY:
        logger.debug("Speech-to-text disabled or OPENAI_API_KEY not set")
        return None
    try:
        import httpx
        audio_bytes = base64.b64decode(audio_base64)
        # Map mime to Whisper-accepted format
        ext = {"audio/webm": "webm", "audio/mpeg": "mp3", "audio/wav": "wav", "audio/mp4": "m4a"}.get(mime_type, "webm")
        files = {"file": (f"audio.{ext}", audio_bytes, mime_type)}
        data = {"model": "whisper-1"}
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(
                "https://api.openai.com/v1/audio/transcriptions",
                files=files,
                data=data,
                headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
            )
            resp.raise_for_status()
            result = resp.json()
            return result.get("text", "").strip() or None
    except Exception as e:
        logger.warning(f"Speech-to-text failed: {e}")
        return None


def is_available() -> bool:
    """Whether speech-to-text is configured and available."""
    return bool(USE_WHISPER and OPENAI_API_KEY)

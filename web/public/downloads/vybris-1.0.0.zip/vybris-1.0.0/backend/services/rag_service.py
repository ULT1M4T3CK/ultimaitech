"""
RAG (Retrieval-Augmented Generation) Service
Business logic for NLP processing, training, and search operations.

This service consolidates:
- Query processing and expansion
- Hybrid search (semantic + keyword)
- Chunk re-ranking
- Training pipeline
- LLM integration (Perplexity)
"""

from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import os
import time
import logging

logger = logging.getLogger(__name__)


class SearchMode(str, Enum):
    """Search mode for retrieval."""
    SEMANTIC = "semantic"
    KEYWORD = "keyword"
    HYBRID = "hybrid"


@dataclass
class SearchResult:
    """A single search result from the knowledge base."""
    content: str
    score: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    source_type: str = "knowledge"
    chunk_id: Optional[str] = None


@dataclass
class ProcessedQuery:
    """Result of query preprocessing."""
    original: str
    normalized: str
    expanded_terms: List[str] = field(default_factory=list)
    detected_intent: Optional[str] = None
    language: str = "en"


@dataclass
class RAGResponse:
    """Response from the RAG pipeline."""
    response: str
    confidence: float
    sources: List[SearchResult] = field(default_factory=list)
    intent: str = "general"
    processing_time_ms: float = 0


class RAGService:
    """
    Service for Retrieval-Augmented Generation operations.
    
    This service provides:
    - Query preprocessing and normalization
    - Hybrid search (semantic + keyword)
    - Re-ranking of search results
    - LLM-based response generation
    - Training data management
    """
    
    # Configuration from environment
    USE_ADVANCED_RAG = os.getenv("USE_ADVANCED_RAG", "true").lower() == "true"
    USE_SEMANTIC_CHUNKING = os.getenv("USE_SEMANTIC_CHUNKING", "true").lower() == "true"
    
    # Search weights
    DEFAULT_SEMANTIC_WEIGHT = 0.7
    DEFAULT_KEYWORD_WEIGHT = 0.3
    DEFAULT_TOP_K = 5
    
    # Confidence thresholds
    HIGH_CONFIDENCE_THRESHOLD = 0.75
    MEDIUM_CONFIDENCE_THRESHOLD = 0.5
    LOW_CONFIDENCE_THRESHOLD = 0.3
    
    def __init__(
        self,
        nlp_service=None,
        llm_provider=None,  # LLM abstraction: Perplexity, OpenAI, etc.
        semantic_weight: float = None,
        keyword_weight: float = None,
        top_k: int = None
    ):
        """
        Initialize the RAG service.
        
        Args:
            nlp_service: NLP service for embeddings and search
            llm_provider: LLM provider (Perplexity, OpenAI, etc.)
            semantic_weight: Weight for semantic search (0-1)
            keyword_weight: Weight for keyword search (0-1)
            top_k: Number of results to return after re-ranking
        """
        self.nlp_service = nlp_service
        self.llm_provider = llm_provider
        self.semantic_weight = semantic_weight or self.DEFAULT_SEMANTIC_WEIGHT
        self.keyword_weight = keyword_weight or self.DEFAULT_KEYWORD_WEIGHT
        self.top_k = top_k or self.DEFAULT_TOP_K
        
        # Lazy-load components
        self._query_processor = None
        self._hybrid_retriever = None
        self._reranker = None
        self._semantic_chunker = None
    
    @property
    def query_processor(self):
        """Lazy-load query processor."""
        if self._query_processor is None:
            try:
                from nlp.query_processor import QueryProcessor
                self._query_processor = QueryProcessor()
            except ImportError:
                logger.warning("QueryProcessor not available")
        return self._query_processor
    
    @property
    def semantic_chunker(self):
        """Lazy-load semantic chunker."""
        if self._semantic_chunker is None:
            try:
                from nlp.chunking import SemanticChunker
                self._semantic_chunker = SemanticChunker(
                    max_chunk_size=500,
                    overlap=50,
                    min_chunk_size=100
                )
            except ImportError:
                logger.warning("SemanticChunker not available")
        return self._semantic_chunker
    
    # ==================== Query Processing ====================
    
    def preprocess_query(self, query: str, context: Optional[Dict] = None) -> ProcessedQuery:
        """
        Preprocess a user query for search.
        
        Steps:
        1. Normalize text (lowercase, remove special chars)
        2. Correct common typos
        3. Expand query with synonyms
        4. Detect intent if possible
        """
        if not query:
            return ProcessedQuery(original="", normalized="")
        
        original = query.strip()
        normalized = original.lower()
        
        # Use query processor if available
        if self.query_processor and self.USE_ADVANCED_RAG:
            try:
                processed = self.query_processor.process(original)
                return ProcessedQuery(
                    original=original,
                    normalized=processed.get('normalized', normalized),
                    expanded_terms=processed.get('expanded_terms', []),
                    detected_intent=processed.get('intent'),
                    language=processed.get('language', 'en')
                )
            except Exception as e:
                logger.warning(f"Query processor error: {e}")
        
        return ProcessedQuery(original=original, normalized=normalized)
    
    # ==================== Search ====================
    
    async def search(
        self,
        chatbot_id: str,
        query: str,
        mode: SearchMode = SearchMode.HYBRID,
        top_k: int = None,
        min_score: float = None
    ) -> List[SearchResult]:
        """
        Search the knowledge base for relevant content.
        
        Args:
            chatbot_id: ID of the chatbot
            query: Search query
            mode: Search mode (semantic, keyword, or hybrid)
            top_k: Number of results to return
            min_score: Minimum score threshold
            
        Returns:
            List of SearchResult objects
        """
        if not self.nlp_service:
            logger.error("NLP service not configured")
            return []
        
        top_k = top_k or self.top_k
        min_score = min_score or self.LOW_CONFIDENCE_THRESHOLD
        
        try:
            # Preprocess query
            processed = self.preprocess_query(query)
            
            # Perform search based on mode
            if mode == SearchMode.HYBRID and self.USE_ADVANCED_RAG:
                results = await self._hybrid_search(chatbot_id, processed, top_k * 2)
            else:
                results = await self._semantic_search(chatbot_id, processed.normalized, top_k * 2)
            
            # Filter by minimum score
            results = [r for r in results if r.score >= min_score]
            
            # Re-rank and limit
            if len(results) > top_k:
                results = self._rerank_results(results, processed.original)[:top_k]
            
            return results
            
        except Exception as e:
            logger.error(f"Search error for chatbot {chatbot_id}: {e}")
            return []
    
    async def _semantic_search(
        self,
        chatbot_id: str,
        query: str,
        top_k: int
    ) -> List[SearchResult]:
        """Perform semantic vector search."""
        raw_results = self.nlp_service.search(chatbot_id, query, top_k=top_k)
        
        return [
            SearchResult(
                content=r.get('text', ''),
                score=r.get('score', 0),
                metadata=r.get('metadata', {}),
                source_type=r.get('type', 'knowledge'),
                chunk_id=r.get('id')
            )
            for r in raw_results
        ]
    
    async def _hybrid_search(
        self,
        chatbot_id: str,
        processed_query: ProcessedQuery,
        top_k: int
    ) -> List[SearchResult]:
        """
        Perform hybrid search combining semantic and keyword matching.
        """
        # Get semantic results
        semantic_results = await self._semantic_search(
            chatbot_id, 
            processed_query.normalized, 
            top_k
        )
        
        # Apply semantic weight
        for r in semantic_results:
            r.score *= self.semantic_weight
        
        # Perform keyword matching on the same results
        # This boosts results that also match keywords
        query_terms = set(processed_query.normalized.lower().split())
        
        for result in semantic_results:
            content_lower = result.content.lower()
            content_terms = set(content_lower.split())
            
            # Calculate keyword overlap
            common_terms = query_terms & content_terms
            if common_terms:
                # Boost score based on keyword matches
                keyword_score = len(common_terms) / len(query_terms) if query_terms else 0
                result.score += keyword_score * self.keyword_weight
                result.score = min(result.score, 1.0)  # Cap at 1.0
        
        # Re-sort by combined score
        semantic_results.sort(key=lambda r: r.score, reverse=True)
        
        return semantic_results
    
    def _rerank_results(
        self,
        results: List[SearchResult],
        original_query: str
    ) -> List[SearchResult]:
        """Re-rank search results by relevance to original query."""
        # Simple re-ranking based on query term overlap
        query_terms = set(original_query.lower().split())
        
        for result in results:
            content_terms = set(result.content.lower().split())
            overlap = len(query_terms & content_terms)
            boost = overlap * 0.1
            result.score = min(result.score + boost, 1.0)
        
        return sorted(results, key=lambda r: r.score, reverse=True)
    
    # ==================== Response Generation ====================
    
    async def generate_response(
        self,
        chatbot_id: str,
        query: str,
        context: Optional[Dict] = None,
        use_llm: bool = True
    ) -> RAGResponse:
        """
        Generate a response using the RAG pipeline.
        
        Steps:
        1. Search for relevant content
        2. Build context from search results
        3. Generate response via LLM or template
        """
        start_time = time.time()
        
        # Search for relevant content
        results = await self.search(chatbot_id, query)
        
        # Calculate confidence based on top result
        raw_confidence = results[0].score if results else 0.0
        
        # Calibrate confidence based on historical accuracy
        from services.nlp_utils import confidence_calibrator
        confidence = confidence_calibrator.calibrate_confidence(chatbot_id, raw_confidence)
        
        # Get chatbot type for context limits
        chatbot_type = "General Purpose"
        try:
            from services.database import ChatbotDB
            chatbot = ChatbotDB.get_by_id(chatbot_id)
            if chatbot:
                chatbot_type = chatbot.get('type', 'General Purpose')
        except Exception:
            pass
        
        # Build context for LLM with type-specific limits
        context_text = self._build_context(results, chatbot_type=chatbot_type)
        
        # Fetch available actions
        available_actions = []
        try:
            from services.action_service import action_service
            available_actions = action_service.get_available_actions(chatbot_id)
        except Exception as e:
            logger.warning(f"Failed to fetch actions: {e}")

        # Generate response
        response = None
        intent = self._detect_intent(query)
        
        if use_llm and self.llm_provider and (confidence >= self.MEDIUM_CONFIDENCE_THRESHOLD or available_actions):
            # Pass 1: Initial Generation
            response = await self._generate_llm_response(
                query, 
                context_text, 
                context, 
                chatbot_id=chatbot_id, # Added chatbot_id for lookup
                available_actions=available_actions
            )
            
            # ReAct Loop: Check for ACTION request
            if response and response.strip().startswith("ACTION:"):
                # Parse action request
                try:
                    import json
                    json_str = response.strip().replace("ACTION:", "", 1).strip()
                    action_req = json.loads(json_str)
                    
                    action_id = action_req.get("action_id")
                    params = action_req.get("params", {})
                    
                    logger.info(f"LLM requested action {action_id} with params {params}")
                    
                    # Execute Action
                    from services.action_service import action_service
                    
                    # Verify action exists in available_actions to prevent ID guessing
                    action_def = next((a for a in available_actions if a['id'] == action_id), None)
                    
                    if action_def:
                        result = action_service.execute_action(action_id, params)
                        
                        action_result_entry = {
                            "action_id": action_id,
                            "action_name": action_def['name'],
                            "result": result
                        }
                        
                        # Pass 2: Final Generation with Action Result
                        response = await self._generate_llm_response(
                            query, 
                            context_text, 
                            context,
                            chatbot_id=chatbot_id,
                            available_actions=available_actions,
                            action_results=[action_result_entry]
                        )
                        
                        # Mark intent as transactional/action
                        intent = "action_execution"
                    else:
                        response = "I attempted to perform an action but the action ID was invalid."
                        
                except Exception as e:
                    logger.error(f"Error in ReAct loop: {e}")
                    response = "I encountered an error while trying to perform the requested action."

        elif results:
            response = self._generate_template_response(query, results)
        else:
            response = None
        
        processing_time = (time.time() - start_time) * 1000
        
        # Track response quality
        from services.nlp_utils import response_quality_tracker
        response_quality_tracker.record_response(
            chatbot_id=chatbot_id,
            query=query,
            response=response or "",
            confidence=confidence,
            sources=[{"score": r.score, "content": r.content[:100], "source": r.source_type} for r in results[:3]],
            processing_time_ms=processing_time,
            session_id=context.get("session_id") if context else None
        )
        
        return RAGResponse(
            response=response or "",
            confidence=confidence,
            sources=results[:3],
            intent=intent,
            processing_time_ms=processing_time
        )
    
    def _build_context(self, results: List[SearchResult], max_tokens: int = None, chatbot_type: str = "General Purpose") -> str:
        """
        Build context string from search results with intelligent truncation.
        Uses token-aware context window management with type-specific limits.
        """
        from services.nlp_utils import ContextWindowManager, ContextChunk
        from shared.constants.type_configurations import get_context_limits
        
        # PHASE 3: Use type-specific context limits
        if max_tokens is None:
            context_limits = get_context_limits(chatbot_type)
            max_tokens = context_limits.get('max_tokens', 2000)
            reserve_tokens = context_limits.get('reserve_tokens', 200)
        else:
            reserve_tokens = 200
        
        manager = ContextWindowManager(max_tokens=max_tokens, reserve_tokens=reserve_tokens)
        
        # Convert results to ContextChunks
        chunks = [
            ContextChunk(
                content=result.content,
                score=result.score,
                source=result.source_type,
                metadata=result.metadata
            )
            for result in results
        ]
        
        # Build context with intelligent truncation
        context, tokens_used = manager.build_context(chunks, prioritize_by_score=True)
        
        logger.debug(f"Built context: {tokens_used} tokens from {len(results)} results")
        
        return context
    
    async def _generate_llm_response(
        self,
        query: str,
        context: str,
        additional_context: Optional[Dict] = None,
        chatbot_id: str = None,
        available_actions: List[Dict[str, Any]] = None,
        action_results: List[Dict[str, Any]] = None
    ) -> str:
        """Generate response using configured LLM provider."""
        if not self.llm_provider:
            return None
        
        try:
            # Use additional_context if provided, otherwise fetch from DB
            chatbot_name = "Assistant"
            company_name = "our company"
            chatbot_type = "General Purpose" 
            personality = "Professional"
            supported_languages = None
            
            if additional_context:
                chatbot_name = additional_context.get('chatbot_name', chatbot_name)
                company_name = additional_context.get('company_name', company_name)
                chatbot_type = additional_context.get('chatbot_type', chatbot_type)
                personality = additional_context.get('personality', personality)
                supported_languages = additional_context.get('supported_languages')
            elif chatbot_id:
                try:
                    from services.database import ChatbotDB
                    chatbot = ChatbotDB.get_by_id(chatbot_id)
                    if chatbot:
                        chatbot_name = chatbot['name']
                        config = chatbot.get('config', {})
                        if config.get('companyName'):
                            company_name = config.get('companyName')
                        chatbot_type = chatbot.get('type', "General Purpose")
                        personality = config.get('personality', 'Professional')
                        supported_languages = config.get('supportedLanguages')
                except Exception as e:
                    logger.warning(f"Failed to fetch chatbot details for LLM context: {e}")

            _start = time.time()
            response = await self.llm_provider.generate_response(
                user_query=query,
                context_chunks=[{'text': context}], # Adapter format
                chatbot_name=chatbot_name,
                company_name=company_name,
                chatbot_type=chatbot_type,
                personality=personality,
                supported_languages=supported_languages,
                available_actions=available_actions,
                action_results=action_results
            )
            if response and chatbot_id:
                try:
                    from services.llm_audit_service import log_llm_call
                    latency_ms = int((time.time() - _start) * 1000)
                    prompt_len = len(query) + len(context)
                    log_llm_call(
                        chatbot_id=chatbot_id,
                        session_id=additional_context.get("session_id") if additional_context else None,
                        request_id=additional_context.get("request_id") if additional_context else None,
                        prompt_text=f"{query[:500]} | {context[:500]}",
                        model=self.llm_provider.get_provider_name() if hasattr(self.llm_provider, "get_provider_name") else "unknown",
                        tokens_in=max(1, prompt_len // 4),
                        tokens_out=max(1, len(response) // 4),
                        latency_ms=latency_ms,
                    )
                except Exception as le:
                    logger.debug(f"LLM audit log failed: {le}")
            return response
        except Exception as e:
            logger.error(f"LLM generation error: {e}")
            return None
    
    def _generate_template_response(
        self,
        query: str,
        results: List[SearchResult]
    ) -> str:
        """Generate a template-based response from search results."""
        if not results:
            return None
        
        top_result = results[0]
        
        # For very high confidence, return content directly
        if top_result.score >= self.HIGH_CONFIDENCE_THRESHOLD:
            return top_result.content
        
        # For medium confidence, add a qualifier
        return f"Based on our information: {top_result.content}"
    
    def _detect_intent(self, query: str) -> str:
        """Detect the intent of a query."""
        query_lower = query.lower()
        
        if any(w in query_lower for w in ['price', 'cost', 'pricing', 'how much']):
            return 'pricing'
        if any(w in query_lower for w in ['contact', 'email', 'phone', 'reach']):
            return 'contact'
        if any(w in query_lower for w in ['about', 'who are', 'company', 'history']):
            return 'about'
        if any(w in query_lower for w in ['help', 'support', 'problem', 'issue']):
            return 'support'
        
        return 'general'
    
    # ==================== Training ====================
    
    def chunk_text(
        self,
        text: str,
        metadata: Optional[Dict] = None
    ) -> List[Dict[str, Any]]:
        """
        Chunk text for training using semantic or simple chunking.
        
        Returns list of dicts with 'text' and optional metadata.
        """
        if not text:
            return []
        
        # Use semantic chunking if available and enabled
        if self.USE_SEMANTIC_CHUNKING and self.semantic_chunker:
            try:
                chunks = self.semantic_chunker.chunk(text)
                return [
                    {
                        'text': chunk['text'],
                        'metadata': {**(metadata or {}), **chunk.get('metadata', {})}
                    }
                    for chunk in chunks
                ]
            except Exception as e:
                logger.warning(f"Semantic chunking failed, using simple: {e}")
        
        # Fallback to simple chunking
        return self._simple_chunk(text, metadata)
    
    def _simple_chunk(
        self,
        text: str,
        metadata: Optional[Dict] = None,
        chunk_size: int = 250,
        overlap: int = 50
    ) -> List[Dict[str, Any]]:
        """Simple word-based chunking."""
        words = text.split()
        chunks = []
        
        if len(words) <= chunk_size:
            return [{'text': text, 'metadata': metadata or {}}]
        
        i = 0
        while i < len(words):
            chunk_words = words[i:i + chunk_size]
            chunk_text = ' '.join(chunk_words)
            chunks.append({
                'text': chunk_text,
                'metadata': {
                    **(metadata or {}),
                    'chunk_index': len(chunks),
                    'start_word': i
                }
            })
            i += chunk_size - overlap
        
        return chunks
    
    async def train_text(
        self,
        chatbot_id: str,
        text: str,
        metadata: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Train the knowledge base with text content.
        
        Returns training statistics.
        """
        if not self.nlp_service:
            raise RuntimeError("NLP service not configured")
        
        chunks = self.chunk_text(text, metadata)
        
        trained_count = 0
        for chunk in chunks:
            try:
                self.nlp_service.train_text(
                    chatbot_id,
                    chunk['text'],
                    chunk.get('metadata', {})
                )
                trained_count += 1
            except Exception as e:
                logger.warning(f"Failed to train chunk: {e}")
        
        return {
            'chunks_created': len(chunks),
            'chunks_trained': trained_count,
            'success': trained_count > 0
        }
    
    async def train_qa(
        self,
        chatbot_id: str,
        question: str,
        answer: str
    ) -> Dict[str, Any]:
        """Train a question-answer pair."""
        if not self.nlp_service:
            raise RuntimeError("NLP service not configured")
        
        try:
            self.nlp_service.train_qa(chatbot_id, question, answer)
            return {'success': True, 'message': 'Q&A pair trained successfully'}
        except Exception as e:
            logger.error(f"Failed to train Q&A: {e}")
            return {'success': False, 'error': str(e)}
    
    def get_stats(self, chatbot_id: str) -> Dict[str, Any]:
        """Get statistics for a chatbot's knowledge base."""
        if not self.nlp_service:
            return {}
        
        try:
            return self.nlp_service.get_stats(chatbot_id)
        except Exception as e:
            logger.error(f"Failed to get stats: {e}")
            return {}


# Factory function for creating configured RAG service
def create_rag_service() -> RAGService:
    """Create and configure a RAG service instance."""
    try:
        from services.nlp_service import nlp_service
        from services.llm import llm_service
        
        return RAGService(
            nlp_service=nlp_service,
            llm_provider=llm_service
        )
    except ImportError as e:
        logger.warning(f"Could not load all dependencies: {e}")
        return RAGService()


# Singleton instance
rag_service = create_rag_service()

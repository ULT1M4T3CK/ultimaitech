"""
Redis Cache Decorator
Provides easy caching for database queries and expensive operations
"""

import json
import functools
import hashlib
from typing import Any, Callable, Optional
import redis
import os
import logging

logger = logging.getLogger(__name__)

# Redis connection
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
redis_client = None

try:
    redis_client = redis.from_url(REDIS_URL, decode_responses=True)
    redis_client.ping()
    logger.info("Redis cache connected successfully")
except Exception as e:
    logger.warning(f"Redis not available, caching disabled: {e}")
    redis_client = None


def cache_result(
    ttl: int = 300,
    key_prefix: str = None,
    serialize: Callable = json.dumps,
    deserialize: Callable = json.loads
):
    """
    Decorator to cache function results in Redis.
    
    Args:
        ttl: Time to live in seconds (default: 5 minutes)
        key_prefix: Prefix for cache keys (default: function name)
        serialize: Function to serialize result (default: json.dumps)
        deserialize: Function to deserialize result (default: json.loads)
    
    Usage:
        @cache_result(ttl=600)
        def get_chatbot_config(chatbot_id: str):
            # Expensive database query
            return ChatbotDB.get_by_id(chatbot_id)
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Skip caching if Redis not available
            if redis_client is None:
                return func(*args, **kwargs)
            
            # Generate cache key
            prefix = key_prefix or f"{func.__module__}.{func.__name__}"
            key_parts = [prefix] + [str(arg) for arg in args] + [f"{k}={v}" for k, v in sorted(kwargs.items())]
            key_string = ":".join(key_parts)
            cache_key = f"cache:{hashlib.md5(key_string.encode()).hexdigest()}"
            
            # Try to get from cache
            try:
                cached = redis_client.get(cache_key)
                if cached:
                    logger.debug(f"Cache HIT: {cache_key}")
                    return deserialize(cached)
            except Exception as e:
                logger.warning(f"Cache read error: {e}")
            
            # Cache miss - execute function
            logger.debug(f"Cache MISS: {cache_key}")
            result = func(*args, **kwargs)
            
            # Store in cache
            try:
                if result is not None:
                    serialized = serialize(result)
                    redis_client.setex(cache_key, ttl, serialized)
                    logger.debug(f"Cached result: {cache_key} (TTL: {ttl}s)")
            except Exception as e:
                logger.warning(f"Cache write error: {e}")
            
            return result
        
        return wrapper
    return decorator


def invalidate_cache(pattern: str):
    """
    Invalidate cache entries matching a pattern.
    
    Args:
        pattern: Redis key pattern (e.g., "cache:chatbot:*")
    
    Usage:
        invalidate_cache("cache:chatbot:*")  # Invalidate all chatbot caches
    """
    if redis_client is None:
        return 0
    
    try:
        keys = redis_client.keys(pattern)
        if keys:
            deleted = redis_client.delete(*keys)
            logger.info(f"Invalidated {deleted} cache entries matching {pattern}")
            return deleted
        return 0
    except Exception as e:
        logger.warning(f"Cache invalidation error: {e}")
        return 0


def cache_chatbot_config(chatbot_id: str) -> Optional[dict]:
    """
    Get chatbot config from cache or database.
    This is a helper function that can be used directly.
    """
    from services.database import ChatbotDB
    
    @cache_result(ttl=300, key_prefix="chatbot_config")
    def _get_cached_config(bot_id: str):
        bot = ChatbotDB.get_by_id(bot_id)
        return bot.get('config', {}) if bot else None
    
    return _get_cached_config(chatbot_id)


def invalidate_chatbot_cache(chatbot_id: str):
    """Invalidate all cache entries for a specific chatbot"""
    patterns = [
        f"cache:chatbot_config:*{chatbot_id}*",
        f"cache:chatbot:*{chatbot_id}*",
        f"cache:integration:*{chatbot_id}*"
    ]
    
    total_invalidated = 0
    for pattern in patterns:
        total_invalidated += invalidate_cache(pattern)
    
    return total_invalidated

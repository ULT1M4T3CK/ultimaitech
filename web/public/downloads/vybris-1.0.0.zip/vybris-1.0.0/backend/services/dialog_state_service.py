"""
Dialog State Service
Persists dialogue state (last intent, context) in Redis for conversation context.
Replaces session:{id}:last_intent from deprecated dialogue router.
"""

import os
import json
import logging
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379")
DIALOG_STATE_TTL = 30 * 60  # 30 minutes

_redis_client = None


def _get_redis():
    """Lazy Redis connection."""
    global _redis_client
    if _redis_client is None:
        try:
            import redis
            _redis_client = redis.from_url(REDIS_URL, decode_responses=True)
        except Exception as e:
            logger.warning(f"Redis connection failed for dialog state: {e}")
    return _redis_client


def get_dialog_state(session_id: str) -> Optional[Dict[str, Any]]:
    """
    Get persisted dialog state for a session.
    Returns dict with last_intent, last_query, etc. or None.
    """
    r = _get_redis()
    if not r or not session_id:
        return None
    try:
        key = f"session:{session_id}:dialog_state"
        data = r.get(key)
        if data:
            return json.loads(data)
    except Exception as e:
        logger.warning(f"Failed to get dialog state: {e}")
    return None


def set_dialog_state(session_id: str, intent: str, metadata: Optional[Dict[str, Any]] = None) -> None:
    """
    Persist dialog state after processing a turn.
    TTL 30 minutes.
    """
    r = _get_redis()
    if not r or not session_id:
        return
    try:
        key = f"session:{session_id}:dialog_state"
        state = {
            "last_intent": intent,
            **(metadata or {}),
        }
        r.setex(key, DIALOG_STATE_TTL, json.dumps(state))
    except Exception as e:
        logger.warning(f"Failed to set dialog state: {e}")


def get_previous_intent(session_id: str) -> Optional[str]:
    """Convenience: get last intent only."""
    state = get_dialog_state(session_id)
    return state.get("last_intent") if state else None

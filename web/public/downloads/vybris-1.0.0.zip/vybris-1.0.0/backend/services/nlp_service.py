import os
import uuid
import json
import hashlib
import asyncio
import threading
from typing import List, Dict, Any, Optional
from qdrant_client import QdrantClient
from qdrant_client.http.models import Distance, VectorParams, PointStruct, FilterSelector, Filter, FieldCondition, MatchValue
from transformers import AutoTokenizer, AutoModel
import torch
from services.qdrant_pool import get_qdrant_client
from services.circuit_breaker import qdrant_circuit, with_fallback
import logging
from functools import lru_cache
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# Configuration
QDRANT_HOST = os.getenv("QDRANT_HOST", "localhost")
QDRANT_PORT = int(os.getenv("QDRANT_PORT", 6333))
QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")
EMBEDDING_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

# Embedding cache configuration
EMBEDDING_CACHE_TTL = int(os.getenv("EMBEDDING_CACHE_TTL_SECONDS", "86400"))  # 24 hours default
EMBEDDING_CACHE_MAX_SIZE = int(os.getenv("EMBEDDING_CACHE_MAX_SIZE", "10000"))  # Max cached embeddings


class EmbeddingCache:
    """Thread-safe cache for embeddings with TTL."""
    
    def __init__(self, ttl_seconds: int = EMBEDDING_CACHE_TTL, max_size: int = EMBEDDING_CACHE_MAX_SIZE):
        self.cache: Dict[str, tuple] = {}  # {text_hash: (embedding, expiry_time)}
        self.lock = threading.RLock()
        self.ttl_seconds = ttl_seconds
        self.max_size = max_size
        self.access_times: Dict[str, datetime] = {}  # For LRU eviction
    
    def _hash_text(self, text: str) -> str:
        """Generate hash for text (normalized)."""
        normalized = text.lower().strip()
        return hashlib.sha256(normalized.encode()).hexdigest()
    
    def get(self, text: str) -> Optional[List[float]]:
        """Get cached embedding if available and not expired."""
        text_hash = self._hash_text(text)
        now = datetime.utcnow()
        
        with self.lock:
            if text_hash in self.cache:
                embedding, expiry = self.cache[text_hash]
                if now < expiry:
                    # Update access time for LRU
                    self.access_times[text_hash] = now
                    return embedding
                else:
                    # Expired, remove
                    del self.cache[text_hash]
                    if text_hash in self.access_times:
                        del self.access_times[text_hash]
        
        return None
    
    def set(self, text: str, embedding: List[float]):
        """Cache an embedding."""
        text_hash = self._hash_text(text)
        expiry = datetime.utcnow() + timedelta(seconds=self.ttl_seconds)
        
        with self.lock:
            # Evict if cache is full (LRU)
            if len(self.cache) >= self.max_size and text_hash not in self.cache:
                self._evict_lru()
            
            self.cache[text_hash] = (embedding, expiry)
            self.access_times[text_hash] = datetime.utcnow()
    
    def _evict_lru(self):
        """Evict least recently used entry."""
        if not self.access_times:
            # Fallback: remove oldest entry by expiry
            if self.cache:
                oldest_key = min(self.cache.keys(), key=lambda k: self.cache[k][1])
                del self.cache[oldest_key]
            return
        
        # Remove least recently accessed
        lru_key = min(self.access_times.keys(), key=lambda k: self.access_times[k])
        if lru_key in self.cache:
            del self.cache[lru_key]
        if lru_key in self.access_times:
            del self.access_times[lru_key]
    
    def clear(self):
        """Clear all cached embeddings."""
        with self.lock:
            self.cache.clear()
            self.access_times.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self.lock:
            now = datetime.utcnow()
            valid_count = sum(1 for _, expiry in self.cache.values() if now < expiry)
            return {
                "total_entries": len(self.cache),
                "valid_entries": valid_count,
                "max_size": self.max_size,
                "ttl_seconds": self.ttl_seconds
            }


class NLPService:
    def __init__(self):
        logger.info(f"Initializing NLP Service with Qdrant at {QDRANT_HOST}:{QDRANT_PORT}")
        # Use connection pool for better performance (reuses connections)
        self.client = get_qdrant_client()

        self.collection_name = "chatbot_knowledge"
        
        # Initialize embedding cache
        self.embedding_cache = EmbeddingCache(
            ttl_seconds=EMBEDDING_CACHE_TTL,
            max_size=EMBEDDING_CACHE_MAX_SIZE
        )
        logger.info(f"Embedding cache initialized (TTL: {EMBEDDING_CACHE_TTL}s, max size: {EMBEDDING_CACHE_MAX_SIZE})")
        
        # Initialize Embedding Model
        logger.info(f"Loading embedding model: {EMBEDDING_MODEL_NAME}")
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(EMBEDDING_MODEL_NAME)
            self.model = AutoModel.from_pretrained(EMBEDDING_MODEL_NAME)
            # Set model to eval mode for inference
            if self.model:
                self.model.eval()
        except Exception as e:
            logger.error(f"Failed to load local model, ensure internet access or pre-downloaded weights. Error: {e}")
            self.tokenizer = None
            self.model = None

        self._ensure_collection()
        
        # Warm up the embedding model to avoid cold start latency
        # Use batch method for warmup to test batch processing
        if self.model:
            import time
            start = time.time()
            _ = self.get_embeddings(["warm up query for model initialization"])
            warmup_time = (time.time() - start) * 1000
            logger.info(f"Embedding model warm-up complete in {warmup_time:.1f}ms")

    @qdrant_circuit
    def _upsert_with_circuit_breaker(self, points: List[PointStruct]):
        """Upsert points with circuit breaker protection."""
        self.client.upsert(
            collection_name=self.collection_name,
            points=points
        )
    
    @qdrant_circuit
    def _ensure_collection(self):
        try:
            collections = self.client.get_collections().collections
            exists = any(c.name == self.collection_name for c in collections)
            
            if not exists:
                # Dimension of all-MiniLM-L6-v2 is 384
                self.client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config=VectorParams(size=384, distance=Distance.COSINE),
                )
        except Exception as e:
            print(f"Error ensuring collection: {e}")

    def get_embedding(self, text: str) -> List[float]:
        """Get embedding for a single text (for backward compatibility)"""
        return self.get_embeddings([text])[0]
    
    def get_embeddings(self, texts: List[str], batch_size: int = 32, use_cache: bool = True) -> List[List[float]]:
        """
        Get embeddings for multiple texts (batch processing for better performance).
        Uses caching to avoid recomputing embeddings for identical texts.
        
        Args:
            texts: List of texts to embed
            batch_size: Number of texts to process in each batch
            use_cache: Whether to use embedding cache
        
        Returns:
            List of embedding vectors
        """
        if not self.model:
            import random
            return [[random.uniform(-1, 1) for _ in range(384)] for _ in texts]
        
        all_embeddings = []
        texts_to_compute = []
        text_indices = []  # Track which indices need computation
        
        # Check cache first
        if use_cache:
            for i, text in enumerate(texts):
                cached = self.embedding_cache.get(text)
                if cached:
                    all_embeddings.append(cached)
                else:
                    texts_to_compute.append(text)
                    text_indices.append(i)
                    all_embeddings.append(None)  # Placeholder
        else:
            texts_to_compute = texts
            text_indices = list(range(len(texts)))
            all_embeddings = [None] * len(texts)
        
        # Compute embeddings for uncached texts
        if texts_to_compute:
            computed_embeddings = []
            
            # Process in batches for better memory efficiency
            for i in range(0, len(texts_to_compute), batch_size):
                batch_texts = texts_to_compute[i:i + batch_size]
                
                # Tokenize batch
                inputs = self.tokenizer(
                    batch_texts,
                    padding=True,
                    truncation=True,
                    return_tensors="pt",
                    max_length=512
                )
                
                # Generate embeddings
                with torch.no_grad():
                    outputs = self.model(**inputs)
                
                # Mean pooling
                embeddings = outputs.last_hidden_state.mean(dim=1)
                batch_results = embeddings.tolist()
                computed_embeddings.extend(batch_results)
                
                # Cache the computed embeddings
                if use_cache:
                    for text, embedding in zip(batch_texts, batch_results):
                        self.embedding_cache.set(text, embedding)
            
            # Fill in computed embeddings at correct indices
            for idx, embedding in zip(text_indices, computed_embeddings):
                all_embeddings[idx] = embedding
        
        return all_embeddings
    
    async def get_embeddings_async(self, texts: List[str], batch_size: int = 32, use_cache: bool = True) -> List[List[float]]:
        """
        Async version of get_embeddings for better concurrency.
        
        Args:
            texts: List of texts to embed
            batch_size: Number of texts to process in each batch
            use_cache: Whether to use embedding cache
        
        Returns:
            List of embedding vectors
        """
        # Run the synchronous version in a thread pool to avoid blocking
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.get_embeddings(texts, batch_size, use_cache)
        )

    def train_text(self, chatbot_id: str, text: str, meta: Dict[str, Any] = None):
        """Train a single text (uses batch method internally for consistency)"""
        return self.train_texts_batch(chatbot_id, [text], [meta] if meta else [None])[0]
    
    def train_texts_batch(self, chatbot_id: str, texts: List[str], metas: List[Dict[str, Any]] = None) -> List[str]:
        """
        Train multiple texts in batch (more efficient than individual calls).
        
        Args:
            chatbot_id: Chatbot ID
            texts: List of texts to train
            metas: Optional list of metadata dicts (one per text)
        
        Returns:
            List of point IDs
        """
        if metas is None:
            metas = [None] * len(texts)
        
        # Prepare texts for embedding with enhanced context
        texts_to_embed = []
        for i, text in enumerate(texts):
            meta = metas[i] if i < len(metas) else None
            
            # Build context prefix for better understanding
            context_parts = []
            
            # Add page type if available
            if meta and meta.get('page_type'):
                context_parts.append(f"[{meta['page_type'].upper()}]")
            
            # Add title
            title = meta.get('title', '') if meta else ''
            if title:
                context_parts.append(title)
            
            # Add heading if available
            if meta and meta.get('heading'):
                context_parts.append(f"Section: {meta['heading']}")
            
            # Build enriched text
            if context_parts:
                context_prefix = ' - '.join(context_parts) + ': '
                # Only add if not already in text
                if context_prefix.lower() not in text.lower()[:150]:
                    enriched_text = context_prefix + text
                else:
                    enriched_text = text
            elif title and title.lower() not in text.lower()[:100]:
                enriched_text = f"{title}: {text}"
            else:
                enriched_text = text
            
            texts_to_embed.append(enriched_text)
        
        # Generate embeddings in batch (much faster)
        embeddings = self.get_embeddings(texts_to_embed)
        
        # Prepare points for upsert
        points = []
        for i, embedding in enumerate(embeddings):
            point_id = str(uuid.uuid4())
            payload = {"chatbot_id": chatbot_id, "text": texts[i]}
            if i < len(metas) and metas[i]:
                payload.update(metas[i])
            
            points.append(PointStruct(
                id=point_id,
                vector=embedding,
                payload=payload
            ))
        
        # Batch upsert (more efficient) with circuit breaker
        if points:
            self._upsert_with_circuit_breaker(points)
        
        return [p.id for p in points]

    def train_qa(self, chatbot_id: str, question: str, answer: str):
        # IMPORTANT: Embed ONLY the question, not the answer
        # This ensures that when users ask similar questions, the embedding
        # matches the Q&A pair's question embedding (not diluted by answer text)
        # The answer is stored in payload for retrieval after matching
        embedding = self.get_embedding(question)
        point_id = str(uuid.uuid4())
        
        self.client.upsert(
            collection_name=self.collection_name,
            points=[
                PointStruct(
                    id=point_id,
                    vector=embedding,
                    payload={
                        "chatbot_id": chatbot_id,
                        "text": answer,
                        "type": "qa",
                        "original_question": question
                    }
                )
            ]
        )
        return point_id

    @qdrant_circuit
    @with_fallback(fallback_value=[])
    def search(self, chatbot_id: str, query: str, limit: int = 5) -> List[Dict[str, Any]]:
        query_vector = self.get_embedding(query)
        
        search_result = self.client.search(
            collection_name=self.collection_name,
            query_vector=query_vector,
            query_filter={
                "must": [
                    {"key": "chatbot_id", "match": {"value": chatbot_id}}
                ]
            },
            limit=limit
        )
        
        return [
            {
                "id": hit.id,
                "score": hit.score,
                "text": hit.payload.get("text", ""),
                "payload": hit.payload
            } for hit in search_result
        ]

    def clear_chatbot_data(self, chatbot_id: str) -> int:
        try:
            # First, check how many points we're about to delete
            scroll_result = self.client.scroll(
                collection_name=self.collection_name,
                scroll_filter=Filter(
                    must=[FieldCondition(key="chatbot_id", match=MatchValue(value=chatbot_id))]
                ),
                limit=1000,
                with_payload=False
            )
            count = len(scroll_result[0])
            
            # Delete them using FilterSelector
            self.client.delete(
                collection_name=self.collection_name,
                points_selector=FilterSelector(
                    filter=Filter(
                        must=[FieldCondition(key="chatbot_id", match=MatchValue(value=chatbot_id))]
                    )
                )
            )
            print(f"Cleared {count} vectors for chatbot {chatbot_id}")
            return count
        except Exception as e:
            print(f"Error clearing chatbot data: {e}")
            return 0

    def clear_scraped_data(self, chatbot_id: str) -> int:
        """
        Clear only scraped website data, preserving corrected Q&A pairs.
        This is used during "Learn from Website" to avoid losing user corrections.
        """
        try:
            # First, check how many non-QA points we're about to delete
            scroll_result = self.client.scroll(
                collection_name=self.collection_name,
                scroll_filter=Filter(
                    must=[FieldCondition(key="chatbot_id", match=MatchValue(value=chatbot_id))],
                    must_not=[FieldCondition(key="type", match=MatchValue(value="qa"))]
                ),
                limit=1000,
                with_payload=False
            )
            count = len(scroll_result[0])
            
            # Delete only non-QA data (scraped content) using FilterSelector
            self.client.delete(
                collection_name=self.collection_name,
                points_selector=FilterSelector(
                    filter=Filter(
                        must=[FieldCondition(key="chatbot_id", match=MatchValue(value=chatbot_id))],
                        must_not=[FieldCondition(key="type", match=MatchValue(value="qa"))]
                    )
                )
            )
            print(f"Cleared {count} scraped vectors for chatbot {chatbot_id} (preserved Q&A pairs)")
            return count
        except Exception as e:
            print(f"Error clearing scraped data: {e}")
            return 0

    def clear_inventory_data(self, chatbot_id: str) -> int:
        """
        Clear only inventory data from the vector store.
        This preserves scraped content and corrected Q&A pairs.
        """
        try:
            scroll_result = self.client.scroll(
                collection_name=self.collection_name,
                scroll_filter=Filter(
                    must=[
                        FieldCondition(key="chatbot_id", match=MatchValue(value=chatbot_id)),
                        FieldCondition(key="source_type", match=MatchValue(value="inventory"))
                    ]
                ),
                limit=1000,
                with_payload=False
            )
            count = len(scroll_result[0])

            self.client.delete(
                collection_name=self.collection_name,
                points_selector=FilterSelector(
                    filter=Filter(
                        must=[
                            FieldCondition(key="chatbot_id", match=MatchValue(value=chatbot_id)),
                            FieldCondition(key="source_type", match=MatchValue(value="inventory"))
                        ]
                    )
                )
            )
            print(f"Cleared {count} inventory vectors for chatbot {chatbot_id}")
            return count
        except Exception as e:
            print(f"Error clearing inventory data: {e}")
            return 0

    def get_qa_pairs(self, chatbot_id: str) -> List[Dict[str, Any]]:
        try:
            scroll_result = self.client.scroll(
                collection_name=self.collection_name,
                scroll_filter={
                    "must": [
                        {"key": "chatbot_id", "match": {"value": chatbot_id}},
                        {"key": "type", "match": {"value": "qa"}}
                    ]
                },
                limit=100
            )
            points = scroll_result[0]
            return [
                {
                    "id": p.id,
                    "question": p.payload.get("original_question", ""),
                    "answer": p.payload.get("text", ""),
                    "payload": p.payload
                } for p in points
            ]
        except Exception as e:
            print(f"Error fetching QA pairs: {e}")
            return []

    def delete_qa_pair(self, point_id: str) -> bool:
        try:
            self.client.delete(
                collection_name=self.collection_name,
                points_selector=[point_id]
            )
            return True
        except Exception as e:
            print(f"Error deleting QA pair: {e}")
            return False

    def delete_vectors(self, chatbot_id: str, point_ids: List[str]) -> bool:
        """Delete specific vectors by point IDs (e.g. when updating a knowledge item)."""
        if not point_ids:
            return True
        try:
            self.client.delete(
                collection_name=self.collection_name,
                points_selector=point_ids
            )
            logger.info(f"Deleted {len(point_ids)} vector(s) for chatbot {chatbot_id}")
            return True
        except Exception as e:
            logger.warning(f"Error deleting vectors: {e}")
            return False

nlp_service = NLPService()

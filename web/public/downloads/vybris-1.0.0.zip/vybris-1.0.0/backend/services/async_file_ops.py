"""
Async File Operations
Non-blocking file I/O operations for better performance
"""

import aiofiles
import os
from typing import Optional
import logging

logger = logging.getLogger(__name__)


async def async_write_file(file_path: str, content: bytes) -> bool:
    """
    Write file asynchronously (non-blocking).
    
    Args:
        file_path: Path to file
        content: Bytes to write
    
    Returns:
        True if successful, False otherwise
    """
    try:
        # Ensure directory exists
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        async with aiofiles.open(file_path, 'wb') as f:
            await f.write(content)
        
        return True
    except Exception as e:
        logger.error(f"Error writing file {file_path}: {e}")
        return False


async def async_read_file(file_path: str) -> Optional[bytes]:
    """
    Read file asynchronously (non-blocking).
    
    Args:
        file_path: Path to file
    
    Returns:
        File content as bytes, or None if error
    """
    try:
        async with aiofiles.open(file_path, 'rb') as f:
            content = await f.read()
        return content
    except Exception as e:
        logger.error(f"Error reading file {file_path}: {e}")
        return None


async def async_file_exists(file_path: str) -> bool:
    """Check if file exists asynchronously"""
    try:
        async with aiofiles.open(file_path, 'r') as f:
            pass
        return True
    except FileNotFoundError:
        return False
    except Exception:
        return False

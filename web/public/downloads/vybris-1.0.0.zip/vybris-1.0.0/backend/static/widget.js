(function () {
    // Add CSS animation for typing indicator
    const styleSheet = document.createElement('style');
    styleSheet.textContent = `
        @keyframes vybris-bounce {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-6px); }
        }
    `;
    document.head.appendChild(styleSheet);

    const scriptTag = document.currentScript;
    const chatbotId = scriptTag.getAttribute('data-id');
    const dataTheme = scriptTag.getAttribute('data-theme'); // optional override: minimal | professional | playful
    let apiUrl = scriptTag.getAttribute('data-url');
    if (!apiUrl) {
        try {
            const scriptSrc = scriptTag && scriptTag.src ? scriptTag.src : '';
            if (scriptSrc) {
                const srcUrl = new URL(scriptSrc, window.location.href);
                if (srcUrl.pathname.includes('/static/')) {
                    apiUrl = srcUrl.origin + srcUrl.pathname.replace(/\/static\/[^/]+$/, '');
                } else {
                    apiUrl = srcUrl.origin + '/vybris/api';
                }
            }
        } catch (e) {
            // Fallback to default below
        }
    }
    apiUrl = (apiUrl || '/vybris/api').replace(/\/$/, '');

    if (!chatbotId) {
        console.error('VYBR!S Widget: No chatbot ID provided.');
        return;
    }

    console.log(`VYBR!S Widget initialized for chatbot: ${chatbotId}`);

    // === SESSION MANAGEMENT ===
    let isOpen = false; // Moved to top scope
    const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutes in milliseconds
    const STORAGE_KEY_PREFIX = `vybris_chat_${chatbotId}_`;

    // Get or create session ID
    function getSessionId() {
        const storageKey = STORAGE_KEY_PREFIX + 'session';
        let session = null;

        try {
            const stored = localStorage.getItem(storageKey);
            if (stored) {
                session = JSON.parse(stored);
                const now = Date.now();

                // Check if session has expired (30 minutes of inactivity)
                if (session.lastActivity && (now - session.lastActivity) < SESSION_TIMEOUT) {
                    // Session is still valid, update last activity
                    session.lastActivity = now;
                    localStorage.setItem(storageKey, JSON.stringify(session));
                    return session.id;
                }
            }
        } catch (e) {
            console.warn('Failed to retrieve session:', e);
        }

        // Create new session
        const newSessionId = 'sess_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        session = {
            id: newSessionId,
            startedAt: Date.now(),
            lastActivity: Date.now()
        };

        try {
            localStorage.setItem(storageKey, JSON.stringify(session));
        } catch (e) {
            console.warn('Failed to store session:', e);
        }

        return newSessionId;
    }

    // Update session activity timestamp
    function updateSessionActivity() {
        const storageKey = STORAGE_KEY_PREFIX + 'session';
        try {
            const stored = localStorage.getItem(storageKey);
            if (stored) {
                const session = JSON.parse(stored);
                session.lastActivity = Date.now();
                localStorage.setItem(storageKey, JSON.stringify(session));
            }
        } catch (e) {
            console.warn('Failed to update session activity:', e);
        }
    }

    // Chat history management
    function saveChatHistory(messages) {
        const storageKey = STORAGE_KEY_PREFIX + 'history';
        try {
            localStorage.setItem(storageKey, JSON.stringify({
                messages: messages,
                timestamp: Date.now()
            }));
        } catch (e) {
            console.warn('Failed to save chat history:', e);
        }
    }

    function loadChatHistory() {
        const storageKey = STORAGE_KEY_PREFIX + 'history';
        try {
            const stored = localStorage.getItem(storageKey);
            if (stored) {
                const history = JSON.parse(stored);
                const now = Date.now();

                // Only restore history if it's from an active session (within timeout)
                if (history.timestamp && (now - history.timestamp) < SESSION_TIMEOUT) {
                    return history.messages || [];
                }
            }
        } catch (e) {
            console.warn('Failed to load chat history:', e);
        }
        return [];
    }

    function clearChatHistory() {
        const storageKey = STORAGE_KEY_PREFIX + 'history';
        try {
            localStorage.removeItem(storageKey);
        } catch (e) {
            console.warn('Failed to clear chat history:', e);
        }
    }

    function getEffectivePageUrl() {
        const href = (typeof window !== 'undefined' && window.location) ? window.location.href : null;
        const referrer = (typeof document !== 'undefined' && document.referrer) ? document.referrer : null;
        const isFramed = (typeof window !== 'undefined' && window.top && window.self) ? window.top !== window.self : false;
        if (isFramed && referrer) {
            return referrer;
        }
        return href || referrer || null;
    }

    function normalizeHost(url) {
        if (!url) return '';
        try {
            const host = new URL(url, window.location.href).hostname.toLowerCase();
            return host.startsWith('www.') ? host.slice(4) : host;
        } catch (e) {
            return '';
        }
    }

    // Live chat state persistence (to restore "waiting for agent" after reload)
    const LIVE_CHAT_STATE_KEY = STORAGE_KEY_PREFIX + 'live_chat_state';
    function loadLiveChatState() {
        try {
            const stored = localStorage.getItem(LIVE_CHAT_STATE_KEY);
            return stored ? JSON.parse(stored) : null;
        } catch (e) {
            console.warn('Failed to load live chat state:', e);
            return null;
        }
    }
    function saveLiveChatState(state) {
        try {
            localStorage.setItem(LIVE_CHAT_STATE_KEY, JSON.stringify({
                ...state,
                updatedAt: Date.now()
            }));
        } catch (e) {
            console.warn('Failed to save live chat state:', e);
        }
    }
    function clearLiveChatState() {
        try {
            localStorage.removeItem(LIVE_CHAT_STATE_KEY);
        } catch (e) {
            console.warn('Failed to clear live chat state:', e);
        }
    }

    // Initialize session
    let sessionId = getSessionId();
    console.log(`Session ID: ${sessionId}`);

    // Chatbot configuration - will be loaded from API
    let chatbotConfig = null;
    let chatbotName = 'Chat Support';

    // Create floating button
    const button = document.createElement('div');
    button.id = 'vybris-chat-button';
    button.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 60px;
        height: 60px;
        background: linear-gradient(135deg, #d148e6, #3b48ae);
        border-radius: 50%;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        transition: transform 0.2s;
    `;
    button.innerHTML = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>';
    document.body.appendChild(button);

    // Create Chat Window
    const chatWindow = document.createElement('div');
    chatWindow.id = 'vybris-chat-window';
    chatWindow.style.cssText = `
        position: fixed;
        bottom: 100px;
        right: 20px;
        width: 350px;
        max-width: calc(100vw - 40px);
        height: 550px;
        background: white;
        border-radius: 16px;
        box-shadow: 0 5px 40px rgba(0,0,0,0.16);
        z-index: 2147483647;
        display: none;
        flex-direction: column;
        overflow: hidden;
        font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.3s, transform 0.3s;
    `;

    // Responsive sizing logic
    // We update explicit dimensions on resize for smooth transitions and robustness
    chatWindow.style.maxHeight = 'calc(100vh - 120px)';

    const updateChatWindowSize = () => {
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;

        // Calculate maximum available height (viewport - 120px for margins)
        // We limit the max height to 650px on desktop and 600px on mobile
        const maxAllowedHeight = viewportWidth >= 768 ? 650 : 600;
        // Ensure strictly non-negative
        const targetHeight = Math.max(200, Math.min(maxAllowedHeight, viewportHeight - 120));

        if (viewportWidth >= 768) {
            // Desktop/Tablet
            chatWindow.style.width = '380px';
            chatWindow.style.height = targetHeight + 'px';
        } else {
            // Mobile
            chatWindow.style.width = Math.max(280, viewportWidth - 40) + 'px';
            chatWindow.style.height = targetHeight + 'px';
        }
    };

    // Initial sizing
    updateChatWindowSize();

    // Dynamic resizing
    window.addEventListener('resize', updateChatWindowSize);

    // Header container
    const header = document.createElement('div');
    header.id = 'vybris-chat-header';
    header.style.cssText = `
        padding: 16px;
        background: #00477e;
        color: white;
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        z-index: 10;
        flex-shrink: 0;
    `;

    // Header Content (Avatar + Text)
    const headerContent = document.createElement('div');
    headerContent.style.cssText = `display: flex; align-items: center; gap: 12px;`;

    // Avatar
    const avatarContainer = document.createElement('div');
    avatarContainer.id = 'vybris-avatar-container';
    avatarContainer.innerHTML = '<div style="width: 40px; height: 40px; background: white; border-radius: 50%; display: flex; align-items: center; justify-content: center;"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" class="text-blue-600"><path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 6C13.66 6 15 7.34 15 9C15 10.66 13.66 12 12 12C10.34 12 9 10.66 9 9C9 7.34 10.34 6 12 6ZM12 20C9.33 20 7 18.67 7 16.5C7 14.33 9.33 13 12 13C14.67 13 17 14.33 17 16.5C17 18.67 14.67 20 12 20Z" fill="#00477e"/></svg></div>';
    headerContent.appendChild(avatarContainer);

    // Text (Name + Secure)
    const headerText = document.createElement('div');
    headerText.style.cssText = `display: flex; flex-direction: column;`;

    const nameEl = document.createElement('span');
    nameEl.id = 'vybris-bot-name';
    nameEl.innerText = chatbotName;
    nameEl.style.cssText = `font-weight: 700; font-size: 16px; line-height: 1.2;`;
    headerText.appendChild(nameEl);

    const secureEl = document.createElement('span');
    secureEl.innerHTML = 'Secure <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor" style="display:inline-block; vertical-align:text-top; margin-left: 2px;"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>';
    secureEl.style.cssText = `font-size: 11px; opacity: 0.8; display: flex; align-items: center;`;
    headerText.appendChild(secureEl);

    headerContent.appendChild(headerText);
    header.appendChild(headerContent);

    // Close Button
    const closeBtn = document.createElement('button');
    closeBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
    closeBtn.style.cssText = `
        background: transparent;
        border: none;
        color: white;
        cursor: pointer;
        padding: 4px;
        opacity: 0.8;
        transition: opacity 0.2s;
        display: flex;
        align-items: center;
        justify-content: center;
    `;
    closeBtn.onmouseover = () => closeBtn.style.opacity = '1';
    closeBtn.onmouseout = () => closeBtn.style.opacity = '0.8';
    header.appendChild(closeBtn);

    chatWindow.appendChild(header);

    // Messages Area
    const messages = document.createElement('div');
    messages.id = 'vybris-chat-messages';
    messages.style.cssText = `
        flex: 1;
        padding: 20px;
        overflow-y: auto;
        background: #f8f9fa;
        display: flex;
        flex-direction: column;
        gap: 12px;
    `;
    chatWindow.appendChild(messages);

    // Input Area
    const inputWrapper = document.createElement('div');
    inputWrapper.style.cssText = `
        padding: 16px 20px 0 20px;
        background: white;
        border-top: 1px solid #eee;
        display: flex;
        flex-direction: column;
        gap: 8px;
    `;

    const inputRow = document.createElement('div');
    inputRow.style.cssText = `
        display: flex;
        gap: 10px;
        align-items: center;
        background: white;
        position: relative;
    `;

    const input = document.createElement('input');
    input.id = 'vybris-chat-input';
    input.placeholder = 'Type a message...';
    input.style.cssText = `
        flex: 1;
        padding: 12px 16px;
        border: 1px solid #e1e4e8;
        border-radius: 24px;
        outline: none;
        font-size: 14px;
        background: #f8f9fa;
        transition: border-color 0.2s;
    `;
    input.onfocus = () => input.style.borderColor = '#00477e';
    input.onblur = () => input.style.borderColor = '#e1e4e8';

    let pendingImage = null;
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/png,image/jpeg,image/webp,image/gif';
    fileInput.style.display = 'none';
    fileInput.onchange = function () {
        var f = fileInput.files && fileInput.files[0];
        if (!f) return;
        var fr = new FileReader();
        fr.onload = function () {
            var data = fr.result;
            if (data && data.indexOf('base64,') >= 0) {
                pendingImage = { base64: data.split('base64,')[1], mime: f.type || 'image/png' };
            }
        };
        fr.readAsDataURL(f);
        fileInput.value = '';
    };

    const attachBtn = document.createElement('button');
    attachBtn.type = 'button';
    attachBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>';
    attachBtn.style.cssText = 'width: 36px; height: 36px; background: transparent; color: #666; border: none; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center;';
    attachBtn.onclick = function () { fileInput.click(); };

    const sendBtn = document.createElement('button');
    sendBtn.id = 'vybris-chat-send';
    sendBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>';
    sendBtn.style.cssText = `
        width: 40px;
        height: 40px;
        background: #00477e;
        color: white;
        border: none;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.2s;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    `;
    sendBtn.onmouseover = () => sendBtn.style.transform = 'scale(1.05)';
    sendBtn.onmouseout = () => sendBtn.style.transform = 'scale(1)';

    inputRow.appendChild(input);
    inputRow.appendChild(attachBtn);
    inputRow.appendChild(sendBtn);
    inputWrapper.appendChild(inputRow);
    inputWrapper.appendChild(fileInput);
    inputWrapper.appendChild(inputRow);

    // Live Chat: Auto-forward to moderator (no button needed)
    // Track if we've already requested a human in this session
    let existingLiveChatState = loadLiveChatState();
    const currentPageUrl = getEffectivePageUrl();
    const currentHost = normalizeHost(currentPageUrl);
    const storedHost = normalizeHost(existingLiveChatState && existingLiveChatState.page_url);
    if (existingLiveChatState && currentHost && storedHost && currentHost !== storedHost) {
        clearLiveChatState();
        existingLiveChatState = null;
    }
    let liveChatRequested = !!(
        existingLiveChatState &&
        (existingLiveChatState.status === 'queued' || existingLiveChatState.status === 'active')
    );
    let liveChatRequestId = (existingLiveChatState && existingLiveChatState.request_id) || null;
    let liveChatPoller = null;
    let liveChatLastSeen = existingLiveChatState && existingLiveChatState.last_seen ? existingLiveChatState.last_seen : 0;
    const seenMessageIds = new Set();

    const LIVE_CHAT_ENDED_KEY = STORAGE_KEY_PREFIX + 'live_chat_ended';
    function getLiveChatEnded() {
        try {
            return localStorage.getItem(LIVE_CHAT_ENDED_KEY) === '1';
        } catch (e) { return false; }
    }
    function setLiveChatEnded(ended) {
        try {
            if (ended) localStorage.setItem(LIVE_CHAT_ENDED_KEY, '1');
            else localStorage.removeItem(LIVE_CHAT_ENDED_KEY);
        } catch (e) {}
    }

    function hexToRgba(hex, alpha) {
        if (!hex || typeof hex !== 'string') return 'rgba(0, 71, 126, ' + alpha + ')';
        hex = hex.replace('#', '');
        if (hex.length === 3) hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
        var r = parseInt(hex.slice(0, 2), 16);
        var g = parseInt(hex.slice(2, 4), 16);
        var b = parseInt(hex.slice(4, 6), 16);
        return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
    }

    function ensureWaitingBadge(labelText, isConnected, primaryColor) {
        const header = document.getElementById('vybris-chat-header');
        if (!header) return;
        let waitingBadge = document.getElementById('vybris-waiting-badge');
        if (!waitingBadge) {
            waitingBadge = document.createElement('div');
            waitingBadge.id = 'vybris-waiting-badge';
            chatWindow.insertBefore(waitingBadge, header.nextSibling);
        }
        if (isConnected) {
            waitingBadge.style.cssText = `
                background: rgba(34, 197, 94, 0.9);
                color: #fff;
                padding: 4px 12px;
                font-size: 11px;
                font-weight: 600;
                text-align: center;
                border-bottom: 1px solid rgba(0,0,0,0.05);
                width: 100%;
                box-sizing: border-box;
            `;
        } else {
            waitingBadge.style.cssText = `
                background: rgba(255, 193, 7, 0.9);
                color: #000;
                padding: 4px 12px;
                font-size: 11px;
                font-weight: 600;
                text-align: center;
                border-bottom: 1px solid rgba(0,0,0,0.05);
                width: 100%;
                box-sizing: border-box;
            `;
        }
        waitingBadge.innerHTML = labelText || (isConnected ? 'Connected to agent' : '⏳ Waiting for agent...');
    }

    function removeWaitingBadge() {
        const badge = document.getElementById('vybris-waiting-badge');
        if (badge) badge.remove();
    }

    async function ingestLiveChatHistory() {
        if (!chatHistory || chatHistory.length === 0) return;
        try {
            const res = await fetch(apiUrl + '/v1/live-chat/messages/ingest', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    chatbot_id: chatbotId,
                    session_id: sessionId,
                    messages: chatHistory.map(function(m) {
                        return {
                            role: m.sender === 'user' ? 'user' : 'assistant',
                            content: m.text,
                            timestamp: m.timestamp
                        };
                    })
                })
            });
            if (!res.ok) {
                console.warn('VYBR!S Widget: Failed to ingest history', res.status);
            }
        } catch (e) {
            console.warn('VYBR!S Widget: Failed to ingest history', e);
        }
    }

    async function fetchLiveChatMessages() {
        if (!liveChatRequested) return;
        try {
            const url = apiUrl + '/v1/live-chat/messages?chatbot_id=' +
                encodeURIComponent(chatbotId) + '&session_id=' + encodeURIComponent(sessionId) +
                (liveChatLastSeen ? `&since=${encodeURIComponent(liveChatLastSeen)}` : '');
            const res = await fetch(url, { method: 'GET' });
            if (!res.ok) return;
            const data = await res.json();
            const messages = Array.isArray(data?.messages) ? data.messages : [];
            messages.forEach((msg) => {
                const msgId = msg?.id;
                if (msgId && seenMessageIds.has(msgId)) return;
                if (msgId) seenMessageIds.add(msgId);
                const role = msg?.role || 'assistant';
                if (role === 'user') {
                    // Skip echoing user's own messages in widget
                    return;
                }
                const source = msg?.metadata?.source;
                addMessage(msg?.content || '', source === 'agent' ? 'agent' : 'bot');
                if (msg?.created_at) {
                    const ts = Date.parse(msg.created_at);
                    if (!Number.isNaN(ts)) {
                        liveChatLastSeen = Math.max(liveChatLastSeen || 0, ts);
                    }
                }
            });
            if (liveChatLastSeen) {
                saveLiveChatState({
                    request_id: liveChatRequestId || (existingLiveChatState && existingLiveChatState.request_id),
                    status: (existingLiveChatState && existingLiveChatState.status) || 'queued',
                    page_url: getEffectivePageUrl(),
                    last_seen: liveChatLastSeen
                });
            }
        } catch (e) {
            // ignore polling errors
        }
    }

    function startLiveChatPolling() {
        if (liveChatPoller) return;
        liveChatPoller = setInterval(function() {
            fetchLiveChatMessages();
            if (isOpen) syncLiveChatStatus();
        }, 3000);
        fetchLiveChatMessages();
        if (isOpen) syncLiveChatStatus();
    }

    function stopLiveChatPolling() {
        if (liveChatPoller) {
            clearInterval(liveChatPoller);
            liveChatPoller = null;
        }
    }

    async function sendLiveChatUserMessage(text) {
        try {
            const res = await fetch(apiUrl + '/v1/live-chat/messages/user', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    chatbot_id: chatbotId,
                    session_id: sessionId,
                    content: text,
                    client_timestamp: Date.now()
                })
            });
            if (!res.ok) return;
            const data = await res.json();
            const message = data?.message;
            if (message?.id) {
                seenMessageIds.add(message.id);
            }
            if (message?.created_at) {
                const ts = Date.parse(message.created_at);
                if (!Number.isNaN(ts)) {
                    liveChatLastSeen = Math.max(liveChatLastSeen || 0, ts);
                }
            }
        } catch (e) {
            console.warn('VYBR!S Widget: Failed to send live chat message', e);
        }
    }

    async function syncLiveChatStatus() {
        try {
            const statusUrl = apiUrl + '/v1/live-chat/status?chatbot_id=' +
                encodeURIComponent(chatbotId) + '&session_id=' + encodeURIComponent(sessionId);
            const res = await fetch(statusUrl, { method: 'GET' });
            if (!res.ok) return;
            const data = await res.json();
            if (data && data.found && (data.status === 'queued' || data.status === 'active')) {
                liveChatRequested = true;
                liveChatRequestId = data.request_id || liveChatRequestId;
                saveLiveChatState({ request_id: data.request_id, status: data.status, page_url: currentPageUrl, last_seen: liveChatLastSeen });
                var primaryColor = (chatbotConfig && chatbotConfig.customStyles && chatbotConfig.customStyles.primaryColor) || '#00477e';
                if (data.status === 'active' && data.moderator_name) {
                    ensureWaitingBadge('Connected to ' + data.moderator_name, true, primaryColor);
                } else {
                    ensureWaitingBadge('Waiting for agent...', false);
                }
                startLiveChatPolling();
            } else {
                liveChatRequested = false;
                liveChatRequestId = null;
                clearLiveChatState();
                removeWaitingBadge();
                stopLiveChatPolling();
            }
        } catch (e) {
            // Silent failure - don't block chat UI
        }
    }

    // Function to auto-request live chat
    async function requestLiveChat(userMessage = null) {
        if (liveChatRequested) {
            console.log('VYBR!S Widget: ⚠️ Live chat already requested, skipping duplicate');
            return;
        }
        liveChatRequested = true;
        console.log('VYBR!S Widget: 🚀 Requesting live chat...', {
            chatbotId: chatbotId,
            sessionId: sessionId,
            apiUrl: apiUrl,
            message: userMessage ? userMessage.substring(0, 50) : null
        });

        try {
            // Use /v1/live-chat/request to match backend router prefix /api/v1/live-chat
            const requestUrl = apiUrl + '/v1/live-chat/request';
            console.log('VYBR!S Widget: 📡 POST to', requestUrl);

            const res = await fetch(requestUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    chatbot_id: chatbotId,
                    session_id: sessionId,
                    message: userMessage, // Pass the user's message
                    page_url: getEffectivePageUrl()
                })
            });
            
            console.log('VYBR!S Widget: Response status', res.status, res.statusText);

            var data = {};
            try {
                data = await res.json();
                console.log('VYBR!S Widget: Response data', data);
            } catch (e) {
                console.error('VYBR!S Widget: Failed to parse JSON response', e);
                const text = await res.text();
                console.error('VYBR!S Widget: Response text', text.substring(0, 200));
                data = { detail: text || 'Unknown error' };
            }

            if (res.ok && (data.status === 'queued' || data.status === 'active')) {
                console.log('VYBR!S Widget: Live chat request queued successfully', data.request_id);
                liveChatRequestId = data.request_id || liveChatRequestId;

                // Add system message
                addMessage('Connecting you to an agent. Please wait...', 'bot');

                if (!liveChatLastSeen && chatHistory && chatHistory.length > 0) {
                    liveChatLastSeen = chatHistory[chatHistory.length - 1].timestamp || liveChatLastSeen;
                }
                saveLiveChatState({
                    request_id: data.request_id,
                    status: data.status || 'queued',
                    page_url: getEffectivePageUrl(),
                    last_seen: liveChatLastSeen
                });
                ensureWaitingBadge('⏳ Waiting for agent...');
                ingestLiveChatHistory();
                startLiveChatPolling();
            } else {
                console.error('VYBR!S Widget: Live chat request failed', {
                    status: res.status,
                    statusText: res.statusText,
                    data: data,
                    url: requestUrl
                });
                var msg = data.message || data.detail || "Sorry, we couldn't connect you to an agent. Please try again.";
                if (typeof msg === 'object') { msg = msg.msg || JSON.stringify(msg); }
                addMessage(msg, 'bot');
                liveChatRequested = false; // Allow retry
                clearLiveChatState();
                removeWaitingBadge();
                
                // Show error badge in header
                const header = document.getElementById('vybris-chat-header');
                if (header) {
                    let errorBadge = document.getElementById('vybris-error-badge');
                    if (!errorBadge) {
                        errorBadge = document.createElement('div');
                        errorBadge.id = 'vybris-error-badge';
                        errorBadge.style.cssText = `
                            background: rgba(220, 53, 69, 0.9);
                            color: #fff;
                            padding: 4px 12px;
                            font-size: 11px;
                            font-weight: 600;
                            text-align: center;
                            width: 100%;
                            box-sizing: border-box;
                        `;
                        errorBadge.innerHTML = '⚠️ Connection failed. Click to retry.';
                        errorBadge.style.cursor = 'pointer';
                        errorBadge.onclick = () => {
                            liveChatRequested = false;
                            errorBadge.remove();
                            requestLiveChat(userMessage);
                        };
                        chatWindow.insertBefore(errorBadge, header.nextSibling);
                    }
                }
            }
        } catch (e) {
            console.error('VYBR!S Widget: ❌ Live chat network error', {
                error: e,
                message: e.message,
                stack: e.stack,
                apiUrl: apiUrl,
                requestUrl: apiUrl + '/v1/live-chat/request',
                name: e.name,
                cause: e.cause
            });
            addMessage("Sorry, we couldn't connect you to an agent. Please try again.", 'bot');
            liveChatRequested = false; // Allow retry
            clearLiveChatState();
            removeWaitingBadge();
            
            // Show error badge in header
            const header = document.getElementById('vybris-chat-header');
            if (header) {
                let errorBadge = document.getElementById('vybris-error-badge');
                if (!errorBadge) {
                    errorBadge = document.createElement('div');
                    errorBadge.id = 'vybris-error-badge';
                    errorBadge.style.cssText = `
                        background: rgba(220, 53, 69, 0.9);
                        color: #fff;
                        padding: 4px 12px;
                        font-size: 11px;
                        font-weight: 600;
                        text-align: center;
                        width: 100%;
                        box-sizing: border-box;
                    `;
                    errorBadge.innerHTML = '⚠️ Connection failed. Click to retry.';
                    errorBadge.style.cursor = 'pointer';
                    errorBadge.onclick = () => {
                        liveChatRequested = false;
                        errorBadge.remove();
                        requestLiveChat(userMessage);
                    };
                    chatWindow.insertBefore(errorBadge, header.nextSibling);
                }
            }
        }
    }

    chatWindow.appendChild(inputWrapper);

    // Footer
    const footer = document.createElement('div');
    footer.style.cssText = `
        padding: 8px;
        text-align: center;
        font-size: 11px;
        color: #999;
        background: white;
        font-weight: 500;
        letter-spacing: 0.3px;
    `;
    footer.innerHTML = 'End-to-end secure';
    chatWindow.appendChild(footer);

    document.body.appendChild(chatWindow);

    // Fetch chatbot configuration
    async function fetchChatbotConfig() {
        try {
            const response = await fetch(`${apiUrl}/v1/chatbots/public/${chatbotId}`);
            if (response.ok) {
                const data = await response.json();
                chatbotConfig = data.config;
                chatbotName = data.name;

                // Load and apply embed theme (data-theme on script overrides config)
                var embedTheme = dataTheme || (chatbotConfig && chatbotConfig.embedTheme) || 'professional';
                if (!document.getElementById('vybris-widget-themes')) {
                    var themeLink = document.createElement('link');
                    themeLink.id = 'vybris-widget-themes';
                    themeLink.rel = 'stylesheet';
                    themeLink.href = apiUrl + '/static/widget-themes.css';
                    document.head.appendChild(themeLink);
                }
                ['vybris-theme-minimal', 'vybris-theme-professional', 'vybris-theme-playful', 'vybris-theme-healthcare', 'vybris-theme-ecommerce', 'vybris-theme-legal'].forEach(function(c) { chatWindow.classList.remove(c); });
                chatWindow.classList.add('vybris-theme-' + embedTheme);

                // Update Name
                const nameEl = document.getElementById('vybris-bot-name');
                if (nameEl) nameEl.innerText = chatbotName;

                // Update Avatar
                if (chatbotConfig?.customStyles?.avatarUrl) {
                    const avatarContainer = document.getElementById('vybris-avatar-container');
                    if (avatarContainer) {
                        const avatarUrl = chatbotConfig.customStyles.avatarUrl;
                        avatarContainer.innerHTML = `<img src="${apiUrl}${avatarUrl}?t=${Date.now()}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(255,255,255,0.3);">`;
                    }
                }

                // Apply custom styles: prefer data-* on script (embed overrides) or CSS vars, then config
                const dataPrimary = scriptTag.getAttribute('data-primary');
                const dataFont = scriptTag.getAttribute('data-font');
                const dataRadius = scriptTag.getAttribute('data-radius');
                const rootStyles = document.documentElement && getComputedStyle(document.documentElement);
                const cssPrimary = rootStyles ? rootStyles.getPropertyValue('--vybris-primary').trim() : '';
                const cssFont = rootStyles ? rootStyles.getPropertyValue('--vybris-font').trim() : '';
                const cssRadius = rootStyles ? rootStyles.getPropertyValue('--vybris-radius').trim() : '';
                const embedPrimary = dataPrimary || cssPrimary;
                const embedFont = dataFont || cssFont;
                const embedRadius = dataRadius || cssRadius;
                if (chatbotConfig && chatbotConfig.customStyles) {
                    const styles = Object.assign({}, chatbotConfig.customStyles);
                    if (embedPrimary) styles.primaryColor = embedPrimary;
                    if (embedFont) styles.fontFamily = embedFont;
                    if (embedRadius) styles.borderRadius = embedRadius;
                    // Default to Nijenhuis Blue if not set
                    const primaryColor = styles.primaryColor || '#00477e';
                    const secondaryColor = styles.secondaryColor || '#003366';
                    const gradientAngle = styles.gradientAngle || 135;
                    const colorType = styles.colorType || 'solid'; // Default to solid for consistency with new design

                    // Calculate background based on color type
                    let bgStyle;
                    if (colorType === 'solid') {
                        bgStyle = primaryColor;
                    } else {
                        bgStyle = `linear-gradient(${gradientAngle}deg, ${primaryColor}, ${secondaryColor})`;
                    }

                    // Apply colors to button and header
                    button.style.background = bgStyle;
                    const headerEl = document.getElementById('vybris-chat-header');
                    if (headerEl) headerEl.style.background = bgStyle;

                    const sendBtnEl = document.getElementById('vybris-chat-send');
                    if (sendBtnEl) sendBtnEl.style.background = primaryColor;

                    const inputEl = document.getElementById('vybris-chat-input');
                    if (inputEl) {
                        inputEl.onfocus = () => inputEl.style.borderColor = primaryColor;
                    }
                    const liveChatBtn = document.getElementById('vybris-live-chat-btn');
                    if (liveChatBtn) { liveChatBtn.style.color = '#111'; liveChatBtn.style.borderColor = '#333'; }
                }

                // Live chat button removed - auto-forward is handled in sendMessage

                console.log('VYBR!S Widget: Loaded config for', chatbotName);
            } else {
                console.warn('VYBR!S Widget: Could not load chatbot config');
            }
        } catch (e) {
            console.error('VYBR!S Widget: Error loading config', e);
        }
    }

    // Load config on init
    fetchChatbotConfig();

    // Toggle logic
    // isOpen is now defined at top scope
    let welcomeShown = false;
    let chatHistory = [];

    button.onclick = async () => {
        isOpen = !isOpen;

        if (isOpen) {
            // Show the chat window with animation
            chatWindow.style.display = 'flex';
            // Trigger reflow to ensure transition works
            chatWindow.offsetHeight;
            chatWindow.style.opacity = '1';
            chatWindow.style.transform = 'translateY(0)';
            syncLiveChatStatus();
        } else {
            // Hide with animation
            chatWindow.style.opacity = '0';
            chatWindow.style.transform = 'translateY(20px)';
            setTimeout(() => {
                chatWindow.style.display = 'none';
            }, 300);
        }

        button.style.transform = isOpen ? 'rotate(15deg)' : 'none';

        // Restore chat history on first open (or show "Start new chat" if chat was ended)
        if (isOpen && (!welcomeShown || getLiveChatEnded())) {
            if (!chatbotConfig) {
                await fetchChatbotConfig();
            }
            var lcRow = document.getElementById('vybris-live-chat-row');
            if (lcRow) lcRow.style.display = (chatbotConfig && chatbotConfig.enableLiveChat) ? 'block' : 'none';

            if (getLiveChatEnded()) {
                messages.innerHTML = '';
                var endedMsg = document.createElement('p');
                endedMsg.style.cssText = 'padding: 12px; color: #555; font-size: 14px;';
                endedMsg.textContent = 'Chat ended. Click below to start a new conversation.';
                messages.appendChild(endedMsg);
                var startNewBtn = document.createElement('button');
                startNewBtn.innerText = 'Start new chat';
                startNewBtn.style.cssText = 'margin: 8px 20px; padding: 10px 20px; background: #00477e; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;';
                startNewBtn.onclick = function() {
                    setLiveChatEnded(false);
                    clearChatHistory();
                    chatHistory = [];
                    welcomeShown = false;
                    messages.innerHTML = '';
                    try {
                        localStorage.removeItem(STORAGE_KEY_PREFIX + 'session');
                        sessionId = getSessionId();
                    } catch (err) {}
                    var welcomeMsg = (chatbotConfig && chatbotConfig.welcomeMessage) || 'Hello! How can I assist you today?';
                    addMessage(welcomeMsg, 'bot');
                    welcomeShown = true;
                };
                messages.appendChild(startNewBtn);
            } else {
                var savedHistory = loadChatHistory();
                if (savedHistory && savedHistory.length > 0) {
                    savedHistory.forEach(function(msg) {
                        addMessage(msg.text, msg.sender, false);
                    });
                    welcomeShown = true;
                    chatHistory = savedHistory;
                } else {
                    var welcomeMessage = (chatbotConfig && chatbotConfig.welcomeMessage) || 'Hello! How can I assist you today?';
                    addMessage(welcomeMessage, 'bot');
                    welcomeShown = true;
                }
            }
        }
    };

    async function doCloseChatWindow() {
        isOpen = false;
        chatWindow.style.opacity = '0';
        chatWindow.style.transform = 'translateY(20px)';
        setTimeout(function() {
            chatWindow.style.display = 'none';
        }, 300);
        button.style.transform = 'none';
    }

    closeBtn.onclick = function(e) {
        e.stopPropagation();
        if (liveChatRequested && (liveChatRequestId || (existingLiveChatState && existingLiveChatState.request_id))) {
            if (!confirm('Do you really want to close the chat? The conversation will end.')) {
                return;
            }
            var rid = liveChatRequestId || (existingLiveChatState && existingLiveChatState.request_id);
            fetch(apiUrl + '/v1/live-chat/close', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    chatbot_id: chatbotId,
                    session_id: sessionId,
                    request_id: rid
                })
            }).then(function(r) { return r.json(); }).catch(function() {});
            liveChatRequested = false;
            liveChatRequestId = null;
            clearLiveChatState();
            removeWaitingBadge();
            stopLiveChatPolling();
            setLiveChatEnded(true);
        }
        doCloseChatWindow();
    };

    // Message Logic
    async function sendMessage() {
        const text = input.value.trim();
        if (!text) return;

        // Update session activity
        updateSessionActivity();

        // Add user message
        addMessage(text, 'user');
        input.value = '';

        if (liveChatRequested) {
            await sendLiveChatUserMessage(text);
            return;
        }

        // Show typing indicator with animated bouncing dots
        const typingDiv = document.createElement('div');
        typingDiv.id = 'vybris-typing';
        typingDiv.innerHTML = `
            <div style="display: flex; align-items: center; gap: 4px;">
                <span class="vybris-dot" style="width: 8px; height: 8px; background: #888; border-radius: 50%; animation: vybris-bounce 1.4s ease-in-out infinite;"></span>
                <span class="vybris-dot" style="width: 8px; height: 8px; background: #888; border-radius: 50%; animation: vybris-bounce 1.4s ease-in-out 0.2s infinite;"></span>
                <span class="vybris-dot" style="width: 8px; height: 8px; background: #888; border-radius: 50%; animation: vybris-bounce 1.4s ease-in-out 0.4s infinite;"></span>
            </div>
        `;
        typingDiv.style.cssText = `
            max-width: 80%;
            padding: 12px 16px;
            border-radius: 12px;
            font-size: 14px;
            align-self: flex-start;
            background: #e9ecef;
        `;
        messages.appendChild(typingDiv);

        // API Call with session ID
        try {
            // Use /v1/nlp/process to match backend router prefix /api/v1/nlp
            const nlpUrl = `${apiUrl}/v1/nlp/process`;
            console.log('VYBR!S Widget: Calling NLP endpoint', nlpUrl);
            const response = await fetch(nlpUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify((function () {
                    var payload = {
                        text: text,
                        chatbot_id: chatbotId,
                        session_id: sessionId,
                        auto_request_live_chat: true,
                        context: { page_url: getEffectivePageUrl() }
                    };
                    if (pendingImage) {
                        payload.image_base64 = pendingImage.base64;
                        payload.image_mime_type = pendingImage.mime;
                        pendingImage = null;
                    }
                    return payload;
                })())
            });
            
            // Check response status first
            if (!response.ok) {
                console.error('VYBR!S Widget: NLP request failed', {
                    status: response.status,
                    statusText: response.statusText,
                    url: nlpUrl
                });
                const errorText = await response.text().catch(() => 'Unknown error');
                console.error('VYBR!S Widget: Error response', errorText);
                throw new Error(`NLP request failed: ${response.status} ${response.statusText}`);
            }
            
            let data;
            try {
                data = await response.json();
                console.log('VYBR!S Widget: NLP response received', {
                    status: response.status,
                    intent: data?.intent,
                    hasResponse: !!data?.response,
                    responsePreview: data?.response?.substring(0, 50),
                    fullData: data
                });
            } catch (e) {
                console.error('VYBR!S Widget: Failed to parse NLP response', e);
                const text = await response.text();
                console.error('VYBR!S Widget: Response text', text.substring(0, 500));
                throw new Error('Failed to parse NLP response');
            }

            // Remove typing indicator
            const typing = document.getElementById('vybris-typing');
            if (typing) typing.remove();

            // Check if response exists and is valid
            if (data && data.response) {
                addMessage(data.response, 'bot', true, data.explanation);

                // Auto-forward to live chat if intent indicates human request
                console.log('VYBR!S Widget: Checking intent for live chat', {
                    intent: data.intent,
                    isLiveChatIntent: data.intent === 'live_chat_auto_forward',
                    chatbotConfig: chatbotConfig ? { enableLiveChat: chatbotConfig.enableLiveChat } : null
                });

                if (data.intent === 'live_chat_auto_forward') {
                    console.log('VYBR!S Widget: ✅ live_chat_auto_forward intent detected!');
                    // Backend already validated enableLiveChat is enabled before returning this intent
                    // So we can trust it and call requestLiveChat immediately
                    console.log('VYBR!S Widget: Backend confirmed live chat is enabled, calling requestLiveChat()');

                    const serverQueued = data?.live_chat_request_id && (
                        data?.live_chat_status === 'queued' || data?.live_chat_status === 'active'
                    );
                    if (serverQueued) {
                        liveChatRequested = true;
                        liveChatRequestId = data.live_chat_request_id || liveChatRequestId;
                        if (!liveChatLastSeen && chatHistory && chatHistory.length > 0) {
                            liveChatLastSeen = chatHistory[chatHistory.length - 1].timestamp || liveChatLastSeen;
                        }
                        saveLiveChatState({
                            request_id: data.live_chat_request_id,
                            status: data.live_chat_status || 'queued',
                            page_url: getEffectivePageUrl(),
                            last_seen: liveChatLastSeen
                        });
                        var primaryColor = (chatbotConfig && chatbotConfig.customStyles && chatbotConfig.customStyles.primaryColor) || '#00477e';
                        if (data.live_chat_status === 'active' && data.moderator_name) {
                            ensureWaitingBadge('Connected to ' + data.moderator_name, true, primaryColor);
                        } else {
                            ensureWaitingBadge('⏳ Waiting for agent...', false);
                        }
                        ingestLiveChatHistory();
                        startLiveChatPolling();
                    } else {
                        try {
                            await requestLiveChat(text); // Pass the user's message - await to catch errors
                        } catch (error) {
                            console.error('VYBR!S Widget: Error calling requestLiveChat()', error);
                            liveChatRequested = false; // Allow retry on error
                        }
                    }
                } else {
                    console.log('VYBR!S Widget: Intent is not live_chat_auto_forward', {
                        intent: data.intent,
                        expected: 'live_chat_auto_forward',
                        receivedIntent: data.intent
                    });
                }
            } else {
                // Handle error response or missing response field
                const errorMsg = data?.detail || data?.error || "Sorry, I couldn't process that request.";
                addMessage(errorMsg, 'bot');
                console.error('VYBR!S Widget: ❌ API returned error or invalid response:', {
                    status: response?.status,
                    statusText: response?.statusText,
                    data: data,
                    hasResponse: !!data?.response,
                    hasIntent: !!data?.intent
                });
            }
        } catch (e) {
            console.error('VYBR!S Widget: ❌ Widget error in sendMessage():', {
                error: e,
                message: e.message,
                stack: e.stack,
                name: e.name
            });
            // Remove typing indicator
            const typing = document.getElementById('vybris-typing');
            if (typing) typing.remove();

            addMessage("Sorry, connection failed.", 'bot');
        }

        // Update session activity after response
        updateSessionActivity();
    }

    // Simple markdown to HTML converter
    function convertMarkdown(text) {
        // Escape HTML first for safety
        let html = text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');

        // Convert markdown syntax to HTML
        // Bold: **text** or __text__
        html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
        html = html.replace(/__(.+?)__/g, '<strong>$1</strong>');

        // Italic: *text* or _text_
        html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
        html = html.replace(/_(.+?)_/g, '<em>$1</em>');

        // Bullet points: lines starting with - or • or *
        html = html.replace(/^[\-\•\*]\s+(.+)$/gm, '<li>$1</li>');

        // Wrap consecutive <li> items in <ul>
        html = html.replace(/(<li>.+<\/li>\n?)+/g, '<ul style="margin: 4px 0; padding-left: 20px; list-style: disc;">$&</ul>');

        // Line breaks
        html = html.replace(/\n/g, '<br>');

        return html;
    }

    function addMessage(text, sender, saveToHistory = true, explanation = null) {
        const wrapper = document.createElement('div');
        wrapper.style.cssText = 'display: flex; flex-direction: column; align-items: ' + (sender === 'user' ? 'flex-end' : 'flex-start') + '; align-self: ' + (sender === 'user' ? 'flex-end' : 'flex-start') + '; max-width: 80%;';

        const div = document.createElement('div');

        // Initialize html with the original text
        let html = text;

        if (sender === 'bot' || sender === 'agent') {
            // For bot/agent messages, convert markdown to HTML
            // Links: [text](url)
            html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" style="color: #00477e; text-decoration: underline;">$1</a>');

            div.innerHTML = convertMarkdown(html);
        } else {
            div.innerText = text;
        }

        var primaryColor = (chatbotConfig && chatbotConfig.customStyles && chatbotConfig.customStyles.primaryColor) || '#00477e';
        var bgColor = sender === 'user' ? '#e0e4f0' : (sender === 'agent' ? hexToRgba(primaryColor, 0.2) : '#e0e0e0');
        div.style.cssText = `
            max-width: 80%;
            padding: 8px 12px;
            border-radius: 12px;
            font-size: 14px;
            align-self: ${sender === 'user' ? 'flex-end' : 'flex-start'};
            background: ${bgColor};
            color: #111;
            line-height: 1.5;
        `;
        div.querySelectorAll && div.querySelectorAll('*').forEach(function (el) {
            el.style.color = '#111';
        });
        wrapper.appendChild(div);

        if (explanation && (sender === 'bot' || sender === 'agent')) {
            var expBtn = document.createElement('button');
            expBtn.innerText = 'Why this response?';
            expBtn.style.cssText = 'margin-top: 4px; font-size: 11px; color: #666; background: none; border: none; cursor: pointer; text-decoration: underline; padding: 0; align-self: flex-start;';
            var expDiv = document.createElement('div');
            expDiv.innerText = explanation;
            expDiv.style.cssText = 'margin-top: 4px; font-size: 11px; color: #555; padding: 6px; background: rgba(0,0,0,0.05); border-radius: 6px; display: none;';
            expBtn.onclick = function () {
                expDiv.style.display = expDiv.style.display === 'none' ? 'block' : 'none';
            };
            wrapper.appendChild(expBtn);
            wrapper.appendChild(expDiv);
        }
        if ((sender === 'bot' || sender === 'agent') && chatbotConfig && chatbotConfig.enableFeedbackButtons) {
            var fbRow = document.createElement('div');
            fbRow.style.cssText = 'margin-top: 6px; display: flex; gap: 8px; align-items: center; align-self: flex-start;';
            var upBtn = document.createElement('button');
            upBtn.setAttribute('aria-label', 'Thumbs up');
            upBtn.innerHTML = '👍';
            upBtn.style.cssText = 'background: none; border: none; cursor: pointer; font-size: 16px; padding: 2px; opacity: 0.7;';
            upBtn.onmouseover = function () { upBtn.style.opacity = '1'; };
            upBtn.onmouseout = function () { upBtn.style.opacity = '0.7'; };
            var downBtn = document.createElement('button');
            downBtn.setAttribute('aria-label', 'Thumbs down');
            downBtn.innerHTML = '👎';
            downBtn.style.cssText = 'background: none; border: none; cursor: pointer; font-size: 16px; padding: 2px; opacity: 0.7;';
            downBtn.onmouseover = function () { downBtn.style.opacity = '1'; };
            downBtn.onmouseout = function () { downBtn.style.opacity = '0.7'; };
            function sendFeedback(rating) {
                upBtn.disabled = true;
                downBtn.disabled = true;
                fetch(apiUrl + '/v1/feedback', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        chatbot_id: chatbotId,
                        session_id: getSessionId(),
                        rating: rating
                    })
                }).catch(function () {});
            }
            upBtn.onclick = function () { sendFeedback('thumbs_up'); };
            downBtn.onclick = function () { sendFeedback('thumbs_down'); };
            fbRow.appendChild(upBtn);
            fbRow.appendChild(downBtn);
            wrapper.appendChild(fbRow);
        }
        messages.appendChild(wrapper);
        messages.scrollTop = messages.scrollHeight;

        // Save to chat history
        if (saveToHistory) {
            chatHistory.push({ text, sender, timestamp: Date.now() });
            saveChatHistory(chatHistory);
        }
    }

    sendBtn.onclick = sendMessage;
    input.onkeypress = (e) => {
        if (e.key === 'Enter') sendMessage();
    };

})();

/**
 * VYBR!S Chat Web Component (Phase 3)
 *
 * Custom element: <vybris-chat data-id="CHATBOT_ID" data-url="API_BASE_URL"></vybris-chat>
 *
 * Usage:
 *   <script src="https://yoursite.com/vybris/api/static/vybris-chat.js"></script>
 *   <vybris-chat data-id="your-chatbot-id" data-url="https://yoursite.com/vybris/api"></vybris-chat>
 *
 * Or data-url can be omitted; it will be derived from the script's origin.
 */
(function () {
    if (typeof customElements === "undefined" || customElements.get("vybris-chat")) {
        return;
    }

    const template = document.createElement("template");
    template.innerHTML = "<slot></slot>";

    class VybrChat extends HTMLElement {
        static get observedAttributes() {
            return ["data-id", "data-url"];
        }

        connectedCallback() {
            const id = this.getAttribute("data-id");
            if (!id) {
                console.error("VYBR!S: data-id is required on <vybris-chat>");
                return;
            }

            let baseUrl = this.getAttribute("data-url") || "";
            if (!baseUrl) {
                const script = document.currentScript || document.querySelector('script[src*="vybris-chat.js"]');
                if (script && script.src) {
                    try {
                        const u = new URL(script.src);
                        baseUrl = u.origin + u.pathname.replace(/\/static\/vybris-chat\.js.*$/, "");
                    } catch (_) {}
                }
                baseUrl = baseUrl || "/vybris/api";
            }
            baseUrl = baseUrl.replace(/\/$/, "");

            const script = document.createElement("script");
            script.setAttribute("data-id", id);
            script.setAttribute("data-url", baseUrl);
            const theme = this.getAttribute("data-theme");
            if (theme) script.setAttribute("data-theme", theme);
            script.src = baseUrl + "/static/widget.js";
            this.appendChild(script);
        }
    }

    customElements.define("vybris-chat", VybrChat);
})();

# VYBR!S Plugins

Plugins extend the platform with custom integrations, agents, or handlers.

## Structure

Each plugin is a directory under `plugins/` with:

- `plugin.json` - metadata (id, name, version, entry_point)
- `handler.py` (or entry_point module) - must define `register(registry)` function

## plugin.json

```json
{
  "id": "my_plugin",
  "name": "My Plugin",
  "version": "1.0.0",
  "entry_point": "handler"
}
```

- `entry_point`: module name within the plugin (e.g. "handler" loads `plugins/my_plugin/handler.py`)

## register(registry)

Your module must define:

```python
def register(registry):
    from services.plugin_registry import PluginRegistry
    registry.register_integration("my_type", MyIntegrationClass)
```

`MyIntegrationClass` should follow the same interface as built-in integrations (e.g. `__init__(self, config)`, `process_text(self, text)` for integrations used in RAG flow).

## Example

See `example_plugin/` for a minimal plugin that registers a stub integration.

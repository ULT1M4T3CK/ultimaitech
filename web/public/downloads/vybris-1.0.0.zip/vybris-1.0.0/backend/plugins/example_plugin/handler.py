"""
Example plugin - registers a stub integration.
"""


class ExampleIntegration:
    """Stub integration for demonstration."""

    def __init__(self, config: dict):
        self.config = config

    def process_text(self, text: str) -> str:
        return ""

    def send_message(self, to: str, message: str) -> dict:
        return {"success": False, "error": "Example stub"}


def register(registry):
    registry.register_integration("example", ExampleIntegration)

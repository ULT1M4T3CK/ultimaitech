#!/usr/bin/env python3
"""
One-off migration: add url_template to custom_actions (and optionally drop old url column).

Run from backend directory (loads .env from backend if present):
  python scripts/migrate_custom_actions_url_template.py

With explicit env:
  POSTGRES_HOST=... POSTGRES_PORT=... POSTGRES_DB=... POSTGRES_USER=... POSTGRES_PASSWORD=... python scripts/migrate_custom_actions_url_template.py
"""
import os
import sys

# Add backend root to path so we can import services.database
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

# Load .env from backend dir or project root (VYBR!S) if present
_env_path = os.path.join(backend_dir, ".env")
if not os.path.isfile(_env_path):
    _env_path = os.path.join(os.path.dirname(backend_dir), ".env")
if os.path.isfile(_env_path):
    with open(_env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                k, v = k.strip(), v.strip().strip("'\"")
                if k and v and not os.environ.get(k):
                    os.environ[k] = v

from services.database.base import get_db_connection


def migrate():
    with get_db_connection() as conn:
        cur = conn.cursor()
        # Check if url_template already exists
        cur.execute("""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = 'custom_actions' AND column_name = 'url_template'
        """)
        if cur.fetchone():
            print("custom_actions.url_template already exists. Nothing to do.")
            return
        # Check for old url column
        cur.execute("""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = 'custom_actions' AND column_name = 'url'
        """)
        has_url = cur.fetchone()
        cur.execute("ALTER TABLE custom_actions ADD COLUMN url_template TEXT")
        if has_url:
            cur.execute("""
                UPDATE custom_actions SET url_template = COALESCE(url, '')
            """)
            cur.execute("ALTER TABLE custom_actions DROP COLUMN IF EXISTS url")
            print("Added url_template, copied from url, dropped url.")
        cur.execute("""
            UPDATE custom_actions SET url_template = '' WHERE url_template IS NULL
        """)
        cur.execute("ALTER TABLE custom_actions ALTER COLUMN url_template SET NOT NULL")
        if not has_url:
            print("Added url_template (default '').")
    print("Migration completed successfully.")


if __name__ == "__main__":
    try:
        migrate()
    except Exception as e:
        print(f"Migration failed: {e}", file=sys.stderr)
        sys.exit(1)

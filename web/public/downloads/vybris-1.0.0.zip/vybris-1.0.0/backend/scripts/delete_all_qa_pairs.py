#!/usr/bin/env python3
"""
Script to delete all Q&A pairs from Qdrant.
This clears user corrections while preserving scraped website content.
"""
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from qdrant_client import QdrantClient
from qdrant_client.http.models import Filter, FieldCondition, MatchValue, FilterSelector

# Configuration
QDRANT_HOST = os.getenv("QDRANT_HOST", "localhost")
QDRANT_PORT = int(os.getenv("QDRANT_PORT", 6333))
QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")
COLLECTION_NAME = "chatbot_knowledge"


def delete_all_qa_pairs():
    """Delete all Q&A pairs from Qdrant."""
    print(f"Connecting to Qdrant at {QDRANT_HOST}:{QDRANT_PORT}...")
    
    if QDRANT_API_KEY:
        client = QdrantClient(host=QDRANT_HOST, port=QDRANT_PORT, api_key=QDRANT_API_KEY)
    else:
        client = QdrantClient(host=QDRANT_HOST, port=QDRANT_PORT)
    
    # First, count how many Q&A pairs exist
    print("Counting Q&A pairs...")
    scroll_result = client.scroll(
        collection_name=COLLECTION_NAME,
        scroll_filter=Filter(
            must=[FieldCondition(key="type", match=MatchValue(value="qa"))]
        ),
        limit=1000,
        with_payload=True
    )
    
    points = scroll_result[0]
    count = len(points)
    
    if count == 0:
        print("No Q&A pairs found. Nothing to delete.")
        return
    
    print(f"Found {count} Q&A pairs to delete.")
    
    # Show some examples
    print("\nExamples of Q&A pairs to be deleted:")
    for i, p in enumerate(points[:5]):
        question = p.payload.get('original_question', 'N/A')[:50]
        answer = p.payload.get('text', 'N/A')[:50]
        chatbot_id = p.payload.get('chatbot_id', 'N/A')
        print(f"  {i+1}. [{chatbot_id}] Q: {question}... A: {answer}...")
    
    if count > 5:
        print(f"  ... and {count - 5} more")
    
    # Delete all Q&A pairs
    print("\nDeleting all Q&A pairs...")
    client.delete(
        collection_name=COLLECTION_NAME,
        points_selector=FilterSelector(
            filter=Filter(
                must=[FieldCondition(key="type", match=MatchValue(value="qa"))]
            )
        )
    )
    
    print(f"\nSuccessfully deleted {count} Q&A pairs.")
    print("Scraped website content has been preserved.")


if __name__ == "__main__":
    delete_all_qa_pairs()

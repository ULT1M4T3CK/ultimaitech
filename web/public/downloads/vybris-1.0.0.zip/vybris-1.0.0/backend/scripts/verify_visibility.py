
import sys
import os
import asyncio
from unittest.mock import MagicMock, patch
import importlib.metadata

# Mock importlib.metadata.version to lie about email-validator being installed
original_version = importlib.metadata.version

def side_effect_version(package_name):
    if package_name == 'email-validator':
        return '2.1.0'
    return original_version(package_name)

importlib.metadata.version = MagicMock(side_effect=side_effect_version)

# Mock playwright BEFORE importing routers that depend on it
sys.modules['playwright'] = MagicMock()
sys.modules['playwright.async_api'] = MagicMock()
sys.modules['email_validator'] = MagicMock()  # Mock for pydantic[email]

# Add backend to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from routers import pipeline, crm
from fastapi import HTTPException

# Mock Data
ADMIN_USER = {'id': 'admin_1', 'role': 'admin', 'is_super_user': True}
PARTNER_USER = {'id': 'partner_1', 'role': 'partner', 'is_super_user': False}
OTHER_USER_ID = 'user_2'

async def verify_pipeline_visibility():
    print("--- Verifying Pipeline Visibility ---")
    
    # Mock DB
    with patch('routers.pipeline.PipelineDB') as mock_db:
        mock_db.get_by_owner.return_value = [{'id': 'stage_1', 'name': 'Stage 1'}]
        
        # 1. Admin accessing own pipeline
        print("Test 1: Admin accessing own pipeline...", end=" ")
        await pipeline.get_pipeline_stages(user_id=None, current_user=ADMIN_USER)
        mock_db.get_by_owner.assert_called_with(ADMIN_USER['id'])
        print("PASS")
        
        # 2. Admin accessing OTHER user's pipeline
        print("Test 2: Admin accessing OTHER user's pipeline...", end=" ")
        await pipeline.get_pipeline_stages(user_id=OTHER_USER_ID, current_user=ADMIN_USER)
        mock_db.get_by_owner.assert_called_with(OTHER_USER_ID)
        print("PASS")
        
        # 3. Partner accessing own pipeline
        print("Test 3: Partner accessing own pipeline...", end=" ")
        await pipeline.get_pipeline_stages(user_id=None, current_user=PARTNER_USER)
        mock_db.get_by_owner.assert_called_with(PARTNER_USER['id'])
        print("PASS")
        
        # 4. Partner attempting to access OTHER user's pipeline
        print("Test 4: Partner accessing OTHER user's pipeline (Should Fail)...", end=" ")
        try:
            await pipeline.get_pipeline_stages(user_id=OTHER_USER_ID, current_user=PARTNER_USER)
            print("FAIL (Did not raise exception)")
        except HTTPException as e:
            if e.status_code == 403:
                print("PASS (Raised 403)")
            else:
                print(f"FAIL (Raised {e.status_code})")
        except Exception as e:
            print(f"FAIL (Raised wrong exception: {e})")

async def verify_crm_visibility():
    print("\n--- Verifying CRM Lead Visibility ---")
    
    with patch('routers.crm.CRMLeadDB') as mock_lead_db:
        mock_lead_db.get_all.return_value = []
        mock_lead_db.count.return_value = 0
        
        # 1. Admin listing leads (no filter)
        print("Test 1: Admin listing all leads...", end=" ")
        await crm.list_leads(
            limit=10, offset=0, status=None, priority=None, account_owner_id=None,
            search=None, sort_by='created_at', sort_order='desc', view_as_user_id=None,
            current_user=ADMIN_USER
        )
        # Verify effective_owner_id passed to DB is None (meaning all) or as logic dictates
        # The logic was: if is_admin and view_as_user_id is None -> effective_owner_id remains whatever account_owner_id was (None)
        call_args = mock_lead_db.get_all.call_args[1]
        if call_args['account_owner_id'] is None:
             print("PASS")
        else:
             print(f"FAIL (Expected None, got {call_args['account_owner_id']})")

        # 2. Admin listing leads as specific user
        print("Test 2: Admin viewing as specific user...", end=" ")
        await crm.list_leads(
            limit=10, offset=0, status=None, priority=None, account_owner_id=None,
            search=None, sort_by='created_at', sort_order='desc', view_as_user_id=OTHER_USER_ID,
            current_user=ADMIN_USER
        )
        call_args = mock_lead_db.get_all.call_args[1]
        if call_args['account_owner_id'] == OTHER_USER_ID:
             print("PASS")
        else:
             print(f"FAIL (Expected {OTHER_USER_ID}, got {call_args['account_owner_id']})")
             
        # 3. Partner listing leads (should force own ID)
        print("Test 3: Partner listing leads...", end=" ")
        await crm.list_leads(
            limit=10, offset=0, status=None, priority=None, account_owner_id=None,
            search=None, sort_by='created_at', sort_order='desc', view_as_user_id=None,
            current_user=PARTNER_USER
        )
        call_args = mock_lead_db.get_all.call_args[1]
        if call_args['account_owner_id'] == PARTNER_USER['id']:
             print("PASS")
        else:
             print(f"FAIL (Expected {PARTNER_USER['id']}, got {call_args['account_owner_id']})")

        # 4. Partner trying to filter by OTHER user (should be overridden to self)
        print("Test 4: Partner trying to view other user's leads...", end=" ")
        await crm.list_leads(
            limit=10, offset=0, status=None, priority=None, account_owner_id=OTHER_USER_ID,
            search=None, sort_by='created_at', sort_order='desc', view_as_user_id=None,
            current_user=PARTNER_USER
        )
        call_args = mock_lead_db.get_all.call_args[1]
        if call_args['account_owner_id'] == PARTNER_USER['id']:
             print("PASS")
        else:
             print(f"FAIL (Expected {PARTNER_USER['id']}, got {call_args['account_owner_id']})")

async def main():
    try:
        await verify_pipeline_visibility()
        await verify_crm_visibility()
    except Exception as e:
        print(f"\nFATAL ERROR: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())

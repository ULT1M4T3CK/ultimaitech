
import sys
import os
import asyncio
from unittest.mock import MagicMock, patch

# Mock dependencies that might be missing or troublesome
sys.modules['playwright'] = MagicMock()
sys.modules['playwright.async_api'] = MagicMock()
sys.modules['email_validator'] = MagicMock()
import importlib.metadata
original_version = importlib.metadata.version
def side_effect_version(package_name):
    if package_name == 'email-validator':
        return '2.1.0'
    return original_version(package_name)
importlib.metadata.version = MagicMock(side_effect=side_effect_version)

# Add backend to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from routers.nlp.analytics import _update_analytics_background

async def verify_history():
    print("--- Verifying Chat History Logic ---")
    
    # Mock bot data
    bot = {'data': {'conversations': 0}}
    
    # Test Data
    SESSION_ID = "test_hist_session_1"
    CHATBOT_ID = "bot_1"
    USER_QUERY = "How much does it cost?"
    BOT_RESPONSE = "It costs $50."
    INTENT = "pricing"
    
    # Mock DBs
    with patch('services.database.MessageDB') as MockMessageDB, \
         patch('services.database.SessionDB') as MockSessionDB, \
         patch('services.perplexity_service.perplexity_service') as mock_perplexity:
        
        # Setup mocks
        mock_perplexity.is_enabled.return_value = True
        # Mock async return value
        f = asyncio.Future()
        f.set_result("Pricing Questions")
        mock_perplexity.generate_response.return_value = f
        
        # Mock SessionDB calls
        MockSessionDB.get_or_create.return_value = {'session_id': SESSION_ID, 'category': 'General'}
        MockSessionDB.get_active_conversations_count.return_value = 1 # Return int to avoid comparison error
        
        print("Test 1: Saving message via analytics task...", end=" ")
        
        # Run background task logic
        await _update_analytics_background(
            chatbot_id=CHATBOT_ID,
            session_id=SESSION_ID,
            chatbot_name="TestBot",
            query_text=USER_QUERY,
            intent=INTENT,
            confidence=0.9,
            relevance_score=0.8,
            grounding_score=0.8,
            response_time=100,
            response_text=BOT_RESPONSE,
            bot=bot
        )
        
        # Verify MessageDB.create was called twice (User + Assistant)
        if MockMessageDB.create.call_count == 2:
            print("PASS (Called create 2 times)")
            # Verify content of calls
            calls = MockMessageDB.create.call_args_list
            user_call = calls[0][0][0]
            bot_call = calls[1][0][0]
            
            if user_call['role'] == 'user' and user_call['content'] == USER_QUERY:
                print("   -> User message verified")
            else:
                print(f"   -> FAIL User message mismatch: {user_call}")
                
            if bot_call['role'] == 'assistant' and bot_call['content'] == BOT_RESPONSE:
                print("   -> Bot message verified")
            else:
                print(f"   -> FAIL Bot message mismatch: {bot_call}")
        else:
            print(f"FAIL (Called create {MockMessageDB.create.call_count} times, expected 2)")

        # Verify Session Categorization
        print("Test 2: Verifying Session Categorization triggered...", end=" ")
        # Check if update_category was called
        if MockSessionDB.update_category.called:
            print(f"PASS (Called with {MockSessionDB.update_category.call_args})")
        else:
            print("FAIL (update_category not called)")
            
        # 3. Verify Unknown Interaction Flagging
        print("Test 3: Verifying Unknown Flag...", end=" ")
        UNKNOWN_SESSION_ID = "test_hist_unknown_1"
        MockSessionDB.reset_mock()
        MockMessageDB.reset_mock()
        MockSessionDB.get_or_create.return_value = {'session_id': UNKNOWN_SESSION_ID}
        
        # Simulate unknown
        await _update_analytics_background(
            chatbot_id=CHATBOT_ID,
            session_id=UNKNOWN_SESSION_ID,
            chatbot_name="TestBot",
            query_text="sdfsdf",
            intent="unknown", 
            confidence=0.1,
            relevance_score=0.0,
            grounding_score=0.0,
            response_time=100,
            response_text="I don't understand.",
            bot=bot
        )
        
        if MockSessionDB.mark_unknown_interaction.called:
             print("PASS (mark_unknown_interaction called)")
        else:
             print("FAIL (mark_unknown_interaction NOT called)")



if __name__ == "__main__":
    asyncio.run(verify_history())

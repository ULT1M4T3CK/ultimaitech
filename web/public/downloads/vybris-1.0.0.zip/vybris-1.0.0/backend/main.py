from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from typing import List
from routers import dialogue, auth, chatbots, scraper_v2 as scraper, users, knowledge, academy, logs, integrations, mfa, compliance, crm, qualifications, pipeline, automations, email_sequences, onboarding, actions, webhooks, history, live_chat, verification, elias, blueprints, workflows, analytics, feedback
from routers import ws_chat
from routers import cors_origins as cors_origins_router
from routers.nlp import router as nlp_router
from monitoring import health as monitoring_health
from middleware.security_headers import SecurityHeadersMiddleware
from middleware.timeout import TimeoutMiddleware
from shared.errors import VybrisError
from shared.error_tracking import error_tracker, ErrorCategory
import os
import logging
import traceback
import uuid
from datetime import datetime

from fastapi.staticfiles import StaticFiles
import signal
import asyncio
from contextlib import asynccontextmanager

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Track in-flight requests for graceful shutdown
_in_flight_requests = 0
_shutdown_event = asyncio.Event()
_request_lock = asyncio.Lock()

# Graceful shutdown lifecycle
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Handle application startup and shutdown."""
    # Startup
    logger.info("Starting VYBR!S API...")
    
    # Initialize database tables with retry (Postgres may not be ready yet in Docker)
    from services.database import init_database
    max_db_attempts = int(os.getenv("DB_STARTUP_ATTEMPTS", "15"))
    db_attempt_interval = float(os.getenv("DB_STARTUP_INTERVAL", "2.0"))
    for attempt in range(1, max_db_attempts + 1):
        try:
            init_database()
            logger.info("Database tables initialized successfully")
            try:
                from services.plugin_registry import apply_plugin_integrations
                apply_plugin_integrations()
                logger.info("Plugin integrations applied")
            except Exception as pe:
                logger.warning("Plugin load failed: %s", pe)
            break
        except Exception as e:
            logger.warning(f"Database initialization attempt {attempt}/{max_db_attempts} failed: {e}")
            if attempt == max_db_attempts:
                logger.error("Database initialization failed after all retries")
                raise
            await asyncio.sleep(db_attempt_interval)
    
    yield
    # Shutdown
    logger.info("Shutting down VYBR!S API...")
    
    # Wait for in-flight requests (max 30 seconds)
    max_wait = 30
    wait_time = 0
    while _in_flight_requests > 0 and wait_time < max_wait:
        logger.info(f"Waiting for {_in_flight_requests} in-flight requests to complete...")
        await asyncio.sleep(1)
        wait_time += 1
    
    if _in_flight_requests > 0:
        logger.warning(f"Shutting down with {_in_flight_requests} requests still in flight")
    
    # Close database connection pool
    try:
        from services.database.pool import close_pool
        close_pool()
        logger.info("Database connection pool closed")
    except Exception as e:
        logger.error(f"Error closing database pool: {e}")
    
    # Flush logs
    logging.shutdown()
    logger.info("Shutdown complete")

# Initialize FastAPI app
app = FastAPI(
    title="VYBRFA!S API",
    description="Backend API for VYBR!S AI Platform",
    version="3.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS Configuration
# SECURITY: Explicit origins only - wildcard incompatible with allow_credentials=True
# Origins are now loaded dynamically from database (auto-added when websites are scraped)
# Static origins from environment variable or defaults are also included

# Import CORS service for dynamic origins
from services.cors_service import cors_service

# Static origins (loaded at startup)
allowed_origins_env = os.getenv("ALLOWED_ORIGINS", "")
if allowed_origins_env:
    static_origins = [origin.strip() for origin in allowed_origins_env.split(",") if origin.strip()]
else:
    static_origins = [
        "http://localhost:3000",
        "http://localhost:80",
        "http://localhost",
        "http://localhost:8888",    # Local development widget testing
        "https://ultimaitech.com",
        "https://www.ultimaitech.com",
        "http://13.50.101.58:3000",  # AWS EC2 direct access
    ]

def get_allowed_origins() -> List[str]:
    """Get all allowed CORS origins (static + dynamic from database)"""
    return cors_service.get_allowed_origins(include_static=True)

# Initial origins for CORSMiddleware (will be supplemented by PublicEndpointCORSMiddleware)
origins = static_origins

# Cloudflare/Proxy compatibility: Rewrite /v1/* to /api/v1/* via middleware
# This handles cases where requests bypass nginx rewrite (direct backend access or Cloudflare routing)
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.types import ASGIApp

class PathRewriteMiddleware(BaseHTTPMiddleware):
    """Rewrite /v1/* paths to /api/v1/* for compatibility"""
    async def dispatch(self, request: Request, call_next):
        original_path = request.url.path
        if original_path.startswith("/v1/") and not original_path.startswith("/api/v1/"):
            # Rewrite the path in the scope - need to modify the underlying scope
            # Create a new scope with modified path
            new_path = original_path.replace("/v1/", "/api/v1/", 1)
            # Modify the request's scope
            request.scope["path"] = new_path
            request.scope["raw_path"] = new_path.encode()
            # Rebuild the URL in the request
            from starlette.datastructures import URL
            new_url = URL(
                scheme=request.url.scheme,
                netloc=request.url.netloc,
                path=new_path,
                query=request.url.query,
                fragment=request.url.fragment
            )
            # Replace the URL
            request._url = new_url
        return await call_next(request)

# Request ID middleware - adds request ID to all requests
class RequestIDMiddleware(BaseHTTPMiddleware):
    """Add request ID to all requests for error tracking and correlation."""
    async def dispatch(self, request: Request, call_next):
        global _in_flight_requests
        
        # Check if shutdown is in progress
        if _shutdown_event.is_set():
            return JSONResponse(
                status_code=503,
                content={"detail": "Service is shutting down"}
            )
        
        # Track in-flight request
        async with _request_lock:
            _in_flight_requests += 1
        
        try:
            # Generate or use existing request ID
            request_id = request.headers.get("X-Request-ID") or error_tracker.generate_request_id()
            request.state.request_id = request_id
            
            # Add to response headers
            response = await call_next(request)
            response.headers["X-Request-ID"] = request_id
            return response
        finally:
            # Decrement in-flight requests
            async with _request_lock:
                _in_flight_requests -= 1

# Signal handlers for graceful shutdown
def setup_signal_handlers():
    """Setup signal handlers for graceful shutdown."""
    def signal_handler(signum, frame):
        logger.info(f"Received signal {signum}, initiating graceful shutdown...")
        _shutdown_event.set()
    
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

# Setup signal handlers
setup_signal_handlers()

# Add path rewrite middleware FIRST (before other middlewares)
# Note: This middleware rewrites request paths in the ASGI scope
app.add_middleware(PathRewriteMiddleware)

# Add request ID middleware
app.add_middleware(RequestIDMiddleware)

# Add compression middleware (reduces response size by 60-80%)
app.add_middleware(GZipMiddleware, minimum_size=1000)

# Add security headers middleware
app.add_middleware(SecurityHeadersMiddleware)

# Add request timeout middleware (30s default, excludes long-running endpoints)
app.add_middleware(TimeoutMiddleware, timeout=int(os.getenv("REQUEST_TIMEOUT_SECONDS", "30")))

# Custom CORS middleware for public endpoints and dynamic origin checking
class PublicEndpointCORSMiddleware(BaseHTTPMiddleware):
    """Allow CORS from any origin for public endpoints, check database for other endpoints"""
    async def dispatch(self, request: Request, call_next):
        origin = request.headers.get("Origin")
        
        # Check if this is a public endpoint
        is_public_endpoint = (
            request.url.path.startswith("/api/v1/chatbots/public/") or
            request.url.path.startswith("/v1/chatbots/public/") or
            request.url.path.startswith("/api/v1/dialogue/public/") or
            request.url.path.startswith("/v1/dialogue/public/")
        )
        
        # Check if this is a widget-accessible endpoint (NLP processing + live-chat for widgets)
        is_widget_endpoint = (
            request.url.path == "/api/v1/nlp/process" or
            request.url.path == "/v1/nlp/process" or
            request.url.path.startswith("/api/v1/nlp/process") or
            request.url.path.startswith("/v1/nlp/process") or
            request.url.path.startswith("/api/v1/live-chat/request") or
            request.url.path.startswith("/v1/live-chat/request") or
            request.url.path.startswith("/api/v1/live-chat/messages") or
            request.url.path.startswith("/v1/live-chat/messages") or
            request.url.path.startswith("/api/v1/live-chat/status") or
            request.url.path.startswith("/v1/live-chat/status") or
            request.url.path.startswith("/api/v1/live-chat/close") or
            request.url.path.startswith("/v1/live-chat/close") or
            request.url.path.startswith("/api/v1/feedback") or
            request.url.path.startswith("/v1/feedback")
        )
        
        # Handle preflight OPTIONS request
        if request.method == "OPTIONS":
            if is_public_endpoint or is_widget_endpoint:
                # Public and widget endpoints allow any origin
                # Widget endpoints are embedded on external websites, so they need to accept any origin
                response = JSONResponse(content={})
                response.headers["Access-Control-Allow-Origin"] = origin or "*"
                response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
                response.headers["Access-Control-Allow-Headers"] = "Content-Type, Accept"
                response.headers["Access-Control-Max-Age"] = "3600"
                return response
            elif origin:
                # Check if origin is in allowed list (static + database)
                allowed_origins = get_allowed_origins()
                if origin in allowed_origins:
                    response = JSONResponse(content={})
                    response.headers["Access-Control-Allow-Origin"] = origin
                    response.headers["Access-Control-Allow-Credentials"] = "true"
                    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, PATCH, OPTIONS"
                    response.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type, X-Requested-With, Accept"
                    response.headers["Access-Control-Max-Age"] = "3600"
                    return response
        
        # Process the request
        response = await call_next(request)
        
        # Add CORS headers for public and widget endpoints (allow any origin)
        if (is_public_endpoint or is_widget_endpoint) and origin:
            # Widget endpoints are embedded on external websites, so they need to accept any origin
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
            response.headers["Access-Control-Allow-Headers"] = "Content-Type, Accept"
        elif origin:
            # For other endpoints, check if origin is allowed
            allowed_origins = get_allowed_origins()
            if origin in allowed_origins:
                response.headers["Access-Control-Allow-Origin"] = origin
                response.headers["Access-Control-Allow-Credentials"] = "true"
        
        return response


# CSRF protection for cookie-based auth (double-submit token)
class CSRFMiddleware(BaseHTTPMiddleware):
    """Validate CSRF token for unsafe methods when auth cookie is present."""
    async def dispatch(self, request: Request, call_next):
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            access_cookie = request.cookies.get("access_token")
            if access_cookie:
                csrf_cookie = request.cookies.get("csrf_token")
                csrf_header = request.headers.get("X-CSRF-Token")
                exempt_paths = (
                    "/api/v1/login",
                    "/api/v1/login-mfa",
                    "/api/v1/refresh",
                    "/v1/login",
                    "/v1/login-mfa",
                    "/v1/refresh",
                    "/api/v1/live-chat/request",
                    "/v1/live-chat/request",
                    "/api/v1/live-chat/messages",
                    "/v1/live-chat/messages",
                    "/api/v1/live-chat/status",
                    "/v1/live-chat/status",
                    "/api/v1/live-chat/close",
                    "/v1/live-chat/close",
                    "/api/v1/nlp/process",
                    "/v1/nlp/process",
                    "/api/v1/feedback",
                    "/v1/feedback",
                )
                if not request.url.path.startswith(exempt_paths):
                    if not csrf_cookie or not csrf_header or csrf_cookie != csrf_header:
                        return JSONResponse(
                            status_code=403,
                            content={
                                "error": "CSRF_ERROR",
                                "message": "CSRF token missing or invalid"
                            }
                        )
        return await call_next(request)

# Add public endpoint CORS middleware BEFORE the main CORS middleware
# This middleware handles both public endpoints (allows any origin) and checks
# database origins for other endpoints
app.add_middleware(PublicEndpointCORSMiddleware)

# Add CSRF middleware after CORS handling
app.add_middleware(CSRFMiddleware)

# Use standard CORSMiddleware for static origins
# PublicEndpointCORSMiddleware (added before this) handles dynamic origins from database
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # Static origins (database origins handled by PublicEndpointCORSMiddleware)
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Requested-With", "Accept"],
)

# Register routers
app.include_router(auth.router)

# Cloudflare/Proxy compatibility: Also handle /v1/* routes (when nginx rewrite is bypassed)
# Create a separate router with /v1 prefix that includes the same auth routes
from fastapi import APIRouter
from routers import auth

# Create a new router with /v1 prefix and include all auth routes
v1_auth_router = APIRouter(prefix="/v1", tags=["auth"])

# Copy all routes from auth.router to v1_auth_router
# We'll do this by re-importing and registering the handlers
from routers.auth import login, login_with_mfa, logout, refresh_token, read_users_me, change_password
from fastapi import Depends, Response
from typing import Annotated
from fastapi.security import OAuth2PasswordRequestForm

v1_auth_router.post("/login")(login)
v1_auth_router.post("/login-mfa")(login_with_mfa)
v1_auth_router.post("/logout")(logout)
v1_auth_router.post("/refresh")(refresh_token)
v1_auth_router.get("/me")(read_users_me)
v1_auth_router.post("/change-password")(change_password)

app.include_router(v1_auth_router)
app.include_router(mfa.router)  # MFA endpoints (SOC 2 CC5.2)
app.include_router(chatbots.router)
app.include_router(scraper.router)
app.include_router(nlp_router)
app.include_router(dialogue.router)
app.include_router(users.router)
app.include_router(knowledge.router)  # Knowledge Base CRUD

app.include_router(academy.router) # Academy Content
app.include_router(logs.router)  # System Logs
app.include_router(integrations.router)  # Third-party Integrations
app.include_router(compliance.router)  # SOC 2 Compliance Monitoring
app.include_router(history.router) # Chat History & Categorization
app.include_router(live_chat.router)  # Live Chat request queue (widget → moderators)
app.include_router(crm.router)  # Sales CRM
app.include_router(qualifications.router)  # Sales Chatbot Qualification Frameworks
app.include_router(pipeline.router)  # Sales Pipeline Stages
app.include_router(automations.router)  # Sales Automation Rules
app.include_router(email_sequences.router)  # Sales Email Sequences
app.include_router(onboarding.router)  # Client Onboarding Workflows
app.include_router(actions.router) # Custom Actions
app.include_router(verification.router) # OTP Verification for Actions
app.include_router(webhooks.router) # Webhooks
app.include_router(elias.router)  # Elias smart assistant (summaries, todos, ask)
app.include_router(cors_origins_router.router)  # CORS Origins Management (Admin)
app.include_router(blueprints.router)  # Phase 4: Blueprint marketplace
app.include_router(workflows.router)  # Phase 4: Workflow engine
app.include_router(analytics.router)  # Analytics: intents, handoffs, attribution, llm-audit
app.include_router(feedback.router)  # Phase 4.2: Widget thumbs up/down
app.include_router(ws_chat.router)  # Phase 4.2: WebSocket streaming chat
app.include_router(monitoring_health.router)  # Health & Metrics

# SEC-021: Static files with cache headers
class CachedStaticFiles(StaticFiles):
    async def get_response(self, path, scope):
        response = await super().get_response(path, scope)
        if response.status_code == 200:
            # widget.js, vybris-chat.js: short cache so embed updates propagate
            if path in ("widget.js", "vybris-chat.js") or path.endswith("/widget.js") or path.endswith("/vybris-chat.js"):
                response.headers["Cache-Control"] = "public, max-age=60"
            else:
                # Avatars, logos, etc.: 1 day
                response.headers["Cache-Control"] = "public, max-age=86400"
        return response

app.mount("/static", CachedStaticFiles(directory="static"), name="static")


# Global Exception Handler - Handle custom VYBR!S errors
@app.exception_handler(VybrisError)
async def vybris_error_handler(request: Request, exc: VybrisError):
    """Handle custom VYBR!S exceptions with standardized format"""
    # Get request ID
    request_id = getattr(request.state, 'request_id', error_tracker.generate_request_id())
    
    # Ensure request ID is set in error
    if not exc.request_id:
        exc.request_id = request_id
    
    # Track error for analytics
    error_record = error_tracker.track_error(
        error=exc,
        request_id=request_id,
        error_code=exc.code,
        context={
            "path": str(request.url.path),
            "method": request.method,
            "status_code": exc.status_code
        }
    )
    
    # Categorize error
    category = error_tracker.categorize_error(exc, exc.code)
    
    logger.error(
        f"VYBR!S Error [{exc.code}]: {exc.message}",
        extra={
            "error_code": exc.code,
            "status_code": exc.status_code,
            "details": exc.details,
            "path": str(request.url.path),
            "request_id": request_id,
            "category": category.value
        }
    )
    
    # Check for systemic issues and log warning
    systemic_issues = error_tracker.detect_systemic_issues(threshold=10)
    if systemic_issues:
        for issue in systemic_issues[:3]:  # Top 3
            if issue["pattern"].startswith(exc.code):
                logger.warning(
                    f"Systemic error detected: {issue['pattern']} occurred {issue['count']} times",
                    extra={"pattern": issue["pattern"], "count": issue["count"]}
                )
    
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.to_dict()
    )


# Global Exception Handler - Prevent stack trace leaks for unexpected errors
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler to prevent stack trace leaks"""
    # Get request ID
    request_id = getattr(request.state, 'request_id', error_tracker.generate_request_id())
    
    # Track error for analytics
    error_record = error_tracker.track_error(
        error=exc,
        request_id=request_id,
        error_code="INTERNAL_ERROR",
        context={
            "path": str(request.url.path),
            "method": request.method,
            "unhandled": True
        }
    )
    
    # Categorize error
    category = error_tracker.categorize_error(exc, "INTERNAL_ERROR")
    
    logger.error(
        f"Unhandled exception: {exc}",
        exc_info=True,
        extra={
            "path": str(request.url.path),
            "request_id": request_id,
            "category": category.value,
            "error_type": type(exc).__name__
        }
    )

    # Record error for metrics/observability
    try:
        from monitoring.health import metrics
        metrics.record_error(str(request.url.path), type(exc).__name__)
    except Exception:
        pass

    # In production, return generic error
    if os.getenv("ENVIRONMENT", "development").lower() == "production":
        return JSONResponse(
            status_code=500,
            content={
                "error": "INTERNAL_ERROR",
                "message": "An internal error occurred. Please try again later.",
                "details": {},
                "request_id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }
        )
    
    # In development, include more details (but still sanitized)
    return JSONResponse(
        status_code=500,
        content={
            "error": "INTERNAL_ERROR",
            "message": "An internal error occurred",
            "details": {
                "error_type": type(exc).__name__,
                "error_message": str(exc)[:200]  # Limit length
            },
            "request_id": request_id,
            "timestamp": datetime.utcnow().isoformat()
        }
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Handle validation errors with standardized format"""
    request_id = getattr(request.state, 'request_id', error_tracker.generate_request_id())
    
    # Track validation errors
    error_tracker.track_error(
        error=exc,
        request_id=request_id,
        error_code="VALIDATION_ERROR",
        context={
            "path": str(request.url.path),
            "method": request.method,
            "validation_errors": exc.errors()
        }
    )
    
    logger.warning(
        f"Validation error: {exc.errors()}",
        extra={
            "path": str(request.url.path),
            "request_id": request_id
        }
    )

    try:
        from monitoring.health import metrics
        metrics.record_error(str(request.url.path), "validation")
    except Exception:
        pass

    return JSONResponse(
        status_code=422,
        content={
            "error": "VALIDATION_ERROR",
            "message": "Invalid request data",
            "details": {
                "errors": exc.errors()
            },
            "request_id": request_id,
            "timestamp": datetime.utcnow().isoformat()
        }
    )


@app.get("/")
def read_root():
    return {
        "status": "VYBR!S Backend Running", 
        "version": "3.0.0",
        "features": {
            "advanced_rag": os.getenv("USE_ADVANCED_RAG", "true").lower() == "true",
            "semantic_chunking": os.getenv("USE_SEMANTIC_CHUNKING", "true").lower() == "true"
        }
    }


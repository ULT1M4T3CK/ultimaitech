"""
Shared Type Definitions
Common Pydantic models and type definitions.
"""

from datetime import datetime
from typing import Generic, TypeVar, List, Optional, Any, Dict
from pydantic import BaseModel, Field


T = TypeVar('T')


class PaginatedResponse(BaseModel, Generic[T]):
    """
    Standard paginated response wrapper.
    
    Attributes:
        items: List of items for current page
        total: Total number of items
        page: Current page number (1-indexed)
        page_size: Number of items per page
        has_more: Whether more pages exist
    """
    items: List[T]
    total: int
    page: int = Field(ge=1)
    page_size: int = Field(ge=1, le=100)
    has_more: bool
    
    @property
    def total_pages(self) -> int:
        """Calculate total number of pages."""
        return (self.total + self.page_size - 1) // self.page_size


class APIResponse(BaseModel, Generic[T]):
    """
    Standard API response wrapper.
    
    Attributes:
        success: Whether the operation succeeded
        data: Response data (if successful)
        error: Error message (if failed)
        message: Human-readable status message
    """
    success: bool
    data: Optional[T] = None
    error: Optional[str] = None
    message: Optional[str] = None


class ErrorResponse(BaseModel):
    """
    Standard error response.
    
    Attributes:
        error: Error code
        message: Human-readable error message
        details: Additional error context
    """
    error: str
    message: str
    details: Dict[str, Any] = Field(default_factory=dict)


class HealthStatus(BaseModel):
    """
    Health check response.
    """
    status: str
    version: str
    timestamp: datetime
    components: Dict[str, str]


class JobStatus(BaseModel):
    """
    Background job status.
    
    Attributes:
        job_id: Unique job identifier
        status: Current status (pending, in_progress, completed, failed)
        progress: Progress percentage (0-100)
        message: Current status message
        started_at: When the job started
        completed_at: When the job completed (if done)
        error: Error message (if failed)
    """
    job_id: str
    status: str = Field(pattern="^(pending|in_progress|completed|failed)$")
    progress: float = Field(ge=0, le=100, default=0)
    message: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None


class AuditLog(BaseModel):
    """
    Audit log entry for tracking user actions.
    
    Attributes:
        user_id: User who performed the action
        action: Action performed (e.g., 'create', 'update', 'delete')
        resource_type: Type of resource affected
        resource_id: ID of affected resource
        changes: Dictionary of changes made
        ip_address: IP address of the request
        user_agent: User agent of the request
        timestamp: When the action occurred
    """
    user_id: str
    action: str
    resource_type: str
    resource_id: Optional[str] = None
    changes: Dict[str, Any] = Field(default_factory=dict)
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# Common field constraints
class Constraints:
    """Common field constraints for validation."""
    
    # String lengths
    NAME_MIN = 1
    NAME_MAX = 100
    DESCRIPTION_MAX = 1000
    CONTENT_MAX = 100000
    URL_MAX = 2048
    
    # Numeric ranges
    PAGE_MIN = 1
    PAGE_MAX = 1000
    LIMIT_MIN = 1
    LIMIT_MAX = 100
    
    # IDs
    ID_PATTERN = r'^[a-zA-Z0-9_-]{1,64}$'

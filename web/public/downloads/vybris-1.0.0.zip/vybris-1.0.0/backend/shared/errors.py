"""
Custom Exception Classes for VYBR!S
Standardized error handling across the application.
"""

import uuid
from typing import Optional, Dict, Any
from datetime import datetime


class VybrisError(Exception):
    """
    Base exception for all VYBR!S errors.
    
    Attributes:
        message: Human-readable error message
        code: Machine-readable error code (e.g., 'USER_NOT_FOUND')
        status_code: HTTP status code to return
        details: Additional error context
    """
    
    def __init__(
        self, 
        message: str, 
        code: Optional[str] = None,
        status_code: int = 500,
        details: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None
    ):
        self.message = message
        self.code = code or self.__class__.__name__.upper()
        self.status_code = status_code
        self.details = details or {}
        self.request_id = request_id or f"req_{uuid.uuid4().hex[:16]}"
        self.timestamp = datetime.utcnow().isoformat()
        super().__init__(message)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert error to dictionary for API response."""
        return {
            "error": self.code,
            "message": self.message,
            "details": self.details,
            "request_id": self.request_id,
            "timestamp": self.timestamp
        }


class ValidationError(VybrisError):
    """
    Invalid input data.
    
    Raised when request data fails validation:
    - Missing required fields
    - Invalid field formats
    - Business rule violations
    """
    
    def __init__(
        self, 
        message: str = "Invalid input data", 
        field: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        error_details = details or {}
        if field:
            error_details["field"] = field
        super().__init__(
            message=message,
            code="VALIDATION_ERROR",
            status_code=400,
            details=error_details
        )


class NotFoundError(VybrisError):
    """
    Resource not found.
    
    Raised when requested resource does not exist:
    - User not found
    - Chatbot not found
    - Knowledge item not found
    """
    
    def __init__(
        self, 
        resource: str = "Resource",
        resource_id: Optional[str] = None,
        message: Optional[str] = None
    ):
        details = {}
        if resource_id:
            details["resource_id"] = resource_id
        
        error_message = message or f"{resource} not found"
        
        super().__init__(
            message=error_message,
            code="NOT_FOUND",
            status_code=404,
            details=details
        )


class AuthorizationError(VybrisError):
    """
    Permission denied.
    
    Raised when user lacks required permissions:
    - Accessing another user's resources
    - Role-based restrictions

    """
    
    def __init__(
        self, 
        message: str = "You don't have permission to perform this action",
        required_role: Optional[str] = None
    ):
        details = {}
        if required_role:
            details["required_role"] = required_role
        
        super().__init__(
            message=message,
            code="AUTHORIZATION_ERROR",
            status_code=403,
            details=details
        )


class RateLimitError(VybrisError):
    """
    Rate limit exceeded.
    
    Raised when user exceeds request limits:
    - API rate limiting
    - Per-minute/hour caps
    """
    
    def __init__(
        self, 
        message: str = "Rate limit exceeded. Please try again later.",
        retry_after: Optional[int] = None
    ):
        details = {}
        if retry_after:
            details["retry_after_seconds"] = retry_after
        
        super().__init__(
            message=message,
            code="RATE_LIMIT_EXCEEDED",
            status_code=429,
            details=details
        )


class ExternalServiceError(VybrisError):
    """
    External service failure.
    
    Raised when an external dependency fails:
    - AI API errors (Perplexity)
    - Email service errors (Resend)
    - Database connection errors
    """
    
    def __init__(
        self, 
        service: str,
        message: Optional[str] = None,
        original_error: Optional[Exception] = None
    ):
        error_message = message or f"External service '{service}' is unavailable"
        details = {"service": service}
        
        if original_error:
            details["original_error"] = str(original_error)
        
        super().__init__(
            message=error_message,
            code="EXTERNAL_SERVICE_ERROR",
            status_code=503,
            details=details
        )


class ConfigurationError(VybrisError):
    """
    Configuration error.
    
    Raised when server configuration is invalid:
    - Missing environment variables
    - Invalid settings
    """
    
    def __init__(
        self, 
        message: str = "Server configuration error",
        config_key: Optional[str] = None
    ):
        details = {}
        if config_key:
            details["config_key"] = config_key
        
        super().__init__(
            message=message,
            code="CONFIGURATION_ERROR",
            status_code=500,
            details=details
        )


class ResourceExhaustedError(VybrisError):
    """
    Resource exhausted.
    
    Raised when a limited resource is exhausted:

    - Storage limits exceeded
    """
    
    def __init__(
        self, 
        resource: str,
        message: Optional[str] = None,
        current_usage: Optional[int] = None,
        limit: Optional[int] = None
    ):
        error_message = message or f"{resource} limit reached"
        details = {"resource": resource}
        
        if current_usage is not None:
            details["current_usage"] = current_usage
        if limit is not None:
            details["limit"] = limit
        
        super().__init__(
            message=error_message,
            code="RESOURCE_EXHAUSTED",
            status_code=402,  # Payment Required
            details=details
        )

"""
Orchestrator configuration for multi-model and fallback chain settings.
"""

from dataclasses import dataclass
from typing import List

DEFAULT_FALLBACK_CHAIN = ["rag", "action", "llm", "handoff"]


@dataclass
class OrchestratorConfig:
    """Configuration for the chat orchestrator."""
    routing_model: str = "rule"  # rule | llm - fast classification
    generation_model: str = "perplexity"  # response generation
    fallback_chain: List[str] = None  # default: rag -> action -> llm -> handoff
    max_llm_calls_per_turn: int = 2

    def __post_init__(self):
        if self.fallback_chain is None:
            self.fallback_chain = DEFAULT_FALLBACK_CHAIN.copy()


def get_orchestrator_config(bot_config: dict) -> OrchestratorConfig:
    """
    Get orchestrator config, with per-chatbot overrides from config.orchestrator.
    """
    orch = bot_config.get("orchestrator") or {}
    return OrchestratorConfig(
        routing_model=orch.get("routing_model", "rule"),
        generation_model=orch.get("generation_model", "perplexity"),
        fallback_chain=orch.get("fallback_chain") or DEFAULT_FALLBACK_CHAIN.copy(),
        max_llm_calls_per_turn=int(orch.get("max_llm_calls_per_turn", 2)),
    )

"""
Type-Specific Configurations for Chatbots
Defines optimized settings for each chatbot type to improve quality, functionality, and accuracy.
"""

from typing import Dict, Any

# Type-specific confidence thresholds
TYPE_CONFIDENCE_THRESHOLDS: Dict[str, Dict[str, float]] = {
    "Booking & Reservations": {
        "min_confidence": 0.8,  # High - bookings must be accurate
        "llm_threshold": 0.6,   # Use LLM even at medium confidence for better responses
        "fallback_threshold": 0.5  # Below this, use fallback message
    },
    "Sales": {
        "min_confidence": 0.5,  # Lower - exploratory queries OK
        "llm_threshold": 0.4,   # Use LLM more liberally for sales conversations
        "fallback_threshold": 0.3
    },
    "Technical Support": {
        "min_confidence": 0.7,  # Medium-high - accuracy critical
        "llm_threshold": 0.5,   # Use LLM for technical explanations
        "fallback_threshold": 0.4
    },
    "Healthcare": {
        "min_confidence": 0.85,  # Very high - safety critical
        "llm_threshold": 0.7,   # High threshold for medical information
        "fallback_threshold": 0.6
    },
    "Customer Service": {
        "min_confidence": 0.6,  # Medium - FAQ-heavy
        "llm_threshold": 0.4,
        "fallback_threshold": 0.3
    },
    "E-Commerce": {
        "min_confidence": 0.6,  # Medium - product matching
        "llm_threshold": 0.4,
        "fallback_threshold": 0.3
    },
    "HR": {
        "min_confidence": 0.7,  # Medium-high - policy accuracy important
        "llm_threshold": 0.5,
        "fallback_threshold": 0.4
    },
    "Education": {
        "min_confidence": 0.65,  # Medium - educational content
        "llm_threshold": 0.45,
        "fallback_threshold": 0.35
    },
    "General Purpose": {
        "min_confidence": 0.7,  # Default - balanced
        "llm_threshold": 0.5,
        "fallback_threshold": 0.4
    }
}

# Type-specific search weights (semantic vs keyword)
TYPE_SEARCH_WEIGHTS: Dict[str, Dict[str, float]] = {
    "Customer Service": {
        "semantic": 0.6,  # FAQ-heavy, keyword matching helps
        "keyword": 0.4
    },
    "Booking & Reservations": {
        "semantic": 0.8,  # Context-heavy, semantic understanding critical
        "keyword": 0.2
    },
    "Sales": {
        "semantic": 0.7,  # Balanced - need both intent and keywords
        "keyword": 0.3
    },
    "Technical Support": {
        "semantic": 0.5,  # Exact terms matter (error codes, commands)
        "keyword": 0.5
    },
    "E-Commerce": {
        "semantic": 0.6,  # Product names and features matter
        "keyword": 0.4
    },
    "Healthcare": {
        "semantic": 0.7,  # Context-sensitive medical information
        "keyword": 0.3
    },
    "HR": {
        "semantic": 0.65,  # Policy understanding + exact terms
        "keyword": 0.35
    },
    "Education": {
        "semantic": 0.7,  # Conceptual understanding important
        "keyword": 0.3
    },
    "General Purpose": {
        "semantic": 0.7,  # Default - balanced
        "keyword": 0.3
    }
}

# Type-specific result limits
TYPE_RESULT_LIMITS: Dict[str, int] = {
    "Booking & Reservations": 3,  # Fewer, higher-confidence results
    "Sales": 10,  # More diverse results for exploration
    "Technical Support": 5,  # Focused troubleshooting
    "Customer Service": 5,  # FAQ-focused
    "E-Commerce": 8,  # Product variety
    "Healthcare": 3,  # Precise, accurate information
    "HR": 5,  # Policy-focused
    "Education": 6,  # Educational content
    "General Purpose": 5  # Default
}

# Type-specific fallback messages
TYPE_FALLBACK_MESSAGES: Dict[str, str] = {
    "Booking & Reservations": "I'd be happy to help you with your booking! Could you provide more details about what you're looking for? For example, what dates are you interested in?",
    "Sales": "I'd love to help you find the right solution! What specific needs or challenges are you looking to address?",
    "Technical Support": "I want to help you resolve this issue. Can you describe the problem you're experiencing in more detail? Include any error messages if you see them.",
    "Customer Service": "I'm here to help! Could you tell me more about what you need assistance with?",
    "E-Commerce": "I can help you find what you're looking for! What product or service are you interested in?",
    "Healthcare": "I'm here to assist you. Could you provide more details about your question? Please note that I can provide general information but cannot provide medical advice.",
    "HR": "I can help with HR-related questions. What specific information are you looking for?",
    "Education": "I'd be happy to help with your learning question! What topic or subject would you like to know more about?",
    "General Purpose": "I'm sorry, I didn't understand that. Could you rephrase your question or ask about something else?"
}

# Type-specific context window limits (in tokens)
TYPE_CONTEXT_LIMITS: Dict[str, Dict[str, int]] = {
    "Booking & Reservations": {
        "max_tokens": 1000,  # Smaller context - focused answers
        "reserve_tokens": 150
    },
    "Sales": {
        "max_tokens": 3000,  # Larger context - comprehensive information
        "reserve_tokens": 250
    },
    "Technical Support": {
        "max_tokens": 2000,  # Medium context - detailed troubleshooting
        "reserve_tokens": 200
    },
    "Customer Service": {
        "max_tokens": 1500,  # Medium context - FAQ responses
        "reserve_tokens": 150
    },
    "E-Commerce": {
        "max_tokens": 2500,  # Medium-large context - product details
        "reserve_tokens": 200
    },
    "Healthcare": {
        "max_tokens": 1500,  # Medium context - precise information
        "reserve_tokens": 200
    },
    "HR": {
        "max_tokens": 1800,  # Medium context - policy details
        "reserve_tokens": 180
    },
    "Education": {
        "max_tokens": 2200,  # Medium-large context - educational content
        "reserve_tokens": 200
    },
    "General Purpose": {
        "max_tokens": 2000,  # Default
        "reserve_tokens": 200
    }
}

# Type-specific query expansion terms
TYPE_QUERY_EXPANSIONS: Dict[str, Dict[str, list]] = {
    "Booking & Reservations": {
        "date_terms": ["available", "availability", "book", "booking", "reserve", "reservation", "schedule", "appointment"],
        "time_terms": ["time", "when", "duration", "hours", "schedule"],
        "pricing_terms": ["price", "cost", "rate", "fee", "pricing"]
    },
    "Sales": {
        "buying_signals": ["buy", "purchase", "interested", "need", "looking for", "compare", "best", "recommend"],
        "product_terms": ["product", "service", "solution", "package", "plan", "tier", "feature"],
        "qualification_terms": ["budget", "company", "team size", "requirements", "use case"]
    },
    "Technical Support": {
        "error_terms": ["error", "issue", "problem", "bug", "broken", "not working", "failed"],
        "troubleshooting_terms": ["fix", "solve", "resolve", "help", "how to", "guide", "steps"],
        "technical_terms": ["configuration", "setup", "install", "update", "version", "compatibility"]
    },
    "E-Commerce": {
        "product_terms": ["product", "item", "buy", "purchase", "add to cart", "checkout"],
        "feature_terms": ["specs", "specifications", "features", "details", "compare", "reviews"],
        "category_terms": ["category", "type", "brand", "model", "price range"]
    },
    "Healthcare": {
        "appointment_terms": ["appointment", "schedule", "visit", "consultation", "checkup"],
        "symptom_terms": ["symptom", "condition", "treatment", "medication", "diagnosis"],
        "general_terms": ["health", "wellness", "care", "medical", "doctor", "physician"]
    },
    "Education": {
        "learning_terms": ["learn", "study", "course", "lesson", "tutorial", "explain"],
        "subject_terms": ["subject", "topic", "concept", "material", "resource"],
        "assessment_terms": ["quiz", "test", "exam", "practice", "exercise", "homework"]
    }
}

# Type-specific response formatting preferences
TYPE_RESPONSE_FORMATTING: Dict[str, Dict[str, Any]] = {
    "Booking & Reservations": {
        "prefer_structured": True,
        "include_confirmation": True,
        "format_type": "structured"  # date, time, confirmation format
    },
    "Sales": {
        "prefer_bullet_points": True,
        "include_cta": True,
        "format_type": "persuasive"  # benefits, CTAs
    },
    "Technical Support": {
        "prefer_numbered_steps": True,
        "include_code_blocks": True,
        "format_type": "instructional"  # numbered steps, code blocks
    },
    "E-Commerce": {
        "prefer_product_cards": True,
        "include_comparisons": True,
        "format_type": "product_focused"  # product cards, comparisons
    },
    "Healthcare": {
        "prefer_structured": True,
        "include_disclaimers": True,
        "format_type": "informative"  # structured, with disclaimers
    },
    "Education": {
        "prefer_explanations": True,
        "include_examples": True,
        "format_type": "educational"  # explanations, examples
    }
}

# Type-specific evaluation metrics weights
TYPE_EVALUATION_WEIGHTS: Dict[str, Dict[str, float]] = {
    "Booking & Reservations": {
        "accuracy": 0.4,  # High weight on accuracy
        "completeness": 0.3,
        "relevance": 0.2,
        "clarity": 0.1
    },
    "Sales": {
        "engagement": 0.3,  # Focus on engagement
        "relevance": 0.3,
        "persuasiveness": 0.2,
        "accuracy": 0.2
    },
    "Technical Support": {
        "accuracy": 0.35,
        "clarity": 0.3,  # Clear instructions important
        "completeness": 0.25,
        "relevance": 0.1
    },
    "E-Commerce": {
        "relevance": 0.3,  # Product match quality
        "accuracy": 0.25,
        "completeness": 0.25,
        "engagement": 0.2
    },
    "Healthcare": {
        "accuracy": 0.5,  # Highest accuracy requirement
        "clarity": 0.3,
        "completeness": 0.15,
        "relevance": 0.05
    }
}


def get_type_config(chatbot_type: str, config_category: str) -> Any:
    """
    Get type-specific configuration.
    
    Args:
        chatbot_type: The chatbot type (e.g., "Booking & Reservations")
        config_category: The configuration category (e.g., "confidence_thresholds")
    
    Returns:
        Configuration dict or default if type not found
    """
    type_mapping = {
        "confidence_thresholds": TYPE_CONFIDENCE_THRESHOLDS,
        "search_weights": TYPE_SEARCH_WEIGHTS,
        "result_limits": TYPE_RESULT_LIMITS,
        "fallback_messages": TYPE_FALLBACK_MESSAGES,
        "context_limits": TYPE_CONTEXT_LIMITS,
        "query_expansions": TYPE_QUERY_EXPANSIONS,
        "response_formatting": TYPE_RESPONSE_FORMATTING,
        "evaluation_weights": TYPE_EVALUATION_WEIGHTS
    }
    
    config_dict = type_mapping.get(config_category)
    if not config_dict:
        return None
    
    # Return type-specific config or default to "General Purpose"
    return config_dict.get(chatbot_type, config_dict.get("General Purpose"))


def get_confidence_thresholds(chatbot_type: str) -> Dict[str, float]:
    """Get confidence thresholds for a chatbot type."""
    return get_type_config(chatbot_type, "confidence_thresholds") or TYPE_CONFIDENCE_THRESHOLDS["General Purpose"]


def get_search_weights(chatbot_type: str) -> Dict[str, float]:
    """Get search weights for a chatbot type."""
    return get_type_config(chatbot_type, "search_weights") or TYPE_SEARCH_WEIGHTS["General Purpose"]


def get_result_limit(chatbot_type: str) -> int:
    """Get result limit for a chatbot type."""
    return get_type_config(chatbot_type, "result_limits") or TYPE_RESULT_LIMITS["General Purpose"]


def get_fallback_message(chatbot_type: str) -> str:
    """Get fallback message for a chatbot type."""
    return get_type_config(chatbot_type, "fallback_messages") or TYPE_FALLBACK_MESSAGES["General Purpose"]


def get_context_limits(chatbot_type: str) -> Dict[str, int]:
    """Get context window limits for a chatbot type."""
    return get_type_config(chatbot_type, "context_limits") or TYPE_CONTEXT_LIMITS["General Purpose"]


def get_query_expansions(chatbot_type: str) -> Dict[str, list]:
    """Get query expansion terms for a chatbot type."""
    return get_type_config(chatbot_type, "query_expansions") or {}


def get_response_formatting(chatbot_type: str) -> Dict[str, Any]:
    """Get response formatting preferences for a chatbot type."""
    return get_type_config(chatbot_type, "response_formatting") or {}


def get_evaluation_weights(chatbot_type: str) -> Dict[str, float]:
    """Get evaluation metric weights for a chatbot type."""
    return get_type_config(chatbot_type, "evaluation_weights") or {}


# Type-specific response length limits (in tokens/words)
TYPE_RESPONSE_LIMITS: Dict[str, Dict[str, int]] = {
    "Booking & Reservations": {
        "max_words": 100,  # Concise, focused responses
        "min_words": 20
    },
    "Sales": {
        "max_words": 200,  # More detailed for persuasion
        "min_words": 30
    },
    "Technical Support": {
        "max_words": 300,  # Detailed troubleshooting steps
        "min_words": 40
    },
    "Customer Service": {
        "max_words": 150,  # Balanced
        "min_words": 25
    },
    "E-Commerce": {
        "max_words": 180,  # Product details
        "min_words": 30
    },
    "Healthcare": {
        "max_words": 150,  # Clear, concise medical info
        "min_words": 30
    },
    "HR": {
        "max_words": 200,  # Policy explanations
        "min_words": 30
    },
    "Education": {
        "max_words": 250,  # Educational explanations
        "min_words": 40
    },
    "General Purpose": {
        "max_words": 200,  # Default
        "min_words": 30
    }
}


def get_response_limits(chatbot_type: str) -> Dict[str, int]:
    """Get response length limits for a chatbot type."""
    return TYPE_RESPONSE_LIMITS.get(chatbot_type, TYPE_RESPONSE_LIMITS["General Purpose"])

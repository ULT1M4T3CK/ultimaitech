"""
Shared Constants Package
"""

from .personality_descriptions import CHATBOT_TYPE_DESCRIPTIONS, PERSONALITY_GUIDELINES

__all__ = [
    'CHATBOT_TYPE_DESCRIPTIONS',
    'PERSONALITY_GUIDELINES',
]

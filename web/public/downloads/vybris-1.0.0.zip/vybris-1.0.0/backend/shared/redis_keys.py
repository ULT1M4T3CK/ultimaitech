"""
Redis Key Namespacing
Tenant and platform prefix for all Redis keys to support:
- Multi-tenant isolation when sharing Redis
- Avoid key collisions across deployments
- Consistent key structure for auditing
"""

import os
from typing import Optional

# Global prefix for all VYBR!S Redis keys (e.g., vybris: or vybris_prod:)
REDIS_KEY_PREFIX = os.getenv("REDIS_KEY_PREFIX", "vybris").strip().rstrip(":") or "vybris"


def redis_key(*parts: str, tenant_id: Optional[str] = None) -> str:
    """
    Build a namespaced Redis key.
    
    Args:
        *parts: Key segments (e.g., "rate_limit", identifier)
        tenant_id: Optional tenant ID for tenant-scoped keys
                  (owner_id, chatbot_id, or similar)
    
    Returns:
        Prefixed key like "vybris:rate_limit:ip_123" or "vybris:tenant_abc:cache:..."
    
    Examples:
        redis_key("rate_limit", ip) -> "vybris:rate_limit:1.2.3.4"
        redis_key("response_cache", chatbot_id, query_hash, tenant_id=owner_id) -> "vybris:tenant_xyz:response_cache:..."
        redis_key("blacklist", "user", user_id) -> "vybris:blacklist:user:u_123"
    """
    segs = [REDIS_KEY_PREFIX]
    if tenant_id:
        segs.append(f"t:{tenant_id}")
    segs.extend(str(p) for p in parts if p is not None and p != "")
    return ":".join(segs)


def rate_limit_key(identifier: str) -> str:
    """Rate limit key with platform prefix."""
    return redis_key("rl", identifier)


def cache_key(chatbot_id: str, query_hash: str, owner_id: Optional[str] = None) -> str:
    """Response cache key with optional tenant prefix."""
    if owner_id:
        return redis_key("cache", chatbot_id, query_hash, tenant_id=owner_id)
    return redis_key("cache", chatbot_id, query_hash)


def auth_blacklist_user_key(user_id: str) -> str:
    """Auth blacklist key for user ID."""
    return redis_key("auth", "blacklist", "user", user_id)


def auth_blacklist_username_key(username: str) -> str:
    """Auth blacklist key for username."""
    return redis_key("auth", "blacklist", "username", username)


def auth_used_refresh_key(jti: str) -> str:
    """Used refresh token key."""
    return redis_key("auth", "used_refresh", jti)


def auth_session_key(user_id: str, session_id: str) -> str:
    """Session storage key."""
    return redis_key("auth", "session", user_id, session_id)


def auth_user_sessions_key(user_id: str) -> str:
    """User sessions set key."""
    return redis_key("auth", "user_sessions", user_id)


def auth_failures_key(identifier: str) -> str:
    """Auth failure tracking key."""
    return redis_key("auth", "failures", identifier)

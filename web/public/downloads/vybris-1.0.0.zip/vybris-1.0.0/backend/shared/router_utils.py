"""
Shared Router Utilities
Common patterns and utilities for router endpoints
"""

from typing import Optional, Dict, Any, TypeVar, Callable
from fastapi import HTTPException
from shared.errors import NotFoundError, AuthorizationError

T = TypeVar('T')


def get_resource_or_404(
    resource_getter: Callable[[str], Optional[T]],
    resource_id: str,
    resource_name: str = "Resource"
) -> T:
    """
    Get a resource by ID or raise NotFoundError.
    
    Args:
        resource_getter: Function that takes an ID and returns Optional[Resource]
        resource_id: ID of the resource to fetch
        resource_name: Human-readable name for error messages
    
    Returns:
        The resource if found
    
    Raises:
        NotFoundError: If resource not found
    """
    resource = resource_getter(resource_id)
    if not resource:
        raise NotFoundError(resource=resource_name, resource_id=resource_id)
    return resource


def check_ownership(
    resource: Dict[str, Any],
    user_id: str,
    owner_field: str = "owner_id",
    resource_name: str = "Resource"
) -> None:
    """
    Check if user owns a resource or raise AuthorizationError.
    
    Args:
        resource: Resource dictionary
        user_id: Current user's ID
        owner_field: Field name containing owner ID
        resource_name: Human-readable name for error messages
    
    Raises:
        AuthorizationError: If user doesn't own the resource
    """
    owner_id = resource.get(owner_field)
    if owner_id != user_id:
        raise AuthorizationError(
            message=f"You don't have permission to access this {resource_name.lower()}"
        )


def ensure_resource_exists(
    resource_getter: Callable[[str], Optional[T]],
    resource_id: str,
    resource_name: str = "Resource"
) -> T:
    """
    Ensure a resource exists or raise NotFoundError.
    Alias for get_resource_or_404 for clarity.
    """
    return get_resource_or_404(resource_getter, resource_id, resource_name)


def format_paginated_response(
    items: list,
    total: int,
    limit: int,
    offset: int
) -> Dict[str, Any]:
    """
    Format a paginated response.
    
    Args:
        items: List of items for current page
        total: Total number of items
        limit: Items per page
        offset: Number of items skipped
    
    Returns:
        Formatted paginated response
    """
    return {
        "items": items,
        "total": total,
        "limit": limit,
        "offset": offset,
        "has_more": (offset + len(items)) < total
    }


def sanitize_response_data(data: Dict[str, Any], fields_to_remove: list = None) -> Dict[str, Any]:
    """
    Remove sensitive fields from response data.
    
    Args:
        data: Data dictionary
        fields_to_remove: List of field names to remove (default: common sensitive fields)
    
    Returns:
        Sanitized data dictionary
    """
    if fields_to_remove is None:
        fields_to_remove = ['password', 'password_hash', 'api_key', 'secret', 'token']
    
    sanitized = data.copy()
    for field in fields_to_remove:
        sanitized.pop(field, None)
    
    return sanitized

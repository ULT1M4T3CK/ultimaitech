"""
Permissions module for VYBR!S
Handles authorization checks for resources

DATA PRIVACY: Partner accounts must never access chatbots or chat history from other accounts.
"""

from typing import Dict, Any, List, Optional


def get_chatbot_account_owner_ids(user: Dict[str, Any]) -> List[str]:
    """
    Get the list of user IDs whose chatbots this user can access.
    Partners can only access chatbots owned by themselves or users in their account.
    Admins are not restricted here (handled at call site).
    """
    from services.database import UserDB

    user_id = user.get("id")
    if not user_id:
        return []

    # Partner: self + all users in their account (partner_id = self)
    # User under partner: self + all users in same account (partner_id = my partner_id)
    partner_id = user.get("partner_id") or user_id
    if user.get("role") == "partner":
        partner_id = user_id  # They ARE the partner

    users_in_account = UserDB.get_by_partner(partner_id)
    return [u["id"] for u in users_in_account]


def can_access_chatbot(user: Dict[str, Any], chatbot: Dict[str, Any]) -> bool:
    """
    Check if a user can access (view/manage) a chatbot.
    DATA PRIVACY: Partners can ONLY access chatbots from their own account.
    Admins and super users can access all.
    """
    if user.get("role") in ["admin", "super_admin"] or user.get("is_super_user"):
        return True

    owner_id = chatbot.get("owner_id")
    if not owner_id:
        return False

    if owner_id == user.get("id"):
        return True

    # Partner account scope: owner must be in this user's account
    allowed_ids = get_chatbot_account_owner_ids(user)
    return owner_id in allowed_ids


def can_manage_chatbot(user: Dict[str, Any], chatbot: Dict[str, Any]) -> bool:
    """
    Check if a user can manage a chatbot.
    Partners can manage chatbots in their account only.
    """
    return can_access_chatbot(user, chatbot)


def can_view_chatbot(user: Dict[str, Any], chatbot: Dict[str, Any]) -> bool:
    """
    Check if a user can view a chatbot.
    Partners can view only chatbots from their account. No cross-account access.
    """
    return can_access_chatbot(user, chatbot)


def can_manage_user(current_user: Dict[str, Any], target_user: Dict[str, Any]) -> bool:
    """
    Check if a user can manage another user.
    
    Args:
        current_user: User performing the action
        target_user: User being managed
    
    Returns:
        bool: True if current_user can manage target_user
    """
    # Super admins can manage anyone
    if current_user.get('role') == 'super_admin':
        return True
    
    # Admins can manage non-admins
    if current_user.get('role') == 'admin':
        if target_user.get('role') not in ['admin', 'super_admin']:
            return True
    
    # Users can manage themselves
    if current_user.get('id') == target_user.get('id'):
        return True
    
    return False


def is_admin(user: Dict[str, Any]) -> bool:
    """Check if user is an admin"""
    return user.get('role') in ['admin', 'super_admin']


def is_super_admin(user: Dict[str, Any]) -> bool:
    """Check if user is a super admin"""
    return user.get('role') == 'super_admin'


def is_sales(user: Dict[str, Any]) -> bool:
    """Check if user has sales role"""
    return user.get('role') == 'sales'


def is_super_or_admin(user: Dict[str, Any]) -> bool:
    """Check if user is an admin or super admin (can see all data)"""
    return user.get('role') in ['admin', 'super_admin']


def can_view_lead(user: Dict[str, Any], lead: Dict[str, Any]) -> bool:
    """
    Check if a user can view a CRM lead.
    
    Args:
        user: User dict with 'id' and 'role'
        lead: Lead dict with 'account_owner_id' or 'created_by'
    
    Returns:
        bool: True if user can view the lead
    """
    # Admins can view any lead
    if is_super_or_admin(user):
        return True
    
    # Lead owner can view their leads
    if lead.get('account_owner_id') == user.get('id'):
        return True
    
    # Creator can view their leads
    if lead.get('created_by') == user.get('id'):
        return True
    
    return False


def can_manage_lead(user: Dict[str, Any], lead: Dict[str, Any]) -> bool:
    """
    Check if a user can manage (edit/delete) a CRM lead.
    
    Args:
        user: User dict with 'id' and 'role'
        lead: Lead dict with 'account_owner_id' or 'created_by'
    
    Returns:
        bool: True if user can manage the lead
    """
    # Same logic as view for now, but separated for future granularity
    return can_view_lead(user, lead)


def can_access_live_chat(user: Dict[str, Any]) -> bool:
    """
    Check if a user can access the Live Chat moderator interface and API.
    Admin and Partner: full access. Moderator: access only (scoped by moderator_chatbot_ids).
    Others: no access.
    """
    return user.get("role") in ("admin", "super_admin", "partner", "moderator")


def get_moderator_allowed_chatbot_ids(user: Dict[str, Any]) -> Optional[List[str]]:
    """
    For live chat: return None for admin/partner (all chatbots), or the list of
    allowed chatbot IDs for moderator. For non-moderator roles that have access, returns None.
    """
    role = user.get("role")
    if role in ("admin", "super_admin", "partner"):
        return None  # all chatbots
    if role != "moderator":
        return []
    raw = user.get("moderator_chatbot_ids")
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x) for x in raw]
    if isinstance(raw, str):
        import json
        try:
            parsed = json.loads(raw)
            return [str(x) for x in parsed] if isinstance(parsed, list) else []
        except Exception:
            return []
    return []

"""
Pagination Utilities
Provides pagination helpers for API endpoints
"""

from typing import List, Dict, Any, Optional
from fastapi import Query
from pydantic import BaseModel


class PaginationParams(BaseModel):
    """Standard pagination parameters"""
    limit: int = Query(default=50, ge=1, le=100, description="Number of items per page")
    offset: int = Query(default=0, ge=0, description="Number of items to skip")


class PaginatedResponse(BaseModel):
    """Standard paginated response format"""
    items: List[Dict[str, Any]]
    total: int
    limit: int
    offset: int
    has_more: bool
    
    @classmethod
    def create(
        cls,
        items: List[Dict[str, Any]],
        total: int,
        limit: int,
        offset: int
    ) -> "PaginatedResponse":
        """Create a paginated response"""
        return cls(
            items=items,
            total=total,
            limit=limit,
            offset=offset,
            has_more=(offset + len(items)) < total
        )


def paginate_query(
    query: str,
    params: List[Any],
    pagination: PaginationParams,
    count_query: Optional[str] = None,
    count_params: Optional[List[Any]] = None
) -> tuple[List[Dict[str, Any]], int]:
    """
    Execute a paginated query and return results with total count.
    
    Args:
        query: SQL query with LIMIT and OFFSET placeholders
        params: Query parameters
        pagination: Pagination parameters
        count_query: Optional count query (if different from main query)
        count_params: Parameters for count query
    
    Returns:
        Tuple of (results, total_count)
    """
    from services.database.base import get_db_connection
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Execute main query with pagination
        paginated_query = f"{query} LIMIT %s OFFSET %s"
        paginated_params = params + [pagination.limit, pagination.offset]
        cursor.execute(paginated_query, paginated_params)
        results = [dict(row) for row in cursor.fetchall()]
        
        # Get total count
        if count_query:
            cursor.execute(count_query, count_params or params)
        else:
            # Generate count query from main query
            count_query = f"SELECT COUNT(*) as count FROM ({query}) as subquery"
            cursor.execute(count_query, params)
        
        total = cursor.fetchone()['count']
        
        return results, total

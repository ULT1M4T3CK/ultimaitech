"""
Text Processing Utilities
Common text cleaning and manipulation functions.
"""

import re
from typing import Optional


def clean_text(text: str) -> str:
    """
    Clean and normalize text content.
    
    Removes:
    - Excessive whitespace
    - Non-printable characters
    - Null bytes
    
    Args:
        text: Raw text to clean
        
    Returns:
        Cleaned and normalized text
    """
    if not text:
        return ""
    
    # Remove null bytes
    text = text.replace('\x00', '')
    
    # Replace tabs and newlines with spaces
    text = re.sub(r'[\t\r\n]+', ' ', text)
    
    # Collapse multiple spaces into one
    text = re.sub(r' +', ' ', text)
    
    # Remove non-printable characters (keep basic ASCII and extended chars)
    text = ''.join(char for char in text if ord(char) >= 32 or char in '\n\t')
    
    return text.strip()


def truncate_text(text: str, max_length: int = 200, suffix: str = "...") -> str:
    """
    Truncate text to a maximum length, preserving whole words.
    
    Args:
        text: Text to truncate
        max_length: Maximum length (default 200)
        suffix: Suffix to add when truncated (default "...")
        
    Returns:
        Truncated text with suffix if needed
    """
    if not text or len(text) <= max_length:
        return text
    
    # Find the last space before max_length
    truncated = text[:max_length - len(suffix)]
    last_space = truncated.rfind(' ')
    
    if last_space > 0:
        truncated = truncated[:last_space]
    
    return truncated.rstrip() + suffix


def count_words(text: str) -> int:
    """
    Count the number of words in text.
    
    Args:
        text: Text to count words in
        
    Returns:
        Number of words
    """
    if not text:
        return 0
    
    # Split on whitespace and count non-empty parts
    words = text.split()
    return len(words)


def extract_sentences(text: str, max_sentences: int = 5) -> str:
    """
    Extract the first N sentences from text.
    
    Args:
        text: Text to extract from
        max_sentences: Maximum number of sentences
        
    Returns:
        First N sentences
    """
    if not text:
        return ""
    
    # Simple sentence splitting on common terminators
    sentences = re.split(r'(?<=[.!?])\s+', text)
    
    return ' '.join(sentences[:max_sentences])


def remove_html_entities(text: str) -> str:
    """
    Remove or convert HTML entities in text.
    
    Args:
        text: Text with HTML entities
        
    Returns:
        Clean text
    """
    import html
    return html.unescape(text)


def normalize_whitespace(text: str) -> str:
    """
    Normalize all whitespace in text to single spaces.
    
    Args:
        text: Text to normalize
        
    Returns:
        Text with normalized whitespace
    """
    if not text:
        return ""
    
    return ' '.join(text.split())


def sanitize_for_storage(text: str, max_length: Optional[int] = None) -> str:
    """
    Sanitize text for safe database storage.
    
    Args:
        text: Text to sanitize
        max_length: Optional maximum length
        
    Returns:
        Sanitized text
    """
    if not text:
        return ""
    
    # Clean the text
    text = clean_text(text)
    
    # Remove null bytes (important for PostgreSQL)
    text = text.replace('\x00', '')
    
    # Truncate if needed
    if max_length and len(text) > max_length:
        text = text[:max_length]
    
    return text

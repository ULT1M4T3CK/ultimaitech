"""
URL Utilities
Common URL validation and normalization functions.
"""

import re
from urllib.parse import urlparse, urljoin, urlunparse, parse_qs, urlencode
from typing import Optional, Tuple


def normalize_url(url: str) -> str:
    """
    Normalize a URL for consistent deduplication.
    
    Handles:
    - Trailing slashes
    - Query parameter sorting
    - Fragment removal
    - Case sensitivity for scheme and domain
    
    Args:
        url: URL to normalize
        
    Returns:
        Normalized URL
    """
    if not url:
        return ""
    
    try:
        parsed = urlparse(url.strip())
        
        # Lowercase scheme and netloc
        scheme = parsed.scheme.lower()
        netloc = parsed.netloc.lower()
        
        # Remove default ports
        if netloc.endswith(':80') and scheme == 'http':
            netloc = netloc[:-3]
        elif netloc.endswith(':443') and scheme == 'https':
            netloc = netloc[:-4]
        
        # Normalize path
        path = parsed.path
        
        # Remove trailing slash (except for root)
        if path != '/' and path.endswith('/'):
            path = path.rstrip('/')
        
        # Sort query parameters for consistency
        if parsed.query:
            query_params = parse_qs(parsed.query, keep_blank_values=True)
            sorted_params = sorted(query_params.items())
            query = urlencode(sorted_params, doseq=True)
        else:
            query = ''
        
        # Remove fragment
        fragment = ''
        
        # Reconstruct URL
        normalized = urlunparse((scheme, netloc, path, '', query, fragment))
        
        return normalized
        
    except Exception:
        # If parsing fails, return original URL
        return url.strip()


import socket
import ipaddress

def is_valid_url(url: str) -> bool:
    """
    Check if a URL is valid and safe from SSRF.
    
    Args:
        url: URL to validate
        
    Returns:
        True if valid and safe, False otherwise
    """
    if not url:
        return False
    
    try:
        parsed = urlparse(url)
        
        # Must have scheme and netloc
        if not parsed.scheme or not parsed.netloc:
            return False
        
        # Scheme must be http or https
        scheme = parsed.scheme.lower()
        if scheme not in ('http', 'https'):
            return False
        
        # Extract hostname and port
        hostname = parsed.hostname
        if not hostname:
            return False
            
        # Basic domain validation (already handled by urlparse to an extent)
        # But we must prevent SSRF to localhost and private networks
        
        # SEC-001: Enhanced SSRF protection - block localhost variants and metadata services
        hostname_lower = hostname.lower()
        
        # Block common localhost variants (including IPv6)
        blocked_hostnames = [
            'localhost',
            '127.0.0.1',
            '0.0.0.0',
            '::1',
            '[::1]',
            'metadata.google.internal',
            '169.254.169.254',  # AWS metadata service
            'metadata.azure.com',
            'metadata.cloud.ovh.net'
        ]
        
        if any(blocked in hostname_lower for blocked in blocked_hostnames):
            return False
        
        # Block if hostname contains localhost variants
        if 'localhost' in hostname_lower or '127.' in hostname:
            return False
        
        # SEC-001: Resolve hostname to check for private IPs
        try:
            # Note: This might block legitimate internal URLs if needed by the app,
            # but for a public scraper, it's a critical safety measure.
            ip = socket.gethostbyname(hostname)
            ip_obj = ipaddress.ip_address(ip)
            
            # Block private, loopback, link-local, and reserved IPs
            if (ip_obj.is_private or 
                ip_obj.is_loopback or 
                ip_obj.is_link_local or 
                ip_obj.is_reserved):
                return False
            
            # Explicitly block AWS metadata service IP
            if ip == '169.254.169.254':
                return False
                
        except (socket.gaierror, ValueError):
            # If we can't resolve it, it might be an invalid domain or a non-IP host
            # we should still be cautious - already blocked hostnames above
            pass
        
        # Basic domain validation for non-localhost
        domain = hostname.split(':')[0]
        if not re.match(r'^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]{2,})+$', domain):
            # Allow IP addresses if they passed the is_private check
            if not re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', domain):
                return False
        
        return True
        
    except Exception:
        return False


def extract_domain(url: str) -> Optional[str]:
    """
    Extract the domain from a URL.
    
    Args:
        url: URL to extract domain from
        
    Returns:
        Domain or None if invalid
    """
    if not url:
        return None
    
    try:
        parsed = urlparse(url)
        netloc = parsed.netloc.lower()
        
        # Remove port
        domain = netloc.split(':')[0]
        
        # Remove www prefix
        if domain.startswith('www.'):
            domain = domain[4:]
        
        return domain if domain else None
        
    except Exception:
        return None


def make_absolute_url(base_url: str, relative_url: str) -> str:
    """
    Convert a relative URL to absolute using a base URL.
    
    Args:
        base_url: Base URL to use
        relative_url: Relative URL to convert
        
    Returns:
        Absolute URL
    """
    if not relative_url:
        return base_url
    
    # Already absolute
    if relative_url.startswith(('http://', 'https://')):
        return relative_url
    
    return urljoin(base_url, relative_url)


def is_same_domain(url1: str, url2: str) -> bool:
    """
    Check if two URLs are from the same domain.
    
    Args:
        url1: First URL
        url2: Second URL
        
    Returns:
        True if same domain
    """
    domain1 = extract_domain(url1)
    domain2 = extract_domain(url2)
    
    if not domain1 or not domain2:
        return False
    
    return domain1 == domain2


def get_url_path(url: str) -> str:
    """
    Get the path component of a URL.
    
    Args:
        url: URL to extract path from
        
    Returns:
        Path component
    """
    try:
        parsed = urlparse(url)
        return parsed.path or '/'
    except Exception:
        return '/'


def is_file_url(url: str) -> bool:
    """
    Check if URL points to a file (based on extension).
    
    Args:
        url: URL to check
        
    Returns:
        True if appears to be a file URL
    """
    file_extensions = {
        '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
        '.zip', '.rar', '.tar', '.gz',
        '.jpg', '.jpeg', '.png', '.gif', '.svg', '.webp', '.ico',
        '.mp3', '.mp4', '.avi', '.mov', '.wmv',
        '.css', '.js', '.json', '.xml',
    }
    
    try:
        path = get_url_path(url).lower()
        return any(path.endswith(ext) for ext in file_extensions)
    except Exception:
        return False


def get_base_url(url: str) -> str:
    """
    Get the base URL (scheme + domain) from a URL.
    
    Args:
        url: URL to extract base from
        
    Returns:
        Base URL
    """
    try:
        parsed = urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}"
    except Exception:
        return url

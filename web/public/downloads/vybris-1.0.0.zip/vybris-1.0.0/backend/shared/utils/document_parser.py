"""
Extract text from PDF, DOCX, TEX, CSV, and Excel for knowledge upload.
Parse Q&A-style content so uploaded FAQ PDFs are trained as individual Q&A pairs.
"""

import csv
import io
import re
from typing import Tuple, Optional, List


def _strip_nul(s: str) -> str:
    """Remove NUL (0x00) characters; PostgreSQL and some APIs reject them."""
    if not s:
        return s
    return s.replace("\x00", "")


# Patterns for Q&A in documents (line-start, case-insensitive)
_QA_QUESTION_START = re.compile(
    r"^\s*(?:\d+[.)]\s*)?(?:Q\.?|Question|Vraag|V)\s*:?\s*",
    re.IGNORECASE,
)
_QA_ANSWER_START = re.compile(
    r"^\s*(?:\d+[.)]\s*)?(?:A\.?|Answer|Antwoord)\s*:?\s*",
    re.IGNORECASE,
)


def parse_qa_pairs_from_text(text: str) -> List[Tuple[str, str]]:
    """
    Parse plain text into (question, answer) pairs.
    Supports: Q:/A:, Question:/Answer:, Vraag:/Antwoord:, numbered (1. Q: ... A: ...).
    Returns list of (question, answer) tuples; empty list if no pairs found.
    """
    if not text or not text.strip():
        return []
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    pairs: List[Tuple[str, str]] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if _QA_QUESTION_START.match(line):
            q_match = _QA_QUESTION_START.sub("", line, count=1)
            question = (q_match or line).strip()
            i += 1
            while i < len(lines) and not _QA_ANSWER_START.match(lines[i]):
                question += " " + lines[i].strip()
                i += 1
            question = re.sub(r"\s+", " ", question).strip()
            if i >= len(lines):
                break
            a_line = lines[i]
            a_match = _QA_ANSWER_START.sub("", a_line, count=1)
            answer = (a_match or a_line).strip()
            i += 1
            while i < len(lines) and not _QA_QUESTION_START.match(lines[i]):
                answer += " " + lines[i].strip()
                i += 1
            answer = re.sub(r"\s+", " ", answer).strip()
            if question and answer and len(question) > 2 and len(answer) > 2:
                pairs.append((question, answer))
        else:
            i += 1

    # Fallback: text may have no newlines (e.g. PDF with spaces only). Match "Q: ... A: ..." on one line.
    if not pairs and re.search(r"(?:Q\.?|Question|Vraag)\s*:?\s*.+(?:A\.?|Answer|Antwoord)\s*:?\s*", text, re.I):
        pattern = re.compile(
            r"(?:(?:Q\.?|Question|Vraag)\s*:?\s*)(.+?)(?:\s+(?:A\.?|Answer|Antwoord)\s*:?\s*)(.+?)(?=(?:Q\.?|Question|Vraag)\s*:|\Z)",
            re.IGNORECASE | re.DOTALL,
        )
        for m in pattern.finditer(text):
            q, a = m.group(1).strip(), m.group(2).strip()
            q, a = re.sub(r"\s+", " ", q), re.sub(r"\s+", " ", a)
            if q and a and len(q) > 2 and len(a) > 2:
                pairs.append((q, a))
    return pairs


def extract_text_from_pdf(content: bytes, filename: str = "") -> Tuple[str, Optional[str]]:
    """
    Extract text from PDF bytes.
    Returns (extracted_text, error_message).
    """
    try:
        from pypdf import PdfReader
    except ImportError:
        return "", "pypdf not installed. Run: pip install pypdf"
    try:
        reader = PdfReader(io.BytesIO(content))
        parts = []
        for page in reader.pages:
            text = page.extract_text()
            if text:
                parts.append(text)
        text = "\n\n".join(parts).strip()
        # Keep newlines so Q&A parser can detect "Q:" / "A:" lines; collapse only spaces/tabs within lines
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n ", "\n", text)
        return text, None
    except Exception as e:
        return "", str(e)


def extract_text_from_docx(content: bytes, filename: str = "") -> Tuple[str, Optional[str]]:
    """
    Extract text from DOCX bytes.
    Returns (extracted_text, error_message).
    """
    try:
        from docx import Document
    except ImportError:
        return "", "python-docx not installed. Run: pip install python-docx"
    try:
        doc = Document(io.BytesIO(content))
        parts = []
        for para in doc.paragraphs:
            if para.text.strip():
                parts.append(para.text.strip())
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    if cell.text.strip():
                        parts.append(cell.text.strip())
        text = "\n\n".join(parts).strip()
        # Keep newlines so Q&A parser can detect "Q:" / "A:" lines
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n ", "\n", text)
        return text, None
    except Exception as e:
        return "", str(e)


def extract_text_from_tex(content: bytes, filename: str = "") -> Tuple[str, Optional[str]]:
    """
    Extract text from LaTeX (.tex) file. Decodes as UTF-8; keeps content as-is for RAG.
    Returns (extracted_text, error_message).
    """
    try:
        text = content.decode("utf-8", errors="replace")
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n ", "\n", text)
        return text.strip(), None
    except Exception as e:
        return "", str(e)


def extract_text_from_csv(content: bytes, filename: str = "") -> Tuple[str, Optional[str]]:
    """
    Extract text from CSV. Rows as lines, cells separated by " | " for readable RAG content.
    Returns (extracted_text, error_message).
    """
    try:
        raw = content.decode("utf-8", errors="replace")
        reader = csv.reader(io.StringIO(raw))
        lines = []
        for row in reader:
            if row:
                lines.append(" | ".join(str(c).strip() for c in row))
        text = "\n".join(lines).strip()
        return text, None
    except Exception as e:
        return "", str(e)


def extract_text_from_xlsx(content: bytes, filename: str = "") -> Tuple[str, Optional[str]]:
    """
    Extract text from Excel .xlsx. All sheets, all cells as plain text.
    Returns (extracted_text, error_message).
    """
    try:
        from openpyxl import load_workbook
    except ImportError:
        return "", "openpyxl not installed. Run: pip install openpyxl"
    try:
        wb = load_workbook(io.BytesIO(content), read_only=False, data_only=True)
        parts = []
        for sheet_name in wb.sheetnames:
            sheet = wb[sheet_name]
            for row in sheet.iter_rows(values_only=True):
                if row and any(c is not None and str(c).strip() for c in row):
                    parts.append(" | ".join(str(c) if c is not None else "" for c in row))
        text = "\n".join(parts).strip()
        return text, None
    except Exception as e:
        return "", str(e)


def extract_text_from_xls(content: bytes, filename: str = "") -> Tuple[str, Optional[str]]:
    """
    Extract text from legacy Excel .xls. All sheets, all cells as plain text.
    Returns (extracted_text, error_message).
    """
    try:
        import xlrd
    except ImportError:
        return "", "xlrd not installed. Run: pip install xlrd"
    try:
        wb = xlrd.open_workbook(file_contents=content)
        parts = []
        for sheet in wb.sheets():
            for row_idx in range(sheet.nrows):
                row = sheet.row_values(row_idx)
                if row and any(x is not None and str(x).strip() for x in row):
                    parts.append(" | ".join(str(x) if x else "" for x in row))
        text = "\n".join(parts).strip()
        return text, None
    except Exception as e:
        return "", str(e)


def extract_text_from_file(content: bytes, filename: str, content_type: Optional[str] = None) -> Tuple[str, Optional[str]]:
    """
    Dispatch to the appropriate parser based on filename or content_type.
    Supports: PDF, DOCX, TEX, CSV, XLSX, XLS.
    Returns (extracted_text, error_message). NUL (0x00) chars are stripped so DB/APIs accept the text.
    """
    name = (filename or "").lower()
    ct = (content_type or "").lower()
    text, err = "", None
    if ".pdf" in name or ct == "application/pdf":
        text, err = extract_text_from_pdf(content, filename)
    elif ".docx" in name or ct == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        text, err = extract_text_from_docx(content, filename)
    elif ".tex" in name or ct == "application/x-tex" or ct == "text/x-tex":
        text, err = extract_text_from_tex(content, filename)
    elif ".csv" in name or ct == "text/csv" or ct == "application/csv":
        text, err = extract_text_from_csv(content, filename)
    elif ".xlsx" in name or ct == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
        text, err = extract_text_from_xlsx(content, filename)
    elif ".xls" in name or ct == "application/vnd.ms-excel":
        text, err = extract_text_from_xls(content, filename)
    else:
        return "", f"Unsupported format. Use PDF, DOCX, TEX, CSV, or Excel. Got: {filename or content_type}"
    if err:
        return "", err
    return _strip_nul(text), None

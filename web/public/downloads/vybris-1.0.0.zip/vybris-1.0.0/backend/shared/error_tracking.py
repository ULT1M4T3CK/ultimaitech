"""
Error Tracking and Analytics
Provides request ID generation, error categorization, error pattern tracking,
and persistent error logging to database.
"""

import uuid
import time
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from collections import defaultdict
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class ErrorCategory(str, Enum):
    """Categories for error classification."""
    USER_ERROR = "user_error"  # Client-side issues (validation, bad input)
    SYSTEM_ERROR = "system_error"  # Internal system issues (bugs, logic errors)
    EXTERNAL_ERROR = "external_error"  # External service failures (APIs, databases)
    CONFIGURATION_ERROR = "configuration_error"  # Configuration issues
    NETWORK_ERROR = "network_error"  # Network-related issues
    AUTHENTICATION_ERROR = "authentication_error"  # Auth failures
    AUTHORIZATION_ERROR = "authorization_error"  # Permission issues


class ErrorTracker:
    """
    Tracks errors for analytics and pattern detection.
    
    Features:
    - Request ID generation and tracking
    - Error categorization
    - Pattern detection
    - Error frequency tracking
    """
    
    def __init__(self):
        # Error patterns: {pattern_key: {count, first_seen, last_seen, category}}
        self.error_patterns: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            "count": 0,
            "first_seen": None,
            "last_seen": None,
            "category": None,
            "examples": []
        })
        
        # Recent errors for quick analysis
        self.recent_errors: List[Dict[str, Any]] = []
        self.max_recent_errors = 1000
    
    def generate_request_id(self) -> str:
        """Generate a unique request ID."""
        return f"req_{uuid.uuid4().hex[:16]}"
    
    def categorize_error(self, error: Exception, error_code: Optional[str] = None) -> ErrorCategory:
        """
        Categorize an error based on its type and code.
        
        Args:
            error: The exception object
            error_code: Optional error code string
        
        Returns:
            ErrorCategory enum value
        """
        error_type = type(error).__name__
        error_code = error_code or ""
        
        # Categorize based on error code
        if "VALIDATION" in error_code or "NOT_FOUND" in error_code:
            return ErrorCategory.USER_ERROR
        
        if "AUTHORIZATION" in error_code or "AUTH" in error_code:
            if "AUTHORIZATION" in error_code:
                return ErrorCategory.AUTHORIZATION_ERROR
            return ErrorCategory.AUTHENTICATION_ERROR
        
        if "EXTERNAL_SERVICE" in error_code or "RATE_LIMIT" in error_code:
            if "RATE_LIMIT" in error_code:
                return ErrorCategory.NETWORK_ERROR
            return ErrorCategory.EXTERNAL_ERROR
        
        if "CONFIGURATION" in error_code:
            return ErrorCategory.CONFIGURATION_ERROR
        
        # Categorize based on exception type
        if isinstance(error, (ConnectionError, TimeoutError)):
            return ErrorCategory.NETWORK_ERROR
        
        if isinstance(error, (ValueError, TypeError, AttributeError)):
            return ErrorCategory.SYSTEM_ERROR
        
        # Default to system error
        return ErrorCategory.SYSTEM_ERROR
    
    def track_error(
        self,
        error: Exception,
        request_id: str,
        error_code: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Track an error for analytics and persist to database.
        
        Args:
            error: The exception
            request_id: Request ID for correlation
            error_code: Optional error code
            context: Additional context
        
        Returns:
            Error tracking record
        """
        category = self.categorize_error(error, error_code)
        error_type = type(error).__name__
        error_message = str(error)
        
        # Create pattern key for grouping similar errors
        pattern_key = f"{error_type}:{error_code or 'UNKNOWN'}"
        
        # Update pattern statistics
        pattern = self.error_patterns[pattern_key]
        pattern["count"] += 1
        pattern["category"] = category.value
        if not pattern["first_seen"]:
            pattern["first_seen"] = datetime.utcnow()
        pattern["last_seen"] = datetime.utcnow()
        
        # Keep example errors (up to 5 per pattern)
        if len(pattern["examples"]) < 5:
            pattern["examples"].append({
                "request_id": request_id,
                "message": error_message[:200],
                "timestamp": datetime.utcnow().isoformat()
            })
        
        # Track recent error
        error_record = {
            "request_id": request_id,
            "error_type": error_type,
            "error_code": error_code,
            "error_message": error_message[:500],
            "category": category.value,
            "timestamp": datetime.utcnow().isoformat(),
            "context": context or {}
        }
        
        self.recent_errors.append(error_record)
        
        # Keep only recent errors
        if len(self.recent_errors) > self.max_recent_errors:
            self.recent_errors = self.recent_errors[-self.max_recent_errors:]
        
        # Persist to database (async, non-blocking)
        self._persist_error_to_db(error_record, context)
        
        return error_record
    
    def _persist_error_to_db(self, error_record: Dict[str, Any], context: Optional[Dict[str, Any]]):
        """Persist error to database (non-blocking)."""
        try:
            import uuid
            import json
            from services.database.base import get_db_connection
            
            error_id = str(uuid.uuid4())
            path = context.get("path") if context else None
            method = context.get("method") if context else None
            status_code = context.get("status_code") if context else None
            
            # Use connection with autocommit for non-blocking write
            with get_db_connection(autocommit=True) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO error_logs (
                        id, request_id, error_type, error_code, error_message,
                        category, path, method, status_code, context, created_at
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
                ''', (
                    error_id,
                    error_record["request_id"],
                    error_record["error_type"],
                    error_record.get("error_code"),
                    error_record["error_message"],
                    error_record["category"],
                    path,
                    method,
                    status_code,
                    json.dumps(context or {})
                ))
        except Exception as e:
            # Don't fail if database write fails - just log it
            logger.warning(f"Failed to persist error to database: {e}")
    
    def get_error_statistics(self, hours: int = 24) -> Dict[str, Any]:
        """
        Get error statistics for the last N hours.
        
        Args:
            hours: Number of hours to analyze
        
        Returns:
            Dictionary with error statistics
        """
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        
        # Filter recent errors
        recent = [
            e for e in self.recent_errors
            if datetime.fromisoformat(e["timestamp"]) >= cutoff
        ]
        
        # Count by category
        by_category = defaultdict(int)
        by_type = defaultdict(int)
        
        for error in recent:
            by_category[error["category"]] += 1
            by_type[error["error_type"]] += 1
        
        # Get top error patterns
        top_patterns = sorted(
            [
                {
                    "pattern": pattern,
                    "count": data["count"],
                    "category": data["category"],
                    "first_seen": data["first_seen"].isoformat() if data["first_seen"] else None,
                    "last_seen": data["last_seen"].isoformat() if data["last_seen"] else None
                }
                for pattern, data in self.error_patterns.items()
                if data["last_seen"] and datetime.fromisoformat(data["last_seen"].isoformat()) >= cutoff
            ],
            key=lambda x: x["count"],
            reverse=True
        )[:10]
        
        return {
            "period_hours": hours,
            "total_errors": len(recent),
            "by_category": dict(by_category),
            "by_type": dict(by_type),
            "top_patterns": top_patterns,
            "unique_patterns": len(self.error_patterns)
        }
    
    def detect_systemic_issues(self, threshold: int = 10) -> List[Dict[str, Any]]:
        """
        Detect systemic issues (errors that occur frequently).
        
        Args:
            threshold: Minimum count to consider systemic
        
        Returns:
            List of systemic error patterns
        """
        issues = []
        
        for pattern, data in self.error_patterns.items():
            if data["count"] >= threshold:
                # Check if it's recent (last hour)
                if data["last_seen"]:
                    time_since_last = (datetime.utcnow() - data["last_seen"]).total_seconds()
                    if time_since_last < 3600:  # Last hour
                        issues.append({
                            "pattern": pattern,
                            "count": data["count"],
                            "category": data["category"],
                            "last_seen": data["last_seen"].isoformat(),
                            "examples": data["examples"][:3]  # Top 3 examples
                        })
        
        return sorted(issues, key=lambda x: x["count"], reverse=True)


# Singleton instance
error_tracker = ErrorTracker()

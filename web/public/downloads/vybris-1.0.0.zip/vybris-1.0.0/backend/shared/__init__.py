"""
VYBR!S Shared Package
Common utilities and types used across the application.
"""

from .errors import (
    VybrisError,
    ValidationError,
    NotFoundError,
    AuthorizationError,
    RateLimitError,
    ExternalServiceError,
)

from .types import (
    PaginatedResponse,
    APIResponse,
    ErrorResponse,
    HealthStatus,
    JobStatus,
)

__all__ = [
    # Errors
    'VybrisError',
    'ValidationError', 
    'NotFoundError',
    'AuthorizationError',
    'RateLimitError',
    'ExternalServiceError',
    # Types
    'PaginatedResponse',
    'APIResponse',
    'ErrorResponse',
    'HealthStatus',
    'JobStatus',
]


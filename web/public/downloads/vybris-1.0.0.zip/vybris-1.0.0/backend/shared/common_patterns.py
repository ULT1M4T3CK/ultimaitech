"""
Common Patterns and Utilities
Shared code patterns to reduce duplication across routers
"""

from typing import Dict, Any, Optional, Callable, TypeVar
from fastapi import HTTPException
from shared.errors import NotFoundError, AuthorizationError

T = TypeVar('T')


def handle_not_found(
    resource_getter: Callable[[str], Optional[T]],
    resource_id: str,
    resource_name: str = "Resource"
) -> T:
    """
    Common pattern: Get resource or raise NotFoundError.
    
    Usage:
        bot = handle_not_found(ChatbotDB.get_by_id, chatbot_id, "Chatbot")
    """
    resource = resource_getter(resource_id)
    if not resource:
        raise NotFoundError(resource=resource_name, resource_id=resource_id)
    return resource


def handle_authorization(
    resource: Dict[str, Any],
    user_id: str,
    owner_field: str = "owner_id",
    resource_name: str = "Resource"
) -> None:
    """
    Common pattern: Check ownership or raise AuthorizationError.
    
    Usage:
        handle_authorization(bot, current_user['id'], "owner_id", "Chatbot")
    """
    owner_id = resource.get(owner_field)
    if owner_id != user_id:
        raise AuthorizationError(
            message=f"You don't have permission to access this {resource_name.lower()}"
        )


def build_paginated_response(
    items: list,
    total: int,
    limit: int,
    offset: int
) -> Dict[str, Any]:
    """
    Common pattern: Build paginated response.
    
    Usage:
        return build_paginated_response(chatbots, total, limit, offset)
    """
    return {
        "items": items,
        "total": total,
        "limit": limit,
        "offset": offset,
        "has_more": (offset + len(items)) < total
    }

"""
Elias Agent - wraps elias_client for OpenClaw gateway.
"""

from typing import Optional, Dict, Any

from application.chat.models import OrchestratorResponse
from application.chat.handlers.elias_handler import handle_elias


class EliasAgent:
    """Agent backend using Elias (OpenClaw) gateway."""

    async def generate(
        self,
        *,
        chatbot_id: str,
        query: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> OrchestratorResponse:
        """Generate response via Elias gateway."""
        bot = context.get("bot") if context else {}
        bot_config = bot.get("config", {}) or {}
        session_id = (context or {}).get("session_id")
        tenant_id = (bot or {}).get("owner_id")
        return await handle_elias(
            text=query,
            chatbot_id=chatbot_id,
            session_id=session_id,
            bot_config=bot_config,
            bot=bot,
            tenant_id=tenant_id,
        )

"""
Chat orchestration models.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any


@dataclass
class OrchestratorResponse:
    """Unified response from the chat orchestrator (Phase 4: explainability)."""
    intent: str
    confidence: float
    response: str
    sources: List[Dict[str, Any]]
    live_chat_request_id: Optional[str] = None
    live_chat_status: Optional[str] = None
    explanation: Optional[str] = None

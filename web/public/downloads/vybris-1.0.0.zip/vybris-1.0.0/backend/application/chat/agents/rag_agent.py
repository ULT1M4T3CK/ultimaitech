"""
RAG Agent - wraps the RAG handler (RAGService + LLM pipeline).
"""

from typing import Optional, Dict, Any

from application.chat.models import OrchestratorResponse
from application.chat.handlers.rag_handler import handle_rag


class RagAgent:
    """Agent backend using RAG pipeline."""

    async def generate(
        self,
        *,
        chatbot_id: str,
        query: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> OrchestratorResponse:
        """Generate response via RAG pipeline."""
        bot = context.get("bot") if context else {}
        bot_config = bot.get("config", {}) or {}
        session_id = (context or {}).get("session_id")
        return await handle_rag(
            text=query,
            chatbot_id=chatbot_id,
            session_id=session_id,
            bot=bot or {},
            bot_config=bot_config,
        )

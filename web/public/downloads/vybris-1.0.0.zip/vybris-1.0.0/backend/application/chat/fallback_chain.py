"""
Fallback Chain Runner - tries handlers in sequence when confidence is low.
Chain: rag -> action -> llm -> handoff
"""

import logging
from typing import Dict, Any, Optional

from application.chat.models import OrchestratorResponse

logger = logging.getLogger(__name__)


def _apply_conversation_studio_overrides(chatbot_id: str, result: OrchestratorResponse) -> OrchestratorResponse:
    """Apply Conversation Studio intent overrides if configured."""
    try:
        from services.database.conversation_flows import get_intent_override
        override = get_intent_override(chatbot_id, result.intent)
        if override:
            return OrchestratorResponse(
                intent=result.intent,
                confidence=result.confidence,
                response=override,
                sources=result.sources,
                explanation="Custom response from Conversation Studio flow.",
                live_chat_request_id=result.live_chat_request_id,
                live_chat_status=result.live_chat_status,
            )
    except Exception as e:
        logger.debug(f"Flow override check failed: {e}")
    return result


async def run_fallback_chain(
    *,
    text: str,
    chatbot_id: str,
    session_id: Optional[str],
    bot: Dict[str, Any],
    bot_config: Dict[str, Any],
    req,
    context: Optional[Dict[str, Any]],
    auto_request_live_chat: bool,
    chain: list,
    confidence_threshold: float,
) -> OrchestratorResponse:
    """
    Run handlers in fallback chain until one returns acceptable result.
    """
    from application.chat.handlers.rag_handler import handle_rag
    from application.chat.handlers.live_chat_handler import handle_live_chat

    for step in chain:
        if step == "rag":
            result = await handle_rag(
                text=text,
                chatbot_id=chatbot_id,
                session_id=session_id,
                bot=bot,
                bot_config=bot_config,
            )
            result = _apply_conversation_studio_overrides(chatbot_id, result)
            if result.confidence >= confidence_threshold or result.response:
                return result
            logger.debug(f"Fallback: RAG confidence {result.confidence} < {confidence_threshold}, trying next")
        elif step == "action":
            result = await _try_action_step(text, chatbot_id, session_id, bot, bot_config)
            if result:
                return _apply_conversation_studio_overrides(chatbot_id, result)
        elif step == "llm":
            result = await _try_llm_step(text, chatbot_id, session_id, bot, bot_config, context)
            if result:
                return _apply_conversation_studio_overrides(chatbot_id, result)
        elif step == "handoff":
            return await handle_live_chat(
                text=text,
                chatbot_id=chatbot_id,
                session_id=session_id,
                context=context,
                auto_request_live_chat=auto_request_live_chat,
                req=req,
            )

    # Final fallback
    fallback = bot_config.get("fallbackMessage", "I'm sorry, I didn't understand that.")
    result = OrchestratorResponse(
        intent="fallback_chain_exhausted",
        confidence=0.0,
        response=fallback,
        sources=[],
    )
    return _apply_conversation_studio_overrides(chatbot_id, result)


async def _try_action_step(
    text: str,
    chatbot_id: str,
    session_id: Optional[str],
    bot: Dict[str, Any],
    bot_config: Dict[str, Any],
) -> Optional[OrchestratorResponse]:
    """Try to match and execute a custom action."""
    try:
        from services.action_service import action_service
        actions = action_service.get_available_actions(chatbot_id)
        if not actions:
            return None
        text_lower = text.lower()
        for act in actions:
            name = (act.get("name") or "").lower()
            desc = (act.get("description") or "").lower()
            if name in text_lower or (desc and desc[:50] in text_lower):
                try:
                    result = action_service.execute_action(act["id"], {}, chatbot_id=chatbot_id)
                    resp = result.get("data") or result.get("response")
                    if isinstance(resp, dict):
                        resp = str(resp)
                    msg = resp or "Action completed." if result.get("success", True) else (result.get("error") or "Action failed.")
                    return OrchestratorResponse(
                        intent="action_execution",
                        confidence=0.9,
                        response=str(msg),
                        sources=[{"type": "action", "action_id": act["id"]}],
                    )
                except Exception as e:
                    logger.warning(f"Action execution failed: {e}")
        return None
    except Exception as e:
        logger.debug(f"Action step failed: {e}")
        return None


async def _try_llm_step(
    text: str,
    chatbot_id: str,
    session_id: Optional[str],
    bot: Dict[str, Any],
    bot_config: Dict[str, Any],
    context: Optional[Dict[str, Any]],
) -> Optional[OrchestratorResponse]:
    """Try LLM generation without RAG context."""
    try:
        from services.llm import llm_service
        if not llm_service.is_enabled():
            return None
        chatbot_name = bot.get("name", "Assistant")
        company_name = (bot_config.get("companyName") or "").strip()
        chatbot_type = bot.get("type", "General Purpose")
        personality = bot_config.get("personality", "Professional")
        history = []
        if session_id:
            from services.database import SessionDB
            history = SessionDB.get_history(session_id)
        reply = await llm_service.generate_response(
            user_query=text,
            context_chunks=[],
            chatbot_name=chatbot_name,
            company_name=company_name,
            chatbot_type=chatbot_type,
            personality=personality,
            supported_languages=bot_config.get("supportedLanguages"),
            temperature=0.3,
            history=history,
        )
        if reply and reply.strip():
            return OrchestratorResponse(
                intent="llm_fallback",
                confidence=0.6,
                response=reply.strip(),
                sources=[],
            )
    except Exception as e:
        logger.debug(f"LLM fallback failed: {e}")
    return None

"""
Agent runtimes - RAG and Elias backends.
"""

"""
RAG Handler - runs the RAG pipeline (integrations, hybrid retrieval, reranking, LLM).
"""

import os
import time
import logging
from typing import Dict, Any, Optional

from application.chat.models import OrchestratorResponse

logger = logging.getLogger(__name__)
USE_ADVANCED_RAG = os.getenv("USE_ADVANCED_RAG", "true").lower() == "true"


async def handle_rag(
    *,
    text: str,
    chatbot_id: str,
    session_id: Optional[str],
    bot: Dict[str, Any],
    bot_config: Dict[str, Any],
) -> OrchestratorResponse:
    """
    Run the full RAG pipeline: integrations, hybrid retrieval, reranking, LLM.
    """
    start_time = time.time()
    from services.database import SessionDB, IntegrationDB
    from services.llm import llm_service
    from services.nlp_service import nlp_service
    from services.response_validator import response_validator
    from nlp.query_processor import DomainQueryProcessor
    from nlp.retrieval import HybridRetriever
    from nlp.reranker import ChunkReranker

    query_processor = DomainQueryProcessor()
    hybrid_retriever = HybridRetriever(nlp_service, semantic_weight=0.7, keyword_weight=0.3)
    reranker = ChunkReranker(top_k=5, use_cross_encoder=True)

    fallback_message = bot_config.get("fallbackMessage", "I'm sorry, I didn't understand that.")
    chatbot_name = bot.get("name", "Assistant") or "Assistant"
    company_name = (bot_config.get("companyName") or chatbot_name or "").strip()
    supported_languages = bot_config.get("supportedLanguages") or [bot_config.get("language", "en")]
    chatbot_type = bot.get("type", "General Purpose") or "General Purpose"
    personality = bot_config.get("personality", "Professional")
    elias_enabled = bool(bot_config.get("elias_enabled"))

    results = []
    intent = "unknown"
    history = []
    if session_id:
        history = SessionDB.get_history(session_id)

    # Integrations
    active_integrations = IntegrationDB.get_by_chatbot(chatbot_id)
    inv_integration = next(
        (i for i in active_integrations if i["integration_type"] == "universal_inventory" and i.get("status", "").lower() == "active"),
        None,
    )
    book_integration = next(
        (i for i in active_integrations if i["integration_type"] == "universal_booking" and i.get("status", "").lower() == "active"),
        None,
    )

    integration_results = []
    try:
        from services.integrations import IntegrationManager
        if inv_integration:
            inv_instance = IntegrationManager.get_integration("universal_inventory", inv_integration.get("config", {}))
            inv_result = inv_instance.process_text(text)
            if inv_result:
                integration_results.append(inv_result)
        if book_integration:
            book_instance = IntegrationManager.get_integration("universal_booking", book_integration.get("config", {}))
            book_result = book_instance.process_text(text)
            if book_result:
                integration_results.append(book_result)
    except Exception as e:
        logger.error(f"Universal Integration processing failed: {e}")

    if integration_results:
        combined = "\n".join(integration_results)
        logger.info(f"Universal Integration Result: {combined}")
        results.insert(0, {
            "text": f"SYSTEM DATA [Real-time]: {combined}",
            "score": 1.5,
            "semantic_score": 1.0,
            "keyword_score": 1.0,
            "payload": {"type": "system", "source": "integration"},
        })
        if "Booking Successfully Created" in combined or "Click Here to Complete Booking" in combined:
            intent = "booking_confirmed"

    # Enhanced RAG Pipeline
    if USE_ADVANCED_RAG:
        processed_query = query_processor.process_with_synonyms(text)
        search_query = processed_query.expanded_query
        if processed_query.corrections or processed_query.expansions:
            logger.info(f"Query processed: corrections={processed_query.corrections}, expansions={processed_query.expansions}")

        search_results = hybrid_retriever.search(chatbot_id, search_query, limit=10)
        results = [
            {
                "text": r.text,
                "score": r.score,
                "semantic_score": r.semantic_score,
                "keyword_score": r.keyword_score,
                "payload": r.payload,
            }
            for r in search_results
        ]
        if results:
            results = reranker.rerank(text, results)
            for r in results:
                if r.get("payload", {}).get("type") == "qa":
                    r["score"] = min(r["score"] * 1.5, 1.0)
            results.sort(key=lambda x: x["score"], reverse=True)
    else:
        results = nlp_service.search(chatbot_id, text, limit=5)

    retrieval_time = (time.time() - start_time) * 1000
    logger.debug(f"Retrieval completed in {retrieval_time:.2f}ms, found {len(results)} results")

    confidence = 0.0
    response_text = fallback_message
    sources = []

    if results and len(results) > 0:
        best_match = results[0]
        confidence = best_match["score"]
        sources = results

        if llm_service.is_enabled():
            valid_results = [r for r in results if r.get("score", 0) >= 0.3]
            if valid_results:
                try:
                    if elias_enabled:
                        from services.rag_service import rag_service
                        rag_response = await rag_service.generate_response(
                            chatbot_id=chatbot_id,
                            query=text,
                            context={
                                "session_id": session_id,
                                "chatbot_name": chatbot_name,
                                "company_name": company_name,
                                "chatbot_type": chatbot_type,
                                "personality": personality,
                            },
                            use_llm=True,
                        )
                        if rag_response and rag_response.response:
                            llm_response = rag_response.response
                            intent = rag_response.intent or "elias_enhanced_response"
                            confidence = rag_response.confidence
                            if intent == "action_execution":
                                logger.info(f"Elias executed action for chatbot {chatbot_id}")
                        else:
                            llm_response = None
                    else:
                        llm_response = await llm_service.generate_response(
                            user_query=text,
                            context_chunks=valid_results,
                            chatbot_name=chatbot_name,
                            company_name=company_name,
                            chatbot_type=chatbot_type,
                            personality=personality,
                            supported_languages=supported_languages,
                            temperature=0.3,
                            history=history,
                        )

                    if llm_response:
                        validation = response_validator.validate_response(
                            response=llm_response,
                            query=text,
                            context_chunks=valid_results,
                            confidence=confidence,
                        )
                        if validation["valid"] and not validation["should_use_fallback"]:
                            response_text = llm_response
                            if intent != "action_execution":
                                intent = "elias_enhanced_response" if elias_enabled else "llm_enhanced_response"
                            if validation["warnings"]:
                                logger.warning(f"Response validation warnings: {validation['warnings']}")
                        else:
                            logger.warning(f"Response validation failed: {validation['warnings']}")
                            if confidence >= 0.5:
                                response_text = best_match["text"]
                                intent = "information_retrieval"
                            else:
                                intent = "validation_failed_fallback"
                    else:
                        if confidence >= 0.5:
                            response_text = best_match["text"]
                            intent = "information_retrieval"
                        else:
                            intent = "llm_failed_fallback"
                except Exception as e:
                    logger.error(f"LLM API error: {e}")
                    if confidence >= 0.5:
                        response_text = best_match["text"]
                        intent = "information_retrieval"
                    else:
                        intent = "llm_error_fallback"
            else:
                intent = "no_valid_rag_results"
        else:
            if confidence >= 0.5:
                response_text = best_match["text"]
                intent = "information_retrieval"
            elif confidence >= 0.3:
                response_text = "I found something that might help: " + best_match["text"]
                intent = "low_confidence_match"

    if not results or len(results) == 0:
        intent = "no_results_fallback"
        logger.info(f"No RAG results found for query: {text[:100]}... Using fallback message.")

    # Phase 4: Explainability - summarize why this response was given
    explanation = None
    if sources:
        top_sources = sources[:3]
        titles = [s.get("payload", {}).get("title") or s.get("text", "")[:50] for s in top_sources]
        explanation = f"Response based on {len(sources)} knowledge base result(s). Top sources: {', '.join(str(t) for t in titles if t)[:200]}."

    # Conversation Studio: intent override from flow
    try:
        from services.database.conversation_flows import get_intent_override
        override = get_intent_override(chatbot_id, intent)
        if override:
            response_text = override
            explanation = "Custom response from Conversation Studio flow."
    except Exception as e:
        logger.debug(f"Flow override check failed: {e}")

    return OrchestratorResponse(
        intent=intent,
        confidence=confidence,
        response=response_text,
        sources=sources,
        explanation=explanation,
    )

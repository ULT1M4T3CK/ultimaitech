"""
Intent Router - determines which handler should process a chat request.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Dict, Any


class RouteType(str, Enum):
    """Routing decision types."""
    LIVE_CHAT = "live_chat"
    ELIAS_GATEWAY = "elias_gateway"
    RAG = "rag"


@dataclass
class RouteDecision:
    """Result of intent routing."""
    route: RouteType
    reason: str


# Live chat phrase matching (extracted from processing.py)
LIVE_CHAT_PHRASES = (
    "talk to a human", "talk to human", "speak to human", "speak to a human",
    "connect to a human", "connect to human", "human agent", "real person",
    "real human", "speak to agent", "talk to agent", "human support",
    "live agent", "live chat", "human please", "want a human", "need a human",
    "contact human", "reach human", "verbinding met mens", "mens spreken",
    "human praten", "agent spreken", "echte persoon", "can i speak to",
    "get a human", "speak with human", "talk with human", "connect me to",
    "transfer to human", "transfer to agent", "i want to talk to",
    "need to speak to", "want to speak to", "speak to someone", "talk to someone",
)
LIVE_CHAT_SHORT = (
    "human", "agent", "person", "live", "support", "human please", "agent please"
)
LIVE_CHAT_KEYWORDS = (
    "human", "agent", "real person", "live chat", "live agent", "human support"
)


class IntentRouter:
    """
    Routes incoming chat requests to the appropriate handler.
    Order: live_chat (if match) -> elias_gateway (if configured) -> rag (default).
    """

    def route(
        self,
        text: str,
        bot_config: Dict[str, Any],
        bot: Optional[Dict[str, Any]] = None,
    ) -> RouteDecision:
        """
        Determine routing based on request text and bot configuration.
        
        Args:
            text: User message
            bot_config: Chatbot config (enableLiveChat, backend_type, elias_url)
            bot: Full bot dict (optional, for future use)
            
        Returns:
            RouteDecision with route type and reason
        """
        if not text or not isinstance(text, str):
            return RouteDecision(RouteType.RAG, "empty_or_invalid_text")

        text_lower = text.strip().lower()
        enable_live_chat = bool(bot_config.get("enableLiveChat") or bot_config.get("enable_live_chat"))

        # 1. Live chat: phrase match and live chat enabled
        if enable_live_chat:
            short_match = text_lower in LIVE_CHAT_SHORT
            phrase_match = any(p in text_lower for p in LIVE_CHAT_PHRASES)
            keyword_match = len(text_lower.split()) <= 8 and any(k in text_lower for k in LIVE_CHAT_KEYWORDS)
            if short_match or phrase_match or keyword_match:
                return RouteDecision(RouteType.LIVE_CHAT, "user_requested_human")

        # 2. Elias gateway: backend_type elias and URL configured
        backend_type = (bot_config.get("backend_type") or "rag").lower()
        elias_url = (bot_config.get("elias_url") or "").strip()
        if backend_type == "elias" and elias_url and elias_url.startswith(("http://", "https://")):
            return RouteDecision(RouteType.ELIAS_GATEWAY, "bot_backend_elias")

        # 3. Default: RAG
        return RouteDecision(RouteType.RAG, "default_rag")

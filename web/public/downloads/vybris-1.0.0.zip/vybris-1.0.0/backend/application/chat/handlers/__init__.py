"""
Chat handlers - RAG, Elias, Live Chat.
"""

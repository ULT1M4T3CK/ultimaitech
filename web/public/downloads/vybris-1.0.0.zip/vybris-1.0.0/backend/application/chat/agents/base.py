"""
Agent backend protocol - abstract interface for chat backends.
"""

from typing import Protocol, Optional, Dict, Any
from application.chat.models import OrchestratorResponse


class AgentBackend(Protocol):
    """Protocol for chat agent backends (RAG, Elias, etc.)."""

    async def generate(
        self,
        *,
        chatbot_id: str,
        query: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> OrchestratorResponse:
        """Generate a response for the given query."""
        ...

"""
Chat Orchestrator - routes requests to RAG, Elias, or Live Chat handlers.
"""

import os
import logging
from typing import Dict, Any, Optional
from fastapi import Request

from application.chat.intent_router import IntentRouter, RouteType
from application.chat.models import OrchestratorResponse
from application.chat.handlers.live_chat_handler import handle_live_chat
from application.chat.handlers.elias_handler import handle_elias
from application.chat.handlers.rag_handler import handle_rag

logger = logging.getLogger(__name__)

USE_ORCHESTRATOR = os.getenv("USE_ORCHESTRATOR", "true").lower() == "true"


class ChatOrchestrator:
    """
    Orchestrates chat processing: routes to Live Chat, Elias, or RAG handler.
    """

    def __init__(self):
        self._router = IntentRouter()

    async def process(
        self,
        *,
        text: str,
        chatbot_id: str,
        session_id: Optional[str],
        context: Optional[Dict[str, Any]],
        auto_request_live_chat: bool,
        bot: Dict[str, Any],
        req: Request,
    ) -> OrchestratorResponse:
        """
        Route and process the request; return unified response.
        """
        bot_config = bot.get("config", {}) or {}
        decision = self._router.route(text=text, bot_config=bot_config, bot=bot)

        if decision.route == RouteType.LIVE_CHAT:
            result = await handle_live_chat(
                text=text,
                chatbot_id=chatbot_id,
                session_id=session_id,
                context=context,
                auto_request_live_chat=auto_request_live_chat,
                req=req,
            )
            # Publish on_handoff workflow event for async processing
            try:
                from services.message_broker import publish_workflow_event

                ctx = {"session_id": session_id, "user_message": text[:500]}
                publish_workflow_event("on_handoff", ctx, chatbot_id=chatbot_id)
            except Exception:
                pass
            return OrchestratorResponse(
                intent=result["intent"],
                confidence=result["confidence"],
                response=result["response"],
                sources=result.get("sources", []),
                live_chat_request_id=result.get("live_chat_request_id"),
                live_chat_status=result.get("live_chat_status"),
            )

        if decision.route == RouteType.ELIAS_GATEWAY:
            result = await handle_elias(
                text=text,
                chatbot_id=chatbot_id,
                session_id=session_id,
                bot_config=bot_config,
                bot=bot,
                tenant_id=bot.get("owner_id") if bot else None,
            )
            return result  # handle_elias returns OrchestratorResponse

        # Default: RAG (optionally with fallback chain)
        use_fallback = bot_config.get("useFallbackChain") or bot_config.get("use_fallback_chain")
        if use_fallback:
            from shared.constants.orchestrator_config import get_orchestrator_config
            from shared.constants.type_configurations import get_confidence_thresholds
            orch_config = get_orchestrator_config(bot_config)
            thresholds = get_confidence_thresholds(bot.get("type", "General Purpose"))
            conf_threshold = float(thresholds.get("fallback_threshold", 0.4))
            from application.chat.fallback_chain import run_fallback_chain
            return await run_fallback_chain(
                text=text,
                chatbot_id=chatbot_id,
                session_id=session_id,
                bot=bot,
                bot_config=bot_config,
                req=req,
                context=context,
                auto_request_live_chat=auto_request_live_chat,
                chain=orch_config.fallback_chain,
                confidence_threshold=conf_threshold,
            )
        return await handle_rag(
            text=text,
            chatbot_id=chatbot_id,
            session_id=session_id,
            bot=bot,
            bot_config=bot_config,
        )


chat_orchestrator = ChatOrchestrator()

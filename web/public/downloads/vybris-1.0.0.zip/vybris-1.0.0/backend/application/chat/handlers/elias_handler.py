"""
Elias Handler - routes to Elias gateway (OpenClaw) for chatbot backend.
"""

import os
import logging
from typing import Optional, Dict, Any

from application.chat.models import OrchestratorResponse

logger = logging.getLogger(__name__)
ELIAS_GATEWAY_URL = os.getenv("ELIAS_GATEWAY_URL", "").strip().rstrip("/")


async def handle_elias(
    *,
    text: str,
    chatbot_id: str,
    session_id: Optional[str],
    bot_config: Dict[str, Any],
    bot: Optional[Dict[str, Any]],
    tenant_id: Optional[str] = None,
) -> OrchestratorResponse:
    """
    Handle Elias gateway routing.
    Calls elias_client.try_elias_reply; on failure falls back to LLM.
    """
    elias_url = (bot_config.get("elias_url") or "").strip().rstrip("/")
    if not elias_url or not elias_url.startswith(("http://", "https://")):
        elias_url = ELIAS_GATEWAY_URL
    if not elias_url or not elias_url.startswith(("http://", "https://")):
        return OrchestratorResponse(
            intent="elias_unconfigured_fallback",
            confidence=0.0,
            response="Elias backend is selected but no gateway URL is configured. Please add elias_url in chatbot settings or set ELIAS_GATEWAY_URL.",
            sources=[],
        )

    elias_bot_name = (bot_config.get("elias_bot_name") or "Elias").strip() or "Elias"
    success, reply_text = await _call_elias(
        message=text,
        chatbot_id=chatbot_id,
        tenant_id=tenant_id,
        session_id=session_id,
        elias_url=elias_url,
        elias_bot_name=elias_bot_name,
    )

    if success and reply_text:
        # Skip 202 placeholder text - prefer real reply
        if "will appear in the conversation or voice panel shortly" not in (reply_text or ""):
            return OrchestratorResponse(
                intent="elias_response",
                confidence=0.95,
                response=reply_text.strip(),
                sources=[],
            )

    # Fallback: LLM so the user gets an actual response
    from services.llm import llm_service
    if llm_service.is_enabled():
        fallback_reply = await llm_service.generate_simple_reply(
            text,
            system_prompt="You are a helpful assistant. Answer concisely and clearly in the same language as the user.",
        )
        if fallback_reply and fallback_reply.strip():
            return OrchestratorResponse(
                intent="elias_fallback_response",
                confidence=0.7,
                response=fallback_reply.strip(),
                sources=[],
            )

    return OrchestratorResponse(
        intent="elias_unavailable_fallback",
        confidence=0.0,
        response="Elias is temporarily unavailable. Please try again later or contact support.",
        sources=[],
    )


async def _call_elias(
    *,
    message: str,
    chatbot_id: str,
    tenant_id: Optional[str],
    session_id: Optional[str],
    elias_url: str,
    elias_bot_name: str,
):
    """Wrap elias_client.try_elias_reply for testing."""
    from services.elias_client import try_elias_reply
    return await try_elias_reply(
        message=message,
        chatbot_id=chatbot_id,
        tenant_id=tenant_id,
        session_id=session_id,
        elias_url=elias_url,
        elias_bot_name=elias_bot_name,
    )

"""
Live Chat Handler - returns intent to connect user to human agent.
"""

import uuid
import logging
from typing import Optional, Dict, Any
from fastapi import Request

logger = logging.getLogger(__name__)


async def handle_live_chat(
    *,
    text: str,
    chatbot_id: str,
    session_id: Optional[str],
    context: Optional[Dict[str, Any]],
    auto_request_live_chat: bool,
    req: Request,
) -> Dict[str, Any]:
    """
    Handle live chat intent - return response that triggers auto-forward in widget.
    """
    live_msg = (
        "I'm connecting you to a human agent now. Please hold on while I find someone available to help you."
    )
    live_chat_request_id = None
    live_chat_status = None

    origin = req.headers.get("Origin")
    referer = req.headers.get("Referer")
    should_auto_request = bool(auto_request_live_chat)
    if not should_auto_request:
        should_auto_request = bool(session_id and (origin or referer))

    if should_auto_request and session_id:
        try:
            from services.database.live_chat import LiveChatDB
            request_id = f"lc_{uuid.uuid4().hex[:12]}"
            context_page_url = (context or {}).get("page_url")
            if not context_page_url:
                context_page_url = referer or origin
            entry = LiveChatDB.create_request(
                request_id=request_id,
                chatbot_id=chatbot_id,
                session_id=session_id,
                message=text,
                page_url=context_page_url,
            )
            if entry:
                live_chat_request_id = entry.get("request_id")
                live_chat_status = entry.get("status") or "queued"
        except Exception as e:
            logger.error(f"Auto live chat request failed: {e}")
    elif should_auto_request and not session_id:
        logger.warning("Auto live chat requested but session_id missing")

    return {
        "intent": "live_chat_auto_forward",
        "confidence": 1.0,
        "response": live_msg,
        "sources": [],
        "live_chat_request_id": live_chat_request_id,
        "live_chat_status": live_chat_status,
    }

#!/usr/bin/env python3
"""
RQ worker entrypoint for VYBR!S background jobs.

Usage:
    cd backend && python run_worker.py

Or with rq directly:
    cd backend && rq worker vybris_training --url redis://localhost:6379
"""

import os
import sys

# Ensure backend is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    from rq import Worker, Queue, Connection
    from jobs.queue import get_redis_connection, QUEUE_NAME

    redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
    with Connection(get_redis_connection()):
        queue = Queue(QUEUE_NAME)
        worker = Worker([queue])
        worker.work()

"""
Test Universal Inventory and Universal Booking integrations.
Tests the split integration flow: inventory (product/stock) and booking (availability, checkout) separately.
"""
import sys
sys.path.append('.')
import os
import json

# Set environment variables if needed
if not os.environ.get('POSTGRES_HOST'):
    os.environ['POSTGRES_HOST'] = os.environ.get('POSTGRES_HOST', 'localhost')
    os.environ['POSTGRES_PORT'] = os.environ.get('POSTGRES_PORT', '5434')
    os.environ['POSTGRES_DB'] = os.environ.get('POSTGRES_DB', 'vybris')
    os.environ['POSTGRES_USER'] = os.environ.get('POSTGRES_USER', 'vybris_admin')
    os.environ['POSTGRES_PASSWORD'] = os.environ.get('POSTGRES_PASSWORD', '5bYykkTGx4jaFtfqtR1OkF3er0lFzIpT')

from services.database import ChatbotDB, IntegrationDB
from services.integrations import IntegrationManager, IntegrationError

CHATBOT_ID = 'bot_c0ce242a3e9f'

def test_integration():
    print("=" * 80)
    print("UNIVERSAL INVENTORY & BOOKING INTEGRATION TEST (split)")
    print("=" * 80)
    
    # Step 1: Check chatbot exists
    print("\n1. Checking chatbot...")
    chatbot = ChatbotDB.get_by_id(CHATBOT_ID)
    if not chatbot:
        print(f"   ❌ Chatbot {CHATBOT_ID} not found")
        return False
    print(f"   ✅ Found chatbot: {chatbot['name']} (ID: {chatbot['id']})")
    
    # Step 2: Check integrations exist (inventory and/or booking)
    print("\n2. Checking integrations...")
    integrations = IntegrationDB.get_by_chatbot(CHATBOT_ID)
    inv_integration = next((i for i in integrations if i['integration_type'] == 'universal_inventory'), None)
    book_integration = next((i for i in integrations if i['integration_type'] == 'universal_booking'), None)
    
    if not inv_integration and not book_integration:
        print("   ❌ No universal_inventory or universal_booking integration found")
        return False
    if inv_integration:
        print(f"   ✅ Found Universal Inventory: {inv_integration['name']} (ID: {inv_integration['id']})")
    if book_integration:
        print(f"   ✅ Found Universal Booking: {book_integration['name']} (ID: {book_integration['id']})")
    
    # Step 3: Verify and test inventory integration if present
    if inv_integration:
        print("\n3. Verifying Universal Inventory...")
        if inv_integration['status'] != 'active':
            IntegrationDB.update(inv_integration['id'], {'status': 'active'})
        config = inv_integration.get('config', {})
        if not config.get('inventory_api_key'):
            print("   ❌ Universal Inventory missing inventory_api_key")
        elif not IntegrationManager.validate_config('universal_inventory', config):
            print("   ❌ Universal Inventory config validation failed")
        else:
            instance = IntegrationManager.get_integration('universal_inventory', config)
            items = instance.fetch_inventory_items()
            print(f"   ✅ Universal Inventory valid, fetch_inventory_items returned {len(items)} items")
    
    # Step 4: Verify and test booking integration if present
    if book_integration:
        print("\n4. Verifying Universal Booking...")
        if book_integration['status'] != 'active':
            IntegrationDB.update(book_integration['id'], {'status': 'active'})
        config = book_integration.get('config', {})
        if not config.get('booking_api_key'):
            print("   ❌ Universal Booking missing booking_api_key")
        elif not IntegrationManager.validate_config('universal_booking', config):
            print("   ❌ Universal Booking config validation failed")
        else:
            instance = IntegrationManager.get_integration('universal_booking', config)
            result = instance.process_text("I want to book")
            print(f"   ✅ Universal Booking valid, process_text(booking) returned: {bool(result)}")
    
    print("\n" + "=" * 80)
    print("✅ INTEGRATION TEST COMPLETE")
    print("=" * 80)
    print("\nSummary:")
    print(f"  - Universal Inventory: {'✅' if inv_integration else '—'}")
    print(f"  - Universal Booking: {'✅' if book_integration else '—'}")
    print("\nIntegrations are split: use universal_inventory for product/stock, universal_booking for availability and checkout.")
    
    return True

if __name__ == '__main__':
    try:
        success = test_integration()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

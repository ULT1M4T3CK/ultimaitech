#!/bin/bash
# VYBR!S - Installation Script
# Run this script to install and configure VYBR!S on your system

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔══════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     VYBR!S - Chatbot Platform Installer  ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════╝${NC}"
echo ""

# 1. Check for Docker
echo -e "${YELLOW}[1/5] Checking Docker...${NC}"
if ! command -v docker &> /dev/null; then
    echo -e "${RED}Docker is not installed. Please install Docker first:${NC}"
    echo "  https://docs.docker.com/get-docker/"
    exit 1
fi
if ! docker info &> /dev/null 2>&1; then
    echo -e "${RED}Docker is installed but not running. Please start Docker and try again.${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Docker is available${NC}"

# 2. Check for Docker Compose
echo -e "${YELLOW}[2/5] Checking Docker Compose...${NC}"
if ! docker compose version &> /dev/null 2>&1; then
    if ! command -v docker-compose &> /dev/null; then
        echo -e "${RED}Docker Compose is not installed. Please install Docker Compose.${NC}"
        exit 1
    fi
    COMPOSE_CMD="docker-compose"
else
    COMPOSE_CMD="docker compose"
fi
echo -e "${GREEN}✓ Docker Compose is available${NC}"

# 3. Create .env from template
echo -e "${YELLOW}[3/5] Configuring environment...${NC}"
if [ ! -f .env ]; then
    if [ -f .env.example ]; then
        cp .env.example .env
        echo -e "${GREEN}✓ Created .env from .env.example${NC}"
        echo -e "${YELLOW}  → IMPORTANT: Edit .env and set your passwords and API keys before first run!${NC}"
        echo "    - POSTGRES_PASSWORD"
        echo "    - JWT_SECRET_KEY"
        echo "    - QDRANT_API_KEY"
        echo "    - ADMIN_PASSWORD"
        echo "    - PERPLEXITY_API_KEY (for AI features)"
    else
        echo -e "${RED}.env.example not found. Cannot create .env${NC}"
        exit 1
    fi
else
    echo -e "${GREEN}✓ .env already exists${NC}"
fi

# 4. Create required data directories
echo -e "${YELLOW}[4/5] Creating data directories...${NC}"
mkdir -p data/postgres data/redis data/qdrant
mkdir -p data/backend/static/avatars data/backend/static/logos data/backend/static/invoices
echo -e "${GREEN}✓ Data directories created${NC}"

# 5. Build and start services
echo -e "${YELLOW}[5/5] Building and starting VYBR!S...${NC}"
echo ""
$COMPOSE_CMD build --no-cache 2>/dev/null || $COMPOSE_CMD build
$COMPOSE_CMD up -d

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  VYBR!S has been installed and started successfully!  ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo "Access the platform at:"
echo "  • Dashboard:  http://localhost:3000"
echo "  • API:       http://localhost:5000"
echo ""
echo "Useful commands:"
echo "  • View logs:  $COMPOSE_CMD logs -f"
echo "  • Stop:       $COMPOSE_CMD down"
echo "  • Start:      $COMPOSE_CMD up -d"
echo ""
echo -e "${YELLOW}If this is your first run, edit .env and set secure passwords, then run:${NC}"
echo "  $COMPOSE_CMD down && $COMPOSE_CMD up -d"
echo ""

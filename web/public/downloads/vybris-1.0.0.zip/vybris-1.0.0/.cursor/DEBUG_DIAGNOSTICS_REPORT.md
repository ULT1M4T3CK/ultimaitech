# VYBR!S Full Debug Diagnostics Report

**Generated:** 2026-02-14

---

## 1. System Status

| Component | Status | Details |
|-----------|--------|---------|
| **Docker** | ✅ Running | All services up |
| **Backend** | ✅ Running | Port 5000, 5002 |
| **Frontend** | ✅ Running | Port 3000, 3004, 3005, 3011 |
| **PostgreSQL** | ✅ Up | Port 5434 |
| **Redis** | ✅ Up | Internal 6379 |
| **Qdrant** | ✅ Up | Port 6335 |

---

## 2. Backend Health

| Endpoint | Status | Notes |
|---------|--------|------|
| `GET /health` | ✅ 200 | DB, Redis, Qdrant healthy |
| `GET /health/ready` | ⚠️ 404 | Route exists in app (confirmed via Python); may be nginx/proxy routing |
| `GET /api/v1/nlp/` | ✅ 200 | NLP Engine Running, Perplexity configured |

**Note:** `/health/ready` is registered in the app. If you access the backend through nginx or a path prefix (e.g. `/vybris/api`), try: `GET /vybris/api/health/ready` or `GET /health/ready` on the backend port directly.

---

## 3. Import Diagnostics (Backend)

| Module | Status |
|--------|--------|
| plugin_registry | ✅ OK |
| vision_service | ✅ OK |
| conversation_events | ✅ OK |
| main.app, analytics, ws_chat, conversation_flows, fallback_chain | ⚠️ Require venv (fastapi, psycopg2) |

---

## 4. Frontend Build

| Check | Status |
|-------|--------|
| TypeScript | ✅ Passes |
| Vite build | ✅ Success |
| Known fixes applied | Analytics.tsx (ternary bracket), ConversationStudio (unused var), KnowledgeTab (import path) |

---

## 5. Linter

- No linter errors in `main.py`, `analytics.py`, `ws_chat.py`, `vision_service.py`, `plugin_registry.py`

---

## 6. API Routes (from OpenAPI)

- `/health` – health check
- `/api/v1/chatbots/*` – chatbot CRUD, analytics, conversation-flow
- `/api/v1/nlp/*` – processing, training, QA
- `/api/v1/live-chat/*` – live chat
- `/api/v1/analytics/*` – intents, handoffs, attribution, recent, llm-audit, conversation-audit, prune-audit
- WebSocket: `/api/v1/chat/ws`

---

## 7. Fixes Applied

1. **Analytics.tsx** – Fixed ternary nesting: added missing `)` so third branch closes correctly.
2. **ConversationStudio.tsx** – Removed unused `flow`/`setFlow` state.
3. **KnowledgeTab.tsx** – Fixed import path: `../../hooks` → `../../../hooks` (tabs subfolder).

---

## 8. Recommendations

1. **`/health/ready` 404** – If you use nginx or a path prefix, ensure `/health/ready` is proxied correctly. The route exists in the app.
2. **Backend tests** – Run `pytest backend/tests/` (with DB/Redis/Qdrant) to validate integrations.
3. **Chat worker** – `chat-worker` service is in `docker-compose`; it runs when `USE_ASYNC_CHAT=true` and Redis Stream is used.

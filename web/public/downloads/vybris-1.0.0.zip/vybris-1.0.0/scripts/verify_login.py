#!/usr/bin/env python3
"""Verify a user exists and password checks out. Loads .env from project root."""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)

_env_path = ROOT / ".env"
if _env_path.exists():
    for line in _env_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k, v = k.strip(), v.strip()
        if v.startswith('"') and v.endswith('"'):
            v = v[1:-1].replace('\\"', '"')
        elif v.startswith("'") and v.endswith("'"):
            v = v[1:-1].replace("\\'", "'")
        if k and k not in os.environ:
            os.environ.setdefault(k, v)

if "--local" in sys.argv:
    sys.argv.remove("--local")
    os.environ["POSTGRES_HOST"] = "localhost"
    os.environ["POSTGRES_PORT"] = os.getenv("POSTGRES_PORT", "5434")

import psycopg2
from psycopg2.extras import RealDictCursor

sys.path.insert(0, str(ROOT / "backend"))
from passlib.context import CryptContext

pwd_context = CryptContext(
    schemes=["argon2", "bcrypt", "pbkdf2_sha256", "pbkdf2_sha512"],
    deprecated="auto",
    argon2__default_rounds=12,
)

DB_HOST = os.getenv("POSTGRES_HOST", "localhost")
DB_PORT = os.getenv("POSTGRES_PORT", "5434")
DB_NAME = os.getenv("POSTGRES_DB", "vybris")
DB_USER = os.getenv("POSTGRES_USER", "user")
DB_PASSWORD = os.getenv("POSTGRES_PASSWORD", "password")

def main():
    email = "info@ultimaitech.com"
    password = "UltimateX180@"

    print(f"Connecting to {DB_HOST}:{DB_PORT}/{DB_NAME}...")
    conn = psycopg2.connect(
        host=DB_HOST, port=int(DB_PORT), dbname=DB_NAME,
        user=DB_USER, password=DB_PASSWORD, cursor_factory=RealDictCursor,
    )
    cur = conn.cursor()

    cur.execute(
        "SELECT id, username, email, status, hashed_password FROM users WHERE email = %s",
        (email,),
    )
    user = cur.fetchone()
    cur.close()
    conn.close()

    if not user:
        print(f"No user with email {email!r}")
        return 1

    print(f"User: id={user['id']} username={user['username']!r} email={user['email']!r} status={user['status']!r}")
    print(f"hashed_password: {'SET' if user['hashed_password'] else 'MISSING'}")
    if not user["hashed_password"]:
        print("Cannot verify password – no hash stored.")
        return 1

    ok = pwd_context.verify(password, user["hashed_password"])
    print(f"verify_password('UltimateX180@'): {ok}")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())

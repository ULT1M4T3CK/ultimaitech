#!/bin/bash
# SOC 2 Compliance Setup Script for VYBR!S
# Automates initial setup of compliance controls

set -e

echo "========================================="
echo "VYBR!S SOC 2 Compliance Setup"
echo "========================================="
echo ""

# Color codes
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if running as user (not root, backups need user permissions)
if [ "$EUID" -eq 0 ]; then 
    echo -e "${RED}Please run this script as your normal user, not as root${NC}"
    exit 1
fi

PROJECT_ROOT="/home/andre/Desktop/Projects/my-website/VYBR!S"
cd "$PROJECT_ROOT"

echo "Step 1: Installing Python Dependencies for MFA..."
if [ -d "backend/.venv" ]; then
    source backend/.venv/bin/activate
    pip install pyotp==2.9.0 qrcode[pil]==7.4.2
    echo -e "${GREEN}✓ MFA dependencies installed${NC}"
else
    echo -e "${YELLOW}⚠ Virtual environment not found. Install manually:${NC}"
    echo "  pip install pyotp==2.9.0 qrcode[pil]==7.4.2"
fi

echo ""
echo "Step 2: Creating Backup Directories..."
sudo mkdir -p /var/backups/vybris
sudo chown $USER:$USER /var/backups/vybris
sudo mkdir -p /var/log
sudo touch /var/log/vybris_backup.log
sudo chown $USER:$USER /var/log/vybris_backup.log
echo -e "${GREEN}✓ Backup directories created${NC}"

echo ""
echo "Step 3: Making Scripts Executable..."
chmod +x scripts/*.sh
echo -e "${GREEN}✓ Scripts are executable${NC}"

echo ""
echo "Step 4: Generating GPG Key for Backupups (if not exists)..."
if ! gpg --list-keys backup@ultimaitech.com &>/dev/null; then
    echo "Generating GPG key for backup encryption..."
    gpg --batch --gen-key <<EOF
%no-protection
Key-Type: RSA
Key-Length: 2048
Name-Real: VYBR!S Backup
Name-Email: backup@ultimaitech.com
Expire-Date: 0
EOF
    echo -e "${GREEN}✓ GPG key generated${NC}"
else
    echo -e "${GREEN}✓ GPG key already exists${NC}"
fi

echo ""
echo "Step 5: PostgreSQL Encryption Setup..."
echo "Creating SSL certificates for PostgreSQL..."

# Create SSL directory in a temporary location first
SSL_TEMP_DIR="/tmp/vybris_ssl"
mkdir -p "$SSL_TEMP_DIR"

if [ ! -f "$SSL_TEMP_DIR/server.crt" ]; then
    cd "$SSL_TEMP_DIR"
    openssl req -new -x509 -days 365 -nodes -text \
        -out server.crt \
        -keyout server.key \
        -subj "/CN=vybris-postgres" 2>/dev/null
    chmod 600 server.key
    chmod 644 server.crt
    cd "$PROJECT_ROOT"
    echo -e "${GREEN}✓ SSL certificates generated in $SSL_TEMP_DIR${NC}"
    echo -e "${YELLOW}⚠ Manual step needed: Copy SSL certs to Docker volume${NC}"
    echo "  Run after containers are up:"
    echo "  docker cp $SSL_TEMP_DIR/server.crt vybris-postgres-1:/var/lib/postgresql/ssl/"
    echo "  docker cp $SSL_TEMP_DIR/server.key vybris-postgres-1:/var/lib/postgresql/ssl/"
    echo "  docker exec vybris-postgres-1 chown postgres:postgres /var/lib/postgresql/ssl/*"
else
    echo -e "${GREEN}✓ SSL certificates already exist${NC}"
fi

echo ""
echo "Step 6: Setting up Cron Jobs for Automated Backups..."
echo "Adding backup cron jobs..."

# Check if cron jobs already exist
if ! crontab -l 2>/dev/null | grep -q "vybris_backup"; then
    (crontab -l 2>/dev/null; echo "# VYBR!S Automated Backups (SOC 2 CC8.6)") | crontab -
    (crontab -l 2>/dev/null; echo "0 2 * * * $PROJECT_ROOT/scripts/backup_database.sh >> /var/log/vybris_backup.log 2>&1") | crontab -
    (crontab -l 2>/dev/null; echo "0 3 * * 0 $PROJECT_ROOT/scripts/test_backup_restore.sh >> /var/log/vybris_backup_test.log 2>&1") | crontab -
    echo -e "${GREEN}✓ Cron jobs installed${NC}"
else
    echo -e "${YELLOW}⚠ Cron jobs already exist. Skipping...${NC}"
fi

echo ""
echo "Step 7: Running Initial Backup Test..."
echo "This will create your first backup..."
./scripts/backup_database.sh
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Initial backup successful${NC}"
else
    echo -e "${RED}✗ Backup failed. Check /var/log/vybris_backup.log${NC}"
fi

echo ""
echo "Step 8: Updating Docker Compose for PostgreSQL SSL..."
if ! grep -q "ssl=on" docker-compose.yml; then
    echo -e "${YELLOW}⚠ Manual step required:${NC}"
    echo "  Add to docker-compose.yml under postgres service:"
    echo "    command: -c ssl=on -c ssl_cert_file=/var/lib/postgresql/ssl/server.crt -c ssl_key_file=/var/lib/postgresql/ssl/server.key"
    echo "    volumes:"
    echo "      - ./data/postgres/ssl:/var/lib/postgresql/ssl:ro"
else
    echo -e "${GREEN}✓ PostgreSQL SSL already configured${NC}"
fi

echo ""
echo "Step 9: Restarting Backend to Apply MFA Database Migrations..."
docker-compose restart backend
sleep 5
echo -e "${GREEN}✓ Backend restarted with MFA support${NC}"

echo ""
echo "========================================="
echo "Setup Complete!"
echo "========================================="
echo ""
echo -e "${GREEN}✓ Automated backups configured (daily at 2:00 AM)${NC}"
echo -e "${GREEN}✓ MFA system ready (database migrated)${NC}"
echo -e "${GREEN}✓ Privacy policy available at /privacy${NC}"
echo -e "${GREEN}✓ Compliance monitoring at /compliance/*${NC}"
echo ""
echo "Next Steps:"
echo "1. Update .env with generated keys:"
echo "   - POSTGRES_ENCRYPTION_KEY (generate with: openssl rand -base64 32)"
echo "   - GCS_BACKUP_BUCKET (optional, for cloud backups)"
echo ""
echo "2. Test privacy policy:"
echo "   Visit: https://ultimaitech.com/vybris/privacy"
echo""
echo "3. Enable admin MFA:"
echo "   - Login as admin"
echo "   - Go to Settings > Security"
echo "   - Enroll in MFA"
echo ""
echo "4. Monitor compliance:"
echo "   GET /compliance/audit-summary"
echo ""
echo "View full documentation:"
echo "  cat docs/SOC2_IMPLEMENTATION.md"
echo ""

#!/bin/bash
# VYBR!S AWS Deployment Script
# Run this script on your EC2 instance

set -e

echo "╔════════════════════════════════════════════════════════════╗"
echo "║           VYBR!S AWS Deployment Script                     ║"
echo "╚════════════════════════════════════════════════════════════╝"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
REPO_URL="${REPO_URL:-https://github.com/YOUR_USERNAME/VYBRIS.git}"
INSTALL_DIR="${INSTALL_DIR:-$HOME/vybris}"

echo -e "\n${YELLOW}Step 1: Verify Docker installation${NC}"
if command -v docker &> /dev/null; then
    echo -e "${GREEN}✓ Docker is installed: $(docker --version)${NC}"
else
    echo -e "${RED}✗ Docker not found. Installing...${NC}"
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    echo -e "${GREEN}✓ Docker installed. Please log out and back in, then run this script again.${NC}"
    exit 1
fi

echo -e "\n${YELLOW}Step 2: Verify Docker Compose${NC}"
if docker compose version &> /dev/null; then
    echo -e "${GREEN}✓ Docker Compose V2 is installed${NC}"
else
    echo -e "${RED}✗ Docker Compose not found. Installing...${NC}"
    # Support both Ubuntu (apt) and Amazon Linux (dnf)
    if command -v dnf &> /dev/null; then
        sudo dnf install -y docker-compose-plugin
    elif command -v apt &> /dev/null; then
        sudo apt update
        sudo apt install -y docker-compose-plugin
    fi
fi

echo -e "\n${YELLOW}Step 3: Clone/Update Repository${NC}"
if [ -d "$INSTALL_DIR" ]; then
    echo "Directory $INSTALL_DIR exists. Pulling latest changes..."
    cd "$INSTALL_DIR"
    git pull origin main || git pull origin master || echo "Could not pull, continuing with existing code..."
else
    echo "Cloning repository to $INSTALL_DIR..."
    git clone "$REPO_URL" "$INSTALL_DIR"
    cd "$INSTALL_DIR"
fi

echo -e "\n${YELLOW}Step 4: Environment Configuration${NC}"
if [ -f ".env" ]; then
    echo -e "${GREEN}✓ .env file exists${NC}"
else
    if [ -f ".env.example" ]; then
        echo "Creating .env from .env.example..."
        cp .env.example .env
        echo -e "${YELLOW}⚠ Please edit .env file with your configuration:${NC}"
        echo "   nano $INSTALL_DIR/.env"
        echo ""
        echo "Required variables to update:"
        echo "  - POSTGRES_PASSWORD"
        echo "  - JWT_SECRET_KEY"
        echo "  - ADMIN_PASSWORD"
        echo "  - SMTP credentials (if using email)"
        echo "  - PERPLEXITY_API_KEY"
        echo ""
        read -p "Press Enter after you have configured .env, or Ctrl+C to exit..."
    else
        echo -e "${RED}✗ No .env.example found!${NC}"
        exit 1
    fi
fi

echo -e "\n${YELLOW}Step 5: Build Docker Containers${NC}"
echo "This may take several minutes on first run..."
docker compose build

echo -e "\n${YELLOW}Step 6: Start Services${NC}"
docker compose up -d

echo -e "\n${YELLOW}Step 7: Wait for services to be ready${NC}"
echo "Waiting 30 seconds for containers to initialize..."
sleep 30

echo -e "\n${YELLOW}Step 8: Verify Deployment${NC}"
echo "Container Status:"
docker compose ps

echo -e "\n${GREEN}╔════════════════════════════════════════════════════════════╗"
echo "║              Deployment Complete!                           ║"
echo "╚════════════════════════════════════════════════════════════╝${NC}"

# Get EC2 public IP
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || echo "YOUR_EC2_IP")

echo ""
echo "Access your application at:"
echo "  Frontend:  http://$PUBLIC_IP:3000"
echo "  Backend:   http://$PUBLIC_IP:5000"
echo ""
echo "Useful commands:"
echo "  View logs:      docker compose logs -f"
echo "  Stop services:  docker compose down"
echo "  Restart:        docker compose restart"
echo ""

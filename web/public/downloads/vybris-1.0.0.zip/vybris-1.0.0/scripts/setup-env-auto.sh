#!/bin/bash
# Auto-generate .env with secure random values - no user input needed
# Used by the no-code installer

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$ROOT_DIR"

# Generate secure random values (works without Python)
gen_pass() { openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 32; }
gen_secret() { openssl rand -base64 48; }

POSTGRES_PW=$(gen_pass)
JWT_SECRET=$(gen_secret)
QDRANT_KEY=$(gen_secret)
ADMIN_PW=$(gen_pass)
ENC_KEY=$(gen_secret)

# Create .env from template with safe replacements
cp .env.example .env

# Replace each placeholder (use | as sed delimiter to avoid / in base64)
sed -i "s|YOUR_SECURE_PASSWORD_HERE|$POSTGRES_PW|g" .env
sed -i "s|YOUR_SECURE_JWT_SECRET_HERE|$JWT_SECRET|g" .env
sed -i "s|your_secure_qdrant_api_key_here|$QDRANT_KEY|g" .env
sed -i "s|YOUR_SECURE_ADMIN_PASSWORD_HERE|$ADMIN_PW|g" .env
sed -i "s|YOUR_POSTGRES_ENCRYPTION_KEY_HERE|$ENC_KEY|g" .env
# Optional: leave placeholders for API keys - app runs without them
sed -i "s|YOUR_ZOHO_APP_PASSWORD_HERE|optional_configure_in_dashboard|g" .env
sed -i "s|pplx_YOUR_API_KEY_HERE|pplx_add_in_dashboard_for_ai|g" .env

# Output admin password for display to user
echo "$ADMIN_PW"

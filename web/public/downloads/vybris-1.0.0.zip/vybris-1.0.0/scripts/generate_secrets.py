#!/usr/bin/env python3
"""
Secure Secrets Generator for VYBR!S
Generates cryptographically secure passwords and keys for production deployment.
"""

import secrets
import string
import hashlib
from datetime import datetime

def generate_password(length=32):
    """Generate a secure random password."""
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def generate_jwt_secret(length=64):
    """Generate a secure JWT secret key."""
    return secrets.token_urlsafe(length)

def generate_postgres_password(length=32):
    """Generate a PostgreSQL-safe password (alphanumeric only)."""
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def main():
    print("=" * 70)
    print("VYBR!S Secure Secrets Generator")
    print("=" * 70)
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    print("⚠️  IMPORTANT: Store these securely and never commit to Git!")
    print("=" * 70)
    print()
    
    # Generate all secrets
    postgres_password = generate_postgres_password()
    jwt_secret = generate_jwt_secret()
    admin_password = generate_password(24)
    
    print("# PostgreSQL Configuration")
    print(f"POSTGRES_PASSWORD={postgres_password}")
    print()
    
    print("# JWT Security")
    print(f"JWT_SECRET_KEY={jwt_secret}")
    print()
    
    print("# Admin Account")
    print(f"ADMIN_PASSWORD={admin_password}")
    print()
    
    print("=" * 70)
    print("NEXT STEPS:")
    print("=" * 70)
    print("1. Copy the values above to your .env file")
    print("2. Regenerate API keys from external services:")
    print("   - Resend: https://resend.com/api-keys")
    print("   - Perplexity: https://www.perplexity.ai/settings/api")
    print("3. Update RESEND_API_KEY and PERPLEXITY_API_KEY in .env")
    print("4. Restart all services: docker-compose down && docker-compose up -d")
    print("5. All users will need to log in again")
    print()
    print("⚠️  BACKUP: Save current .env before replacing:")
    print("   cp .env .env.backup.$(date +%Y%m%d_%H%M%S)")
    print()

if __name__ == "__main__":
    main()

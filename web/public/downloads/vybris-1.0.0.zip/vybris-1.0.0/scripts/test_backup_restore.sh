#!/bin/bash
# Weekly Backup Restore Test for VYBR!S
# SOC 2 Compliance: CC8.6 (Data Recovery Testing)
#
# This script tests backup restoration weekly to ensure backups are valid

set -e

BACKUP_DIR="/var/backups/vybris"
TEST_DB="vybris_test_restore"
LOG_FILE="/var/log/vybris_backup_test.log"

log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "=== Starting Weekly Backup Restore Test ==="

# Get latest backup
LATEST_POSTGRES=$(ls -t "$BACKUP_DIR"/postgres_*.sql.gpg 2>/dev/null | head -1)

if [ -z "$LATEST_POSTGRES" ]; then
    log "ERROR: No backup files found!"
    exit 1
fi

log "Testing backup: $LATEST_POSTGRES"

# Decrypt backup
log "Decrypting backup..."
gpg --batch --yes --decrypt "$LATEST_POSTGRES" > /tmp/test_restore.sql

# Create test database
log "Creating test database..."
docker exec vybris-postgres-1 psql -U "$POSTGRES_USER" -c "DROP DATABASE IF EXISTS $TEST_DB"
docker exec vybris-postgres-1 psql -U "$POSTGRES_USER" -c "CREATE DATABASE $TEST_DB"

# Restore to test database
log "Restoring backup to test database..."
docker exec -i vybris-postgres-1 psql -U "$POSTGRES_USER" -d "$TEST_DB" < /tmp/test_restore.sql

# Verify restoration
log "Verifying restored data..."
ROW_COUNT=$(docker exec vybris-postgres-1 psql -U "$POSTGRES_USER" -d "$TEST_DB" -t -c "SELECT COUNT(*) FROM users")

if [ "$ROW_COUNT" -gt 0 ]; then
    log "✅ Backup restore test PASSED - $ROW_COUNT users found"
else
    log "❌ Backup restore test FAILED - No data found!"
    exit 1
fi

# Cleanup
log "Cleaning up..."
docker exec vybris-postgres-1 psql -U "$POSTGRES_USER" -c "DROP DATABASE $TEST_DB"
rm /tmp/test_restore.sql

log "=== Backup Restore Test Complete ==="
exit 0

#!/bin/bash
set -e
set +H  # Disable history expansion to handle "!" in paths

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration (PEM: prefer env, then default path, then project root)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PEM_KEY="${PEM_KEY:-/home/andre/Desktop/Documents/AWS/vybrs.pem}"
[ ! -f "$PEM_KEY" ] && [ -f "$PROJECT_ROOT/vybrs.pem" ] && PEM_KEY="$PROJECT_ROOT/vybrs.pem"
REMOTE_USER="${REMOTE_USER:-ec2-user}"
REMOTE_HOST="${REMOTE_HOST:-13.50.101.58}"
REMOTE_DIR="${REMOTE_DIR:-~/vybris}"
LOCAL_DIR="."

echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║           VYBR!S AWS Deployment Script                     ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"

# Verify PEM key exists
if [ ! -f "$PEM_KEY" ]; then
    echo -e "${RED}✗ ERROR: PEM key not found at $PEM_KEY${NC}"
    echo "  Set PEM_KEY or place vybrs.pem in project root."
    exit 1
fi

# Set correct permissions on PEM key
echo -e "${YELLOW}Setting PEM key permissions...${NC}"
chmod 400 "$PEM_KEY" 2>/dev/null || true
echo -e "${GREEN}✓ PEM key permissions set${NC}"

# Verify SSH connection
echo -e "${YELLOW}Verifying SSH connection...${NC}"
if ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 -i "$PEM_KEY" "$REMOTE_USER@$REMOTE_HOST" "echo 'Connection successful'" 2>/dev/null; then
    echo -e "${GREEN}✓ SSH connection verified${NC}"
else
    echo -e "${RED}✗ Cannot connect to $REMOTE_USER@$REMOTE_HOST${NC}"
    echo -e "${YELLOW}Please verify:${NC}"
    echo "  - IP address: $REMOTE_HOST"
    echo "  - PEM key: $PEM_KEY"
    echo "  - Security group allows SSH (port 22)"
    exit 1
fi

echo -e "${YELLOW}Deploying from $(pwd) to $REMOTE_USER@$REMOTE_HOST:$REMOTE_DIR${NC}"

# 1. Sync files
echo -e "\n${YELLOW}Step 1: Syncing files...${NC}"
rsync -avz --progress --delete --no-times -e "ssh -o StrictHostKeyChecking=no -i $PEM_KEY" \
    --exclude '.git' \
    --exclude '.venv' \
    --exclude '__pycache__' \
    --exclude 'node_modules' \
    --exclude 'data' \
    --exclude 'dist' \
    --exclude '.env' \
    --exclude '*.pem' \
    --exclude '.DS_Store' \
    --exclude '*.log' \
    --exclude 'backend/venv' \
    "$LOCAL_DIR/" "$REMOTE_USER@$REMOTE_HOST:$REMOTE_DIR/"

echo -e "${GREEN}✓ Files synced successfully${NC}"

# 2. Rebuild and Restart
echo -e "\n${YELLOW}Step 2: Rebuilding and restarting containers on remote...${NC}"
# Use timeout and force TTY allocation for better control
ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=30 -o ServerAliveCountMax=3 -i "$PEM_KEY" "$REMOTE_USER@$REMOTE_HOST" << 'ENDSSH'
    set -e
    cd ~/vybris
    
    # Ensure we're in the right directory
    if [ ! -f "docker-compose.yml" ]; then
        echo "ERROR: docker-compose.yml not found in $(pwd)"
        exit 1
    fi
    
    # Check if .env exists, if not warn
    if [ ! -f .env ]; then
        echo "⚠️  WARNING: No .env file found on remote."
        if [ -f .env.example ]; then
            echo "Copying .env.example to .env..."
            cp .env.example .env
            echo "⚠️  Please update .env file with your configuration!"
        else
            echo "ERROR: No .env.example found either!"
            exit 1
        fi
    fi

    # Fix avatar upload directory permissions
    echo "Creating necessary directories..."
    mkdir -p ./data/backend/static/avatars
    mkdir -p ./data/backend/static/logos
    mkdir -p ./data/backend/static/invoices
    mkdir -p ./data/postgres
    mkdir -p ./data/redis
    mkdir -p ./data/qdrant
    
    echo "Fixing permissions..."
    # Fix ownership first if files exist
    if [ -d ./data/backend/static/avatars ]; then
        sudo chown -R $USER:$USER ./data/backend/static/avatars 2>/dev/null || true
    fi
    if [ -d ./data/backend/static/logos ]; then
        sudo chown -R $USER:$USER ./data/backend/static/logos 2>/dev/null || true
    fi
    chmod -R 755 ./data/backend/static/avatars 2>/dev/null || sudo chmod -R 755 ./data/backend/static/avatars 2>/dev/null || true
    chmod -R 755 ./data/backend/static/logos 2>/dev/null || sudo chmod -R 755 ./data/backend/static/logos 2>/dev/null || true
    
    # Build and restart
    echo "Building Docker images (this may take a while)..."
    # Use docker-compose if available, otherwise docker compose
    if command -v docker-compose &> /dev/null; then
        DOCKER_COMPOSE_CMD="docker-compose"
    else
        DOCKER_COMPOSE_CMD="docker compose"
    fi
    
    # Build only changed services (faster)
    # Frontend usually builds faster, so do it first
    echo "Building frontend..."
    timeout 600 $DOCKER_COMPOSE_CMD build frontend || {
        echo "⚠️  Frontend build timed out or failed, continuing..."
    }
    
    echo "Building backend (this may take 5-10 minutes for PyTorch)..."
    # Set a longer timeout for backend build (15 minutes) due to PyTorch
    timeout 900 $DOCKER_COMPOSE_CMD build backend || {
        echo "⚠️  Backend build timed out or failed"
        echo "Attempting to restart with existing image..."
    }
    
    echo "Stopping existing containers..."
    $DOCKER_COMPOSE_CMD down || true
    
    echo "Starting containers..."
    $DOCKER_COMPOSE_CMD up -d
    
    # Wait for services to be healthy
    echo "Waiting for services to start..."
    sleep 15
    
    # Check container status
    echo ""
    echo "Container Status:"
    $DOCKER_COMPOSE_CMD ps
    
    # Check logs for errors
    echo ""
    echo "Checking backend logs for errors..."
    if $DOCKER_COMPOSE_CMD logs backend 2>/dev/null | tail -20 | grep -i "error\|exception\|failed" > /dev/null; then
        echo "⚠️  WARNING: Some errors detected in backend logs. Check with: $DOCKER_COMPOSE_CMD logs backend"
    else
        echo "✓ Backend started successfully"
    fi
    
    # Prune unused images to save space
    echo "Cleaning up unused Docker images..."
    docker image prune -f
    
    echo ""
    echo "✅ Deployment complete on remote server!"
ENDSSH

# 3. Verify deployment
echo -e "\n${YELLOW}Step 3: Verifying deployment...${NC}"
sleep 5

# Check backend /health (dedicated health endpoint)
echo "Checking backend health (/health)..."
BACKEND_CODE=$(ssh -o StrictHostKeyChecking=no -i "$PEM_KEY" "$REMOTE_USER@$REMOTE_HOST" "curl -s -o /dev/null -w '%{http_code}' --max-time 10 http://localhost:5000/health" 2>/dev/null || echo "000")
if [ "$BACKEND_CODE" = "200" ]; then
    echo -e "${GREEN}✓ Backend is healthy (HTTP 200)${NC}"
else
    echo -e "${YELLOW}⚠️  Backend /health returned HTTP $BACKEND_CODE (expected 200)${NC}"
fi

# Check if frontend is responding
echo "Checking frontend health..."
if ssh -o StrictHostKeyChecking=no -i "$PEM_KEY" "$REMOTE_USER@$REMOTE_HOST" "curl -s -o /dev/null -w '%{http_code}' http://localhost:3000/vybris/" | grep -q "200"; then
    echo -e "${GREEN}✓ Frontend is responding${NC}"
else
    echo -e "${YELLOW}⚠️  Frontend health check inconclusive${NC}"
fi

echo -e "\n${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║              Deployment Complete!                           ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"

echo ""
echo "Access your application:"
echo "  Frontend:  http://$REMOTE_HOST:3000/vybris"
echo "  Backend:   http://$REMOTE_HOST:5000"
echo ""
echo "Optional (Elias tab Ask feature): On the server, set ELIAS_GATEWAY_URL in .env (e.g. http://127.0.0.1:18789) and run: docker compose up -d backend"
echo ""
echo "Useful commands:"
echo "  View logs:       ssh -i $PEM_KEY $REMOTE_USER@$REMOTE_HOST 'cd ~/vybris && docker compose logs -f'"
echo "  View status:     ssh -i $PEM_KEY $REMOTE_USER@$REMOTE_HOST 'cd ~/vybris && docker compose ps'"
echo "  Restart:         ssh -i $PEM_KEY $REMOTE_USER@$REMOTE_HOST 'cd ~/vybris && docker compose restart'"
echo ""

#!/bin/bash
# Secure .env updater script
# This script updates the .env file with new secure credentials

ENV_FILE="/home/andre/Desktop/Projects/my-website/VYBR!S/.env"

echo "Updating .env file with new secure credentials..."

# Update PostgreSQL password
sed -i 's/^POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=5bYykkTGx4jaFtfqtR1OkF3er0lFzIpT/' "$ENV_FILE"

# Update JWT secret
sed -i 's|^JWT_SECRET_KEY=.*|JWT_SECRET_KEY=Ukh8XYoAKaLawhubVpihgAPx4CWmG3FvM-fu0l_Se2cKODx5FKR8kLKUNWN4u-ROkbJgqsZeD0c0Tp4dFbXiMA|' "$ENV_FILE"

# Update admin password
sed -i 's/^ADMIN_PASSWORD=.*/ADMIN_PASSWORD=gze*01zvvGdC)ZHh6^$EvSyM/' "$ENV_FILE"

# Update Resend API key
sed -i 's/^RESEND_API_KEY=.*/RESEND_API_KEY=re_b6ssTwLd_CuCns5a2WZtM9LgvJTgCiKRm/' "$ENV_FILE"

# Update Perplexity API key
sed -i 's/^PERPLEXITY_API_KEY=.*/PERPLEXITY_API_KEY=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/' "$ENV_FILE"

echo "✅ .env file updated successfully!"
echo ""
echo "New credentials:"
echo "  - PostgreSQL password: ROTATED"
echo "  - JWT secret: ROTATED"
echo "  - Admin password: ROTATED"
echo "  - Resend API key: UPDATED"
echo "  - Perplexity API key: UPDATED"
echo ""
echo "Next steps:"
echo "1. cd frontend && npm install && npm run build"
echo "2. docker-compose down"
echo "3. docker-compose build --no-cache"
echo "4. docker-compose up -d"

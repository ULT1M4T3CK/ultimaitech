import sys
import os
import asyncio
import uuid
import json
from datetime import date

# Add backend to path
sys.path.append(os.path.join(os.path.dirname(__file__), "../backend"))

from services.database import CRMLeadDB, CRMCompanyDB
from routers.crm import LeadUpdate

# Mock get_db_connection to use real DB
# We assume we can import and run this.

def test_update_repro():
    print("Testing Lead Update...")
    
    # 1. Create a fresh Lead
    lead_id = f"lead_repro_{uuid.uuid4().hex[:8]}"
    company_id = f"comp_repro_{uuid.uuid4().hex[:8]}"
    
    # Create DB records manually/directly for setup
    CRMCompanyDB.create({
        'id': company_id,
        'name': 'Repro Corp'
    })
    
    CRMLeadDB.create({
        'id': lead_id,
        'name': 'Repro Lead',
        'status': 'negotiation', 
        'priority': 'medium'
    })
    
    print(f"Created Lead: {lead_id}, Company: {company_id}")
    
    # 2. Simulate the UPDATE that fails
    # User sends {"company_id": "...", "status": "won"}
    
    updates = {
        'company_id': company_id,
        'status': 'won'
    }
    
    print(f"Applying updates: {updates}")
    
    # Call the DB Update directly first to see if DB layer works
    updated_lead = CRMLeadDB.update(lead_id, updates)
    
    if updated_lead['company_id'] == company_id:
        print(" [OK] DB Layer check passed: company_id is updated.")
    else:
        print(f" [FAIL] DB Layer check failed: company_id is {updated_lead.get('company_id')}")
        
    if updated_lead['status'] == 'won':
        print(" [OK] DB Layer check passed: status is won.")
    else:
        print(f" [FAIL] DB Layer check failed: status is {updated_lead.get('status')}")

    # Clean up
    CRMLeadDB.delete(lead_id)
    CRMCompanyDB.delete(company_id)

if __name__ == "__main__":
    test_update_repro()

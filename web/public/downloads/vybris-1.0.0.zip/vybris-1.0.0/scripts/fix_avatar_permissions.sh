#!/bin/bash
# Fix permissions for avatar uploads
# Run this script if avatar uploads are failing

echo "Fixing avatar upload directory permissions..."

# Create directories if they don't exist
mkdir -p ./data/backend/static/avatars
mkdir -p ./data/backend/static/logos

# Set permissions (755 for directories, 644 for files)
chmod -R 755 ./data/backend/static/avatars
chmod -R 755 ./data/backend/static/logos

# If running in Docker, the container user (appuser, UID 1000) needs write access
# Check if we're on macOS/Linux
if [[ "$OSTYPE" == "darwin"* ]] || [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Make sure the directory is writable by the container user (UID 1000)
    # On macOS, Docker Desktop runs containers with your user, so this should work
    # On Linux, you may need to adjust the UID
    echo "Setting ownership for container user (UID 1000)..."
    
    # Try to set ownership to UID 1000 (container user)
    # If this fails, the directory should still be writable if permissions are correct
    if command -v chown &> /dev/null; then
        sudo chown -R 1000:1000 ./data/backend/static/avatars 2>/dev/null || \
        chmod -R 777 ./data/backend/static/avatars
        
        sudo chown -R 1000:1000 ./data/backend/static/logos 2>/dev/null || \
        chmod -R 777 ./data/backend/static/logos
    else
        chmod -R 777 ./data/backend/static/avatars
        chmod -R 777 ./data/backend/static/logos
    fi
fi

echo "✅ Permissions fixed!"
echo ""
echo "If uploads still fail, try:"
echo "1. Restart Docker containers: docker-compose restart backend"
echo "2. Check Docker logs: docker-compose logs backend | grep -i avatar"
echo "3. Verify directory exists: ls -la ./data/backend/static/avatars"

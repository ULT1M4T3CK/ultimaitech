#!/usr/bin/env python3
"""
Reset a user's password (e.g. after login issues).
Uses the same hashing as the auth service.

Usage:
  # From project root, with .env present:
  python scripts/reset_password.py <email_or_username> <new_password>

  # For local Docker Postgres (host side):
  POSTGRES_HOST=localhost POSTGRES_PORT=5434 python scripts/reset_password.py <email_or_username> <new_password>

  # Load .env from project root (optional, if you use dotenv):
  python -c "import runpy; runpy.run_path('scripts/reset_password.py')"  # not needed with below

Run from project root. Needs POSTGRES_* in env (or .env in root).
Use backend venv for deps:  ./backend/venv/bin/python scripts/reset_password.py ...
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

# Project root (parent of scripts/)
ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)

# Load .env if present (simple parser, no extra deps)
_env_path = ROOT / ".env"
if _env_path.exists():
    for line in _env_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k, v = k.strip(), v.strip()
        if v.startswith('"') and v.endswith('"'):
            v = v[1:-1].replace('\\"', '"')
        elif v.startswith("'") and v.endswith("'"):
            v = v[1:-1].replace("\\'", "'")
        if k and k not in os.environ:
            os.environ.setdefault(k, v)

import psycopg2
from psycopg2.extras import RealDictCursor

# Use same hashing as auth
sys.path.insert(0, str(ROOT / "backend"))
from passlib.context import CryptContext

pwd_context = CryptContext(
    schemes=["argon2", "bcrypt", "pbkdf2_sha256", "pbkdf2_sha512"],
    deprecated="auto",
    argon2__default_rounds=12,
)

DB_HOST = os.getenv("POSTGRES_HOST", "localhost")
DB_PORT = os.getenv("POSTGRES_PORT", "5434")
DB_NAME = os.getenv("POSTGRES_DB", "vybris")
DB_USER = os.getenv("POSTGRES_USER", "user")
DB_PASSWORD = os.getenv("POSTGRES_PASSWORD", "password")


def main() -> None:
    args = [a for a in sys.argv[1:] if a != "--local"]
    if "--local" in sys.argv:
        os.environ["POSTGRES_HOST"] = "localhost"
        os.environ["POSTGRES_PORT"] = os.getenv("POSTGRES_PORT", "5434")
    if len(args) < 2:
        print("Usage: python scripts/reset_password.py <email_or_username> <new_password> [--local]")
        print("  --local  use localhost:5434 (when Postgres runs in Docker and you run this on the host)")
        print("Example:  python scripts/reset_password.py --local info@ultimaitech.com myNewPassword")
        sys.exit(1)

    identifier = args[0].strip()
    new_password = args[1]
    if len(new_password) < 8:
        print("Password must be at least 8 characters.")
        sys.exit(1)

    print(f"Connecting to PostgreSQL at {DB_HOST}:{DB_PORT}/{DB_NAME}...")
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            port=int(DB_PORT),
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            cursor_factory=RealDictCursor,
        )
    except Exception as e:
        print(f"Database connection failed: {e}")
        print("For local Docker Postgres, run: POSTGRES_HOST=localhost POSTGRES_PORT=5434 python scripts/reset_password.py ...")
        sys.exit(1)

    cur = conn.cursor()

    # Find by username or email
    cur.execute(
        "SELECT id, username, email, full_name FROM users WHERE username = %s OR email = %s",
        (identifier, identifier),
    )
    user = cur.fetchone()
    if not user:
        print(f"No user found for '{identifier}' (username or email).")
        cur.close()
        conn.close()
        sys.exit(1)

    hashed = pwd_context.hash(new_password)
    cur.execute(
        "UPDATE users SET hashed_password = %s WHERE id = %s RETURNING id, username, email",
        (hashed, user["id"]),
    )
    row = cur.fetchone()
    conn.commit()
    cur.close()
    conn.close()

    print(f"Password updated for {row['email']} ({row['username']}). You can log in with the new password.")


if __name__ == "__main__":
    main()

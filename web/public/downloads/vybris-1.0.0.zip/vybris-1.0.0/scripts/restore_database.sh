#!/bin/bash
# Database Restore Script for VYBR!S
# SOC 2 Compliance: CC8.6, A1.3
#
# Usage: ./restore_database.sh [backup_date]
# Example: ./restore_database.sh 20251213_140000

set -e

BACKUP_DIR="/var/backups/vybris"
LOG_FILE="/var/log/vybris_restore.log"

log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Get backup date from argument or use latest
if [ -z "$1" ]; then
    POSTGRES_BACKUP=$(ls -t "$BACKUP_DIR"/postgres_*.sql.gpg 2>/dev/null | head -1)
    QDRANT_BACKUP=$(ls -t "$BACKUP_DIR"/qdrant_*.tar.gz.gpg 2>/dev/null | head -1)
    log "No date specified, using latest backups"
else
    POSTGRES_BACKUP="$BACKUP_DIR/postgres_$1.sql.gpg"
    QDRANT_BACKUP="$BACKUP_DIR/qdrant_$1.tar.gz.gpg"
fi

if [ ! -f "$POSTGRES_BACKUP" ] || [ ! -f "$QDRANT_BACKUP" ]; then
    log "ERROR: Backup files not found!"
    exit 1
fi

log "=== Starting VYBR!S Restore ==="
log "PostgreSQL backup: $POSTGRES_BACKUP"
log "Qdrant backup: $QDRANT_BACKUP"

read -p "This will OVERWRITE current data. Continue? (yes/no): " confirm
if [ "$confirm" != "yes" ]; then
    log "Restore cancelled by user"
    exit 0
fi

# Decrypt backups
log "Decrypting backups..."
gpg --batch --yes --decrypt "$POSTGRES_BACKUP" > "${POSTGRES_BACKUP%.gpg}"
gpg --batch --yes --decrypt "$QDRANT_BACKUP" > "${QDRANT_BACKUP%.gpg}"

# Restore PostgreSQL
log "Restoring PostgreSQL..."
docker exec -i vybris-postgres-1 psql \
    -U "$POSTGRES_USER" \
    -d "$POSTGRES_DB" \
    < "${POSTGRES_BACKUP%.gpg}"

# Restore Qdrant
log "Restoring Qdrant..."
docker-compose -f /home/andre/Desktop/Projects/my-website/VYBR!S/docker-compose.yml stop vector-db
tar -xzf "${QDRANT_BACKUP%.gpg}" \
    -C /home/andre/Desktop/Projects/my-website/VYBR!S/data
docker-compose -f /home/andre/Desktop/Projects/my-website/VYBR!S/docker-compose.yml start vector-db

# Cleanup decrypted files
rm "${POSTGRES_BACKUP%.gpg}" "${QDRANT_BACKUP%.gpg}"

log "=== Restore Complete ==="
exit 0

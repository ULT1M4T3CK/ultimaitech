# Archive Notes

- `all_local_qa_pairs.json` was removed during cleanup due to size and redundancy.
  - Regenerate via `scripts/archive/extract_all_qa.py` if needed.

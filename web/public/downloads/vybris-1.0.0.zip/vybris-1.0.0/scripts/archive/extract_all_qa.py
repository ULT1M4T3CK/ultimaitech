import requests
import json

BASE_URL = "http://localhost:6335/collections/chatbot_knowledge/points/scroll"

def extract_all_qa():
    all_qa = []
    next_page = None
    
    while True:
        payload = {"limit": 100}
        if next_page:
            payload["offset"] = next_page
            
        r = requests.post(BASE_URL, json=payload)
        r.raise_for_status()
        data = r.json()
        
        points = data.get("result", {}).get("points", [])
        for p in points:
            payload_data = p.get("payload", {})
            # Look for indicators of a Q&A pair
            if "original_question" in payload_data or payload_data.get("type") == "qa":
                all_qa.append(p)
                
        next_page = data.get("result", {}).get("next_page_offset")
        if not next_page:
            break
            
    print(f"Total points searched: ??? (multiple pages)")
    print(f"Total Q&A pairs found: {len(all_qa)}")
    
    with open("scripts/all_local_qa_pairs.json", "w") as f:
        json.dump({"result": {"points": all_qa}}, f, indent=2)

if __name__ == "__main__":
    extract_all_qa()

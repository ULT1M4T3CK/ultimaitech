#!/usr/bin/env python3
"""
Migration script to transfer leads from local database to AWS database.
Generates a SQL file that can be transferred and executed on AWS.

Mapping rules:
- Leads owned by j.bal@outlook.com (user_1d1f5718bd91) -> julian.bal@ultimaitech.com (user_7cb86434df99)
- All other leads -> info@ultimaitech.com (user_a92f4d65583e)
"""

import json
import subprocess
import sys
from datetime import datetime
import uuid

# Configuration
LOCAL_USER = "vybris_admin"
LOCAL_DB = "vybris"
OUTPUT_SQL_FILE = "/tmp/leads_migration.sql"

# User ID mapping
LOCAL_JULIAN_USER_ID = "user_1d1f5718bd91"  # j.bal1997@outlook.com (local)
AWS_JULIAN_USER_ID = "user_7cb86434df99"    # julian.bal@ultimaitech.com
AWS_JULIAN_NAME = "Julian Bal"

AWS_INFO_USER_ID = "user_a92f4d65583e"      # info@ultimaitech.com
AWS_INFO_NAME = "System Administrator"


def run_local_command(cmd):
    """Run a command locally."""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout, result.stderr, result.returncode


def get_local_leads():
    """Fetch all leads from local database."""
    print("Fetching leads from local database...")
    cmd = f'docker compose exec -T postgres psql -U {LOCAL_USER} -d {LOCAL_DB} -t -A -c "SELECT json_agg(t) FROM crm_leads t;"'
    stdout, stderr, code = run_local_command(cmd)
    
    if code != 0:
        print(f"Error fetching local leads: {stderr}")
        sys.exit(1)
    
    try:
        leads = json.loads(stdout.strip())
        print(f"Found {len(leads)} leads in local database")
        return leads
    except json.JSONDecodeError as e:
        print(f"Error parsing leads JSON: {e}")
        print(f"Raw output: {stdout[:500]}")
        sys.exit(1)


def transform_lead(lead):
    """Transform lead with new owner assignment."""
    # Check if the lead was owned by Julian locally
    if lead.get("account_owner_id") == LOCAL_JULIAN_USER_ID:
        lead["account_owner_id"] = AWS_JULIAN_USER_ID
        lead["account_owner_name"] = AWS_JULIAN_NAME
    else:
        # All other leads go to info@ultimaitech.com
        lead["account_owner_id"] = AWS_INFO_USER_ID
        lead["account_owner_name"] = AWS_INFO_NAME
    
    # Also update created_by if it matches
    if lead.get("created_by") == LOCAL_JULIAN_USER_ID:
        lead["created_by"] = AWS_JULIAN_USER_ID
    elif lead.get("created_by"):
        lead["created_by"] = AWS_INFO_USER_ID
    
    # Set company_id to NULL since companies don't exist on AWS
    lead["company_id"] = None
    
    return lead


def escape_sql_string(s):
    """Escape string for SQL."""
    if s is None:
        return "NULL"
    s = str(s)
    s = s.replace("'", "''")
    return f"'{s}'"


def generate_insert_sql(lead, idx):
    """Generate INSERT SQL for a lead."""
    # Generate new ID to avoid conflicts
    new_id = f"lead_mig{idx:03d}_{uuid.uuid4().hex[:8]}"
    
    columns = [
        "id", "name", "email", "phone", "company_id", "company_name",
        "status", "priority", "contact_method", "source_campaign",
        "account_owner_id", "account_owner_name",
        "first_contact_date", "last_contact_date", "next_followup_date",
        "expected_close_date", "closed_date", "estimated_value",
        "industry", "company_size", "pain_points", "products_interested",
        "notes", "created_by", "contacted"
    ]
    
    values = []
    for col in columns:
        val = lead.get(col)
        if col == "id":
            values.append(escape_sql_string(new_id))
        elif col == "company_id":
            # Always NULL - companies don't exist on AWS
            values.append("NULL")
        elif col in ["pain_points", "products_interested"]:
            if isinstance(val, list):
                values.append(escape_sql_string(json.dumps(val)))
            else:
                values.append(escape_sql_string("[]"))
        elif col == "estimated_value":
            values.append(str(val) if val is not None else "NULL")
        elif col == "contacted":
            values.append("TRUE" if val else "FALSE")
        elif col in ["first_contact_date", "last_contact_date", "next_followup_date", 
                     "expected_close_date", "closed_date"]:
            if val:
                values.append(escape_sql_string(val))
            else:
                values.append("NULL")
        else:
            values.append(escape_sql_string(val) if val is not None else "NULL")
    
    sql = f"INSERT INTO crm_leads ({', '.join(columns)}) VALUES ({', '.join(values)});"
    return sql, new_id


def main():
    print("=" * 60)
    print("Lead Migration Script: Local -> AWS")
    print("=" * 60)
    print()
    
    # Get local leads
    local_leads = get_local_leads()
    
    print()
    print("Generating SQL migration file...")
    print("-" * 40)
    
    sql_statements = []
    sql_statements.append("-- Lead Migration SQL")
    sql_statements.append(f"-- Generated: {datetime.now().isoformat()}")
    sql_statements.append("-- Owner mapping:")
    sql_statements.append(f"--   Julian Bal (local) -> julian.bal@ultimaitech.com ({AWS_JULIAN_USER_ID})")
    sql_statements.append(f"--   Others -> info@ultimaitech.com ({AWS_INFO_USER_ID})")
    sql_statements.append("-- Note: company_id set to NULL for all leads (companies not migrated)")
    sql_statements.append("")
    
    for idx, lead in enumerate(local_leads, 1):
        lead_name = lead.get("name", "Unknown")
        lead_email = lead.get("email") or "no-email"
        original_owner = lead.get("account_owner_name", "Unknown")
        
        # Transform lead with new owner
        transformed = transform_lead(lead.copy())
        new_owner = transformed.get("account_owner_name")
        
        print(f"{idx}. {lead_name} ({lead_email})")
        print(f"   Owner: {original_owner} -> {new_owner}")
        
        # Generate SQL
        sql, new_id = generate_insert_sql(transformed, idx)
        sql_statements.append(f"-- Lead {idx}: {lead_name} ({lead_email})")
        sql_statements.append(f"-- Original owner: {original_owner} -> New owner: {new_owner}")
        sql_statements.append(sql)
        sql_statements.append("")
    
    # Write to file
    with open(OUTPUT_SQL_FILE, "w") as f:
        f.write("\n".join(sql_statements))
    
    print()
    print("=" * 60)
    print(f"SQL file generated: {OUTPUT_SQL_FILE}")
    print(f"Total leads to migrate: {len(local_leads)}")
    print()
    print("To complete the migration, run:")
    print("  1. Copy to AWS:")
    print(f"     scp -i /home/andre/Desktop/Documents/vybrs.pem {OUTPUT_SQL_FILE} ec2-user@13.50.100.38:/tmp/")
    print("  2. Execute on AWS:")
    print("     ssh -i /home/andre/Desktop/Documents/vybrs.pem ec2-user@13.50.100.38")
    print("     cd /home/ec2-user/vybris")
    print("     docker-compose exec -T postgres psql -U vybris_admin -d vybris -f /tmp/leads_migration.sql")
    print("=" * 60)


if __name__ == "__main__":
    main()

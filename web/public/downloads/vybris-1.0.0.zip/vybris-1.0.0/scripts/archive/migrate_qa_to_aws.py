import json
import requests
import psycopg2
from psycopg2.extras import RealDictCursor
import sys
import os

# Configuration for internal container execution
AWS_BACKEND_URL = "http://localhost:5000" 
DB_CONFIG = {
    "dbname": "vybris",
    "user": "vybris_admin",
    "password": "5bYykkTGx4jaFtfqtR1OkF3er0lFzIpT",
    "host": "postgres",
    "port": "5432"
}

INITIAL_DATA_FILE = "scripts/local_qa_pairs.json"

def migrate():
    actual_data_file = INITIAL_DATA_FILE
    
    # If running from /app in container, path is scripts/local_qa_pairs.json
    if not os.path.exists(actual_data_file):
        print(f"Checking: {actual_data_file} ... not found")
        # Try local dir just in case
        if os.path.exists("local_qa_pairs.json"):
            actual_data_file = "local_qa_pairs.json"
        elif os.path.exists("scripts/local_qa_pairs.json"):
            actual_data_file = "scripts/local_qa_pairs.json"
        else:
            print(f"Error: Could not find data file in scripts/ or local dir")
            return

    print(f"Using data file: {actual_data_file}")
    with open(actual_data_file, 'r') as f:
        data = json.load(f)

    points = data.get('result', {}).get('points', [])
    print(f"Found {len(points)} Q&A pairs to migrate.")

    # Connect to Postgres
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cursor = conn.cursor()
    except Exception as e:
        print(f"Failed to connect to Postgres: {e}")
        return

    success_count = 0
    
    # Let's get an admin token first
    # Based on main.py, auth.router is included without prefix, so /login
    login_url = f"{AWS_BACKEND_URL}/login"
    # FastAPI OAuth2PasswordRequestForm expects 'username' even for email
    login_data = {"username": "admin@ultimaitech.com", "password": "Dmo48T30b2mrP2ebPojd"}
    try:
        # Use data= for form-encoded request
        r = requests.post(login_url, data=login_data)
        if r.status_code == 404:
            print(f"404 at {login_url}, trying /auth/login...")
            login_url = f"{AWS_BACKEND_URL}/auth/login"
            r = requests.post(login_url, data=login_data)
            
        r.raise_for_status()
        token_data = r.json()
        token = token_data.get('access_token') or token_data.get('token')
        if not token:
            print(f"Login response: {token_data}")
            raise ValueError("No token in response")
            
        headers = {"Authorization": f"Bearer {token}"}
        print("Logged in successfully.")
    except Exception as e:
        print(f"Failed to login to AWS backend: {e}")
        # If login fails, we might be able to skip training and just do DB but training is more important
        return

    for point in points:
        payload = point.get('payload', {})
        chatbot_id = payload.get('chatbot_id')
        question = payload.get('original_question')
        answer = payload.get('text')
        
        if not all([chatbot_id, question, answer]):
            continue

        print(f"Migrating Q&A for {chatbot_id}: {question[:50]}...")

        # 1. Train in Qdrant via Backend API
        try:
            train_url = f"{AWS_BACKEND_URL}/nlp/train/qa"
            train_payload = {
                "chatbot_id": chatbot_id,
                "question": question,
                "answer": answer
            }
            res = requests.post(train_url, json=train_payload, headers=headers)
            res.raise_for_status()
            print(f"  - Trained in Qdrant")
        except Exception as e:
            print(f"  - Failed to train in Qdrant: {e}")
            continue

        # 2. Persist in PostgreSQL knowledge_items
        try:
            # Check if already exists to avoid duplicates if re-run
            cursor.execute("SELECT id FROM knowledge_items WHERE chatbot_id = %s AND source_type = 'qa' AND title = %s", (chatbot_id, question))
            if cursor.fetchone():
                print(f"  - Already exists in Postgres")
            else:
                ki_id = f"ki_mig_{point['id'][:10]}"
                cursor.execute("""
                    INSERT INTO knowledge_items (id, chatbot_id, source_type, title, content, metadata)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """, (ki_id, chatbot_id, 'qa', question, answer, json.dumps({"migrated": True})))
                conn.commit()
                print(f"  - Persisted in Postgres")
            success_count += 1
        except Exception as e:
            conn.rollback()
            print(f"  - Failed to persist in Postgres: {e}")

    conn.close()
    print(f"\nMigration complete! Successfully migrated {success_count} pairs.")

if __name__ == "__main__":
    migrate()

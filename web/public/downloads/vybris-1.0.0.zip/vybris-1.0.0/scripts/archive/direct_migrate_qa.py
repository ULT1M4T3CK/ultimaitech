import json
import os
import sys

# Add /app to sys.path so we can import our services
sys.path.append('/app')

from services.nlp_service import nlp_service
from services.database import KnowledgeDB

DATA_FILE = "scripts/local_qa_pairs.json"

def migrate():
    actual_data_file = DATA_FILE
    if not os.path.exists(actual_data_file):
        if os.path.exists("local_qa_pairs.json"):
            actual_data_file = "local_qa_pairs.json"
        else:
            print(f"Error: {actual_data_file} not found")
            return

    with open(actual_data_file, 'r') as f:
        data = json.load(f)

    points = data.get('result', {}).get('points', [])
    print(f"Found {len(points)} Q&A pairs to migrate.")

    success_count = 0
    for point in points:
        payload = point.get('payload', {})
        chatbot_id = payload.get('chatbot_id')
        question = payload.get('original_question')
        answer = payload.get('text')
        
        if not all([chatbot_id, question, answer]):
            continue

        print(f"Migrating Q&A for {chatbot_id}: {question[:50]}...")

        # 1. Train in Qdrant via Direct Service Call
        try:
            # train_qa(chatbot_id, question, answer)
            nlp_service.train_qa(chatbot_id, question, answer)
            print(f"  - Trained in Qdrant via nlp_service")
        except Exception as e:
            print(f"  - Failed to train in Qdrant: {e}")
            continue

        # 2. Persist in PostgreSQL knowledge_items via Direct DB Call
        try:
            # Check if already exists
            existing = KnowledgeDB.get_by_chatbot(chatbot_id)
            is_dupe = any(item.get('source_type') == 'qa' and item.get('title') == question for item in existing)
            
            if is_dupe:
                print(f"  - Already exists in Postgres")
            else:
                KnowledgeDB.create({
                    "chatbot_id": chatbot_id,
                    "source_type": "qa",
                    "title": question,
                    "content": answer,
                    "metadata": {"migrated": True}
                })
                print(f"  - Persisted in Postgres")
            success_count += 1
        except Exception as e:
            print(f"  - Failed to persist in Postgres: {e}")

    print(f"\nDirect migration complete! Successfully migrated {success_count} pairs.")

if __name__ == "__main__":
    migrate()

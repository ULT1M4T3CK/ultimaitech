#!/usr/bin/env python3
"""
Script to transfer corrected Q&A pairs from one chatbot to another.
"""
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from services.nlp_service import nlp_service

def transfer_qa_pairs(source_bot_id: str, target_bot_id: str):
    """Transfer Q&A pairs from source bot to target bot."""
    print(f"Fetching Q&A pairs from source bot: {source_bot_id}")
    
    # Get Q&A pairs from source bot
    qa_pairs = nlp_service.get_qa_pairs(source_bot_id)
    
    if not qa_pairs:
        print("No Q&A pairs found in source bot.")
        return
    
    print(f"Found {len(qa_pairs)} Q&A pairs to transfer.")
    
    # Transfer each Q&A pair to target bot
    transferred = 0
    for qa in qa_pairs:
        question = qa.get('question', '')
        answer = qa.get('answer', '')
        
        if question and answer:
            print(f"Transferring: Q: {question[:50]}...")
            nlp_service.train_qa(target_bot_id, question, answer)
            transferred += 1
    
    print(f"\nSuccessfully transferred {transferred} Q&A pairs to bot: {target_bot_id}")

if __name__ == "__main__":
    SOURCE_BOT = "bot_c0ce242a3e9f"
    TARGET_BOT = "bot_d315cb9c035da"
    
    print("=" * 60)
    print("Q&A Transfer Script")
    print("=" * 60)
    print(f"Source Bot: {SOURCE_BOT}")
    print(f"Target Bot: {TARGET_BOT}")
    print("=" * 60)
    
    transfer_qa_pairs(SOURCE_BOT, TARGET_BOT)

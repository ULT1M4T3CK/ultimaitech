#!/bin/bash
# PostgreSQL + Qdrant Backup Script for VYBR!S
# SOC 2 Compliance: CC8.6, A1.3
# 
# This script backs up PostgreSQL and Qdrant data with encryption
# and uploads to Google Cloud Storage (or local backup location)

set -e  # Exit on error
set -o pipefail

# Configuration
BACKUP_DIR="/var/backups/vybris"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30
LOG_FILE="/var/log/vybris_backup.log"

# Load environment variables
if [ -f "/home/andre/Desktop/Projects/my-website/VYBR!S/.env" ]; then
    export $(cat /home/andre/Desktop/Projects/my-website/VYBR!S/.env | grep -v '^#' | xargs)
fi

# Logging function
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"

log "=== Starting VYBR!S Backup ==="

# 1. Backup PostgreSQL
log "Backing up PostgreSQL database: $POSTGRES_DB"
POSTGRES_BACKUP="$BACKUP_DIR/postgres_${TIMESTAMP}.sql"

docker exec vybris-postgres-1 pg_dump \
    -U "$POSTGRES_USER" \
    -d "$POSTGRES_DB" \
    --clean \
    --if-exists \
    > "$POSTGRES_BACKUP"

if [ $? -eq 0 ]; then
    log "PostgreSQL backup successful: $(du -h $POSTGRES_BACKUP | cut -f1)"
else
    log "ERROR: PostgreSQL backup failed!"
    exit 1
fi

# 2. Backup Qdrant Vector Database
log "Backing up Qdrant vector database"
QDRANT_BACKUP="$BACKUP_DIR/qdrant_${TIMESTAMP}.tar.gz"

# Stop Qdrant temporarily for consistent backup
docker-compose -f /home/andre/Desktop/Projects/my-website/VYBR!S/docker-compose.yml stop vector-db

# Backup Qdrant data directory
tar -czf "$QDRANT_BACKUP" \
    -C /home/andre/Desktop/Projects/my-website/VYBR!S/data qdrant/

# Restart Qdrant
docker-compose -f /home/andre/Desktop/Projects/my-website/VYBR!S/docker-compose.yml start vector-db

if [ $? -eq 0 ]; then
    log "Qdrant backup successful: $(du -h $QDRANT_BACKUP | cut -f1)"
else
    log "ERROR: Qdrant backup failed!"
    exit 1
fi

# 3. Encrypt backups (GPG encryption for confidentiality)
log "Encrypting backups..."
ENCRYPTION_KEY="${BACKUP_ENCRYPTION_KEY:-backup@ultimaitech.com}"

gpg --batch --yes --recipient "$ENCRYPTION_KEY" \
    --encrypt "$POSTGRES_BACKUP"
gpg --batch --yes --recipient "$ENCRYPTION_KEY" \
    --encrypt "$QDRANT_BACKUP"

if [ $? -eq 0 ]; then
    log "Encryption successful"
    # Remove unencrypted files
    rm "$POSTGRES_BACKUP" "$QDRANT_BACKUP"
else
    log "WARNING: Encryption failed, keeping unencrypted backups"
fi

# 4. Upload to Google Cloud Storage (optional)
if command -v gsutil &> /dev/null && [ ! -z "$GCS_BACKUP_BUCKET" ]; then
    log "Uploading backups to Google Cloud Storage: $GCS_BACKUP_BUCKET"
    
    gsutil cp "${POSTGRES_BACKUP}.gpg" "gs://$GCS_BACKUP_BUCKET/postgres/"
    gsutil cp "${QDRANT_BACKUP}.gpg" "gs://$GCS_BACKUP_BUCKET/qdrant/"
    
    if [ $? -eq 0 ]; then
        log "Cloud upload successful"
    else
        log "WARNING: Cloud upload failed, backups remain local only"
    fi
else
    log "Skipping cloud upload (gsutil not found or GCS_BACKUP_BUCKET not set)"
fi

# 5. Cleanup old backups (retention policy)
log "Cleaning up backups older than $RETENTION_DAYS days"
find "$BACKUP_DIR" -name "*.gpg" -mtime +$RETENTION_DAYS -delete
find "$BACKUP_DIR" -name "*.sql" -mtime +$RETENTION_DAYS -delete
find "$BACKUP_DIR" -name "*.tar.gz" -mtime +$RETENTION_DAYS -delete

# 6. Verify backup integrity
log "Verifying backup integrity..."
LATEST_POSTGRES=$(ls -t "$BACKUP_DIR"/postgres_*.sql.gpg 2>/dev/null | head -1)
LATEST_QDRANT=$(ls -t "$BACKUP_DIR"/qdrant_*.tar.gz.gpg 2>/dev/null | head -1)

if [ -z "$LATEST_POSTGRES" ] || [ -z "$LATEST_QDRANT" ]; then
    log "ERROR: Backup verification failed - files missing!"
    exit 1
fi

# Check file sizes (should not be empty)
POSTGRES_SIZE=$(stat -f%z "$LATEST_POSTGRES" 2>/dev/null || stat -c%s "$LATEST_POSTGRES" 2>/dev/null)
QDRANT_SIZE=$(stat -f%z "$LATEST_QDRANT" 2>/dev/null || stat -c%s "$LATEST_QDRANT" 2>/dev/null)

if [ "$POSTGRES_SIZE" -lt 1000 ] || [ "$QDRANT_SIZE" -lt 1000 ]; then
    log "ERROR: Backup files appear corrupted (too small)"
    exit 1
fi

log "Backup verification successful"
log "=== Backup Complete ==="
log "PostgreSQL: $LATEST_POSTGRES ($POSTGRES_SIZE bytes)"
log "Qdrant: $LATEST_QDRANT ($QDRANT_SIZE bytes)"

exit 0

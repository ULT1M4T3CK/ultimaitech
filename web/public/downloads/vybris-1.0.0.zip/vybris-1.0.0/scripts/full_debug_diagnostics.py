#!/usr/bin/env python3
"""
Full Debug Diagnostics for VYBR!S
Runs health checks, connectivity tests, and verification scripts.
Run from project root. Use backend venv or Docker for full checks.
"""

import sys
import os
import json
import subprocess

# Add backend to path
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(SCRIPT_DIR)
BACKEND_DIR = os.path.join(REPO_ROOT, "backend")
sys.path.insert(0, BACKEND_DIR)
os.chdir(REPO_ROOT)

# Track if heavy imports (psycopg2, etc.) are available
HEAVY_IMPORTS_OK = False

def section(title: str):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print('='*60)

def ok(msg: str): print(f"  [OK]   {msg}")
def fail(msg: str): print(f"  [FAIL] {msg}")
def warn(msg: str): print(f"  [WARN] {msg}")
def info(msg: str): print(f"  [INFO] {msg}")

def run():
    results = {"passed": 0, "failed": 0, "warnings": 0}
    
    # 1. Environment & config
    section("1. Environment & Config")
    if os.path.exists(os.path.join(REPO_ROOT, ".env")):
        ok(".env exists")
        results["passed"] += 1
    else:
        warn(".env not found (may use env vars)")
        results["warnings"] += 1
    
    env_example = os.path.join(REPO_ROOT, ".env.example")
    if os.path.exists(env_example):
        ok(".env.example exists")
        results["passed"] += 1
    
    # 2. Backend imports
    section("2. Backend Imports")
    global HEAVY_IMPORTS_OK
    try:
        from services.database.base import get_db_connection, init_database, check_connection_health
        ok("services.database.base")
        results["passed"] += 1
        HEAVY_IMPORTS_OK = True
    except Exception as e:
        fail(f"services.database.base: {e}")
        results["failed"] += 1
        info("  (Install deps: cd backend && pip install -r requirements.txt)")
        info("  (Or run in Docker: docker-compose up backend)")
    
    if HEAVY_IMPORTS_OK:
        try:
            from routers.feedback import router as feedback_router
            ok("routers.feedback")
            results["passed"] += 1
        except Exception as e:
            fail(f"routers.feedback: {e}")
            results["failed"] += 1
        
        try:
            from routers.nlp.analytics import _update_analytics_background
            ok("routers.nlp.analytics")
            results["passed"] += 1
        except Exception as e:
            fail(f"routers.nlp.analytics: {e}")
            results["failed"] += 1
    
    # 3. Database connection
    section("3. Database Connection")
    if HEAVY_IMPORTS_OK:
        try:
            health = check_connection_health()
            status = health.get("status", "unknown")
            if status == "healthy":
                ok(f"DB pool: {status}")
                results["passed"] += 1
            else:
                warn(f"DB pool: {status}")
                results["warnings"] += 1
            if health.get("errors"):
                for err in health["errors"]:
                    info(f"  {err}")
        except Exception as e:
            fail(f"DB health check: {e}")
            results["failed"] += 1
            info("  (Ensure POSTGRES_* env vars or .env is set)")
        
        # Try actual connection
        try:
            with get_db_connection() as conn:
                cur = conn.cursor()
                cur.execute("SELECT 1")
                cur.fetchone()
            ok("DB connection works")
            results["passed"] += 1
        except Exception as e:
            fail(f"DB connect: {e}")
            results["failed"] += 1
        
        # 4. Required tables
        section("4. Database Tables")
        try:
            with get_db_connection() as conn:
                cur = conn.cursor()
                for table in ["chatbots", "chat_sessions", "chat_messages", "response_feedback"]:
                    try:
                        cur.execute(f"SELECT 1 FROM {table} LIMIT 1")
                        cur.fetchone()
                        ok(f"Table exists: {table}")
                        results["passed"] += 1
                    except Exception as e:
                        fail(f"Table {table}: {e}")
                        results["failed"] += 1
        except Exception as e:
            fail(f"Table check: {e}")
            results["failed"] += 1
    else:
        info("Skipped (backend deps not available)")
    
    # 5. Health endpoint (works even without local deps)
    section("5. Health Endpoint (Backend)")
    for base in ["http://localhost:5000", "http://127.0.0.1:5000", "http://localhost:8080"]:
        try:
            import urllib.request
            req = urllib.request.Request(f"{base}/health", method="GET")
            with urllib.request.urlopen(req, timeout=3) as r:
                data = json.loads(r.read().decode())
                ok(f"Backend at {base}: {data.get('status', 'unknown')}")
                results["passed"] += 1
                for k, v in data.get("checks", {}).items():
                    s = v.get("status", "?")
                    info(f"    {k}: {s}")
                break
        except Exception as e:
            continue
    else:
        warn("Backend not reachable (start with: docker-compose up backend)")
        results["warnings"] += 1
    
    # 6. Verify scripts (run in Docker if backend is up)
    section("6. Verify Scripts")
    verify_history = os.path.join(BACKEND_DIR, "scripts", "verify_history.py")
    backend_up = False
    for base in ["http://localhost:5000", "http://127.0.0.1:5000"]:
        try:
            import urllib.request
            req = urllib.request.Request(f"{base}/health", method="GET")
            with urllib.request.urlopen(req, timeout=2) as r:
                backend_up = r.status == 200
                break
        except Exception:
            pass
    
    if os.path.exists(verify_history) and backend_up:
        # Try Docker exec into backend container (common compose project names)
        for cmd in [
            ["docker", "exec", "vybrs-backend-1", "python", "scripts/verify_history.py"],
            ["docker", "compose", "exec", "-T", "backend", "python", "scripts/verify_history.py"],
            ["docker", "exec", "vybris-backend-1", "python", "scripts/verify_history.py"],
            [sys.executable, verify_history],
        ]:
            try:
                r = subprocess.run(
                    cmd,
                    cwd=BACKEND_DIR if os.path.basename(cmd[0]).startswith("python") and cmd[-1] == verify_history else REPO_ROOT,
                    capture_output=True,
                    text=True,
                    timeout=15,
                )
                if r.returncode == 0:
                    ok("verify_history.py")
                    results["passed"] += 1
                    break
                else:
                    if "docker" in str(cmd):
                        warn(f"verify_history (docker): exit {r.returncode}")
                    else:
                        warn(f"verify_history: exit {r.returncode}")
                    results["warnings"] += 1
                    break
            except (subprocess.TimeoutExpired, FileNotFoundError):
                continue
            except Exception as e:
                continue
        else:
            info("verify_history skipped (Docker container name may differ)")
    elif os.path.exists(verify_history):
        info("verify_history.py exists (run backend first to verify)")
    else:
        info("verify_history.py not found")
    
    # 7. Frontend
    section("7. Frontend")
    frontend_dir = os.path.join(REPO_ROOT, "frontend")
    if os.path.isdir(frontend_dir):
        ok("frontend/ exists")
        results["passed"] += 1
        pkg = os.path.join(frontend_dir, "package.json")
        if os.path.exists(pkg):
            ok("package.json exists")
            results["passed"] += 1
    else:
        fail("frontend/ missing")
        results["failed"] += 1
    
    # 8. Static widget
    section("8. Static Assets")
    widget = os.path.join(BACKEND_DIR, "static", "widget.js")
    if os.path.exists(widget):
        sz = os.path.getsize(widget)
        ok(f"widget.js ({sz:,} bytes)")
        results["passed"] += 1
    else:
        fail("widget.js missing")
        results["failed"] += 1
    
    # Summary
    section("Summary")
    print(f"  Passed:   {results['passed']}")
    print(f"  Failed:   {results['failed']}")
    print(f"  Warnings: {results['warnings']}")
    print()
    
    # Exit 0 if no critical failures (import fails are expected without venv)
    if results["failed"] > 0 and not HEAVY_IMPORTS_OK:
        info("  (Some checks skipped - use backend venv or Docker for full diagnostics)")
    
    return results

if __name__ == "__main__":
    r = run()
    critical = r["failed"] > 0 and HEAVY_IMPORTS_OK
    sys.exit(1 if critical else 0)

#!/usr/bin/env python3
"""
Check and Fix User Status Script
Checks and fixes the account status for info@ultimaitech.com

Run this script to verify and fix the admin account:
    python scripts/check_user_status.py
"""

import os
import sys
import psycopg2
from psycopg2.extras import RealDictCursor

# Database connection settings
DB_HOST = os.getenv("POSTGRES_HOST", "localhost")
DB_PORT = os.getenv("POSTGRES_PORT", "5434")
DB_NAME = os.getenv("POSTGRES_DB", "vybris")
DB_USER = os.getenv("POSTGRES_USER", "user")
DB_PASSWORD = os.getenv("POSTGRES_PASSWORD", "password")

ADMIN_EMAIL = "info@ultimaitech.com"


def main():
    print(f"Connecting to PostgreSQL at {DB_HOST}:{DB_PORT}/{DB_NAME}...")
    
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            cursor_factory=RealDictCursor
        )
        cursor = conn.cursor()
        
        # Find the user
        cursor.execute("""
            SELECT id, email, full_name, role, status, is_super_user, is_blacklisted
            FROM users 
            WHERE email = %s
        """, (ADMIN_EMAIL,))
        user = cursor.fetchone()
        
        if not user:
            print(f"ERROR: User with email '{ADMIN_EMAIL}' not found!")
            sys.exit(1)
        
        print(f"\n📋 User Information:")
        print(f"   ID: {user['id']}")
        print(f"   Email: {user['email']}")
        print(f"   Name: {user.get('full_name', 'N/A')}")
        print(f"   Role: {user.get('role', 'N/A')}")
        print(f"   Status: {user.get('status', 'N/A')}")
        print(f"   Super User: {user.get('is_super_user', False)}")
        print(f"   Blacklisted: {user.get('is_blacklisted', False)}")
        
        # Check for issues
        issues = []
        fixes = []
        
        if user.get('status') != 'active':
            issues.append(f"❌ Status is '{user.get('status')}' but should be 'active'")
            fixes.append("status = 'active'")
        
        if user.get('is_blacklisted'):
            issues.append("❌ User is blacklisted")
            fixes.append("is_blacklisted = FALSE")
        
        if not user.get('is_super_user') and user.get('role') in ['admin', 'super_admin']:
            issues.append("⚠️  User is admin but not marked as super_user")
            fixes.append("is_super_user = TRUE")
        
        if issues:
            print(f"\n⚠️  Issues found:")
            for issue in issues:
                print(f"   {issue}")
            
            if fixes:
                print(f"\n🔧 Applying fixes...")
                update_parts = ", ".join(fixes)
                cursor.execute(f"""
                    UPDATE users 
                    SET {update_parts}
                    WHERE email = %s
                    RETURNING id, email, status, is_super_user, is_blacklisted
                """, (ADMIN_EMAIL,))
                updated = cursor.fetchone()
                conn.commit()
                
                print(f"\n✅ SUCCESS: User account has been fixed!")
                print(f"   Status: {updated['status']}")
                print(f"   Super User: {updated.get('is_super_user', False)}")
                print(f"   Blacklisted: {updated.get('is_blacklisted', False)}")
        else:
            print(f"\n✅ User account is properly configured!")
        
        cursor.close()
        conn.close()
        
    except psycopg2.Error as e:
        print(f"❌ Database error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

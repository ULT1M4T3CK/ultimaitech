#!/usr/bin/env python3
"""
Set Super User Script
Sets is_super_user = true for info@ultimaitech.com

Run this script on the AWS server after deploying the updated backend:
    python scripts/set_super_user.py
"""

import os
import sys
import psycopg2
from psycopg2.extras import RealDictCursor

# Database connection settings
DB_HOST = os.getenv("POSTGRES_HOST", "localhost")
DB_PORT = os.getenv("POSTGRES_PORT", "5434")
DB_NAME = os.getenv("POSTGRES_DB", "vybris")
DB_USER = os.getenv("POSTGRES_USER", "user")
DB_PASSWORD = os.getenv("POSTGRES_PASSWORD", "password")

SUPER_USER_EMAIL = "info@ultimaitech.com"


def main():
    print(f"Connecting to PostgreSQL at {DB_HOST}:{DB_PORT}/{DB_NAME}...")
    
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            cursor_factory=RealDictCursor
        )
        cursor = conn.cursor()
        
        # Check if is_super_user column exists
        cursor.execute("""
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name = 'users' AND column_name = 'is_super_user'
        """)
        if not cursor.fetchone():
            print("Adding is_super_user column...")
            cursor.execute("ALTER TABLE users ADD COLUMN is_super_user BOOLEAN DEFAULT FALSE")
            conn.commit()
            print("Column added.")
        
        # Find the user
        cursor.execute("SELECT id, email, full_name, is_super_user FROM users WHERE email = %s", (SUPER_USER_EMAIL,))
        user = cursor.fetchone()
        
        if not user:
            print(f"ERROR: User with email '{SUPER_USER_EMAIL}' not found!")
            sys.exit(1)
        
        print(f"Found user: {user['full_name']} ({user['email']})")
        print(f"Current is_super_user: {user.get('is_super_user', False)}")
        
        if user.get('is_super_user'):
            print("User is already a super user. No changes needed.")
            return
        
        # Set as super user
        cursor.execute(
            "UPDATE users SET is_super_user = TRUE WHERE email = %s RETURNING id, email, is_super_user",
            (SUPER_USER_EMAIL,)
        )
        updated = cursor.fetchone()
        conn.commit()
        
        print(f"\n✅ SUCCESS: {updated['email']} is now a super user!")
        print("This user will now see a dropdown to switch between all users.")
        
        cursor.close()
        conn.close()
        
    except psycopg2.Error as e:
        print(f"Database error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

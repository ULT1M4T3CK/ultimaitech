#!/bin/bash
set -e
set +H  # Disable history expansion to handle "!" in paths

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PEM_KEY="/home/andre/Desktop/Documents/AWS/vybrs.pem"
REMOTE_USER="ec2-user"
REMOTE_HOST="13.50.101.58"
REMOTE_DIR="~/vybris"
LOCAL_DIR="."

echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║        VYBR!S Quick Deploy (No Build)                      ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"

# Verify PEM key exists
if [ ! -f "$PEM_KEY" ]; then
    echo -e "${RED}✗ ERROR: PEM key not found at $PEM_KEY${NC}"
    exit 1
fi

# Set correct permissions on PEM key
chmod 400 "$PEM_KEY" 2>/dev/null || true

# Verify SSH connection
echo -e "${YELLOW}Verifying SSH connection...${NC}"
if ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 -i "$PEM_KEY" "$REMOTE_USER@$REMOTE_HOST" "echo 'Connection successful'" 2>/dev/null; then
    echo -e "${GREEN}✓ SSH connection verified${NC}"
else
    echo -e "${RED}✗ Cannot connect to $REMOTE_USER@$REMOTE_HOST${NC}"
    exit 1
fi

# 1. Sync files
echo -e "\n${YELLOW}Step 1: Syncing files...${NC}"
rsync -avz --progress --delete -e "ssh -o StrictHostKeyChecking=no -i $PEM_KEY" \
    --exclude '.git' \
    --exclude '.venv' \
    --exclude '__pycache__' \
    --exclude 'node_modules' \
    --exclude 'data' \
    --exclude 'dist' \
    --exclude '.env' \
    --exclude '*.pem' \
    --exclude '.DS_Store' \
    --exclude '*.log' \
    --exclude 'backend/venv' \
    "$LOCAL_DIR/" "$REMOTE_USER@$REMOTE_HOST:$REMOTE_DIR/"

echo -e "${GREEN}✓ Files synced successfully${NC}"

# 2. Restart containers (no build)
echo -e "\n${YELLOW}Step 2: Restarting containers (using existing images)...${NC}"
ssh -o StrictHostKeyChecking=no -i "$PEM_KEY" "$REMOTE_USER@$REMOTE_HOST" << 'ENDSSH'
    set -e
    cd ~/vybris
    
    if [ ! -f "docker-compose.yml" ]; then
        echo "ERROR: docker-compose.yml not found"
        exit 1
    fi
    
    # Use docker-compose if available, otherwise docker compose
    if command -v docker-compose &> /dev/null; then
        DOCKER_COMPOSE_CMD="docker-compose"
    else
        DOCKER_COMPOSE_CMD="docker compose"
    fi
    
    echo "Restarting containers..."
    $DOCKER_COMPOSE_CMD restart backend frontend || {
        echo "Restart failed, trying down/up..."
        $DOCKER_COMPOSE_CMD down
        $DOCKER_COMPOSE_CMD up -d
    }
    
    echo "Waiting for services to start..."
    sleep 10
    
    echo ""
    echo "Container Status:"
    $DOCKER_COMPOSE_CMD ps
    
    echo ""
    echo "✅ Quick deployment complete!"
ENDSSH

echo -e "\n${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║              Quick Deployment Complete!                     ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"

echo ""
echo "Note: This deployment skipped Docker builds for speed."
echo "If you need to rebuild images, use: bash scripts/deploy_local_to_aws.sh"
echo ""

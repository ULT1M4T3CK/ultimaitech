#!/bin/bash
# Start Elias (OpenClaw) AI agent on AWS — run this on the EC2 instance (e.g. ssh then: cd ~/vybris && ./scripts/start_elias_aws.sh).
# Requires: Docker, docker compose; repo at ~/vybris (or /opt/vybris) with ./Elias and deploy/elias/.env configured.

set -e
cd ~/vybris

# Optional: free disk space before building (Elias image is large)
echo "Disk space before:"
df -h /
docker system prune -f || true
echo "Disk space after prune:"
df -h /

# Ensure deploy/elias has .env and agent config
ELIAS_DEPLOY_DIR=deploy/elias
if [ ! -f "$ELIAS_DEPLOY_DIR/.env" ]; then
  echo "ERROR: Create $ELIAS_DEPLOY_DIR/.env from .env.example and set OPENCLAW_GATEWAY_TOKEN, PERPLEXITY_API_KEY, ELIAS_HOOK_TOKEN"
  exit 1
fi
mkdir -p "$ELIAS_DEPLOY_DIR/data/elias/.openclaw" "$ELIAS_DEPLOY_DIR/data/elias/workspace" "$ELIAS_DEPLOY_DIR/data/elias/logs"
[ -f "$ELIAS_DEPLOY_DIR/elias.json" ] && cp "$ELIAS_DEPLOY_DIR/elias.json" "$ELIAS_DEPLOY_DIR/data/elias/.openclaw/openclaw.json" 2>/dev/null || true

# Build and run from repo root so context ./Elias is correct
export ELIAS_REPO_PATH=./Elias
docker compose -f "$ELIAS_DEPLOY_DIR/docker-compose.yml" --project-directory . build openclaw-gateway
docker compose -f "$ELIAS_DEPLOY_DIR/docker-compose.yml" --project-directory . up -d openclaw-gateway

echo "Elias gateway starting. Check: docker compose -f $ELIAS_DEPLOY_DIR/docker-compose.yml --project-directory . ps"
echo "Webhook: http://127.0.0.1:18789/hooks/elias (use NGINX to proxy from /hooks/elias)"
